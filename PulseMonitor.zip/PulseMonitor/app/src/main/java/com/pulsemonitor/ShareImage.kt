package com.pulsemonitor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.LinearGradient
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import kotlin.math.ceil
import kotlin.math.max

/** Menggambar laporan rekaman menjadi satu gambar PNG (lebar 1080 px) untuk dibagikan. Tidak bergantung pada layar yang sedang tampil. */
object ShareImage {
    private const val W = 1080
    private const val PAD = 48f
    private val BG = Color.parseColor("#101014")
    private val CARD = Color.parseColor("#1D1E24")
    private val MUTED_DEF = Color.parseColor("#8E8E99")
    private var MUTED = MUTED_DEF
    private var cardColor = CARD
    private val SUB = Color.parseColor("#C4C6CE")
    private val GRID = Color.parseColor("#34363F")
    private val BLUE = Color.parseColor("#4C8DFF")
    private val GREEN = Color.parseColor("#4CC38A")
    private val AMBER = Color.parseColor("#F5B83D")
    private val PINK = Color.parseColor("#E5677A")
    private val ORANGE = Color.parseColor("#B07CFF")
    private val GRAY = Color.parseColor("#C9CDD4")
    private val CYAN = Color.parseColor("#5BC8F5")

    private class Line(val name: String, val color: Int, val v: List<Float>)

    private fun paint(color: Int, size: Float = 0f, bold: Boolean = false, align: Paint.Align = Paint.Align.LEFT) =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color; if (size > 0f) textSize = size; textAlign = align
            typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }

    /** part 0 = header + kartu statistik halaman 1 + semua grafik (atau hanya maxCharts grafik pertama); part 1 = header + kartu statistik halaman 2.
     *  Dikirim sebagai dua gambar sekaligus, jadi di chat bisa digeser kiri-kanan seperti halaman di aplikasi. */
    fun render(ctx: Context, s: Session, part: Int = 0, maxCharts: Int = Int.MAX_VALUE): Bitmap {
        // Bila ada wallpaper aplikasi: dipakai sebagai latar gambar (sama seperti layar laporan), kartu jadi kaca transparan, teks sekunder putih
        val wall = WallpaperStore.load(ctx)
        cardColor = if (wall != null) 0x4D1E1F26 else CARD
        MUTED = if (wall != null) Color.WHITE else MUTED_DEF
        try {
            val h = layout(null, ctx, s, part, maxCharts)
            val bmp = Bitmap.createBitmap(W, h, Bitmap.Config.ARGB_8888)
            val cv = Canvas(bmp)
            if (wall != null) drawWallpaper(cv, wall, h, WallpaperStore.dim(ctx))
            layout(cv, ctx, s, part, maxCharts)
            return bmp
        } finally {
            wall?.recycle()
            cardColor = CARD; MUTED = MUTED_DEF
        }
    }

    /** Wallpaper selebar gambar, diulang ke bawah untuk gambar yang tinggi; ubin genap dibalik supaya sambungannya tidak terlihat.
     *  Lapisan gelap sama dengan layar laporan (gradien atas ke bawah mengikuti slider redup). */
    private fun drawWallpaper(c: Canvas, b: Bitmap, h: Int, dim: Float) {
        val th = W.toFloat() * b.height / b.width
        val src = Rect(0, 0, b.width, b.height)
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        val dark = 0x0C0C0E
        val top = ((dim * 0.12f * 255f).toInt().coerceIn(0, 255) shl 24) or dark
        val bot = ((dim * 0.8f * 255f).toInt().coerceIn(0, 255) shl 24) or dark
        var y = 0f; var k = 0
        while (y < h) {
            c.save()
            c.clipRect(0f, y, W.toFloat(), y + th)
            if (k % 2 == 1) c.scale(1f, -1f, 0f, y + th / 2f)
            c.drawBitmap(b, src, RectF(0f, y, W.toFloat(), y + th), p)
            val g = Paint().apply { shader = LinearGradient(0f, y, 0f, y + th, top, bot, Shader.TileMode.CLAMP) }
            c.drawRect(0f, y, W.toFloat(), y + th, g)
            c.restore()
            y += th; k++
        }
    }

    private fun fit(text: String, p: Paint, width: Float): String =
        TextUtils.ellipsize(text, TextPaint(p), width, TextUtils.TruncateAt.END).toString()

    private class Chart(val title: String, val lines: List<Line>, val fromZero: Boolean, val endLabels: Boolean = false, val secs: List<Line> = emptyList())

    private const val GAP = 20f

    /** Satu fungsi untuk dua tahap: c == null hanya mengukur tinggi total, c != null menggambar. Tata letak mengikuti layar laporan. */
    private fun layout(c: Canvas?, ctx: Context, s: Session, part: Int, maxCharts: Int): Int {
        val st = s.stats()
        if (c != null && cardColor == CARD) c.drawColor(BG)
        var y = PAD
        val cardP = paint(cardColor)

        // ---- Header: ikon di kiri; di kanan nama game (maks. 2 baris) dan di bawahnya "tanggal · durasi · resolusi" ----
        val icon = appIcon(ctx, s.pkg)
        val isz = 140f
        val tx = PAD + isz + 46f; val avail = W - PAD - tx
        val tp = TextPaint(paint(Color.WHITE, 60f, true))
        val sl = StaticLayout.Builder.obtain(s.label, 0, s.label.length, tp, avail.toInt())
            .setMaxLines(2).setEllipsize(TextUtils.TruncateAt.END).setLineSpacing(0f, 0.92f).build()
        val sub = fit("${fmtDate(s.id)} · ${fmtDur(s.dur)}" + (if (s.res.isNotBlank()) " · ${s.res}" else ""), paint(SUB, 35f), avail)
        val blockH = sl.height + 10f + 40f
        val hh = max(isz, blockH)
        if (c != null) {
            val iy = y + (hh - isz) / 2f
            val r = RectF(PAD, iy, PAD + isz, iy + isz)
            if (icon != null) {
                val clip = Path().apply { addRoundRect(r, 32f, 32f, Path.Direction.CW) }
                c.save(); c.clipPath(clip); c.drawBitmap(icon, null, r, Paint(Paint.FILTER_BITMAP_FLAG)); c.restore()
            } else c.drawRoundRect(r, 32f, 32f, cardP)
            val by = y + (hh - blockH) / 2f
            c.save(); c.translate(tx, by); sl.draw(c); c.restore()
            c.drawText(sub, tx, by + sl.height + 10f + 31f, paint(SUB, 35f))
        }
        y += hh + 38f

        // ---- Catatan (bila diisi) ----
        if (s.desc.isNotBlank()) {
            val dp = TextPaint(paint(Color.WHITE, 39f))
            val dl = StaticLayout.Builder.obtain(s.desc, 0, s.desc.length, dp, (W - 2 * PAD - 88f).toInt()).build()
            val nh = dl.height + 70f
            if (c != null) {
                c.drawRoundRect(RectF(PAD, y, W - PAD, y + nh), 40f, 40f, cardP)
                c.save(); c.translate(PAD + 44f, y + 35f); dl.draw(c); c.restore()
            }
            y += nh + 33f
        }

        // ---- Statistik, sama dengan layar laporan: kotak atas (3 kolom besar) + kotak bawah (daftar 2 kolom) + titik halaman ----
        val rp = reportPages(s, st)[part]
        val topH = 225f; val listH = 361f
        if (c != null) {
            c.drawRoundRect(RectF(PAD, y, W - PAD, y + topH), 40f, 40f, cardP)
            val colW = (W - 2 * PAD - 64f) / 3f
            rp.top.forEachIndexed { k, (lb, v, un) ->
                val cx = PAD + 32f + colW * k + colW / 2f
                c.drawText(lb.uppercase(), cx, y + 66f, paint(SUB, 26f, align = Paint.Align.CENTER))
                c.drawText(v, cx, y + 137f, paint(Color.WHITE, 54f, true, Paint.Align.CENTER))
                c.drawText(un, cx, y + 179f, paint(MUTED, 26f, align = Paint.Align.CENTER))
            }
        }
        y += topH + 29f
        if (c != null) {
            c.drawRoundRect(RectF(PAD, y, W - PAD, y + listH), 40f, 40f, cardP)
            val rows = rp.rows.chunked(2)
            val colW2 = (W - 2 * PAD - 88f - 61f) / 2f
            rows.forEachIndexed { ri, row ->
                row.forEachIndexed { ci, (lb, v, un) ->
                    val x0 = PAD + 44f + ci * (colW2 + 61f)
                    val base = y + 15f + ri * 110f + 69f
                    val extra = if (un.isNotBlank() && un != "%") " $un" else ""
                    val vt = (if (un == "%" && v != "-") "$v%" else v)
                    val xr = x0 + colW2
                    val ew = if (extra.isEmpty()) 0f else paint(MUTED, 30f).measureText(extra)
                    c.drawText(lb, x0, base, paint(SUB, 39f))
                    if (extra.isNotEmpty()) c.drawText(extra, xr, base, paint(MUTED, 30f, align = Paint.Align.RIGHT))
                    c.drawText(vt, xr - ew, base, paint(Color.WHITE, 42f, true, Paint.Align.RIGHT))
                    if (ri < rows.size - 1) c.drawLine(x0, y + 15f + (ri + 1) * 110f, xr, y + 15f + (ri + 1) * 110f, paint(0x22FFFFFF).apply { strokeWidth = 2f })
                }
            }
            // Titik halaman: yang aktif memanjang dan putih
            val dy = y + listH + 30f
            val dim = paint(0x55FFFFFF); val on = paint(Color.WHITE)
            if (part == 0) {
                c.drawRoundRect(RectF(W / 2f - 28f, dy - 7f, W / 2f + 12f, dy + 7f), 7f, 7f, on)
                c.drawCircle(W / 2f + 30f, dy, 7f, dim)
            } else {
                c.drawCircle(W / 2f - 30f, dy, 7f, dim)
                c.drawRoundRect(RectF(W / 2f - 12f, dy - 7f, W / 2f + 28f, dy + 7f), 7f, 7f, on)
            }
        }
        y += listH + 58f

        if (part == 1) { y += PAD - GAP; return ceil(y).toInt() }

        // ---- Grafik (urutan sama dengan layar laporan; angka di ujung kanan hanya untuk grafik yang garisnya stabil) ----
        val ch = 690f
        val clColors = listOf(BLUE, GREEN, AMBER, ORANGE)
        val charts = ArrayList<Chart>()
        // FPS, Frametime, dan Temperatur digabung dalam satu grafik (satu sumbu, angka di ujung kanan); Suhu CPU/GPU tepat di bawahnya
        val fpsView = smoothSeries(s.fps, maxOf(1, s.fps.size / 50))
        charts.add(Chart("FPS", listOf(Line("FPS", GRAY, fpsView), Line("Frametime", GREEN, frametimeMs(fpsView)), Line("Temperatur", AMBER, s.temp)), true, true))
        charts.add(Chart("Suhu (°C)", listOf(Line("CPU", AMBER, s.tCpu), Line("GPU", ORANGE, s.tGpu)), false, true))
        if (s.clusters.isNotEmpty()) charts.add(Chart("Beban CPU (%)",
            s.clusters.mapIndexed { i, c -> Line("Cluster $c", clColors[i % 4], s.clCpu.getOrElse(i) { emptyList() }) } + Line("Total", PINK, s.cpu), true))
        if (s.clFreq.isNotEmpty()) charts.add(Chart("Frekuensi CPU (MHz)",
            s.clusters.mapIndexed { i, c -> Line("Cluster $c", clColors[i % 4], s.clFreq.getOrElse(i) { emptyList() }) }, true))
        charts.add(Chart("Frekuensi GPU (MHz)", listOf(Line("Frekuensi", BLUE, s.gpuMhz)), true, true))
        charts.add(Chart("GPU", listOf(Line("Beban", GREEN, s.gpu), Line("Suhu", AMBER, s.tGpu)), true))
        charts.add(Chart("Daya (W)", listOf(Line("Daya (Watt)", BLUE, s.watt)), true))
        charts.add(Chart("Baterai", listOf(Line("Suhu", GREEN, s.tBat), Line("Level", AMBER, s.batLvl)), true, true))
        var drawn = 0
        for (chart in charts) {
            if (drawn >= maxCharts) break   // mode ringkas (Simpan): hanya beberapa grafik pertama (FPS + Suhu)
            val lines = chart.lines.filter { l -> l.v.any { it >= 0f } }   // seri tanpa data tidak digambar; grafik tanpa data dilewati
            if (lines.isEmpty()) continue
            if (c != null) drawChart(c, y, ch, chart.title, s.t, lines, chart.fromZero, chart.endLabels)
            y += ch + GAP
            drawn++
        }

        // ---- Penutup (hanya pada gambar penuh; mode ringkas berakhir tepat setelah grafik terakhir) ----
        if (maxCharts == Int.MAX_VALUE) {
            c?.drawText("Pulse Monitor", W / 2f, y + 36f, paint(MUTED, 30f, align = Paint.Align.CENTER))
            y += 36f + PAD
        }
        return ceil(y).toInt()
    }

    private fun drawChart(c: Canvas, top: Float, h: Float, title: String, t: List<Float>, lines: List<Line>, fromZero: Boolean, endLabels: Boolean) {
        c.drawRoundRect(RectF(PAD, top, W - PAD, top + h), 40f, 40f, paint(cardColor))
        c.drawText(title, PAD + 32f, top + 66f, paint(Color.WHITE, 40f).apply { typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) })
        val pl = PAD + 90f; val pr = W - PAD - 84f
        val pt = top + 141f; val pb = top + h - 150f
        // legenda di bawah grafik, di bawah label waktu, sejajar tepi kiri area grafik
        var lx = pl
        for (l in lines) {
            c.drawCircle(lx + 10f, top + h - 74f, 10f, paint(l.color))
            c.drawText(l.name, lx + 32f, top + h - 64f, paint(SUB, 30f))
            lx += 32f + paint(SUB, 30f).measureText(l.name) + 36f
        }
        // skala Y: 6 petak sama besar (sama dengan layar laporan)
        val vals = lines.flatMap { it.v }.filter { it >= 0f }
        val ax = if (vals.isEmpty()) AxisY(0f, 6f) else axisY(vals.min(), vals.max(), fromZero)
        val lo = ax.lo; val hi = ax.hi
        val tmax = max(t.lastOrNull() ?: 1f, 1f)
        val grid = paint(0x66FFFFFF).apply { strokeWidth = 3f; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; pathEffect = DashPathEffect(floatArrayOf(0.1f, 12f), 0f) }
        val yl = paint(MUTED, 28f, align = Paint.Align.RIGHT)
        for (i in 0..ax.rows) {
            val yy = pb - (pb - pt) * i / ax.rows
            c.drawLine(pl, yy, pr, yy, grid)
            c.drawText(ax.fmt(lo + ax.step * i), pl - 12f, yy + 10f, yl)
        }
        // skala X: 5 petak sama lebar, 0s ... akhir rekaman (mis. 0s, 14s, 28s, 42s, 56s, 1m10s)
        val xl = paint(MUTED, 28f, align = Paint.Align.CENTER)
        for (k in 0..5) {
            val xx = pl + (pr - pl) * k / 5f
            c.drawLine(xx, pt, xx, pb, grid)
            c.drawText(fmtAxisTime(tmax * k / 5f, tmax), xx, pb + 50f, xl)
        }
        // garis data (nilai < 0 = tidak terbaca, garis putus di situ)
        for (l in lines) {
            // Seri kembar (mis. CPU = GPU) digeser sedikit supaya dua garisnya sama-sama terlihat
            val group = lines.filter { o -> o === l || sameSeries(o.v, l.v) }
            val off = if (group.size > 1) (group.indexOf(l) - (group.size - 1) / 2f) * 6f else 0f
            val path = Path(); var pen = false
            val n = minOf(l.v.size, t.size)
            for (i in 0 until n) {
                val v = l.v[i]
                if (v < 0f) { pen = false; continue }
                val xx = pl + (pr - pl) * t[i] / tmax
                val yy = pb - (pb - pt) * ((v - lo) / (hi - lo)).coerceIn(0f, 1f) + off
                if (!pen) { path.moveTo(xx, yy); pen = true } else path.lineTo(xx, yy)
            }
            c.drawPath(path, paint(l.color).apply { style = Paint.Style.STROKE; strokeWidth = 4.5f; strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND })
        }
        // nilai terakhir tiap garis di kanan area grafik (hanya bila diminta); yang berdekatan direnggangkan
        if (endLabels) {
            val ends = lines.mapNotNull { l ->
                l.v.lastOrNull { it >= 0f }?.let { v -> Triple(pb - (pb - pt) * ((v - lo) / (hi - lo)).coerceIn(0f, 1f), ax.fmt(v), l.color) }
            }.sortedBy { it.first }
            val ys = ends.map { it.first }.toMutableList()
            for (i in 1 until ys.size) if (ys[i] - ys[i - 1] < 36f) ys[i] = ys[i - 1] + 36f
            ends.forEachIndexed { i, e -> c.drawText(e.second, pr + 14f, ys[i] + 11f, paint(e.third, 32f)) }
        }
    }

    private fun sameSeries(a: List<Float>, b: List<Float>): Boolean {
        val m = minOf(a.size, b.size)
        if (m == 0) return false
        for (i in 0 until m) {
            val x = a[i]; val y = b[i]
            if ((x < 0f) != (y < 0f)) return false
            if (x >= 0f && kotlin.math.abs(x - y) > 0.5f) return false
        }
        return true
    }
}
