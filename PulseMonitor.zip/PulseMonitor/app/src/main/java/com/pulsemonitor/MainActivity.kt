@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.pulsemonitor

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.graphics.Bitmap
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.compose.ui.text.style.TextOverflow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.os.SystemClock
import android.view.View
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import androidx.core.animation.doOnEnd
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.ui.input.pointer.pointerInput
import rikka.shizuku.Shizuku

// Teks sekunder juga putih supaya terbaca di atas wallpaper
private val Grey = Color.White
private val Bg = Color(0xFF0C0C0E)
// Panel besar di bawah (gaya WuWa Config); transparansinya diatur di tab Settings
private val Glass: Color get() = Color(0xFF101116).copy(alpha = AppSettings.panelAlpha / 100f)
// Kotak dalam: kaca gelap setengah tembus yang tetap (tidak ikut slider), gaya BakaSU. Wallpaper samar terlihat, teks tetap terbaca
private val Inner: Color get() = Color(0xFF1E1F26).copy(alpha = 0.30f)
// Warna tiap tab navigasi: Beranda biru, Statistik ungu, Baterai hijau, Settings kuning (Rekam FPS sekarang ada di Beranda)
private val NavColors = listOf(Color(0xFF6FA8FF), Color(0xFFA78BFA), Color(0xFF5BD68E), Color(0xFFE8B84A))
// Latar ikon: warna aksen 16% di atas dasar gelap, tapi pekat (tidak tembus wallpaper)
private fun chipBg(c: Color, a: Float = 0.16f, base: Color = Color(0xFF1E1F26)) =
    Color(base.red + (c.red - base.red) * a, base.green + (c.green - base.green) * a, base.blue + (c.blue - base.blue) * a)
private val RecPink = Color(0xFFF08FB8)
private val Pink = Color(0xFFD58FC4)
private val Blue = Color(0xFF6FA8FF)
private fun acc() = Color(AppSettings.accent)

class MainActivity : ComponentActivity() {
    // Android 13+: tanpa izin ini notifikasi foreground service tidak muncul
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private var wallpaperBmp by mutableStateOf<Bitmap?>(null)
    private var dim by mutableFloatStateOf(0.6f)
    private var cropSrc by mutableStateOf<Bitmap?>(null)        // gambar yang sedang dipotong
    private var overlayOn by mutableStateOf(OverlayService.overlayShown.value)
    private var reportId by mutableStateOf<Long?>(null)
    private var healthOpen by mutableStateOf(false)                // layar Kesehatan & log
    private var batPage by mutableStateOf<Long?>(null)          // null = tertutup, 0 = daftar riwayat baterai, >0 = detail sesi (id)
    private var accessDlg by mutableStateOf(false)
    private var styleDlg by mutableStateOf(false)
    private var refreshTick by mutableIntStateOf(0)           // naik tiap tarik-untuk-refresh; dipakai sebagai kunci pembacaan ulang data
    private var refreshing by mutableStateOf(false)

    /** Tarik ke bawah di tab mana pun: baca ulang akses, daftar rekaman, wallpaper, dan info perangkat. */
    private fun doRefresh() {
        if (refreshing) return
        refreshing = true
        Thread {
            runCatching { Access.refresh() }
            runCatching {
                val w = WallpaperStore.load(this); val d = WallpaperStore.dim(this)
                runOnUiThread { wallpaperBmp = w; dim = d }
            }
            Recorder.version.value = Recorder.version.value + 1
            runOnUiThread { refreshTick++ }
            Thread.sleep(700)   // beri waktu spinner terlihat
            runOnUiThread { refreshing = false }
        }.start()
    }

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, r -> Access.onPermissionResult(r == PackageManager.PERMISSION_GRANTED) }
    private val binderListener = Shizuku.OnBinderReceivedListener { Access.refresh() }
    private val deadListener = Shizuku.OnBinderDeadListener { Access.refresh() }

    // Photo Picker: tanpa izin galeri. Di Android 10-12 otomatis jatuh ke pemilih dokumen.
    private val pickImage = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) Thread {
            val bmp = WallpaperStore.decodePreview(this, uri)
            if (bmp != null) cropSrc = bmp
        }.start()
    }

    override fun onCreate(b: Bundle?) {
        // Layar splash: logo P di tengah latar gelap, ditahan sebentar lalu logo membesar sambil memudar
        val splash = installSplashScreen()
        val t0 = SystemClock.uptimeMillis()
        splash.setKeepOnScreenCondition { SystemClock.uptimeMillis() - t0 < 600 }
        splash.setOnExitAnimationListener { provider ->
            // Di sebagian HP (HyperOS/MIUI) tampilan splash dari sistem tidak punya iconView -> null; jangan sampai crash
            val icon: View? = runCatching { provider.iconView }.getOrNull()
            val root = provider.view
            runCatching {
                val bgOut = ObjectAnimator.ofFloat(root, View.ALPHA, 1f, 0f).apply {
                    duration = 280; interpolator = DecelerateInterpolator()
                }
                val seq = AnimatorSet()
                if (icon != null) {
                    val logoOut = AnimatorSet().apply {
                        playTogether(
                            ObjectAnimator.ofFloat(icon, View.SCALE_X, 1f, 1.25f),
                            ObjectAnimator.ofFloat(icon, View.SCALE_Y, 1f, 1.25f),
                            ObjectAnimator.ofFloat(icon, View.ALPHA, 1f, 0f)
                        )
                        duration = 260; interpolator = AccelerateInterpolator()
                    }
                    seq.playSequentially(logoOut, bgOut)
                } else {
                    // Tanpa iconView: seluruh layar splash membesar tipis sambil memudar
                    val zoom = AnimatorSet().apply {
                        playTogether(
                            ObjectAnimator.ofFloat(root, View.SCALE_X, 1f, 1.04f),
                            ObjectAnimator.ofFloat(root, View.SCALE_Y, 1f, 1.04f)
                        )
                        duration = 280; interpolator = DecelerateInterpolator()
                    }
                    seq.playTogether(zoom, bgOut)
                }
                seq.doOnEnd { runCatching { provider.remove() } }
                seq.start()
            }.onFailure { runCatching { provider.remove() } }
        }
        super.onCreate(b)
        // Edge-to-edge penuh: bilah status/navigasi transparan, tanpa scrim kontras, dan konten boleh sampai ke area poni/lubang kamera
        enableEdgeToEdge(
            statusBarStyle = androidx.activity.SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = androidx.activity.SystemBarStyle.dark(android.graphics.Color.TRANSPARENT))
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        if (Build.VERSION.SDK_INT >= 28) window.attributes = window.attributes.apply {
            layoutInDisplayCutoutMode = android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        AppSettings.load(this); Sampler.init(this)
        Shizuku.addRequestPermissionResultListener(permListener)
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        wallpaperBmp = WallpaperStore.load(this); dim = WallpaperStore.dim(this)
        WallpaperStore.purgeNotifLeftovers(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        showLastCrash()
        setContent {
            val s by Sampler.state.collectAsState()
            // Status tombol mengikuti keadaan layanan yang sebenarnya (tetap benar setelah aplikasi dibuka ulang)
            val shown by OverlayService.overlayShown.collectAsState()
            LaunchedEffect(shown) { overlayOn = shown }
            var tab by remember { mutableIntStateOf(0) }
            BackHandler(enabled = tab != 0) { tab = 0 }
            val rid = reportId
            BackHandler(enabled = rid != null) { reportId = null }
            val bp = batPage
            BackHandler(enabled = bp != null) { batPage = if (bp != null && bp > 0L) 0L else null }
            BackHandler(enabled = healthOpen) { healthOpen = false }
            if (healthOpen) HealthScreen(onBack = { healthOpen = false })
            else if (bp != null) {
                if (bp == 0L) BatteryListScreen(onBack = { batPage = null }, onOpen = { batPage = it }, wallpaper = wallpaperBmp, dim = dim)
                else BatteryDetailScreen(bp, onBack = { batPage = 0L }, onDeleted = { batPage = 0L }, wallpaper = wallpaperBmp, dim = dim)
            } else
            AnimatedContent(targetState = rid, label = "page", transitionSpec = {
                if (targetState != null)   // buka laporan: masuk dari kanan, halaman lama bergeser sedikit
                    (slideInHorizontally(tween(320)) { it } + fadeIn(tween(320))) togetherWith
                        (slideOutHorizontally(tween(320)) { -it / 4 } + fadeOut(tween(220)))
                else                       // kembali: laporan keluar ke kanan
                    (slideInHorizontally(tween(320)) { -it / 4 } + fadeIn(tween(320))) togetherWith
                        (slideOutHorizontally(tween(320)) { it } + fadeOut(tween(220)))
            }) { id -> if (id != null) ReportScreen(id) else Screen(s, tab) { tab = it } }
        }
    }

    /** Bila sesi sebelumnya berhenti karena crash, tampilkan jejaknya supaya bisa disalin dan dikirim. */
    private fun showLastCrash() {
        val trace = CrashLog.take(this) ?: return
        runCatching {
            android.app.AlertDialog.Builder(this)
                .setTitle("Pulse Monitor berhenti tiba-tiba")
                .setMessage(trace.take(3000))
                .setPositiveButton("Salin") { _, _ ->
                    getSystemService(android.content.ClipboardManager::class.java)
                        .setPrimaryClip(android.content.ClipData.newPlainText("crash", trace))
                    Toast.makeText(this, "Disalin", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Tutup", null).show()
        }
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        super.onDestroy()
    }

    @Volatile private var batLoop = false

    /** Riwayat baterai terekam selama aplikasi terbuka, tanpa perlu overlay atau notifikasi. Sesi yang sama dilanjutkan oleh layanan bila aktif. */
    private fun startBatteryRecording() {
        if (batLoop) return
        batLoop = true
        AppLog.i("Baterai", "perekaman dimulai (aplikasi terbuka)")
        Thread {
            runCatching { BatteryStats.init(applicationContext) }
            while (batLoop) {
                runCatching { BatteryStats.tick() }
                try { Thread.sleep(10_000L) } catch (e: InterruptedException) { break }
            }
        }.apply { name = "bat-record"; isDaemon = true }.start()
    }

    override fun onStart() {
        super.onStart()
        startBatteryRecording()
        Access.refresh()
        OverlayService.ensureRunning(this)   // mode latar belakang aktif tapi layanan sempat mati -> notifikasi dimunculkan lagi
        Sampler.uiVisible = true; Sampler.start()
    }

    override fun onStop() {
        super.onStop()
        if (batLoop) AppLog.i("Baterai", "perekaman berhenti (aplikasi tertutup)")
        batLoop = false
        // Aplikasi tidak terlihat: hentikan pembacaan sensor bila tidak ada overlay/rekaman yang memakainya
        Sampler.uiVisible = false
        if (!OverlayService.overlayShown.value && !Recorder.active.value) Sampler.stop()
    }

    private fun toggleOverlay() {
        val turnOn = !OverlayService.overlayShown.value
        if (turnOn && !Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val i = Intent(this, OverlayService::class.java)
        try {
            when {
                turnOn -> { playOverlaySound(); startForegroundService(i) }
                // Mode latar belakang: overlay disembunyikan, layanan (notifikasi) tetap hidup
                AppSettings.bgMode -> startForegroundService(i.setAction(OverlayService.ACTION_HIDE))
                else -> stopService(i)
            }
        } catch (e: Throwable) {
            android.util.Log.e("PulseMonitor", "Gagal memulai layanan overlay", e)
            Toast.makeText(this, "Overlay gagal: ${e.javaClass.simpleName}: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    /** Saklar "Tetap aktif di latar belakang": nyala = layanan hidup tanpa overlay; mati = layanan berhenti bila overlay juga mati. */
    private fun applyBgMode(on: Boolean) {
        AppLog.i("Layanan", "saklar Tetap aktif di latar belakang (Settings): ${if (on) "nyala" else "mati"}")
        val i = Intent(this, OverlayService::class.java)
        try {
            // Nyala: selalu kirim RESTORE, tidak bergantung pada flag "alive". Flag itu bisa basi (layanan baru saja dihentikan dan belum
            // sempat onDestroy, atau notifikasinya sudah disingkirkan sistem/pengguna), sehingga notifikasi tidak muncul sampai saklar
            // dimatikan lalu dinyalakan lagi. RESTORE aman dikirim berulang: overlay tidak diubah, notifikasi dipasang ulang.
            if (on) startForegroundService(i.setAction(OverlayService.ACTION_RESTORE))
            else if (!OverlayService.overlayShown.value) stopService(i)
        } catch (e: Throwable) {
            android.util.Log.e("PulseMonitor", "Gagal mengubah mode latar belakang", e)
            Toast.makeText(this, "Notifikasi gagal: ${e.javaClass.simpleName}: ${e.message}", Toast.LENGTH_LONG).show()
        }
        Watchdog.sync(this, on)
    }

    /** Suara notifikasi saat overlay dinyalakan (res/raw/overlay_on.m4a). Gagal memutar tidak boleh mengganggu overlay. */
    private fun playOverlaySound() {
        runCatching {
            val attrs = android.media.AudioAttributes.Builder()
                .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            val mp = android.media.MediaPlayer.create(this, R.raw.overlay_on, attrs, android.media.AudioManager.AUDIO_SESSION_ID_GENERATE)
                ?: return
            mp.setOnCompletionListener { it.release() }
            mp.setOnErrorListener { p, _, _ -> p.release(); true }
            mp.setVolume(1f, 1f)
            mp.start()
        }
    }

    @Composable
    fun Screen(s: Snap, tab: Int, setTab: (Int) -> Unit) {
        val titles = listOf("", "Statistik memori, suhu, CPU & RAM", "Level, daya, suhu, dan riwayat baterai", "Akses dan pengaturan")
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1A2038), Bg)))) {
            wallpaperBmp?.let { bmp ->
                Image(bmp.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop,
                    filterQuality = androidx.compose.ui.graphics.FilterQuality.High)
                // makin gelap ke bawah supaya panel dan teks tetap terbaca
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
                    listOf(Bg.copy(alpha = dim * 0.12f), Bg.copy(alpha = dim * 0.8f)))))
            }
            // Kepala: judul + chip akses sebaris, subjudul satu baris di bawahnya (tinggi tetap supaya tidak loncat antar tab)
            Column(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 24.dp, vertical = 20.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Pulse Monitor", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold,
                        style = androidx.compose.ui.text.TextStyle(shadow = androidx.compose.ui.graphics.Shadow(Color.Black.copy(alpha = 0.6f), Offset(0f, 2f), 8f)), maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(12.dp))   // jarak judul dan chip akses
                    val ok = s.access != "-"
                    Row(Modifier.clip(RoundedCornerShape(50)).background(Color(0xFF1E1F26).copy(alpha = 0.35f))
                        .clickable(enabled = !ok) { Access.refresh(); accessDlg = true }.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(10.dp).background(if (ok) Color(0xFF7CFFB2) else Color(0xFFFF5C5C), CircleShape))
                        Text(if (ok) s.access else "Beri izin", color = if (ok) Color(0xFF7CFFB2) else Color(0xFFFF8A8A),
                            fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, modifier = Modifier.padding(start = 8.dp))
                    }
                }
                Box(Modifier.fillMaxWidth().height(22.dp).padding(top = 2.dp)) {
                    AnimatedContent(targetState = titles[tab], label = "subtitle",
                        transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(120)) }) { t ->
                        if (t.isNotEmpty()) Text(t, color = Color(0xFFE6E6EE), fontSize = 14.sp, style = androidx.compose.ui.text.TextStyle(shadow = androidx.compose.ui.graphics.Shadow(Color.Black.copy(alpha = 0.6f), Offset(0f, 2f), 8f)), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            if (accessDlg) AccessDialog { accessDlg = false }
            cropSrc?.let { src ->
                // Rasio potong = rasio layar penuh (termasuk area di balik status bar dan navigasi), supaya wallpaper pas satu layar
                val aspect = if (Build.VERSION.SDK_INT >= 30) windowManager.maximumWindowMetrics.bounds.let { it.width().toFloat() / it.height() }
                else android.graphics.Point().also { @Suppress("DEPRECATION") windowManager.defaultDisplay.getRealSize(it) }.let { it.x.toFloat() / it.y }
                CropDialog(src, aspect, "Potong wallpaper aplikasi", onCancel = { cropSrc = null }) { cropped ->
                    cropSrc = null
                    Thread {
                        if (WallpaperStore.saveCropped(this@MainActivity, cropped)) wallpaperBmp = WallpaperStore.load(this@MainActivity)
                    }.start()
                }
            }
            // Panel bawah + navigasi
            Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(Modifier.fillMaxWidth().padding(8.dp)) {  // tanpa kotak luar: cuma kartu dalam yang terlihat
                    PullToRefreshBox(isRefreshing = refreshing, onRefresh = { doRefresh() }) {
                    AnimatedContent(targetState = tab, label = "tab", transitionSpec = {
                        val dir = if (targetState > initialState) 1 else -1   // geser sesuai arah tab
                        (slideInHorizontally(tween(260)) { it / 4 * dir } + fadeIn(tween(260))) togetherWith
                            (slideOutHorizontally(tween(200)) { -it / 4 * dir } + fadeOut(tween(160))) using SizeTransform(clip = true)
                    }) { t ->
                    when (t) {
                        0 -> Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState())) { HomeTab(s) }
                        // Tab Statistik: tampil penuh setinggi ruang yang tersedia (di antara kepala dan navigasi), bukan dibatasi 460dp.
                        // Sisa ~310dp = kepala + status bar + panel navigasi bawah + jarak. Kalau isi lebih panjang, tetap bisa digulir.
                        1 -> Column(Modifier.heightIn(max = (androidx.compose.ui.platform.LocalConfiguration.current.screenHeightDp - 310).dp.coerceAtLeast(460.dp))
                            .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(10.dp)) { StatsTab(s) }
                        2 -> Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(10.dp)) { BatteryTab(s) }
                        else -> Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(10.dp)) { SettingsContent() }
                    }
                    }
                    }
                }
                Box(Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(32.dp)).padding(8.dp)) {   // transparan sama seperti kartu di atasnya
                    BoxWithConstraints(Modifier.fillMaxWidth()) {
                        val w = maxWidth / 4
                        val pill by animateColorAsState(NavColors[tab].copy(alpha = 0.28f), tween(260), label = "navPillCol")
                        val x by animateDpAsState(w * tab, spring(dampingRatio = 0.75f, stiffness = Spring.StiffnessMediumLow), label = "navPill")
                        // pil penanda meluncur ke tab terpilih
                        Box(Modifier.matchParentSize()) {
                            Box(Modifier.offset(x = x).width(w).fillMaxHeight().background(pill, RoundedCornerShape(26.dp)))
                        }
                        Row(Modifier.fillMaxWidth()) {
                            NavItem("⌂", "Beranda", tab == 0, NavColors[0]) { setTab(0) }
                            NavItem("▤", "Statistik", tab == 1, NavColors[1]) { setTab(1) }
                            NavItem(BAT_ICON, "Baterai", tab == 2, NavColors[2]) { setTab(2) }
                            NavItem("⚙", "Settings", tab == 3, NavColors[3]) { setTab(3) }
                        }
                    }
                }
            }
        }
    }

    /** Kartu Status CPU (di tab Statistik): frekuensi tiap inti (dua kolom) dan grafik beban CPU di dasar kartu. */
    @Composable
    private fun CpuCard(s: Snap) {
        val green = Color(0xFF9AA0A6)
        var tempDialog by remember { mutableStateOf(false) }
        if (tempDialog) CpuTempDialog(s) { tempDialog = false }
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Inner)) {
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Status CPU", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                Box(Modifier.size(34.dp).clip(CircleShape).background(Color(0xFF2E3039)).clickable { tempDialog = true }, contentAlignment = Alignment.Center) {
                    Text("⚙", color = Color.White, fontSize = 18.sp)
                }
            }
            val peak = remember { intArrayOf(0) }
            peak[0] = maxOf(peak[0], s.coreMhz.maxOrNull() ?: 0)
            if (s.coreMhz.isEmpty()) {
                Text("Frekuensi belum terbaca", color = Grey, fontSize = 13.sp, modifier = Modifier.padding(16.dp))
            } else Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                s.coreMhz.withIndex().toList().chunked(4).forEach { group ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        group.forEach { (i, mhz) ->
                            val frac = if (mhz > 0 && peak[0] > 0) (mhz.toFloat() / peak[0]).coerceIn(0.03f, 1f) else 0f
                            val barCol = if (frac >= 0.95f) Color(0xFFE6E8EB) else green
                            Column(Modifier.weight(1f).background(Color(0xFF101116).copy(alpha = 0.35f), RoundedCornerShape(12.dp)).padding(horizontal = 8.dp, vertical = 7.dp)) {
                                Text("Inti $i", color = Grey, fontSize = 10.sp, maxLines = 1)
                                Text(if (mhz > 0) "$mhz MHz" else "Offline", color = if (mhz > 0) Color.White else Grey, fontSize = 12.sp, maxLines = 1, softWrap = false)
                                Box(Modifier.padding(top = 4.dp).fillMaxWidth().height(3.dp).background(Color(0xFF2A2D38), RoundedCornerShape(2.dp))) {
                                    Box(Modifier.fillMaxWidth(frac).height(3.dp).background(barCol, RoundedCornerShape(2.dp)))
                                }
                            }
                        }
                        repeat(4 - group.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
            CpuInfoBox(s)
            CpuGraph(s.cpuHist, green, Modifier.fillMaxWidth().height(36.dp))
        }
    }

    /** Info di dasar kartu Status CPU: beban sistem, frekuensi sekarang / maksimum tiap cluster (bilah), dan governor. Format baris "Label : nilai". */
    @Composable
    private fun CpuInfoBox(s: Snap) {
        val bar = Color(0xFF9AA0A6); val track = Color(0xFF2A2D38)
        val names = clusterNames(s.clMaxMhz.size)
        Column(Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, bottom = 10.dp)
            .background(Color(0xFF101116).copy(alpha = 0.35f), RoundedCornerShape(12.dp)).padding(horizontal = 12.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Column {
                InfoLine("Beban sistem CPU", if (s.cpu >= 0) "${s.cpu}%" else "-")
                Box(Modifier.padding(top = 4.dp).fillMaxWidth().height(3.dp).background(track, RoundedCornerShape(2.dp))) {
                    Box(Modifier.fillMaxWidth((s.cpu.coerceIn(0, 100) / 100f).coerceAtLeast(0.02f)).height(3.dp).background(bar, RoundedCornerShape(2.dp)))
                }
            }
            s.clMaxMhz.forEachIndexed { i, (start, maxMhz) ->
                // Frekuensi sekarang cluster = tertinggi di antara inti-intinya (inti mati = -1 diabaikan)
                val end = s.clMaxMhz.getOrNull(i + 1)?.first ?: Int.MAX_VALUE
                val now = s.coreMhz.withIndex().filter { it.index in start until end && it.value > 0 }.maxOfOrNull { it.value } ?: 0
                val frac = if (maxMhz > 0) (now.toFloat() / maxMhz).coerceIn(0f, 1f) else 0f
                Column {
                    InfoLine(if (names[i] == "CPU") "Frekuensi CPU" else "Frekuensi ${names[i]} cluster",
                        "${if (now > 0) now.toString() else "-"} / $maxMhz MHz")
                    Box(Modifier.padding(top = 4.dp).fillMaxWidth().height(3.dp).background(track, RoundedCornerShape(2.dp))) {
                        Box(Modifier.fillMaxWidth(frac.coerceAtLeast(0.02f)).height(3.dp)
                            .background(if (frac >= 0.95f) Color(0xFFE6E8EB) else bar, RoundedCornerShape(2.dp)))
                    }
                }
            }
            if (s.govs.isNotEmpty()) {
                Box(Modifier.fillMaxWidth().height(1.dp).background(track))
                val groups = s.govs.groupBy({ it.second }, { it.first })
                if (groups.size == 1) InfoLine("Governor CPU", groups.keys.first(), alignEnd = false)
                else s.govs.forEach { (core, gov) ->
                    val idx = s.clMaxMhz.indexOfFirst { it.first == core }
                    InfoLine("Governor ${if (idx >= 0) names[idx] else "Cluster $core"} cluster", gov, alignEnd = false)
                }
            }
        }
    }

    /** Satu baris "Label :" di kiri dan nilai tebal. alignEnd = true: nilai rata kanan; false: nilai langsung setelah label (dipakai Governor). */
    @Composable
    private fun InfoLine(label: String, value: String, alignEnd: Boolean = true) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("$label :", color = Grey, fontSize = 12.sp, maxLines = 1, softWrap = false)
            Spacer(Modifier.width(if (alignEnd) 10.dp else 6.dp))
            if (alignEnd) Spacer(Modifier.weight(1f))
            Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1, softWrap = false)
        }
    }

    /** Nama cluster urut dari terkecil: 1 = CPU, 2 = Little/Big, 3 = Little/Big/Prime, 4+ = Little, Mid, ..., Big, Prime. */
    private fun clusterNames(n: Int): List<String> = when (n) {
        0 -> emptyList()
        1 -> listOf("CPU")
        2 -> listOf("Little", "Big")
        3 -> listOf("Little", "Big", "Prime")
        else -> List(n) { i -> when (i) { 0 -> "Little"; n - 1 -> "Prime"; n - 2 -> "Big"; else -> "Mid ${i}" } }
    }

    /** Ketuk angka FPS atau grafik di Beranda: ganti warna aksen ke pilihan berikutnya (sama dengan pilihan di Settings > Wallpaper dan overlay, overlay ikut berubah). */
    private fun cycleAccent() {
        val a = AppSettings.ACCENTS
        AppSettings.accent = a[(a.indexOf(AppSettings.accent) + 1) % a.size]
        AppSettings.save(this)
    }

    @Composable
    private fun HomeTab(s: Snap) {
        // Tiga kartu kecil (Perangkat, Overlay + grafik, lalu Rekam FPS) dengan teks dan jarak diperkecil supaya wallpaper tetap terlihat
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            DeviceCard()
            Column(Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(20.dp)).padding(horizontal = 10.dp, vertical = 12.dp)) {
                // Padding 6dp di DALAM area klik (setelah clip) supaya huruf paling kiri tidak terpotong sudut membulat
                // FPS rata kiri, Frametime di kanan (di samping tombol sensor)
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).clickable { cycleAccent() }.padding(horizontal = 6.dp, vertical = 1.dp)) {
                        Text("FPS", color = Grey, fontSize = 11.sp, lineHeight = 14.sp)
                        Text("${s.fps}", color = acc(), fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, lineHeight = 20.sp)
                    }
                    Column(Modifier.padding(horizontal = 6.dp, vertical = 1.dp), horizontalAlignment = Alignment.End) {
                        Text("Frametime", color = Grey, fontSize = 11.sp, lineHeight = 14.sp)
                        Text(if (s.ft > 0f) "%.1f ms".format(s.ft) else "-", color = Color.White, fontSize = 16.sp,
                            fontWeight = FontWeight.Bold, maxLines = 1, lineHeight = 20.sp)
                    }
                }
                FpsGraph(s.hist, Modifier.padding(top = 6.dp, start = 6.dp, end = 6.dp).fillMaxWidth().height(24.dp).clip(RoundedCornerShape(12.dp)).clickable { cycleAccent() })
                Row(Modifier.fillMaxWidth().padding(top = 4.dp, start = 6.dp, end = 6.dp)) {
                    Text(if (s.idle) "Layar diam  ·  30 detik terakhir" else "30 detik terakhir", color = Grey, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(end = 8.dp))
                    Text("AVG ${if (s.avg > 0) s.avg else "-"}  ·  LOW ${if (s.low > 0) s.low else "-"}", color = Grey, fontSize = 11.sp, maxLines = 1, softWrap = false)
                }
                Box(Modifier.padding(top = 6.dp, start = 6.dp, end = 6.dp).fillMaxWidth().height(1.dp).background(Color(0xFF2A2C36)))
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { toggleOverlay() }.padding(horizontal = 6.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Overlay", color = Color.White, fontSize = 13.sp, lineHeight = 16.sp)
                        Text(if (overlayOn) "Aktif" else "Mati", color = if (overlayOn) acc() else Grey, fontSize = 11.sp, lineHeight = 14.sp)
                    }
                    Box(Modifier.size(width = 38.dp, height = 22.dp).clip(CircleShape).background(if (overlayOn) acc() else Color(0xFF3A3D4A)),
                        contentAlignment = if (overlayOn) Alignment.CenterEnd else Alignment.CenterStart) {
                        Box(Modifier.padding(horizontal = 3.dp).size(16.dp).background(Color.White, CircleShape))
                    }
                }
            }
            RecordControls(s)
        }
    }

    /** Info perangkat di tab Statistik: baterai, jaringan, RAM, dan penyimpanan sebagai empat baris berikon, nilai, dan bilah progres. */
    @Composable
    private fun DeviceInfoCard(s: Snap) {
        val ctx = LocalContext.current
        val ex by produceState(Extras(), refreshTick) {
            while (true) {
                value = withContext(Dispatchers.IO) { DeviceExtras.read(ctx) }
                delay(2000)
            }
        }
        var netDialog by remember { mutableStateOf(false) }
        if (netDialog) NetDialog { netDialog = false }
        var batDialog by remember { mutableStateOf(false) }
        if (batDialog) BatDialog { batDialog = false }
        var ramDialog by remember { mutableStateOf(false) }
        if (ramDialog) RamDialog { ramDialog = false }
        var stoDialog by remember { mutableStateOf(false) }
        if (stoDialog) StorageDialog { stoDialog = false }
        val bat = ex.bat
        val net = ex.net
        val ram = s.mem?.let { SizeExtra(it.ramUsed, it.ramTotal) } ?: ex.ram
        val sto = ex.storage
        val tBat = if (bat.tempC >= 0f) bat.tempC else s.tBat
        val batPct = if (bat.pct >= 0) bat.pct else s.batPct
        fun sizeSub(v: SizeExtra) = if (v.pct >= 0) "%d%% terpakai · %.1f GB bebas".format(v.pct, (v.totalGb - v.usedGb).coerceAtLeast(0f)) else ""
        fun sizeVal(v: SizeExtra) = if (v.usedGb >= 0f && v.totalGb > 0f) "%.1f / %.1f GB".format(v.usedGb, v.totalGb) else "-"
        val batSub = listOf(if (tBat >= 0f) "${deg(tBat)}C" else "", if (bat.remain.isNotBlank() && bat.remain != "-") bat.remain else bat.state)
            .filter { it.isNotBlank() && it != "-" }.joinToString(" · ")
        // Grid 2 kolom: tiap kotak berisi ikon + judul, angka utama besar, bilah tipis, dan keterangan kecil
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatTile(Modifier.weight(1f).fillMaxHeight(), NavColors[2], "Baterai", if (batPct >= 0) "$batPct" else "-", "%",
                    if (batPct >= 0) batPct / 100f else 0f, batSub, onClick = { batDialog = true }) {
                    Canvas(Modifier.size(14.dp, 18.dp)) {
                        val sw = 1.6.dp.toPx(); val c = NavColors[2]
                        drawRoundRect(c, Offset(sw / 2, 3.dp.toPx()), androidx.compose.ui.geometry.Size(size.width - sw, size.height - 3.dp.toPx() - sw / 2),
                            androidx.compose.ui.geometry.CornerRadius(3.dp.toPx()), style = Stroke(sw))
                        drawRoundRect(c, Offset(size.width * 0.35f, 0f), androidx.compose.ui.geometry.Size(size.width * 0.3f, 2.2.dp.toPx()),
                            androidx.compose.ui.geometry.CornerRadius(1.dp.toPx()))
                    }
                }
                StatTile(Modifier.weight(1f).fillMaxHeight(), NavColors[0], "Jaringan", if (net.mbps > 0) "${net.mbps}" else net.type, if (net.mbps > 0) " Mbps" else "",
                    if (net.sigPct >= 0) net.sigPct / 100f else 0f,
                    if (net.sigPct >= 0) "${net.type} · ${net.dbm} dBm" else "", onClick = { netDialog = true }) {
                    SignalBars(net.sigPct, NavColors[0])
                }
            }
            Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatTile(Modifier.weight(1f).fillMaxHeight(), NavColors[1], "RAM", if (ram.pct >= 0) "${ram.pct}" else "-", "%",
                    if (ram.pct >= 0) ram.pct / 100f else 0f, sizeVal(ram), onClick = { ramDialog = true }) {
                    Canvas(Modifier.size(20.dp)) {
                        val w = size.width; val sw = w * 0.09f; val c = NavColors[1]
                        drawRoundRect(c, Offset(w * 0.2f, w * 0.26f), androidx.compose.ui.geometry.Size(w * 0.6f, w * 0.48f),
                            androidx.compose.ui.geometry.CornerRadius(w * 0.08f), style = Stroke(sw))
                        for (i in 0..2) {
                            val x = w * (0.34f + 0.16f * i)
                            drawLine(c, Offset(x, w * 0.1f), Offset(x, w * 0.26f), sw, StrokeCap.Round)
                            drawLine(c, Offset(x, w * 0.74f), Offset(x, w * 0.9f), sw, StrokeCap.Round)
                        }
                    }
                }
                StatTile(Modifier.weight(1f).fillMaxHeight(), NavColors[3], "Penyimpanan", if (sto.pct >= 0) "${sto.pct}" else "-", "%",
                    if (sto.pct >= 0) sto.pct / 100f else 0f, sizeVal(sto), onClick = { stoDialog = true }) {
                    Canvas(Modifier.size(20.dp)) {
                        val w = size.width; val sw = w * 0.09f; val c = NavColors[3]
                        drawRoundRect(c, Offset(w * 0.16f, w * 0.24f), androidx.compose.ui.geometry.Size(w * 0.68f, w * 0.54f),
                            androidx.compose.ui.geometry.CornerRadius(w * 0.14f), style = Stroke(sw))
                        drawLine(c, Offset(w * 0.16f, w * 0.57f), Offset(w * 0.84f, w * 0.57f), sw, StrokeCap.Round)
                        drawCircle(c, w * 0.03f, Offset(w * 0.67f, w * 0.68f))
                    }
                }
            }
        }
    }

    /** Satu kotak grid: ikon berwarna + judul, angka utama besar (satuan kecil), bilah progres tipis, keterangan kecil. Bisa diketuk bila onClick diisi. */
    @Composable
    private fun StatTile(modifier: Modifier, color: Color, title: String, big: String, unit: String, frac: Float, sub: String,
                         onClick: (() -> Unit)? = null, icon: @Composable BoxScope.() -> Unit) {
        val anim by animateFloatAsState(frac.coerceIn(0f, 1f), tween(500), label = "tileFrac")
        Column(modifier.clip(RoundedCornerShape(20.dp)).background(Inner)
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier).padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(30.dp).background(chipBg(color), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center, content = icon)
                Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(start = 8.dp))
            }
            Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.Bottom) {
                Text(big, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, lineHeight = 26.sp)
                if (unit.isNotEmpty()) Text(unit, color = Color.White, fontSize = 12.sp, maxLines = 1, modifier = Modifier.padding(bottom = 3.dp))
            }
            Box(Modifier.padding(top = 6.dp).fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)).background(Color(0xFF2A2D38))) {
                Box(Modifier.fillMaxWidth(anim).fillMaxHeight().background(color, RoundedCornerShape(3.dp)))
            }
            Text(sub.ifEmpty { " " }, color = Grey, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
        }
    }

    /** Satu baris info: ikon berwarna di kiri; judul + nilai, bilah progres, dan keterangan kecil di kanan. */
    @Composable
    private fun StatInfoRow(color: Color, title: String, value: String, frac: Float, sub: String, onClick: (() -> Unit)? = null, icon: @Composable BoxScope.() -> Unit) {
        val anim by animateFloatAsState(frac.coerceIn(0f, 1f), tween(500), label = "infoFrac")
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Inner)
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(horizontal = 14.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.size(38.dp).background(chipBg(color), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center, content = icon)
            Column(Modifier.weight(1f)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
                    Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                    Text(value, color = Color.White, fontSize = 12.sp, maxLines = 1)
                }
                Box(Modifier.padding(top = 6.dp, bottom = 5.dp).fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)).background(Color(0xFF2A2D38))) {
                    Box(Modifier.fillMaxWidth(anim).fillMaxHeight().background(color, RoundedCornerShape(3.dp)))
                }
                if (sub.isNotEmpty()) Text(sub, color = Grey, fontSize = 12.sp, maxLines = 1)
            }
        }
    }

    /** Kerangka dialog rincian (RAM, Penyimpanan): ringkasan persen besar + lencana + bilah, lalu kotak rincian dua kolom. */
    @Composable
    private fun InfoDialog(title: String, subtitle: String, pct: Int, color: Color, badge: String, cells: List<Pair<String, String>>, onDismiss: () -> Unit) {
        val anim by animateFloatAsState(if (pct >= 0) pct / 100f else 0f, tween(500), label = "infoDlgFrac")
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Color.Black,
            shape = RoundedCornerShape(28.dp),
            title = {
                Column {
                    Text(title, color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 22.sp)
                    Text(subtitle, color = Grey, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
                }
            },
            text = {
                Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Column(Modifier.fillMaxWidth().background(Color(0xFF16171C), RoundedCornerShape(20.dp)).padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Row(Modifier.weight(1f), verticalAlignment = Alignment.Bottom) {
                                Text(if (pct >= 0) "$pct" else "-", color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 44.sp)
                                Text("%", color = Color.White, fontSize = 18.sp, modifier = Modifier.padding(start = 2.dp, bottom = 6.dp))
                            }
                            Text(badge, color = color, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1,
                                modifier = Modifier.background(color.copy(alpha = 0.14f), CircleShape).padding(horizontal = 10.dp, vertical = 4.dp))
                        }
                        Box(Modifier.padding(top = 10.dp).fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFF2A2D38))) {
                            Box(Modifier.fillMaxWidth(anim).fillMaxHeight().background(color, RoundedCornerShape(4.dp)))
                        }
                    }
                    cells.chunked(2).forEach { pair ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            pair.forEach { (label, value) ->
                                Column(Modifier.weight(1f).background(Color(0xFF16171C), RoundedCornerShape(16.dp)).padding(horizontal = 12.dp, vertical = 10.dp)) {
                                    Text(label, color = NetLabel, fontSize = 12.sp, maxLines = 1)
                                    Text(value, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, modifier = Modifier.padding(top = 2.dp))
                                }
                            }
                            if (pair.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text("Tutup", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
        )
    }

    private fun gbTxt(v: Float) = if (v >= 0f) "%.1f GB".format(v) else "-"

    /** Dialog di kotak RAM: total, terpakai, tersedia, bebas, cache, dan swap/ZRAM. Diperbarui tiap 2 detik. */
    @Composable
    private fun RamDialog(onDismiss: () -> Unit) {
        val d by produceState(MemDetail()) {
            while (true) { value = withContext(Dispatchers.IO) { DeviceExtras.memDetail() }; delay(2000) }
        }
        val pct = if (d.totalGb > 0f && d.usedGb >= 0f) (d.usedGb * 100f / d.totalGb).toInt().coerceIn(0, 100) else -1
        InfoDialog("RAM", "Pemakaian memori saat ini", pct, NavColors[1],
            if (d.availGb >= 0f) "${gbTxt(d.availGb)} tersedia" else "-",
            listOf(
                "Total" to gbTxt(d.totalGb),
                "Terpakai" to gbTxt(d.usedGb),
                "Tersedia" to gbTxt(d.availGb),
                "Bebas" to gbTxt(d.freeGb),
                "Cache" to gbTxt(d.cacheGb),
                "Swap / ZRAM" to if (d.swapTotalGb > 0f) "%.1f / %.1f GB".format(d.swapUsedGb, d.swapTotalGb) else "Tidak ada"
            ), onDismiss)
    }

    /** Dialog di kotak Penyimpanan: partisi data (isi pengguna) dan partisi sistem. Diperbarui tiap 2 detik. */
    @Composable
    private fun StorageDialog(onDismiss: () -> Unit) {
        val d by produceState(StoDetail()) {
            while (true) { value = withContext(Dispatchers.IO) { DeviceExtras.stoDetail() }; delay(2000) }
        }
        val pct = if (d.totalGb > 0f && d.usedGb >= 0f) (d.usedGb * 100f / d.totalGb).toInt().coerceIn(0, 100) else -1
        InfoDialog("Penyimpanan", "Penyimpanan internal", pct, NavColors[3],
            if (d.freeGb >= 0f) "${gbTxt(d.freeGb)} bebas" else "-",
            listOf(
                "Total" to gbTxt(d.totalGb),
                "Terpakai" to gbTxt(d.usedGb),
                "Bebas" to gbTxt(d.freeGb),
                "Terisi" to if (pct >= 0) "$pct%" else "-",
                "Partisi sistem" to gbTxt(d.sysTotalGb),
                "Sistem terpakai" to gbTxt(d.sysUsedGb)
            ), onDismiss)
    }

    /** Dialog di kartu Baterai: ringkasan level + status di atas, lalu rincian dalam kotak kecil dua kolom. Diperbarui tiap 2 detik selama terbuka. */
    @Composable
    private fun BatDialog(onDismiss: () -> Unit) {
        val ctx = LocalContext.current
        val d by produceState(BatDetail()) {
            while (true) {
                value = withContext(Dispatchers.IO) { DeviceExtras.batDetail(ctx) }
                delay(2000)
            }
        }
        val green = NavColors[2]
        val lvlCol = when { d.pct in 0..15 -> Color(0xFFFF6B6B); d.pct in 0..30 -> Color(0xFFFFD866); else -> green }
        val anim by animateFloatAsState(if (d.pct >= 0) d.pct / 100f else 0f, tween(500), label = "batDlgFrac")
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Color.Black,
            shape = RoundedCornerShape(28.dp),
            title = {
                Column {
                    Text("Baterai", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 22.sp)
                    Text("Level, kondisi, dan kapasitas", color = Grey, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
                }
            },
            text = {
                Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Ringkasan: persen besar + status, bilah level di bawahnya
                    Column(Modifier.fillMaxWidth().background(Color(0xFF16171C), RoundedCornerShape(20.dp)).padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Row(Modifier.weight(1f), verticalAlignment = Alignment.Bottom) {
                                Text(if (d.pct >= 0) "${d.pct}" else "-", color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 44.sp)
                                Text("%", color = Color.White, fontSize = 18.sp, modifier = Modifier.padding(start = 2.dp, bottom = 6.dp))
                            }
                            val bc = if (d.charging) green else Color(0xFF9AA0A6)
                            Text(d.status, color = bc, fontSize = 12.sp, fontWeight = FontWeight.Medium,
                                modifier = Modifier.background(bc.copy(alpha = 0.14f), CircleShape).padding(horizontal = 10.dp, vertical = 4.dp))
                        }
                        Box(Modifier.padding(top = 10.dp).fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFF2A2D38))) {
                            Box(Modifier.fillMaxWidth(anim).fillMaxHeight().background(lvlCol, RoundedCornerShape(4.dp)))
                        }
                    }
                    val cells = listOf(
                        "Suhu" to if (d.tempC >= 0f) "%.1f°C".format(d.tempC) else "-",
                        "Tegangan" to if (d.volt > 0f) "%.3f V".format(d.volt) else "-",
                        "Kondisi" to d.health,
                        "Teknologi" to d.tech,
                        "Kapasitas desain" to if (d.designMah > 0) "${d.designMah} mAh" else "-",
                        "Muatan tersisa" to if (d.remainMah > 0) "${d.remainMah} mAh" else "-",
                        "Arus" to if (d.currentMa != Int.MIN_VALUE) "${d.currentMa} mA" else "-",
                        "Siklus" to if (d.cycles > 0) "${d.cycles}x" else "-"
                    )
                    cells.chunked(2).forEach { pair ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            pair.forEach { (label, value) ->
                                val bad = label == "Kondisi" && !d.healthGood
                                Column(Modifier.weight(1f).background(Color(0xFF16171C), RoundedCornerShape(16.dp)).padding(horizontal = 12.dp, vertical = 10.dp)) {
                                    Text(label, color = NetLabel, fontSize = 12.sp, maxLines = 1)
                                    Text(value, color = if (bad) Color(0xFFFF8A8A) else Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                                        maxLines = 1, modifier = Modifier.padding(top = 2.dp))
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text("Tutup", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
        )
    }

    /** Dialog di kartu Jaringan: tiga bagian (Wi-Fi, Seluler, SIM), tiap bagian satu kartu dengan lencana status dan baris rincian. Diperbarui tiap 2 detik selama terbuka. */
    @Composable
    private fun NetDialog(onDismiss: () -> Unit) {
        val ctx = LocalContext.current
        val d by produceState(NetDetail()) {
            while (true) {
                value = withContext(Dispatchers.IO) { DeviceExtras.netDetail(ctx) }
                delay(2000)
            }
        }
        val wifiC = NavColors[0]; val mobC = NavColors[1]; val simC = NavColors[2]
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Color.Black,
            shape = RoundedCornerShape(28.dp),
            title = {
                Column {
                    Text("Jaringan", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 22.sp)
                    Text("Wi-Fi, seluler, dan SIM", color = Grey, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
                }
            },
            text = {
                Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    NetSection(wifiC, "Wi-Fi", if (d.wifiOn) "Terhubung" else "Tidak terhubung", d.wifiOn, { SignalBars(if (d.wifiOn) d.wifiPct else 0, wifiC) }) {
                        if (d.wifiOn) {
                            // Kekuatan sinyal sebagai bilah besar, rincian lain di bawahnya
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
                                Text("${d.wifiPct}%", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                                Text("  ${d.wifiDbm} dBm", color = NetLabel, fontSize = 13.sp, modifier = Modifier.padding(bottom = 4.dp))
                            }
                            Box(Modifier.padding(top = 6.dp, bottom = 4.dp).fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)).background(Color(0xFF2A2D38))) {
                                Box(Modifier.fillMaxWidth((d.wifiPct / 100f).coerceIn(0f, 1f)).fillMaxHeight().background(wifiC, RoundedCornerShape(3.dp)))
                            }
                            NetRow("Alamat IP", d.wifiIp.ifEmpty { "-" })
                            NetRow("Kecepatan link", if (d.wifiMbps > 0) "${d.wifiMbps} Mbps" else "-")
                            if (d.wifiBand.isNotEmpty()) NetRow("Pita", d.wifiBand)
                        } else Text("Tidak tersambung ke Wi-Fi.", color = NetLabel, fontSize = 13.sp)
                    }
                    NetSection(mobC, "Seluler", if (d.mobileOn) "Terhubung" else "Tidak terhubung", d.mobileOn, {
                        Canvas(Modifier.size(14.dp, 20.dp)) {
                            val sw = 1.7.dp.toPx()
                            drawRoundRect(mobC, Offset(sw / 2, sw / 2), androidx.compose.ui.geometry.Size(size.width - sw, size.height - sw),
                                androidx.compose.ui.geometry.CornerRadius(3.dp.toPx()), style = Stroke(sw))
                            drawCircle(mobC, 1.2.dp.toPx(), Offset(size.width / 2, size.height - 4.dp.toPx()))
                        }
                    }) {
                        NetRow("Tipe telepon", d.phoneType)
                        NetRow("Data seluler", if (d.mobileOn) "Aktif" else "Tidak aktif")
                    }
                    NetSection(simC, "Kartu SIM", d.simState, d.simReady, {
                        Canvas(Modifier.size(16.dp, 20.dp)) {
                            val sw = 1.7.dp.toPx()
                            drawRoundRect(simC, Offset(sw / 2, sw / 2), androidx.compose.ui.geometry.Size(size.width - sw, size.height - sw),
                                androidx.compose.ui.geometry.CornerRadius(3.dp.toPx()), style = Stroke(sw))
                            drawRoundRect(simC, Offset(size.width * 0.28f, size.height * 0.42f), androidx.compose.ui.geometry.Size(size.width * 0.44f, size.height * 0.34f),
                                androidx.compose.ui.geometry.CornerRadius(1.5.dp.toPx()))
                        }
                    }) {
                        NetRow("Operator", d.operator)
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text("Tutup", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
        )
    }

    private val NetLabel = Color(0xFFA9ADBA)

    /** Satu bagian dialog jaringan: ikon + judul + lencana status di kepala, rincian di bawahnya. */
    @Composable
    private fun NetSection(color: Color, title: String, badge: String, on: Boolean, icon: @Composable BoxScope.() -> Unit, content: @Composable ColumnScope.() -> Unit) {
        Column(Modifier.fillMaxWidth().background(Color(0xFF16171C), RoundedCornerShape(20.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(36.dp).background(chipBg(color), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center, content = icon)
                Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f).padding(start = 12.dp))
                val bc = if (on) Color(0xFF5BD68E) else Color(0xFF9AA0A6)
                Text(badge, color = bc, fontSize = 12.sp, fontWeight = FontWeight.Medium,
                    modifier = Modifier.background(bc.copy(alpha = 0.14f), CircleShape).padding(horizontal = 10.dp, vertical = 4.dp))
            }
            content()
        }
    }

    @Composable
    private fun NetRow(label: String, value: String) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = NetLabel, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text(value, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
    }

    /** Ikon sinyal 4 batang; batang yang menyala mengikuti kekuatan sinyal (persen), sisanya redup. */
    @Composable
    private fun SignalBars(pct: Int, color: Color) {
        val lit = when {
            pct >= 80 -> 4
            pct >= 55 -> 3
            pct >= 30 -> 2
            pct >= 1 -> 1
            else -> 0
        }
        Canvas(Modifier.size(width = 20.dp, height = 16.dp)) {
            val n = 4
            val gap = 2.dp.toPx()
            val bw = (size.width - gap * (n - 1)) / n
            val r = androidx.compose.ui.geometry.CornerRadius(1.5.dp.toPx())
            for (i in 0 until n) {
                val h = size.height * (i + 1) / n
                drawRoundRect(
                    color = if (i < lit) color else color.copy(alpha = 0.25f),
                    topLeft = Offset(i * (bw + gap), size.height - h),
                    size = androidx.compose.ui.geometry.Size(bw, h),
                    cornerRadius = r
                )
            }
        }
    }

    private fun toggleRecord(s: Snap) {
        if (Recorder.active.value) {
            Thread {
                val r = Recorder.stop(this)
                runOnUiThread { Toast.makeText(this, if (r != null) "Rekaman tersimpan" else "Tidak ada data FPS yang terekam\n${Recorder.lastFail}", if (r != null) Toast.LENGTH_SHORT else Toast.LENGTH_LONG).show() }
            }.start()
        } else {
            if (s.access == "-") { Toast.makeText(this, "Butuh Shizuku atau root untuk merekam", Toast.LENGTH_SHORT).show(); return }
            Sampler.onRecordStart()
            Recorder.start()
            if (!overlayOn) Toast.makeText(this, "Nyalakan overlay supaya rekaman tetap jalan saat kamu pindah ke game", Toast.LENGTH_LONG).show()
        }
    }

    /** Bagikan laporan sebagai dua gambar PNG (halaman 1 + grafik, halaman 2) supaya bisa digeser di chat. Ringkasan teks ikut sebagai keterangan. Gagal membuat gambar -> kirim teks saja. */
    private fun shareReportImage(s: Session) {
        Toast.makeText(this, "Membuat gambar...", Toast.LENGTH_SHORT).show()
        Thread {
            val uris = runCatching {
                val dir = java.io.File(cacheDir, "share").apply { mkdirs() }
                dir.listFiles()?.forEach { it.delete() }
                (0..1).map { part ->
                    val bmp = ShareImage.render(this, s, part)
                    val f = java.io.File(dir, "PulseMonitor_${s.id}_${part + 1}.png")
                    f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    androidx.core.content.FileProvider.getUriForFile(this, "$packageName.files", f)
                }
            }.getOrNull()
            runOnUiThread {
                if (uris == null) { shareSummary(s); return@runOnUiThread }
                val i = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                    type = "image/png"
                    putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
                    putExtra(Intent.EXTRA_TEXT, Recorder.summary(s))
                    clipData = android.content.ClipData.newRawUri("", uris[0]).also { cd -> uris.drop(1).forEach { cd.addItem(android.content.ClipData.Item(it)) } }
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(Intent.createChooser(i, "Bagikan laporan"))
            }
        }.start()
    }

    /** Simpan laporan sebagai dua gambar PNG ke galeri (Pictures/PulseMonitor), tanpa izin storage. Gambar 1 = ringkas (header, statistik, grafik FPS dan Suhu). */
    private fun saveReportImage(s: Session) {
        Toast.makeText(this, "Menyimpan gambar...", Toast.LENGTH_SHORT).show()
        Thread {
            val ok = runCatching {
                (0..1).forEach { part ->
                    // Simpan = gambar ringkas seukuran layar: header + statistik + 2 grafik pertama (FPS dan Suhu). Bagikan tetap gambar penuh.
                    val bmp = ShareImage.render(this, s, part, maxCharts = 2)
                    val cv = android.content.ContentValues().apply {
                        put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, "PulseMonitor_${s.id}_${part + 1}.png")
                        put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/png")
                        put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, android.os.Environment.DIRECTORY_PICTURES + "/PulseMonitor")
                    }
                    val uri = contentResolver.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)!!
                    contentResolver.openOutputStream(uri)!!.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                }
            }.isSuccess
            runOnUiThread { Toast.makeText(this, if (ok) "Gambar tersimpan di Pictures/PulseMonitor" else "Gagal menyimpan gambar", Toast.LENGTH_SHORT).show() }
        }.start()
    }

    private fun shareSummary(s: Session) {
        val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, Recorder.summary(s)) }
        startActivity(Intent.createChooser(i, "Bagikan laporan"))
    }

    /** Kartu Rekam FPS kecil di Beranda: titik status, judul + keterangan pendek, ikon riwayat, tombol Mulai / Berhenti. */
    @Composable
    private fun RecordControls(s: Snap, modifier: Modifier = Modifier) {
        val rec by Recorder.active.collectAsState()
        val n by Recorder.count.collectAsState()
        val ver by Recorder.version.collectAsState()
        var list by remember { mutableStateOf<List<Session>>(emptyList()) }
        LaunchedEffect(ver) { list = withContext(Dispatchers.IO) { Recorder.list(this@MainActivity) } }
        var showList by remember { mutableStateOf(false) }
        val recRed = Color(0xFFFF5C5C)
        Row(modifier.fillMaxWidth().background(Inner, RoundedCornerShape(20.dp)).padding(start = 14.dp, end = 8.dp, top = 10.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically) {
            val blink by rememberInfiniteTransition(label = "rec").animateFloat(1f, 0.25f,
                infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "recDot")
            Box(Modifier.size(10.dp).graphicsLayer { alpha = if (rec) blink else 1f }.background(if (rec) recRed else RecPink, CircleShape))
            Column(Modifier.weight(1f).padding(start = 10.dp)) {
                Text(if (rec) "Merekam · ${fmtDur(n)}" else "Rekam FPS", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, lineHeight = 18.sp)
                Text(if (rec) "${s.fps} FPS saat ini" else "Lalu buka game", color = Grey, fontSize = 11.sp, maxLines = 1, lineHeight = 14.sp)
            }
            // Pembungkus tanpa clip supaya lencana angka boleh menonjol keluar lingkaran tombol (sebelumnya terpotong)
            Box(Modifier.size(34.dp)) {
                Box(Modifier.fillMaxSize().clip(CircleShape).background(Color(0xFF2E3039)).clickable { showList = true }, contentAlignment = Alignment.Center) {
                    HistoryIcon(Color.White, Modifier.size(17.dp))
                }
                if (list.isNotEmpty()) Box(Modifier.align(Alignment.TopEnd).offset(x = 4.dp, y = (-4).dp)
                    .defaultMinSize(minWidth = 18.dp, minHeight = 18.dp)
                    .border(2.dp, Inner, CircleShape).padding(2.dp).background(RecPink, CircleShape).padding(horizontal = 2.dp),
                    contentAlignment = Alignment.Center) {
                    Text(if (list.size > 9) "9+" else "${list.size}", color = Color(0xFF0C0C0E), fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false)
                }
            }
            Spacer(Modifier.width(8.dp))
            Box(Modifier.height(34.dp).clip(RoundedCornerShape(17.dp))
                .background(Brush.horizontalGradient(if (rec) listOf(Color(0xFFE5677A), Pink) else listOf(RecPink, Pink)))
                .clickable { toggleRecord(s) }.padding(horizontal = 18.dp), contentAlignment = Alignment.Center) {
                Text(if (rec) "Berhenti" else "Mulai", maxLines = 1, softWrap = false,
                    color = if (rec) Color.White else Color(0xFF0C0C0E), fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
        if (showList) TabDialog("Rekaman", if (list.isEmpty()) "Belum ada rekaman FPS" else "${list.size} rekaman FPS, ketuk untuk lihat laporan", { showList = false }) {
            if (list.isEmpty()) Text("Belum ada rekaman. Tekan Rekam, lalu buka game.", color = Grey, fontSize = 13.sp,
                modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp), textAlign = TextAlign.Center)
            else list.forEach { r -> RecRow(r) { showList = false; reportId = r.id } }
            Text("Rekaman juga bisa dihentikan lewat tombol di notifikasi, atau tahan overlay sekitar 1 detik tanpa menggesernya.",
                color = Grey.copy(alpha = 0.85f), fontSize = 11.sp, lineHeight = 15.sp, modifier = Modifier.padding(top = 8.dp, start = 4.dp, end = 4.dp))
        }
    }

    /** Kartu riwayat: ikon game, nama, tanggal · resolusi, rata-rata FPS, grafik mini FPS, dan chip Min / 5% low. */
    @Composable
    private fun RecRow(r: Session, onClick: () -> Unit) {
        val st = remember(r.id) { r.stats() }
        val ctx = LocalContext.current
        val icon = remember(r.pkg) { appIcon(ctx, r.pkg) }
        val line = acc()
        val whenTxt = remember(r.id) { java.text.SimpleDateFormat("d MMM · HH:mm", java.util.Locale.getDefault()).format(java.util.Date(r.id)) }
        val spark = remember(r.id) {
            val f = r.fps.filter { it > 0f }
            if (f.size <= 60) f else List(60) { i -> f[(i * (f.size - 1)) / 59] }
        }
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Inner).clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (icon != null) Image(icon.asImageBitmap(), null, Modifier.size(44.dp).clip(RoundedCornerShape(11.dp)))
                else Box(Modifier.size(44.dp).background(Color(0xFF262833), RoundedCornerShape(11.dp)), contentAlignment = Alignment.Center) {
                    Text(r.label.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                    Text(r.label, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(whenTxt + (if (r.res.isBlank()) "" else " · ${r.res}"), color = Grey, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Column(Modifier.padding(start = 10.dp), horizontalAlignment = Alignment.End) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(f1(st.avg), color = line, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                        Text(" FPS", color = Grey, fontSize = 11.sp, modifier = Modifier.padding(bottom = 3.dp))
                    }
                    Text(fmtDur(r.dur), color = Grey, fontSize = 12.sp, maxLines = 1)
                }
            }
            if (spark.size >= 2) {
                Canvas(Modifier.fillMaxWidth().height(30.dp)) {
                    var lo = spark.min(); var hi = spark.max()
                    if (hi - lo < 4f) { val m = (hi + lo) / 2f; lo = m - 2f; hi = m + 2f }
                    val path = Path()
                    spark.forEachIndexed { i, v ->
                        val x = size.width * i / (spark.size - 1)
                        val y = size.height * (1f - (v - lo) / (hi - lo))
                        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    drawPath(path, line.copy(alpha = 0.9f), style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Min" to st.min, "5% low" to st.low5, "Maks" to st.max).forEach { (k, v) ->
                    Row(Modifier.background(Color.White.copy(alpha = 0.06f), CircleShape).padding(horizontal = 10.dp, vertical = 4.dp)) {
                        Text("$k ", color = Grey, fontSize = 11.sp)
                        Text("%.0f".format(v), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }

    @Composable
    private fun ReportScreen(id: Long) {
        val sess by produceState<Session?>(null, id, refreshTick) { value = withContext(Dispatchers.IO) { Recorder.load(this@MainActivity, id) } }
        val ss = sess
        if (ss == null) {
            Box(Modifier.fillMaxSize().background(Color(0xFF101014)), contentAlignment = Alignment.Center) { Text("Memuat…", color = Grey) }
            return
        }
        PullToRefreshBox(isRefreshing = refreshing, onRefresh = { doRefresh() }, modifier = Modifier.fillMaxSize()) {
        ReportView(ss, onBack = { reportId = null }, onShare = { shareReportImage(ss) }, onSave = { saveReportImage(ss) },
            onCsv = {
                Thread {
                    val ok = Recorder.exportCsv(this@MainActivity, ss)
                    runOnUiThread { Toast.makeText(this@MainActivity, if (ok) "CSV tersimpan di folder Download" else "Gagal menyimpan CSV", Toast.LENGTH_SHORT).show() }
                }.start()
            },
            onDelete = { Recorder.delete(this@MainActivity, ss.id); reportId = null },
            onDesc = { t -> Thread { Recorder.saveDesc(this@MainActivity, ss, t) }.start() },
            wallpaper = wallpaperBmp, dim = dim)
        }
    }

    @Composable
    private fun StatsTab(s: Snap) {
        val scope = rememberCoroutineScope()
        var tools by remember { mutableStateOf(false) }
        if (tools) StatsToolsDialog(s) { tools = false }
        if (s.access == "-") Text("Belum ada akses. Pilih Shizuku atau Root di tab Settings.", color = Color(0xFFE0B040), fontSize = 12.sp,
            modifier = Modifier.fillMaxWidth().background(Color(0x1FE0B040), RoundedCornerShape(16.dp)).padding(horizontal = 14.dp, vertical = 10.dp))
        // Geser kiri-kanan: halaman 1 Memori, halaman 2 Status CPU (titik penanda di bawah)
        val pager = androidx.compose.foundation.pager.rememberPagerState { 2 }
        // Tinggi kedua halaman beda (Memori vs Status CPU). Tanpa ini tinggi pager loncat saat geser dan
        // panel (menempel di bawah) ikut naik-turun. Sekarang tinggi diinterpolasi halus mengikuti jari.
        val pageH = remember { androidx.compose.runtime.mutableStateListOf(0, 0) }
        val density = androidx.compose.ui.platform.LocalDensity.current
        val pagerMod = if (pageH[0] > 0 && pageH[1] > 0) {
            val f = (pager.currentPage + pager.currentPageOffsetFraction).coerceIn(0f, 1f)
            val hPx = pageH[0] + (pageH[1] - pageH[0]) * f
            Modifier.fillMaxWidth().height(with(density) { hPx.toDp() })
        } else Modifier.fillMaxWidth()
        androidx.compose.foundation.pager.HorizontalPager(state = pager, pageSpacing = 10.dp, verticalAlignment = Alignment.Top,
            beyondViewportPageCount = 1, modifier = pagerMod) { page ->
            // Animasi geser: halaman yang menjauh sedikit mengecil dan memudar, halaman yang masuk membesar dan menyala
            Box(Modifier.fillMaxWidth().wrapContentHeight(Alignment.Top, unbounded = true)
                .onSizeChanged { if (it.height > 0 && pageH[page] != it.height) pageH[page] = it.height }
                .graphicsLayer {
                val off = ((pager.currentPage - page) + pager.currentPageOffsetFraction).let { if (it < 0f) -it else it }.coerceIn(0f, 1f)
                val k = 1f - off
                transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0.5f, 0f)
                scaleX = 0.95f + 0.05f * k; scaleY = 0.95f + 0.05f * k
                alpha = 0.6f + 0.4f * k
                translationX = size.width * 0.03f * (if (pager.currentPage + pager.currentPageOffsetFraction > page) off else -off)
            }) {
            if (page == 0) {
            // Kartu Memori: judul di kiri, tombol pengaturan (Probe GPU + Diagnostik) di kanan atas
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {  // judul, RAM, ZRAM: masing-masing kartu terpisah
                Row(Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(20.dp)).padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Memori", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    s.mem?.let {
                        Text("${it.marketGb} GB", color = Color.White, fontSize = 12.sp,
                            modifier = Modifier.padding(start = 10.dp).background(Color(0xFF1E1F26).copy(alpha = 0.35f), CircleShape).padding(horizontal = 10.dp, vertical = 3.dp))
                    }
                    Spacer(Modifier.weight(1f))
                    Box(Modifier.size(32.dp).clip(CircleShape).background(Color(0xFF1E1F26).copy(alpha = 0.35f)).clickable { tools = true }, contentAlignment = Alignment.Center) {
                        Text("⚙", color = Color.White, fontSize = 16.sp)
                    }
                }
                val m = s.mem
                val rowCard = Modifier.background(Inner, RoundedCornerShape(20.dp)).padding(horizontal = 14.dp, vertical = 4.dp)
                if (m == null) {
                    Column(Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(20.dp)).padding(horizontal = 14.dp, vertical = 6.dp)) {
                        MeterRow("RAM", s.ramText, if (s.ramPct >= 0) s.ramPct / 100f else 0f, barLoad(s.ramPct))
                        if (s.swapText.isNotEmpty()) MeterRow("Swap", s.swapText, usedFrac(s.swapText), Color(0xFFF472B6))
                    }
                } else {
                    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        MemRow("RAM", m.ramTotal, m.ramUsed, m.ramFree, barLoad(s.ramPct), swap = false, modifier = rowCard)
                        if (m.swapTotal > 0f) MemRow(if (m.zram) "ZRAM" else "Swap", m.swapTotal, m.swapUsed, m.swapFree, Color(0xFFF472B6), swap = true, modifier = rowCard)
                        if (m.extraTotal > 0f) MemRow("Swap tambahan", m.extraTotal, m.extraUsed, (m.extraTotal - m.extraUsed).coerceAtLeast(0f), Color(0xFFF472B6), swap = true, modifier = rowCard)
                    }
                }
            }
            } else CpuCard(s)
            }
        }
        // Penanda halaman geser: pil aksen meluncur mengikuti jari (bukan loncat), dua titik putih di bawahnya.
        // Area penanda juga bisa digeser kiri-kanan atau diketuk (kiri = Memori, kanan = Status CPU) untuk pindah halaman.
        val pill = 22.dp; val dot = 8.dp; val travel = 16.dp
        val slide = (pager.currentPage + pager.currentPageOffsetFraction).coerceIn(0f, 1f)
        Box(Modifier.fillMaxWidth().padding(top = 2.dp).height(28.dp)
            .pointerInput(Unit) {
                detectTapGestures { pos -> scope.launch { pager.animateScrollToPage(if (pos.x < size.width / 2f) 0 else 1) } }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragEnd = {
                        scope.launch {
                            val f = pager.currentPageOffsetFraction
                            val target = when { f > 0.2f -> pager.currentPage + 1; f < -0.2f -> pager.currentPage - 1; else -> pager.currentPage }
                            pager.animateScrollToPage(target.coerceIn(0, 1))
                        }
                    },
                    onDragCancel = { scope.launch { pager.animateScrollToPage(pager.currentPage) } }
                ) { change, dx -> change.consume(); scope.launch { pager.scrollBy(-dx) } }
            }, contentAlignment = Alignment.Center) {
            Box(Modifier.width(pill + travel).height(8.dp)) {
                Box(Modifier.align(Alignment.CenterStart).size(dot).background(Color(0x99FFFFFF), CircleShape))
                Box(Modifier.align(Alignment.CenterEnd).size(dot).background(Color(0x99FFFFFF), CircleShape))
                Box(Modifier.offset { androidx.compose.ui.unit.IntOffset((slide * travel.toPx()).toInt(), 0) }
                    .width(pill).height(8.dp).background(acc(), CircleShape))
            }
        }
        DeviceInfoCard(s)
    }

    /** Tab Baterai: ringkasan langsung (level, daya, suhu) dan pintu ke riwayat baterai. */
    @Composable
    private fun BatteryTab(s: Snap) {
        // Ikon baterai yang terisi sesuai level (hijau; kuning <= 30%, merah <= 15%)
        val frac by animateFloatAsState(if (s.batPct >= 0) s.batPct / 100f else 0f, tween(500), label = "batFill")
        val batCol = when { s.batPct in 0..15 -> Color(0xFFFF6B6B); s.batPct in 0..30 -> Color(0xFFFFD866); else -> NavColors[2] }
        Row(Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(24.dp)).padding(horizontal = 18.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.padding(top = 8.dp)) {
                Box(Modifier.size(52.dp, 84.dp).border(3.dp, batCol, RoundedCornerShape(12.dp)).padding(3.dp), contentAlignment = Alignment.BottomCenter) {
                    Box(Modifier.fillMaxWidth().fillMaxHeight(frac.coerceIn(0f, 1f)).background(batCol, RoundedCornerShape(7.dp)))
                }
                Box(Modifier.align(Alignment.TopCenter).offset(y = (-8).dp).size(16.dp, 5.dp).background(batCol, RoundedCornerShape(2.dp)))
            }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text("Level baterai", color = Grey, fontSize = 12.sp)
                Text(if (s.batPct >= 0) "${s.batPct}%" else "-", color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.ExtraBold)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(if (s.watt >= 0f) "%.1f W".format(s.watt) else "-", color = acc(), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(if (s.tBat >= 0f) "%.0f°C".format(s.tBat) else "-", color = Grey, fontSize = 13.sp)
            }
        }
        BatteryHistoryCard()
        BatteryOngoingCard()
    }

    /** Kartu di tab Baterai: buka riwayat baterai (grafik level / daya / suhu dan pemakaian per aplikasi). */
    @Composable
    private fun BatteryHistoryCard() {
        val ver by BatteryHistory.version.collectAsState()
        val count by produceState(0, ver / 3) { value = withContext(Dispatchers.IO) { BatteryHistory.list(this@MainActivity).size } }
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Inner).clickable { batPage = 0L }
            .padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Riwayat baterai", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(if (count == 0) "Terekam otomatis saat aplikasi dibuka" else "$count sesi · pemakaian per aplikasi",
                    color = Grey, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text("›", color = Grey, fontSize = 26.sp)
        }
    }

    /** Kartu "Sedang berjalan" di tab Baterai: empat kotak (layar menyala/mati, terjaga, tidur lelap) dan baris baterai terpakai, sejak dicabut dari charger. */
    @Composable
    private fun BatteryOngoingCard() {
        val og by produceState(BatteryStats.ongoing()) { while (true) { value = BatteryStats.ongoing(); delay(1000) } }
        val amber = Color(0xFFE8B84A); val blue = Color(0xFF6FA8FF); val green = Color(0xFF5BD68E); val purple = Color(0xFFA78BFA)
        val tile = Color(0x0DFFFFFF)
        @Composable fun Tile(label: String, value: String, mod: Modifier, icon: @Composable () -> Unit) {
            Column(mod.background(tile, RoundedCornerShape(18.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(22.dp), contentAlignment = Alignment.CenterStart) { icon() }
                    Text(label, color = Grey, fontSize = 12.sp, maxLines = 1)
                }
                Text(value, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            }
        }
        Column(Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(24.dp)).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.Bottom) {
                Text("Sedang berjalan", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                Text("  ·  sejak dicabut", color = Grey, fontSize = 11.sp, modifier = Modifier.padding(bottom = 1.dp))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Tile("Layar menyala", og.on, Modifier.weight(1f)) { SunIcon(amber) }
                Tile("Layar mati", og.off, Modifier.weight(1f)) { MoonIcon(blue) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Tile("Terjaga", og.awake, Modifier.weight(1f)) { EyeIcon(green) }
                Tile("Tidur lelap", og.deep, Modifier.weight(1f)) { Text("Zz", color = purple, fontSize = 14.sp, fontWeight = FontWeight.Bold) }
            }
            Row(Modifier.fillMaxWidth().background(tile, RoundedCornerShape(18.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(22.dp), contentAlignment = Alignment.CenterStart) { BatteryNavIcon(Color.White) }
                Text("Baterai terpakai", color = Grey, fontSize = 12.sp, modifier = Modifier.weight(1f))
                Text(og.used, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                if (og.mah.isNotEmpty()) Text("  ${og.mah}", color = Color.White, fontSize = 13.sp)
            }
        }
    }

    /** Baca properti sistem lewat getprop (tanpa izin); kosong bila tidak ada. */
    private fun sysProp(key: String): String = try {
        val pr = Runtime.getRuntime().exec(arrayOf("getprop", key))
        pr.inputStream.bufferedReader().use { it.readText() }.trim()
    } catch (e: Exception) { "" }

    private fun androidName(sdk: Int) = when (sdk) {
        36 -> "Baklava"; 35 -> "Vanilla Ice Cream"; 34 -> "Upside Down Cake"; 33 -> "Tiramisu"
        32, 31 -> "Snow Cone"; 30 -> "Red Velvet Cake"; 29 -> "Quince Tart"; else -> ""
    }

    private fun fmtUptime(ms: Long): String {
        val t = ms / 1000
        return "%dj %dm %dd".format(t / 3600, (t % 3600) / 60, t % 60)
    }

    /** Kartu info perangkat: nama HP, chipset, versi Android, waktu aktif dan deep sleep (diperbarui tiap detik). */
    @Composable
    private fun DeviceCard() {
        val info by produceState(listOf("", ""), refreshTick) {
            value = withContext(Dispatchers.IO) {
                val market = sysProp("ro.product.marketname").ifEmpty { sysProp("ro.product.model") }.ifEmpty { Build.MODEL }
                val brand = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
                val name = if (market.startsWith(brand, true)) market else "$brand $market"
                val soc = if (Build.VERSION.SDK_INT >= 31 && Build.SOC_MODEL.isNotEmpty() && Build.SOC_MODEL != "unknown")
                    "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}".trim() else Build.HARDWARE
                listOf(name, soc)
            }
        }
        val up by produceState(0L to 0L) {
            while (true) {
                value = android.os.SystemClock.elapsedRealtime() to android.os.SystemClock.uptimeMillis()
                delay(1000)
            }
        }
        val awake = up.first; val sleep = (up.first - up.second).coerceAtLeast(0L)
        val sleepPct = if (awake > 0) (sleep * 100 / awake).toInt() else 0
        val an = androidName(Build.VERSION.SDK_INT)
        val isPoco = Build.BRAND.equals("poco", true)
        val badgeBg = if (isPoco) Color(0xFFFFD500) else Color(0xFF101116)
        val badgeFg = if (isPoco) Color.Black else Color.White
        val accent = Color(0xFF9AA0A6)
        val accentSoft = Color(0xFFD3D7DC)
        val shape = RoundedCornerShape(24.dp)
        @Composable fun Chip(text: String, tint: Color = Color(0x1FFFFFFF), fg: Color = Color(0xFFE6E8EB)) =
            Text(text, color = fg, fontSize = 11.5.sp, fontWeight = FontWeight.Medium, maxLines = 1,
                modifier = Modifier.background(tint, RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 4.dp))
        @Composable fun Tile(value: String, label: String, valueColor: Color = Color.White, mod: Modifier) =
            Column(mod.background(Color(0x14FFFFFF), RoundedCornerShape(16.dp)).padding(horizontal = 14.dp, vertical = 10.dp)) {
                Text(label, color = Grey, fontSize = 11.sp, maxLines = 1)
                Text(value, color = valueColor, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            }
        Column(
            Modifier.fillMaxWidth()
                .clip(shape)
                .background(Brush.linearGradient(listOf(Color(0xFF3A3D42).copy(alpha = 0.34f), Color(0xFF17181B).copy(alpha = 0.30f), Color(0xFF0A0B0C).copy(alpha = 0.30f))), shape)
                .border(1.dp, Brush.linearGradient(listOf(accent.copy(alpha = 0.6f), Color(0x14FFFFFF))), shape)
                .padding(16.dp)
        ) {
            // Atas: lencana merek + nama HP + chip chipset / versi Android
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(56.dp).background(badgeBg, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
                    Text(Build.BRAND.uppercase(), color = badgeFg, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, maxLines = 1)
                }
                Column(Modifier.padding(start = 14.dp).weight(1f)) {
                    Text(info[0], color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (info[1].isNotEmpty()) Chip(info[1])
                        Chip(if (an.isNotEmpty()) "Android ${Build.VERSION.RELEASE} · $an" else "Android ${Build.VERSION.RELEASE}",
                            accent.copy(alpha = 0.22f), accentSoft)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            // Dua kotak ringkas: waktu aktif dan deep sleep
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Tile(fmtUptime(awake), "Waktu aktif", mod = Modifier.weight(1f))
                Tile(fmtUptime(sleep), "Deep sleep • $sleepPct%", valueColor = accentSoft, mod = Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
            // Bilah tipis: porsi deep sleep dari total waktu aktif
            Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(Color(0x1FFFFFFF))) {
                Box(Modifier.fillMaxWidth((sleepPct / 100f).coerceIn(0.02f, 1f)).fillMaxHeight()
                    .background(Brush.horizontalGradient(listOf(accent, accentSoft)), RoundedCornerShape(3.dp)))
            }
        }
    }

    /** Jalankan probe node GPU di thread terpisah lalu salin hasilnya ke clipboard. */
    private fun runResProbe() {
        Toast.makeText(this, "Membaca layer game...", Toast.LENGTH_SHORT).show()
        Thread {
            val t = runCatching { Sampler.resProbe() }.getOrDefault("")
            runOnUiThread {
                if (t.isBlank()) Toast.makeText(this, "Tidak ada hasil (butuh Shizuku/root)", Toast.LENGTH_SHORT).show()
                else {
                    val cm = getSystemService(android.content.ClipboardManager::class.java)
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("res-probe", t))
                    Toast.makeText(this, "Tersalin (${t.length} karakter). Tempel ke chat.", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun runGpuProbe() {
        Toast.makeText(this, "Membaca node GPU...", Toast.LENGTH_SHORT).show()
        Thread {
            val t = Sampler.gpuProbe()
            runOnUiThread {
                if (t.isBlank()) Toast.makeText(this, "Tidak ada hasil (butuh Shizuku/root)", Toast.LENGTH_SHORT).show()
                else {
                    val cm = getSystemService(android.content.ClipboardManager::class.java)
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("gpu-probe", t))
                    Toast.makeText(this, "Tersalin (${t.length} karakter). Tempel ke chat.", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    /** Dialog di kartu Status CPU: suhu CPU, GPU, dan baterai (dulunya kartu Suhu terpisah). */
    @Composable
    private fun CpuTempDialog(s: Snap, onDismiss: () -> Unit) {
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Color.Black,
            shape = RoundedCornerShape(28.dp),
            title = {
                Column {
                    Text("Suhu", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 22.sp)
                    Text("CPU, GPU, dan Baterai", color = Grey, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    TempMeter("CPU", s.tCpu); TempMeter("GPU", s.tGpu); TempMeter("Baterai", s.tBat)
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text("Tutup", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
        )
    }

    /** Dialog pengaturan di kartu Memori: Probe GPU sekarang bagian dari Diagnostik. */
    @Composable
    private fun StatsToolsDialog(s: Snap, onDismiss: () -> Unit) {
        var diag by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Color.Black,
            shape = RoundedCornerShape(28.dp),
            title = {
                Column {
                    Text("Pengaturan Statistik", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 22.sp)
                    Text("Probe GPU dan Diagnostik", color = Grey, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
                }
            },
            text = {
                Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SettingCard("Diagnostik") {
                        Text("Probe GPU membaca semua node GPU di HP ini dan menyalinnya ke clipboard, untuk mencari sumber frekuensi yang benar.", color = Grey, fontSize = 12.sp)
                        if (s.access != "-") PillButton("Probe GPU dan salin") { runGpuProbe() }
                        else Text("Probe GPU butuh akses Shizuku atau Root (tab Settings).", color = Color(0xFFE0B040), fontSize = 12.sp)
                        Text("Probe resolusi menyalin cuplikan layer game supaya cara bacanya bisa disesuaikan. Buka game dulu dengan overlay menyala.", color = Grey, fontSize = 12.sp)
                        if (s.access != "-") PillButton("Probe resolusi game dan salin") { runResProbe() }
                        if (s.dbg.isNotEmpty()) {
                            PillButton(if (diag) "Sembunyikan" else "Tampilkan", filled = false) { diag = !diag }
                            if (diag) Text(s.dbg, color = Grey, fontSize = 10.5.sp, lineHeight = 15.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text("Tutup", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
        )
    }

    @Composable
    private fun DisplayContent() {
        // 0 = tutup, 2 = warna dan ukuran overlay, 3 = transparan panel
        var dlg by remember { mutableIntStateOf(0) }
        SettingCard("Wallpaper") {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PillButton(if (wallpaperBmp == null) "Pilih gambar" else "Ganti gambar") {
                    pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
                if (wallpaperBmp != null) PillButton("Hapus", filled = false) { WallpaperStore.clear(this@MainActivity); wallpaperBmp = null }
            }
            if (wallpaperBmp == null) Text("Belum ada gambar. Pilih satu untuk jadi latar aplikasi.", color = Grey, fontSize = 12.sp)
            if (wallpaperBmp != null) {
                SliderLabel("Redupkan latar", "${(dim * 100).toInt()}%")
                AccSlider(dim, 0f..0.9f,{ dim = it }) { WallpaperStore.saveDim(this@MainActivity, dim) }
            }
        }
        NavCard("Warna dan ukuran overlay", "Aksen, teks, latar, suhu, dan ukuran", { dlg = 2 }) {
            Box(Modifier.size(22.dp).background(Color(AppSettings.accent), CircleShape).border(1.dp, Color(0x33FFFFFF), CircleShape))
            Spacer(Modifier.width(6.dp))
            Box(Modifier.size(22.dp).background(Color(AppSettings.overlayText), CircleShape).border(1.dp, Color(0x33FFFFFF), CircleShape))
            Spacer(Modifier.width(6.dp))
            Box(Modifier.size(22.dp).background(Color(AppSettings.overlayBg), CircleShape).border(1.dp, Color(0x33FFFFFF), CircleShape))
        }
        NavCard("Transparan panel", "Panel dan navigasi", { dlg = 3 }) {
            Text("${AppSettings.panelAlpha}%", color = acc(), fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
        if (dlg == 2) TabDialog("Warna dan ukuran overlay", "Perubahan muncul dalam sekitar 1 detik", { dlg = 0 }) { ColorContent() }
        if (dlg == 3) TabDialog("Transparan panel", "Panel dan navigasi", { dlg = 0 }) { SizeContent() }
    }

    /** Dialog umum untuk pengaturan tampilan di tab Settings: judul, keterangan, isi bisa digulir, tombol Tutup. */
    @Composable
    private fun TabDialog(title: String, sub: String, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Color.Black,
            shape = RoundedCornerShape(28.dp),
            title = {
                Column {
                    Text(title, color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 22.sp)
                    Text(sub, color = Grey, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
                }
            },
            text = { Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) { content() } },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text("Tutup", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
        )
    }

    /** Kartu satu baris yang membuka dialog; isi kecil (pratinjau nilai) tampil di kanan. */
    @Composable
    private fun NavCard(title: String, sub: String, onClick: () -> Unit, trailing: @Composable RowScope.() -> Unit) {
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Inner).clickable { onClick() }.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold)
                Text(sub, color = Grey, fontSize = 12.sp)
            }
            trailing()
            Text("  ›", color = Grey, fontSize = 22.sp)
        }
    }

    @Composable
    private fun SizeContent() {
        val ctx = LocalContext.current
        SettingCard("Transparan panel") {
            SliderLabel("Seberapa tembus panel dan navigasi", "${AppSettings.panelAlpha}%")
            AccSlider(AppSettings.panelAlpha / 100f, 0.15f..1f, { AppSettings.panelAlpha = (it * 100).toInt().coerceIn(15, 100) }) { AppSettings.save(ctx) }
            PillButton("Kembalikan bawaan", filled = false) { AppSettings.panelAlpha = AppSettings.DEF_PANEL; AppSettings.save(ctx) }
        }
    }

    /** Pratinjau gaya Simple dan Normal (kartu kecil): label gradasi biru-ungu-pink, isi dan urutan baris sama dengan overlay aslinya. */
    private fun previewText(idx: Int): AnnotatedString {
        val yel = Color(0xFFFFD866)
        val s0 = Color(0xFF5E9BF5); val s1 = Color(0xFF9A86E8); val s2 = Color(0xFFEE8FBE)
        fun at(f: Float): Color = if (f < 0.5f) androidx.compose.ui.graphics.lerp(s0, s1, f * 2f) else androidx.compose.ui.graphics.lerp(s1, s2, (f - 0.5f) * 2f)
        return buildAnnotatedString {
            fun p(t: String, c: Color = Color.Unspecified, b: Boolean = false) =
                withStyle(SpanStyle(color = c, fontWeight = if (b) FontWeight.Bold else null)) { append(t) }
            fun g(t: String) = t.forEachIndexed { i, ch -> p(ch.toString(), at(if (t.length > 1) i / (t.length - 1f) else 1f)) }
            fun pd(t: String, n: Int) = t.padStart(n)
            fun pe(t: String, n: Int) = t.padEnd(n)
            if (idx == 0) {
                g("FPS"); p(" "); p("60", b = true)
                p("  "); g("CPU"); p(" 35% 42°")
                p("  "); g("GPU"); p(" 45% 41°")
                p("  "); g("RAM"); p(" 62%")
                p("  "); g("BAT"); p(" 85% 36°")
            } else {
                val gap = "  "
                g("FPS"); p(gap + pe("60", 4)); p("16.7ms", yel); p("\n")
                g("CPU"); p(gap + pe("35%", 4) + pe("42°", 4)); p(pd("1800", 4) + "MHz", yel); p("\n")
                g("GPU"); p(gap + pe("45%", 4) + pe("41°", 4)); p(pd("680", 4) + "MHz", yel); p("\n")
                g("BAT"); p(gap + pe("85%", 4) + pe("36°", 4)); p("2.4W", yel); p("\n")
                g("GOV"); p(gap); p("sugov_ext", yel); p("\n")
                g("RAM"); p(gap + "62%")
            }
        }
    }

    /** Label gradasi biru, ungu, pink per huruf: sama dengan label overlay Normal asli. */
    private fun gradLabel(t: String): AnnotatedString {
        val stops = intArrayOf(0xFF5E9BF5.toInt(), 0xFF9A86E8.toInt(), 0xFFEE8FBE.toInt())
        fun ch(c: Int, sh: Int) = c ushr sh and 255
        fun mix(a: Int, b: Int, f: Float): Int {
            fun m(sh: Int) = (ch(a, sh) + (ch(b, sh) - ch(a, sh)) * f).toInt()
            return (0xFF shl 24) or (m(16) shl 16) or (m(8) shl 8) or m(0)
        }
        fun at(f: Float): Int = if (f < 0.5f) mix(stops[0], stops[1], f * 2f) else mix(stops[1], stops[2], (f - 0.5f) * 2f)
        return buildAnnotatedString {
            t.forEachIndexed { i, c ->
                withStyle(SpanStyle(color = Color(at(if (t.length > 1) i / (t.length - 1f) else 1f)))) { append(c.toString()) }
            }
        }
    }

    /** Pratinjau gaya Normal: FPS besar di kiri, cincin CPU/GPU (label + persen di dalam, MHz di bawah), garis tipis, baris RAM/BAT. Sama dengan overlay asli. */
    @Composable
    private fun CompactPreview() {
        val tx = Color(AppSettings.overlayText)
        val yel = Color(0xFFFFD866)
        val grn = Color(0xFF7CFFB2)
        val pv = RoundedCornerShape(12.dp)
        val mono = androidx.compose.ui.text.font.FontFamily.Monospace
        @Composable fun Ring(label: String, pct: Int, mhz: String) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(58.dp), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.fillMaxSize()) {
                        val sw = 4.5.dp.toPx(); val r = 23.dp.toPx()
                        val tl = Offset(size.width / 2f - r, size.height / 2f - r)
                        val sz = androidx.compose.ui.geometry.Size(r * 2f, r * 2f)
                        drawArc(color = tx.copy(alpha = 0.16f), startAngle = -90f, sweepAngle = 360f, useCenter = false,
                            topLeft = tl, size = sz, style = Stroke(width = sw))
                        drawArc(color = Color(loadCol(pct)), startAngle = -90f, sweepAngle = 360f * pct / 100f, useCenter = false,
                            topLeft = tl, size = sz, style = Stroke(width = sw, cap = StrokeCap.Round))
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(label, color = tx, fontSize = 9.5.sp, lineHeight = 11.sp, fontWeight = FontWeight.Bold, fontFamily = mono)
                        Text("$pct%", color = tx, fontSize = 12.5.sp, lineHeight = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Text(mhz, color = yel, fontSize = 10.5.sp, lineHeight = 15.sp, fontFamily = mono, softWrap = false)
            }
        }
        Column(Modifier.width(IntrinsicSize.Max).clip(pv).background(Color(withAlpha(AppSettings.overlayBg, AppSettings.alpha)))
            .border(1.dp, Color(withAlpha(AppSettings.overlayText, 14)), pv)
            .padding(horizontal = 14.dp, vertical = 10.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                // Blok FPS: sejajar vertikal dengan cincin, label di tengah atas angka
                Column(Modifier.height(58.dp).widthIn(min = 32.dp), verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("FPS", color = tx, fontSize = 10.5.sp, lineHeight = 14.sp, fontFamily = mono)
                    Text("60", color = tx, fontSize = 26.sp, lineHeight = 28.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(16.dp))
                Ring("CPU", 35, "2840MHz")
                Spacer(Modifier.width(14.dp))
                Ring("GPU", 45, "680MHz")
            }
            Box(Modifier.padding(vertical = 8.dp).fillMaxWidth().height(0.5.dp).background(tx.copy(alpha = 0.14f)))
            Text(buildAnnotatedString {
                withStyle(SpanStyle(color = tx)) { append("RAM 62%   BAT ") }
                withStyle(SpanStyle(color = grn)) { append("36°") }
                withStyle(SpanStyle(color = yel)) { append(" 2.4W") }
            }, fontSize = 10.5.sp, lineHeight = 15.sp, fontFamily = mono, softWrap = false)
        }
    }

    /** Pratinjau gaya Compact (bilah): baris FPS + bilah CPU/GPU + baris teks BAT/TMP, sama dengan overlay aslinya. */
    @Composable
    private fun RingPreview() {
        val tx = Color(AppSettings.overlayText)
        val yel = Color(0xFFFFD866)
        val pv = RoundedCornerShape(14.dp)
        Column(Modifier.clip(pv).background(Color(withAlpha(AppSettings.overlayBg, AppSettings.alpha)))
            .border(1.dp, Color(withAlpha(AppSettings.overlayText, 14)), pv)
            .padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.width(196.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("FPS", color = tx, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(32.dp))
                Text("60", color = tx, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("16.7ms", color = yel, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            PreviewBar("CPU", 0.35f, Color(loadCol(35)), "3300MHz", tx, yel)
            PreviewBar("GPU", 0.92f, Color(loadCol(92)), "702MHz", tx, yel)
            Text(buildAnnotatedString {
                withStyle(SpanStyle(color = tx)) { append("BAT ") }
                withStyle(SpanStyle(color = yel)) { append("85%") }
                withStyle(SpanStyle(color = tx)) { append("   TMP ") }
                withStyle(SpanStyle(color = yel)) { append("36.0°C") }
            }, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }

    @Composable
    private fun PreviewBar(label: String, frac: Float, col: Color, value: String, tx: Color, yel: Color) {
        Row(Modifier.width(196.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = tx, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(32.dp))
            Box(Modifier.width(86.dp).height(6.dp).clip(RoundedCornerShape(3.dp)).background(tx.copy(alpha = 0.16f))) {
                Box(Modifier.fillMaxHeight().fillMaxWidth(frac).clip(RoundedCornerShape(3.dp)).background(col))
            }
            Text(value, color = yel, fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.End, modifier = Modifier.weight(1f))
        }
    }

    @Composable
    private fun StyleOption(idx: Int, title: String, sub: String, inDialog: Boolean = false, onPicked: () -> Unit = {}) {
        val ctx = LocalContext.current
        val sel = AppSettings.overlayStyle == idx
        val ac = acc()
        val border by animateColorAsState(if (sel) ac else Color(0x22FFFFFF), tween(200), label = "styBorder")
        val shape = RoundedCornerShape(20.dp)
        Column(Modifier.fillMaxWidth().clip(shape)
            .background(if (sel) ac.copy(alpha = 0.10f) else Color(0x12FFFFFF))
            .border(if (sel) 2.dp else 1.dp, border, shape)
            .clickable { AppSettings.overlayStyle = idx; AppSettings.save(ctx); onPicked() }.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(sub, color = Grey, fontSize = 12.sp)
                }
                Box(Modifier.size(24.dp).background(if (sel) ac else Color.Transparent, CircleShape)
                    .border(2.dp, if (sel) ac else Grey, CircleShape), contentAlignment = Alignment.Center) {
                    if (sel) Text("✓", color = Color(0xFF101014), fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
            val pv = RoundedCornerShape(if (idx == 0) 20.dp else 14.dp)
            if (idx == 2) RingPreview() else if (idx == 1) CompactPreview()
            else Text(previewText(idx), color = Color(AppSettings.overlayText), fontSize = 10.5.sp, lineHeight = 15.sp,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, softWrap = idx != 0 || inDialog, maxLines = if (idx == 0 && !inDialog) 1 else Int.MAX_VALUE,
                modifier = Modifier.clip(pv).background(Color(withAlpha(AppSettings.overlayBg, AppSettings.alpha)))
                    .border(1.dp, Color(withAlpha(AppSettings.accent, 33)), pv)
                    .padding(horizontal = 12.dp, vertical = if (idx == 0) 6.dp else 9.dp))
        }
    }

    @Composable
    private fun SettingsContent() {
        val ctx = LocalContext.current
        val s by Sampler.state.collectAsState()
        // Setelah memilih metode, status mengikuti Access langsung (bukan menunggu tick Sampler)
        val auto = Access.choice == Access.AUTO
        val connected = if (auto) s.access != "-" else Access.status == 2
        val root = if (auto && connected) s.access == "Root" else Access.isRoot()
        SettingCard("Akses") {
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable { Access.refresh(); accessDlg = true }.padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).background(Color(0xFF0A0A1A), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                    if (root) ShieldIcon(Color(0xFFE49A72), Modifier.size(24.dp)) else PhoneIcon(Color(0xFF8E86F0), Modifier.size(24.dp))
                }
                Column(Modifier.weight(1f).padding(start = 14.dp)) {
                    Text(if (root) "Root" else "Shizuku", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text(when {
                        Access.busy > 0 -> "Memeriksa…"
                        connected -> "Terhubung"
                        Access.status == 1 -> "Ketuk untuk beri izin"
                        root -> "Root tidak tersedia"
                        else -> "Tidak berjalan"
                    }, color = if (connected) Color(0xFF5BD68E) else Color(0xFFE0B040), fontSize = 13.sp)
                }
                Text("›", color = Grey, fontSize = 22.sp)
            }
        }
        // Satu baris berpanah (seperti Kesehatan & log): wallpaper, warna overlay, ukuran dan transparan ada di dalam dialognya
        var look by remember { mutableStateOf(false) }
        Row(Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(20.dp)).clickable { look = true }.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Wallpaper dan overlay", color = Color.White, fontWeight = FontWeight.Bold)
                Text("Wallpaper, warna, dan ukuran overlay", color = Grey, fontSize = 12.sp)
            }
            Text("›", color = Grey, fontSize = 22.sp)
        }
        if (look) TabDialog("Wallpaper dan overlay", "Wallpaper, warna, dan ukuran overlay", { look = false }) { DisplayContent() }
        // Kartu Pengaturan: tombol gear (sama seperti di kartu Memori) membuka dialog berisi semua pengaturan
        var cfg by remember { mutableStateOf(false) }
        Row(Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(20.dp)).clickable { cfg = true }.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Pengaturan", color = Color.White, fontWeight = FontWeight.Bold)
                Text("Latar belakang, info overlay, dan gaya overlay", color = Grey, fontSize = 12.sp)
            }
            Box(Modifier.size(34.dp).clip(CircleShape).background(Color(0xFF1E1F26).copy(alpha = 0.35f)).clickable { cfg = true }, contentAlignment = Alignment.Center) {
                Text("⚙", color = Color.White, fontSize = 18.sp)
            }
        }
        if (cfg) AppSettingsDialog { cfg = false }
        Row(Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(20.dp)).clickable { healthOpen = true }.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Kesehatan & log", color = Color.White, fontWeight = FontWeight.Bold)
                Text("Cek fitur jalan atau tidak, lalu kirim laporannya", color = Grey, fontSize = 12.sp)
            }
            Text("›", color = Grey, fontSize = 22.sp)
        }
        // Komunitas dan pembuat aplikasi: keduanya membuka Discord
        SettingCard("Komunitas") {
            LinkRow({ GamepadIcon(Color(0xFF8E86F0), Modifier.size(26.dp)) }, "Komunitas Discord", "") {
                openLink("https://discord.gg/EFaCxujTcC")
            }
            SettingDivider()
            LinkRow({ PersonIcon(Color(0xFFE49A72), Modifier.size(26.dp)) }, "Pembuat aplikasi", "lismoyca") {
                openLink("https://discord.com/users/1426827460187656223")
            }
        }
    }

    private fun openLink(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { Toast.makeText(this, "Tidak ada aplikasi untuk membuka tautan", Toast.LENGTH_SHORT).show() }
    }

    /** Dialog pengaturan di tab Settings: Latar belakang, Info tambahan di overlay, dan Gaya overlay. */
    @Composable
    private fun AppSettingsDialog(onDismiss: () -> Unit) {
        val ctx = LocalContext.current
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Color.Black,
            shape = RoundedCornerShape(28.dp),
            title = {
                Column {
                    Text("Pengaturan", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 22.sp)
                    Text("Latar belakang, info overlay, dan gaya overlay", color = Grey, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
                }
            },
            text = {
                Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SettingCard("Latar belakang") {
                        ToggleRow("Tetap aktif di latar belakang", "Notifikasi baterai tetap hidup walau overlay mati",
                            "Notifikasi baterai tetap hidup walau overlay dimatikan. Tanpa overlay dan tanpa pembacaan sensor, jadi ringan di RAM. Matikan saklar ini untuk menghapus notifikasi.",
                            AppSettings.bgMode) { on -> AppSettings.bgMode = on; AppSettings.save(ctx); applyBgMode(on) }
                        SettingDivider()
                        ToggleRow("Nama aplikasi di notifikasi", "Game atau aplikasi yang sedang dibuka",
                            "Nama game atau aplikasi yang sedang di depan (mis. Wuthering Waves, Discord) tampil di notifikasi baterai. Dibaca tiap 3 detik saat layar nyala. Butuh Shizuku atau root.",
                            AppSettings.notifApp) { on -> AppSettings.notifApp = on; AppSettings.save(ctx); Watchdog.sync(ctx, AppSettings.bgMode) }
                    }
                    SettingCard("Info tambahan di overlay") {
                        ToggleRow("Touch rate", "Angka Hz saat layar disentuh",
                            "Angka Hz muncul saat layar disentuh, \"-\" saat tidak. Butuh Shizuku atau root.",
                            AppSettings.touchRate) { on -> AppSettings.touchRate = on; AppSettings.save(ctx) }
                        SettingDivider()
                        ToggleRow("Latensi sentuh", "Angka ms tiap layar diketuk",
                            "Angka ms (terakhir dan rata-rata 20 ketukan) muncul tiap layar diketuk. Mengukur waktu dari driver sentuh sampai ke aplikasi, di luar waktu render layar. Tidak butuh Shizuku atau root.",
                            AppSettings.touchLat) { on -> AppSettings.touchLat = on; if (!on) TouchLatency.reset(); AppSettings.save(ctx) }
                        SettingDivider()
                        ToggleRow("Governor CPU", "Nama governor di gaya Normal",
                            "Nama governor CPU (mis. GOV sugov_ext) di gaya Normal; satu baris bila semua cluster sama. Butuh Shizuku atau root.",
                            AppSettings.cpuGov) { on -> AppSettings.cpuGov = on; AppSettings.save(ctx) }
                    }
                    // Satu baris: nama gaya yang aktif tampil di samping, ketuk untuk memilih gaya lain
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Inner).clickable { styleDlg = true }.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Gaya overlay", color = Color.White, fontWeight = FontWeight.Bold)
                            Text("Ketuk untuk memilih bentuk overlay", color = Grey, fontSize = 12.sp)
                        }
                        Text(AppSettings.STYLES[AppSettings.overlayStyle], color = acc(), fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text("  ›", color = Grey, fontSize = 22.sp)
                    }
                    if (styleDlg) StyleDialog { styleDlg = false }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text("Tutup", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
        )
    }

    @Composable
    private fun StyleDialog(onDismiss: () -> Unit) {
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Color.Black,
            shape = RoundedCornerShape(28.dp),
            title = { Text("Gaya overlay", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 24.sp) },
            text = {
                Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Pratinjau mengikuti warna dan transparansi di tab Settings.", color = Color(0xFFA9B0B5), fontSize = 13.sp)
                    StyleOption(0, "Simple", "Satu baris: FPS, CPU, GPU, baterai", inDialog = true, onPicked = onDismiss)
                    StyleOption(1, "Normal", "FPS besar dan cincin CPU, GPU", inDialog = true, onPicked = onDismiss)
                    StyleOption(2, "Compact", "Bilah per baris: FPS, CPU, GPU, dan baterai", inDialog = true, onPicked = onDismiss)
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text("Batal", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
        )
    }

    @Composable
    private fun AccessDialog(onDismiss: () -> Unit) {
        val cur = Access.choice
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Color.Black,
            shape = RoundedCornerShape(28.dp),
            title = { Text("Izinkan Akses", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 24.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Pilih metode yang ingin dipakai untuk akses tingkat tinggi.", color = Color(0xFFA9B0B5))
                    AccessOption("Shizuku", "Tanpa root, jalan lewat Wireless Debugging atau ADB.",
                        Color(0xFF8E86F0), Color(0xFF13111F), cur == Access.SHIZUKU, { PhoneIcon(Color(0xFF8E86F0), Modifier.size(30.dp)) }) {
                        Access.select(Access.SHIZUKU); onDismiss()
                    }
                    AccessOption("Root", "Butuh perangkat yang di-root (Magisk, KernelSU, APatch, dll).",
                        Color(0xFFE49A72), Color(0xFF181412), cur == Access.ROOT, { ShieldIcon(Color(0xFFE49A72), Modifier.size(30.dp)) }) {
                        Access.select(Access.ROOT); onDismiss()
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text("Batal", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
        )
    }

    /** Warna overlay (dialog dari tab Settings). */
    @Composable
    private fun ColorContent() {
        val ctx = LocalContext.current
        var accentDlg by remember { mutableStateOf(false) }
        if (accentDlg) AlertDialog(
            onDismissRequest = { accentDlg = false },
            containerColor = Color.Black,
            shape = RoundedCornerShape(28.dp),
            title = { Text("Warna aksen", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 22.sp) },
            text = { Swatches(AppSettings.ACCENTS, AppSettings.accent) { AppSettings.accent = it; AppSettings.save(ctx) } },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { accentDlg = false }) { Text("Selesai", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
        )
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Inner).clickable { accentDlg = true }.padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text("Warna aksen", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Box(Modifier.size(28.dp).background(Color(AppSettings.accent), CircleShape).border(1.dp, Color(0x33FFFFFF), CircleShape))
        }
        SettingCard("Warna teks overlay") {
            Swatches(AppSettings.TEXTS, AppSettings.overlayText) { AppSettings.overlayText = it; AppSettings.save(ctx) }
        }
        SettingCard("Latar overlay") {
            Swatches(AppSettings.BGS, AppSettings.overlayBg) { AppSettings.overlayBg = it; AppSettings.save(ctx) }
            SliderLabel("Transparan", "${AppSettings.alpha}%")
            AccSlider(AppSettings.alpha / 100f, 0.2f..1f, { AppSettings.alpha = (it * 100).toInt().coerceIn(20, 100) }) { AppSettings.save(ctx) }
        }
        SettingCard("Ukuran overlay") {
            SliderLabel("Besar kecil", "${AppSettings.size}%")
            AccSlider(AppSettings.size / 100f, 0.6f..2f, { AppSettings.size = ((it * 100).toInt() / 5 * 5).coerceIn(60, 200) }) { AppSettings.save(ctx) }
            PillButton("Ukuran normal", filled = false) { AppSettings.size = AppSettings.DEF_SIZE; AppSettings.save(ctx) }
        }
        SettingCard("Warna suhu") {
            Text("Berubah sesuai tingkat panas", color = Grey, fontSize = 12.sp)
            HeatLegend(30f, "Aman, di bawah 45°"); HeatLegend(50f, "Hangat, 45-54°")
            HeatLegend(60f, "Panas, 55-64°"); HeatLegend(70f, "Sangat panas, 65°+")
        }
        PillButton("Kembalikan warna awal", filled = false, modifier = Modifier.fillMaxWidth()) { AppSettings.reset(ctx) }
    }
}

@Composable
fun AccessOption(title: String, desc: String, accent: Color, bg: Color, selected: Boolean, icon: @Composable () -> Unit, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(bg)
        .border(if (selected) 2.dp else 1.dp, accent.copy(alpha = if (selected) 0.85f else 0.35f), RoundedCornerShape(20.dp))
        .clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        icon(); Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = accent, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Text(desc, color = Color(0xFFC4CACE), fontSize = 14.sp)
        }
    }
}

/** Ikon riwayat (daftar tiga baris dengan titik), digambar langsung. */
@Composable
fun HistoryIcon(c: Color, m: Modifier) = Canvas(m) {
    val w = size.width; val h = size.height; val sw = w * 0.1f
    listOf(0.22f, 0.5f, 0.78f).forEach { y ->
        drawCircle(c, sw * 0.8f, androidx.compose.ui.geometry.Offset(w * 0.1f, h * y))
        drawLine(c, androidx.compose.ui.geometry.Offset(w * 0.32f, h * y), androidx.compose.ui.geometry.Offset(w * 0.92f, h * y), sw, StrokeCap.Round)
    }
}

/** Ikon ponsel (Shizuku) dan perisai (Root), digambar langsung supaya tidak perlu pustaka ikon tambahan. */
/** Baris tautan: ikon, judul, keterangan di kanan, dan tanda buka-luar. */
@Composable
fun LinkRow(icon: @Composable () -> Unit, title: String, trailing: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { onClick() }.padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(34.dp), contentAlignment = Alignment.Center) { icon() }
        Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f).padding(start = 10.dp))
        if (trailing.isNotEmpty()) Text(trailing, color = Grey, fontSize = 14.sp, modifier = Modifier.padding(end = 8.dp))
        Text("↗", color = Grey, fontSize = 20.sp)
    }
}

/** Ikon gamepad (Discord) dan orang (pembuat), garis tipis digambar langsung. */
@Composable
fun GamepadIcon(c: Color, m: Modifier) = Canvas(m) {
    val w = size.width; val h = size.height; val st = Stroke(width = w * 0.09f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    drawRoundRect(c, androidx.compose.ui.geometry.Offset(w * 0.04f, h * 0.22f), androidx.compose.ui.geometry.Size(w * 0.92f, h * 0.56f),
        androidx.compose.ui.geometry.CornerRadius(w * 0.24f), style = st)
    drawLine(c, androidx.compose.ui.geometry.Offset(w * 0.28f, h * 0.4f), androidx.compose.ui.geometry.Offset(w * 0.28f, h * 0.6f), st.width, StrokeCap.Round)
    drawLine(c, androidx.compose.ui.geometry.Offset(w * 0.18f, h * 0.5f), androidx.compose.ui.geometry.Offset(w * 0.38f, h * 0.5f), st.width, StrokeCap.Round)
    drawCircle(c, w * 0.05f, androidx.compose.ui.geometry.Offset(w * 0.66f, h * 0.46f))
    drawCircle(c, w * 0.05f, androidx.compose.ui.geometry.Offset(w * 0.78f, h * 0.56f))
}

@Composable
fun PersonIcon(c: Color, m: Modifier) = Canvas(m) {
    val w = size.width; val h = size.height; val st = Stroke(width = w * 0.09f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    drawCircle(c, w * 0.2f, androidx.compose.ui.geometry.Offset(w * 0.5f, h * 0.3f), style = st)
    val p = Path().apply { moveTo(w * 0.14f, h * 0.9f); cubicTo(w * 0.14f, h * 0.55f, w * 0.86f, h * 0.55f, w * 0.86f, h * 0.9f); close() }
    drawPath(p, c, style = st)
}

@Composable
fun PhoneIcon(c: Color, m: Modifier) = Canvas(m) {
    val w = size.width * 0.55f; val h = size.height * 0.9f
    drawRoundRect(c, androidx.compose.ui.geometry.Offset((size.width - w) / 2, (size.height - h) / 2),
        androidx.compose.ui.geometry.Size(w, h), androidx.compose.ui.geometry.CornerRadius(size.width * 0.1f))
}

@Composable
fun ShieldIcon(c: Color, m: Modifier) = Canvas(m) {
    val w = size.width; val h = size.height
    val p = Path().apply {
        moveTo(w * 0.5f, h * 0.04f); lineTo(w * 0.92f, h * 0.2f); lineTo(w * 0.92f, h * 0.5f)
        cubicTo(w * 0.92f, h * 0.76f, w * 0.7f, h * 0.92f, w * 0.5f, h * 0.98f)
        cubicTo(w * 0.3f, h * 0.92f, w * 0.08f, h * 0.76f, w * 0.08f, h * 0.5f)
        lineTo(w * 0.08f, h * 0.2f); close()
    }
    drawPath(p, c)
}

@Composable
fun RowScope.NavItem(icon: String, label: String, selected: Boolean, color: Color, onClick: () -> Unit) {
    val col by animateColorAsState(if (selected) color else Grey, tween(220), label = "navCol")
    val sc by animateFloatAsState(if (selected) 1.15f else 1f, spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMedium), label = "navScale")
    Column(Modifier.weight(1f).clip(RoundedCornerShape(26.dp))
        .clickable { onClick() }.padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        if (icon == BAT_ICON) BatteryNavIcon(col, Modifier.graphicsLayer { scaleX = sc; scaleY = sc })
        else Text(icon, color = col, fontSize = 22.sp, modifier = Modifier.graphicsLayer { scaleX = sc; scaleY = sc })
        Text(label, color = col, fontSize = 11.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

/** Penanda untuk NavItem: pakai ikon baterai gambar sendiri, bukan karakter teks. */
const val BAT_ICON = "bat"

/** Ikon baterai tegak: badan bergaris, kepala kecil di atas, dan petir di dalamnya. Ukurannya disamakan dengan ikon teks tab lain (22sp). Warna mengikuti status tab. */
@Composable
fun BatteryNavIcon(color: Color, modifier: Modifier = Modifier) {
    Box(Modifier.fillMaxWidth().height(26.dp), contentAlignment = Alignment.Center) {
        Canvas(modifier.size(width = 15.dp, height = 19.dp)) {
            val w = size.width; val h = size.height
            val sw = 1.6.dp.toPx()
            // kepala baterai
            drawRoundRect(color, topLeft = Offset(w * 0.36f, 0f), size = androidx.compose.ui.geometry.Size(w * 0.28f, h * 0.10f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(1.5.dp.toPx()))
            // badan baterai
            drawRoundRect(color, topLeft = Offset(w * 0.08f + sw / 2f, h * 0.12f + sw / 2f),
                size = androidx.compose.ui.geometry.Size(w * 0.84f - sw, h * 0.88f - sw),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(3.dp.toPx()), style = Stroke(width = sw))
            // petir di dalam badan
            val bolt = Path().apply {
                moveTo(w * 0.58f, h * 0.30f); lineTo(w * 0.40f, h * 0.55f)
                lineTo(w * 0.60f, h * 0.60f); lineTo(w * 0.42f, h * 0.84f)
            }
            drawPath(bolt, color, style = Stroke(width = 1.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
}

/** Ikon matahari (layar menyala): lingkaran dengan delapan sinar. */
@Composable
fun SunIcon(color: Color) {
    Canvas(Modifier.size(22.dp)) {
        val c = center; val w = size.width; val sw = 1.8.dp.toPx()
        drawCircle(color, radius = w * 0.20f, center = c, style = Stroke(width = sw))
        for (i in 0 until 8) {
            val a = Math.toRadians(i * 45.0); val dx = Math.cos(a).toFloat(); val dy = Math.sin(a).toFloat()
            drawLine(color, Offset(c.x + dx * w * 0.32f, c.y + dy * w * 0.32f), Offset(c.x + dx * w * 0.46f, c.y + dy * w * 0.46f),
                strokeWidth = sw, cap = StrokeCap.Round)
        }
    }
}

/** Ikon bulan sabit (layar mati). */
@Composable
fun MoonIcon(color: Color) {
    Canvas(Modifier.size(22.dp)) {
        val w = size.width
        val a = Path().apply { addOval(androidx.compose.ui.geometry.Rect(Offset(w * 0.12f, w * 0.10f), androidx.compose.ui.geometry.Size(w * 0.76f, w * 0.76f))) }
        val b = Path().apply { addOval(androidx.compose.ui.geometry.Rect(Offset(w * 0.38f, 0f), androidx.compose.ui.geometry.Size(w * 0.70f, w * 0.70f))) }
        drawPath(Path.combine(androidx.compose.ui.graphics.PathOperation.Difference, a, b), color)
    }
}

/** Ikon mata terbuka (terjaga). */
@Composable
fun EyeIcon(color: Color) {
    Canvas(Modifier.size(22.dp)) {
        val w = size.width; val h = size.height
        val p = Path().apply {
            moveTo(w * 0.04f, h * 0.5f); quadraticBezierTo(w * 0.5f, h * 0.02f, w * 0.96f, h * 0.5f)
            quadraticBezierTo(w * 0.5f, h * 0.98f, w * 0.04f, h * 0.5f); close()
        }
        drawPath(p, color, style = Stroke(width = 1.8.dp.toPx(), join = StrokeJoin.Round))
        drawCircle(color, radius = w * 0.15f, center = center)
    }
}

@Composable
fun BigCard(title: String, value: String, sub: String, selected: Boolean, m: Modifier) {
    val shape = RoundedCornerShape(24.dp)
    Column(m.background(Inner, shape)
        .then(if (selected) Modifier.border(1.5.dp, acc().copy(alpha = 0.85f), shape) else Modifier)
        .padding(horizontal = 16.dp, vertical = 10.dp)) {
        Text(title, color = Grey, fontSize = 13.sp)
        Text(value, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
        Text(sub, color = Grey, fontSize = 12.sp, maxLines = 1)
    }
}

/** Warna beban: hijau normal, kuning mulai berat, merah hampir penuh. */
fun loadColor(p: Int): Color = when {
    p < 0 -> Color.White
    p < 60 -> Color.White
    p < 85 -> Color(0xFFFFD866)
    else -> Color(0xFFFF6B6B)
}

@Composable
fun RowScope.MetricDivider() = Box(Modifier.width(1.dp).height(34.dp).background(Color(0x1FFFFFFF)))

@Composable
fun RowScope.Metric(label: String, main: String, sub: String, subTemp: Float, mainTemp: Float = -1f, mainColor: Color? = null) {
    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = Grey, fontSize = 12.sp)
        Text(main, color = mainColor ?: if (mainTemp >= 0) Color(heat(mainTemp)) else Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        if (sub.isNotEmpty()) Text(sub, color = if (subTemp >= 0) Color(heat(subTemp)) else Grey, fontSize = 13.sp, textAlign = TextAlign.Center)
    }
}

@Composable
fun InfoRow(label: String, value: String, t: Float? = null) {
    Row(Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(20.dp)).padding(horizontal = 18.dp, vertical = 14.dp)) {
        Text(label, color = Grey, modifier = Modifier.weight(1f))
        Text(value, color = if (t != null && t >= 0) Color(heat(t)) else Color.White, fontWeight = FontWeight.Bold)
    }
}

/** Baris saklar ringkas: judul + satu baris keterangan; ikon ⓘ membuka penjelasan lengkap di bawahnya. */
@Composable
fun ToggleRow(title: String, short: String, detail: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                Text(short, color = Grey, fontSize = 12.sp)
            }
            Box(Modifier.size(32.dp).clip(CircleShape).clickable { open = !open }, contentAlignment = Alignment.Center) {
                Text(if (open) "▴" else "ⓘ", color = Grey, fontSize = 16.sp)
            }
            Spacer(Modifier.width(4.dp))
            Switch(checked = checked, onCheckedChange = onChange)
        }
        if (open) Text(detail, color = Grey, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp, end = 8.dp))
    }
}

@Composable
fun SettingDivider() = Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x14FFFFFF)))

@Composable
fun SettingCard(title: String, content: @Composable ColumnScope.() -> Unit) = Column(
    Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(20.dp)).padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
) { Text(title, color = Color.White, fontWeight = FontWeight.Bold); content() }

@Composable
fun Swatches(colors: List<Int>, selected: Int, onPick: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        colors.forEach { c ->
            val on = c == selected
            Box(Modifier.size(38.dp).background(Color(c), CircleShape)
                .border(if (on) 2.5.dp else 1.dp, if (on) Color.White else Color(0x33FFFFFF), CircleShape)
                .clickable { onPick(c) }, contentAlignment = Alignment.Center) {
                if (on) Text("✓", color = if (Color(c).luminance() > 0.5f) Color(0xFF101014) else Color.White, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

@Composable
fun SectionTitle(t: String) = Text(t, color = Grey, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 6.dp, top = 4.dp))

@Composable
fun SliderLabel(label: String, value: String) = Row(Modifier.fillMaxWidth()) {
    Text(label, color = Grey, fontSize = 12.sp, modifier = Modifier.weight(1f))
    Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
}

@Composable
fun AccSlider(value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit, onDone: () -> Unit) {
    Slider(value = value, onValueChange = onChange, valueRange = range, onValueChangeFinished = onDone,
        colors = SliderDefaults.colors(thumbColor = acc(), activeTrackColor = acc(), inactiveTrackColor = Color(0x22FFFFFF)))
}

/** Tombol seragam: terisi (aksi utama) atau garis tepi (aksi sekunder). */
@Composable
fun PillButton(text: String, filled: Boolean = true, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(modifier.clip(shape)
        .then(if (filled) Modifier.background(Blue) else Modifier.border(1.dp, Color(0x33FFFFFF), shape))
        .clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 10.dp), contentAlignment = Alignment.Center) {
        Text(text, color = if (filled) Color(0xFF0C0C0E) else Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** Baris ukuran dengan batang: label + nilai di atas, batang tipis di bawah. */
@Composable
fun MeterRow(label: String, value: String, frac: Float, color: Color, valueColor: Color = Color.White) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Grey, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text(value, color = valueColor, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
        Box(Modifier.fillMaxWidth().height(5.dp).background(Color(0x1FFFFFFF), CircleShape)) {
            Box(Modifier.fillMaxWidth(frac.coerceIn(0f, 1f)).fillMaxHeight().background(color, CircleShape))
        }
    }
}

/** Blok memori: nama + total di atas, terpakai + bebas di tengah, batang di bawah. */
/** Garis pemisah tipis antar blok memori. */
@Composable
fun MemDivider() {
    Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF2A2C36)))
}

/** Baris memori: chip ikon, label + persen, batang animasi, lalu terpakai dari total dan sisa bebas. */
@Composable
fun MemRow(label: String, total: Float, used: Float, free: Float, color: Color, swap: Boolean, modifier: Modifier = Modifier) {
    val frac = if (total > 0f) (used / total).coerceIn(0f, 1f) else 0f
    val anim by animateFloatAsState(frac, tween(600), label = "memFrac")
    val dim = Color.White
    Row(modifier.fillMaxWidth().padding(vertical = 8.dp),   // tanpa kotak dalam: baris langsung di atas kartu Memori
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Box(Modifier.size(44.dp).background(chipBg(color), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(22.dp)) {
                val w = size.width; val sw = w * 0.09f
                val st = Stroke(width = sw, cap = StrokeCap.Round)
                if (!swap) {
                    // ikon chip RAM: badan + kaki di atas dan bawah
                    drawRoundRect(color, androidx.compose.ui.geometry.Offset(w * 0.2f, w * 0.26f),
                        androidx.compose.ui.geometry.Size(w * 0.6f, w * 0.48f),
                        androidx.compose.ui.geometry.CornerRadius(w * 0.08f), style = st)
                    for (i in 0..2) {
                        val x = w * (0.34f + 0.16f * i)
                        drawLine(color, androidx.compose.ui.geometry.Offset(x, w * 0.1f), androidx.compose.ui.geometry.Offset(x, w * 0.26f), sw, StrokeCap.Round)
                        drawLine(color, androidx.compose.ui.geometry.Offset(x, w * 0.74f), androidx.compose.ui.geometry.Offset(x, w * 0.9f), sw, StrokeCap.Round)
                    }
                } else {
                    // ikon tumpukan lapisan untuk ZRAM / Swap
                    for (i in 0..2) {
                        drawRoundRect(color.copy(alpha = if (i == 2) 1f else 0.55f),
                            androidx.compose.ui.geometry.Offset(w * 0.12f, w * (0.14f + 0.27f * i)),
                            androidx.compose.ui.geometry.Size(w * 0.76f, w * 0.18f),
                            androidx.compose.ui.geometry.CornerRadius(w * 0.09f))
                    }
                }
            }
        }
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, modifier = Modifier.weight(1f))
                Text(buildAnnotatedString {
                    withStyle(SpanStyle(fontSize = 13.sp, fontWeight = FontWeight.SemiBold)) { append("${Math.round(frac * 100)}") }
                    withStyle(SpanStyle(fontSize = 10.sp, fontWeight = FontWeight.Medium)) { append("%") }
                }, color = Color.White, maxLines = 1)
            }
            Box(Modifier.padding(top = 6.dp, bottom = 8.dp).fillMaxWidth().height(6.dp).clip(CircleShape).background(Color(0x1FFFFFFF))) {
                if (anim > 0f) Box(Modifier.fillMaxWidth(anim).fillMaxHeight().clip(CircleShape).background(color))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(buildAnnotatedString {
                    withStyle(SpanStyle(color = Color.White, fontWeight = FontWeight.SemiBold)) { append("%.1f".format(used)) }
                    append(" dari %.1f GB".format(total))
                }, color = dim, fontSize = 12.sp, maxLines = 1, modifier = Modifier.weight(1f))
                Text("Bebas %.1f GB".format(free), color = dim, fontSize = 12.sp, maxLines = 1)
            }
        }
    }
}

/** Kartu mini memori: label, persen besar, batang tipis, lalu terpakai / total dan sisa bebas. */
@Composable
fun MemMini(label: String, total: Float, used: Float, free: Float, color: Color, modifier: Modifier = Modifier) {
    val frac = if (total > 0f) (used / total).coerceIn(0f, 1f) else 0f
    Column(modifier.background(Color(0xFF1C1D26), RoundedCornerShape(16.dp)).padding(horizontal = 12.dp, vertical = 14.dp)) {
        Text(label, color = Color.White, fontSize = 13.sp, maxLines = 1)
        Text("${Math.round(frac * 100)}%", color = color, fontSize = 28.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 2.dp))
        Box(Modifier.padding(top = 10.dp, bottom = 10.dp).fillMaxWidth().height(6.dp).clip(CircleShape).background(Color(0x1FFFFFFF))) {
            if (frac > 0f) Box(Modifier.fillMaxWidth(frac).fillMaxHeight().clip(CircleShape).background(color))
        }
        Text(buildAnnotatedString {
            withStyle(SpanStyle(color = Color.White, fontWeight = FontWeight.SemiBold)) { append("%.2f".format(used)) }
            append(" / %.2f GB".format(total))
        }, color = Color.White, fontSize = 12.sp, maxLines = 1)
        Text("Bebas %.2f GB".format(free), color = Color.White, fontSize = 12.sp, maxLines = 1, modifier = Modifier.padding(top = 2.dp))
    }
}

/** Blok memori minimalis: label + terpakai / total di atas, batang tipis, lalu persen terpakai dan sisa bebas. */
@Composable
fun MemBar(label: String, total: Float, used: Float, free: Float, color: Color) {
    val frac = if (total > 0f) (used / total).coerceIn(0f, 1f) else 0f
    Column(Modifier.padding(vertical = 14.dp)) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text(label, color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Text(buildAnnotatedString {
                withStyle(SpanStyle(color = Color.White, fontWeight = FontWeight.SemiBold)) { append("%.2f".format(used)) }
                append(" / %.2f GB".format(total))
            }, color = Color.White, fontSize = 12.sp, maxLines = 1)
        }
        Box(Modifier.padding(top = 10.dp).fillMaxWidth().height(6.dp).clip(CircleShape).background(Color(0x1FFFFFFF))) {
            if (frac > 0f) Box(Modifier.fillMaxWidth(frac).fillMaxHeight().clip(CircleShape).background(color))
        }
        Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("${Math.round(frac * 100)}% terpakai", color = color, fontSize = 12.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            Text("Bebas %.2f GB".format(free), color = Color.White, fontSize = 12.sp)
        }
    }
}

@Composable
fun MemBlock(label: String, total: Float, used: Float, free: Float, color: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f))
            Text("%.2f GB total".format(total), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("%.2f GB digunakan".format(used), color = Grey, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text("%.2f GB Bebas".format(free), color = Grey, fontSize = 12.sp)
        }
        Spacer(Modifier.height(2.dp))
        Box(Modifier.fillMaxWidth().height(8.dp).background(Color(0x1FFFFFFF), CircleShape)) {
            Box(Modifier.fillMaxWidth(if (total > 0f) (used / total).coerceIn(0f, 1f) else 0f).fillMaxHeight().background(color, CircleShape))
        }
    }
}

@Composable
fun TempMeter(label: String, t: Float) {
    if (t < 0f) { MeterRow(label, "-", 0f, Grey); return }
    val word = when { t < 45f -> "Aman"; t < 55f -> "Hangat"; t < 65f -> "Panas"; else -> "Sangat panas" }
    MeterRow(label, "${deg(t)}  $word", (t - 20f) / 70f, Color(heat(t)), Color(heat(t)))
}

/** Warna batang beban: aksen saat normal, kuning mulai berat, merah hampir penuh. */
@Composable
fun barLoad(p: Int): Color = when { p < 60 -> acc(); p < 85 -> Color(0xFFFFD866); else -> Color(0xFFFF6B6B) }

private fun usedFrac(txt: String): Float {
    val n = Regex("[0-9]+[.,]?[0-9]*").findAll(txt).map { it.value.replace(',', '.').toFloatOrNull() ?: 0f }.toList()
    return if (n.size >= 2 && n[1] > 0f) n[0] / n[1] else 0f
}

@Composable
fun HeatLegend(t: Float, label: String) = Row(verticalAlignment = Alignment.CenterVertically) {
    Box(Modifier.size(12.dp).background(Color(heat(t)), CircleShape))
    Text(label, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(start = 10.dp))
}

/** Grafik FPS: garis halus + isi tipis, skala 0..maks (kelipatan 10, minimal 30), garis bantu tipis, titik di nilai terakhir. */
/** Grafik area beban CPU 0..100%, menempel di dasar kartu. */
@Composable
fun CpuGraph(h: List<Int>, col: Color, m: Modifier) {
    Canvas(m) {
        if (h.size < 2) return@Canvas
        val stepX = size.width / (h.size - 1)
        fun py(v: Int) = size.height * (1f - 0.12f - 0.78f * v.coerceIn(0, 100) / 100f)
        val fill = Path(); fill.moveTo(0f, size.height); fill.lineTo(0f, py(h[0]))
        for (i in 1 until h.size) {
            val x0 = (i - 1) * stepX; val y0 = py(h[i - 1]); val x1 = i * stepX; val y1 = py(h[i])
            fill.quadraticBezierTo(x0, y0, (x0 + x1) / 2f, (y0 + y1) / 2f)
            if (i == h.size - 1) fill.lineTo(x1, y1)
        }
        fill.lineTo(size.width, size.height); fill.close()
        drawPath(fill, col.copy(alpha = 0.35f))
    }
}

@Composable
fun FpsGraph(h: List<Int>, m: Modifier) {
    val col = acc()
    Canvas(m) {
        val guide = Color(0x1AFFFFFF)
        for (i in 0..2) { val y = size.height * i / 2f; drawLine(guide, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f) }
        if (h.size < 2) return@Canvas
        val pad = 4.dp.toPx()
        val mx = (kotlin.math.ceil(maxOf(h.maxOrNull() ?: 30, 30) / 10f) * 10f)
        val stepX = size.width / (h.size - 1)
        fun px(i: Int) = i * stepX
        fun py(v: Int) = pad + (size.height - 2 * pad) * (1f - v / mx)
        val line = Path(); val fill = Path()
        line.moveTo(px(0), py(h[0])); fill.moveTo(px(0), size.height); fill.lineTo(px(0), py(h[0]))
        for (i in 1 until h.size) {
            // kurva halus lewat titik tengah antar sampel
            val x0 = px(i - 1); val y0 = py(h[i - 1]); val x1 = px(i); val y1 = py(h[i])
            val mxp = (x0 + x1) / 2f; val myp = (y0 + y1) / 2f
            line.quadraticBezierTo(x0, y0, mxp, myp); fill.quadraticBezierTo(x0, y0, mxp, myp)
            if (i == h.size - 1) { line.lineTo(x1, y1); fill.lineTo(x1, y1) }
        }
        fill.lineTo(size.width, size.height); fill.close()
        drawPath(fill, col.copy(alpha = 0.14f))
        drawPath(line, col, style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawCircle(col, 4.dp.toPx(), Offset(px(h.size - 1), py(h.last())))
    }
}

@Composable
fun Stat(l: String, v: String) = Column { Text(l, color = Grey, fontSize = 11.sp); Text(v, color = Color.White, fontSize = 19.sp) }
