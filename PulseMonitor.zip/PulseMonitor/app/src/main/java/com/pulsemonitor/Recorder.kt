package com.pulsemonitor

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Satu sesi rekaman. Semua list sama panjang: satu nilai per sampel (kira-kira per detik). Nilai -1 = tidak terbaca. */
class Session(
    val id: Long, val pkg: String, val label: String, val res: String, var desc: String,
    val t: List<Float>, val fps: List<Float>, val cpu: List<Float>, val gpu: List<Float>, val ram: List<Float>,
    val tCpu: List<Float>, val tGpu: List<Float>, val tBat: List<Float>, val watt: List<Float>,
    val tSkin: List<Float> = emptyList()   // suhu HP (sensor skin); kosong pada rekaman lama
) {
    val n: Int get() = fps.size
    /** Suhu HP per sampel: sensor skin; bila tidak terbaca pakai suhu baterai (sensor terdekat ke badan HP). */
    val phoneTemp: List<Float> get() = List(n) { i ->
        val sk = tSkin.getOrElse(i) { -1f }; if (sk >= 0f) sk else tBat[i]
    }
    val dur: Int get() = (t.lastOrNull() ?: 0f).roundToInt()
    /** Suhu tunggal untuk grafik FPS: yang terpanas antara CPU dan GPU, cadangan baterai. */
    val temp: List<Float> get() = List(n) { i ->
        val m = maxOf(tCpu[i], tGpu[i]); if (m >= 0f) m else tBat[i]
    }
}

class Stats(
    val max: Float, val min: Float, val avg: Float, val sd: Float, val smooth: Float, val low5: Float,
    val maxTemp: Float, val avgWatt: Float
)

fun Session.stats(): Stats {
    val f = fps.filter { it > 0f }
    if (f.isEmpty()) return Stats(0f, 0f, 0f, 0f, 0f, 0f, -1f, -1f)
    val avg = f.average().toFloat()
    val sd = sqrt(f.map { (it - avg) * (it - avg) }.average()).toFloat()
    val sorted = f.sorted(); val k = maxOf(1, sorted.size * 5 / 100)
    val low = sorted.take(k).average().toFloat()
    val smooth = if (avg > 0f) (100f * (1f - sd / avg)).coerceIn(0f, 100f) else 0f
    val mt = phoneTemp.despike().filter { it >= 0f }.maxOrNull() ?: -1f
    return Stats(f.maxOrNull() ?: 0f, f.minOrNull() ?: 0f, avg, sd, smooth, low, mt, watt.avgValid())
}

/** Buang lonjakan satu sampel (glitch sensor): tiap titik diganti median tiga titik di sekitarnya; ujung memakai yang lebih kecil dari dua titik. */
fun List<Float>.despike(): List<Float> = when {
    size < 3 -> this
    else -> List(size) { i ->
        when (i) {
            0 -> minOf(this[0], this[1]).let { if (this[1] < 0f) this[0] else it }
            size - 1 -> minOf(this[i], this[i - 1]).let { if (this[i - 1] < 0f) this[i] else it }
            else -> listOf(this[i - 1], this[i], this[i + 1]).sorted()[1]
        }
    }
}

fun List<Float>.avgValid(): Float { val v = filter { it >= 0f }; return if (v.isEmpty()) -1f else v.average().toFloat() }
fun List<Float>.maxValid(): Float = filter { it >= 0f }.maxOrNull() ?: -1f
fun fmtDur(sec: Int) = "%d:%02d".format(sec / 60, sec % 60)
fun fmtDate(ms: Long): String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(ms))
fun f1(x: Float) = "%.1f".format(x)

/** Merekam Snap dari Sampler. Disimpan sebagai JSON di filesDir/records. */
object Recorder {
    val active = MutableStateFlow(false)
    val count = MutableStateFlow(0)       // jumlah sampel yang sudah terekam
    val version = MutableStateFlow(0)     // naik tiap ada rekaman baru/dihapus, supaya daftar dimuat ulang
    private val buf = ArrayList<Snap>()
    private val ts = ArrayList<Long>()
    private var stopping = false
    private val resCount = HashMap<String, Int>()   // resolusi render game -> jumlah pembacaan

    /** Dipanggil Sampler: resolusi render game yang terbaca saat merekam. */
    @Synchronized fun onRes(w: Int, h: Int) {
        if (!active.value || stopping) return
        val k = "${w}x$h"; resCount[k] = (resCount[k] ?: 0) + 1
    }

    /** Sudah ada pembacaan resolusi game di rekaman ini? */
    @Synchronized fun hasRes() = resCount.isNotEmpty()

    @Synchronized fun start() {
        if (active.value) return
        buf.clear(); ts.clear(); resCount.clear(); count.value = 0; stopping = false; active.value = true
    }

    /** Dipanggil Sampler tiap tick. */
    @Synchronized fun onSample(s: Snap) {
        if (!active.value || stopping) return
        buf.add(s); ts.add(System.currentTimeMillis()); count.value = buf.size
    }

    /** Hentikan dan simpan. Null bila tidak ada data FPS. Panggil dari thread latar (menulis file). */
    fun stop(ctx: Context): Session? {
        var data: List<Snap> = emptyList(); var times: List<Long> = emptyList(); var gameRes: String? = null
        synchronized(this) {
            if (!active.value || stopping) return null
            stopping = true; data = ArrayList(buf); times = ArrayList(ts)
            gameRes = resCount.maxByOrNull { it.value }?.key
        }
        try {
            val first0 = data.indexOfFirst { it.fpsRaw > 0 }; val last = data.indexOfLast { it.fpsRaw > 0 }
            if (first0 < 0) return null
            // Semua sampel dipakai sejak FPS pertama terbaca: rekaman langsung jalan, tanpa membuang detik awal.
            val first = first0
            val d = data.subList(first, last + 1); val tt = times.subList(first, last + 1)
            val own = ctx.packageName
            fun top(l: List<Snap>) = l.filter { !Sampler.isIgnoredPkg(it.pkg, own) }
                .groupingBy { it.pkg }.eachCount().maxByOrNull { it.value }?.key
            // Nama game: paket terbanyak di sampel ber-FPS; bila kosong, seluruh sampel; bila masih kosong, app terakhir di depan
            val pkg = top(d.filter { it.fpsRaw > 0 }) ?: top(data)
                ?: Sampler.lastGamePkg().takeIf { !Sampler.isIgnoredPkg(it, own) } ?: ""
            val label = if (pkg.isEmpty()) "Rekaman" else runCatching {
                val pm = ctx.packageManager; pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
            }.getOrDefault(pkg)
            // Resolusi: dari layer game saat merekam; bila belum terbaca (rekaman pendek), baca sekali lagi sekarang;
            // terakhir baru ukuran layar asli.
            // Utamakan resolusi yang diset game sendiri (GameUserSettings.ini); bila tak terbaca, pakai urutan di bawah.
            val res = Sampler.iniRes(pkg)?.let { "${it.first}x${it.second}" }
                ?: gameRes
                ?: Sampler.cachedRes(pkg)?.let { "${it.first}x${it.second}" }
                ?: Sampler.readResNow(pkg)?.let { "${it.first}x${it.second}" }
                ?: Sampler.realScreenRes()?.let { "${maxOf(it.first, it.second)}x${minOf(it.first, it.second)}" }
                ?: ctx.resources.displayMetrics.let { "${it.widthPixels}x${it.heightPixels}" }
            val s = Session(
                id = System.currentTimeMillis(), pkg = pkg, label = label, res = res, desc = "",
                t = tt.map { (it - tt[0]) / 1000f }, fps = d.map { if (it.fpsRawF > 0f) it.fpsRawF else it.fpsRaw.toFloat() },
                cpu = d.map { it.cpu.toFloat() }, gpu = d.map { it.gpu.toFloat() }, ram = d.map { it.ramPct.toFloat() },
                tCpu = d.map { it.tCpu }, tGpu = d.map { it.tGpu }, tBat = d.map { it.tBat }, watt = d.map { it.watt }, tSkin = d.map { it.tSkin }
            )
            save(ctx, s)
            return s
        } finally {
            synchronized(this) { stopping = false; active.value = false; buf.clear(); ts.clear(); resCount.clear(); count.value = 0 }
            version.value = version.value + 1
        }
    }

    private fun dir(c: Context) = File(c.filesDir, "records").also { it.mkdirs() }

    private fun arr(l: List<Float>) = JSONArray().also { a -> l.forEach { a.put(Math.round(it * 10f) / 10.0) } }

    private fun toJson(s: Session) = JSONObject().apply {
        put("id", s.id); put("pkg", s.pkg); put("label", s.label); put("res", s.res); put("desc", s.desc)
        put("t", arr(s.t)); put("fps", arr(s.fps)); put("cpu", arr(s.cpu)); put("gpu", arr(s.gpu)); put("ram", arr(s.ram))
        put("tCpu", arr(s.tCpu)); put("tGpu", arr(s.tGpu)); put("tBat", arr(s.tBat)); put("tSkin", arr(s.tSkin)); put("watt", arr(s.watt))
    }

    private fun floats(o: JSONObject, k: String): List<Float> {
        val a = o.optJSONArray(k) ?: return emptyList()
        return List(a.length()) { a.optDouble(it, -1.0).toFloat() }
    }

    /** Samakan panjang list dengan jumlah sampel FPS. Rekaman lama / berkas rusak yang kurang kolom tidak lagi bikin crash atau CSV gagal. */
    private fun fit(l: List<Float>, n: Int, fill: Float) = if (l.size >= n) l.take(n) else l + List(n - l.size) { fill }

    private fun parse(txt: String): Session {
        val o = JSONObject(txt)
        val fps = floats(o, "fps"); val n = fps.size
        val t = floats(o, "t").let { if (it.size >= n) it.take(n) else it + List(n - it.size) { i -> (it.size + i).toFloat() } }
        return Session(
            o.getLong("id"), o.optString("pkg"), o.optString("label"), o.optString("res"), o.optString("desc"),
            t, fps, fit(floats(o, "cpu"), n, -1f), fit(floats(o, "gpu"), n, -1f), fit(floats(o, "ram"), n, -1f),
            fit(floats(o, "tCpu"), n, -1f), fit(floats(o, "tGpu"), n, -1f), fit(floats(o, "tBat"), n, -1f), fit(floats(o, "watt"), n, -1f),
            fit(floats(o, "tSkin"), n, -1f)
        )
    }

    fun save(c: Context, s: Session) {
        val f = File(dir(c), "${s.id}.json"); val tmp = File(dir(c), "${s.id}.tmp")
        tmp.writeText(toJson(s).toString())
        if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f) }
    }

    fun saveDesc(c: Context, s: Session, text: String) { s.desc = text; runCatching { save(c, s) } }

    fun load(c: Context, id: Long): Session? = runCatching { parse(File(dir(c), "$id.json").readText()) }.getOrNull()

    fun list(c: Context): List<Session> =
        dir(c).listFiles { f -> f.extension == "json" }?.mapNotNull { f -> runCatching { parse(f.readText()) }.getOrNull() }
            ?.sortedByDescending { it.id } ?: emptyList()

    fun delete(c: Context, id: Long) { File(dir(c), "$id.json").delete(); version.value = version.value + 1 }

    fun csv(s: Session): String {
        val sb = StringBuilder("time_s,fps,frametime_ms,cpu_pct,gpu_pct,ram_pct,temp_cpu,temp_gpu,temp_bat,temp_hp,power_w\n")
        for (i in 0 until s.n) {
            val f = s.fps[i]
            sb.append("%.1f,%.1f,%.1f,%.0f,%.0f,%.0f,%.1f,%.1f,%.1f,%.1f,%.2f\n".format(
                Locale.US, s.t[i], f, if (f > 0f) 1000f / f else 0f, s.cpu[i], s.gpu[i], s.ram[i],
                s.tCpu[i], s.tGpu[i], s.tBat[i], s.phoneTemp[i], s.watt[i]))
        }
        return sb.toString()
    }

    /** Simpan CSV ke folder Download (MediaStore, tanpa izin storage). */
    fun exportCsv(c: Context, s: Session): Boolean = runCatching {
        val safe = s.label.replace(Regex("[^A-Za-z0-9]+"), "_")
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date(s.id))
        val cv = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, "PulseMonitor_${safe}_$stamp.csv")
            put(MediaStore.Downloads.MIME_TYPE, "text/csv")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val uri = c.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)!!
        c.contentResolver.openOutputStream(uri)!!.use { it.write(csv(s).toByteArray()) }
    }.isSuccess

    fun summary(s: Session): String {
        val st = s.stats()
        return buildString {
            append("Pulse Monitor - ${s.label}\n${fmtDate(s.id)}  (${fmtDur(s.dur)}, ${s.res})\n")
            if (s.desc.isNotBlank()) append("${s.desc}\n")
            append("FPS rata-rata ${f1(st.avg)}\n")
            append("5% low ${f1(st.low5)} FPS, kehalusan ${f1(st.smooth)}%\n")
            if (st.maxTemp >= 0f) append("Suhu HP ${"%.0f".format(st.maxTemp)}°C\n")
            if (st.avgWatt >= 0f) append("Daya rata-rata ${f1(st.avgWatt)} W\n")
        }
    }
}
