package com.pulsemonitor

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs

/** Baterai: persen, suhu (°C), status teks, dan perkiraan sisa waktu ("-" bila tidak terbaca). */
data class BatExtra(val pct: Int = -1, val tempC: Float = -1f, val state: String = "-", val remain: String = "-")
/** Jaringan: jenis koneksi, kecepatan tautan Wi-Fi (Mbps), kekuatan sinyal (persen) dan dBm. -1 = tidak ada. */
data class NetExtra(val type: String = "-", val mbps: Int = -1, val sigPct: Int = -1, val dbm: Int = 0)
/** Ukuran dalam GB desimal (1 GB = 1 miliar byte). */
data class SizeExtra(val usedGb: Float = -1f, val totalGb: Float = -1f) {
    val pct get() = if (totalGb > 0f && usedGb >= 0f) (usedGb * 100f / totalGb).toInt().coerceIn(0, 100) else -1
}
data class Extras(val bat: BatExtra = BatExtra(), val net: NetExtra = NetExtra(), val ram: SizeExtra = SizeExtra(), val storage: SizeExtra = SizeExtra())

/** Info tambahan untuk dialog Sensor di Beranda: baterai, jaringan, RAM, dan penyimpanan. Dibaca tanpa Shizuku/Root. */
object DeviceExtras {
    private fun fmt(ms: Long): String {
        val m = ms / 60_000
        return "%dj %dm".format(m / 60, m % 60)
    }

    fun read(c: Context): Extras = Extras(battery(c), network(c), ram(c), storage())

    private fun battery(c: Context): BatExtra = runCatching {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return BatExtra()
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1); val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_UNKNOWN)
        val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        val tRaw = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        val temp = if (tRaw != Int.MIN_VALUE) tRaw / 10f else -1f
        val state = when {
            plugged && st == BatteryManager.BATTERY_STATUS_CHARGING -> "Mengisi"
            plugged && st == BatteryManager.BATTERY_STATUS_FULL -> "Penuh"
            else -> "Tidak mengisi"
        }
        val bm = c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        var remain = "-"
        if (plugged && st == BatteryManager.BATTERY_STATUS_CHARGING) {
            val t = if (Build.VERSION.SDK_INT >= 28) bm.computeChargeTimeRemaining() else -1L
            if (t > 0) remain = "Penuh dalam ${fmt(t)}"
        } else if (!plugged) {
            // Perkiraan kasar: muatan tersisa dibagi arus saat ini. Satuan arus beda-beda antar HP (µA atau mA).
            val cur = Math.abs(bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW).toLong())
            val cnt = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER).toLong()
            if (cur > 0 && cnt > 0) {
                val ua = if (cur < 20_000) cur * 1000 else cur
                val ms = (cnt.toDouble() / ua * 3_600_000.0).toLong()
                if (ms in 60_000..(99L * 3_600_000)) remain = "Sisa ${fmt(ms)}"
            }
        }
        BatExtra(pct, temp, state, remain)
    }.getOrDefault(BatExtra())

    @Suppress("DEPRECATION")
    private fun network(c: Context): NetExtra = runCatching {
        val cm = c.getSystemService(ConnectivityManager::class.java)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return NetExtra("Tidak ada koneksi")
        when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> {
                val wi = c.applicationContext.getSystemService(Context.WIFI_SERVICE).let { it as WifiManager }.connectionInfo
                val rssi = wi.rssi
                NetExtra("Wi-Fi", wi.linkSpeed.takeIf { it > 0 } ?: -1, ((rssi + 100) * 2).coerceIn(0, 100), rssi)
            }
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> NetExtra("Data seluler")
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> NetExtra("Ethernet")
            else -> NetExtra("Terhubung")
        }
    }.getOrDefault(NetExtra())

    private fun ram(c: Context): SizeExtra = runCatching {
        val mi = ActivityManager.MemoryInfo()
        c.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        SizeExtra((mi.totalMem - mi.availMem) / 1e9f, mi.totalMem / 1e9f)
    }.getOrDefault(SizeExtra())

    private fun storage(): SizeExtra = runCatching {
        val sf = StatFs(Environment.getDataDirectory().path)
        val total = sf.blockCountLong * sf.blockSizeLong
        val free = sf.availableBlocksLong * sf.blockSizeLong
        SizeExtra((total - free) / 1e9f, total / 1e9f)
    }.getOrDefault(SizeExtra())
}
