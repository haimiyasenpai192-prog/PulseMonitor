package com.pulsemonitor

import android.os.SystemClock
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * Mengukur touch sampling rate (Hz) layar sentuh dari `getevent`.
 * Tiap SYN_REPORT dari perangkat yang melaporkan ABS_MT_POSITION = satu frame sentuhan; Hz = 1000 / jarak antar frame.
 * Angka hanya ada saat layar sedang disentuh (0 = tidak menyentuh). Butuh Shizuku/root, sama seperti Sampler.
 */
object TouchMonitor {
    val hz = MutableStateFlow(0)
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var job: Job? = null

    fun start() {
        if (job?.isActive == true) return
        job = scope.launch {
            var proc: Process? = null
            try {
                proc = Shell.spawn("getevent -lt") ?: return@launch
                val touchDevs = HashSet<String>()
                val lastTs = HashMap<String, Double>()
                val ring = ArrayDeque<Double>()          // jarak antar frame (ms) sentuhan yang sedang berjalan
                var lastArrive = 0L; var lastPub = 0L
                // Penjaga: tidak ada event ~1,5 detik = jari diangkat, angka kembali 0
                val guard = launch {
                    while (isActive) {
                        delay(300)
                        if (hz.value != 0 && SystemClock.elapsedRealtime() - lastArrive > 1500) hz.value = 0
                    }
                }
                proc.inputStream.bufferedReader().useLines { lines ->
                    for (line in lines) {
                        if (!isActive) break
                        val dev = line.substringAfter("] ", "").substringBefore(":", "")
                        if (dev.isEmpty()) continue
                        if (line.contains("ABS_MT_POSITION") || line.contains("ABS_MT_TRACKING_ID")) { touchDevs.add(dev); continue }
                        if (!line.contains("SYN_REPORT") || dev !in touchDevs) continue
                        val ts = line.substringAfter("[").substringBefore("]").trim().toDoubleOrNull() ?: continue
                        val prev = lastTs[dev]; lastTs[dev] = ts
                        val now = SystemClock.elapsedRealtime(); lastArrive = now
                        if (prev == null) continue
                        val dt = (ts - prev) * 1000.0
                        if (dt < 0.5 || dt > 60.0) { ring.clear(); continue }   // jeda panjang = sentuhan baru
                        ring.addLast(dt); if (ring.size > 24) ring.removeFirst()
                        if (ring.size >= 6 && now - lastPub > 150) {
                            lastPub = now
                            // Persentil bawah: jari diam sesaat menjarangkan laporan, jadi ambil jarak antar frame yang rapat
                            val sorted = ring.sorted()
                            hz.value = (1000.0 / sorted[sorted.size / 4]).toInt().coerceIn(1, 1000)
                        }
                    }
                }
                guard.cancel()
            } catch (e: Throwable) {
                if (e !is CancellationException) android.util.Log.e("PulseMonitor", "Touch rate gagal", e)
            } finally {
                runCatching { proc?.destroy() }
                hz.value = 0
            }
        }
    }

    fun stop() { job?.cancel(); job = null; hz.value = 0 }
}

/**
 * Latensi sentuh (ms): selang dari saat layar mencatat sentuhan (MotionEvent.eventTime, cap waktu dari driver)
 * sampai sentuhan itu sampai ke aplikasi. Diukur dari ketukan (ACTION_DOWN) di mana pun di layar lewat
 * FLAG_WATCH_OUTSIDE_TOUCH pada overlay, jadi tidak butuh Shizuku/root. Tidak termasuk waktu render ke layar.
 * Hanya dipanggil dari thread utama.
 */
object TouchLatency {
    data class Lat(val last: Int, val avg: Int)
    val state = MutableStateFlow<Lat?>(null)
    private val buf = ArrayDeque<Int>()

    fun record(ms: Long) {
        val v = ms.toInt().coerceIn(0, 999)
        buf.addLast(v); if (buf.size > 20) buf.removeFirst()
        state.value = Lat(v, Math.round(buf.average()).toInt())
    }

    fun reset() { buf.clear(); state.value = null }
}
