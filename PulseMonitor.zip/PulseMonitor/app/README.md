
## v0.4.5: Mode latar belakang (hemat RAM) dan perbaikan status overlay
- Settings > "Latar belakang" > saklar "Tetap aktif di latar belakang". Nyala: matikan overlay hanya menyembunyikan overlay, notifikasi baterai tetap hidup. Mati (bawaan): matikan overlay = layanan berhenti dan notifikasi hilang.
- Hemat RAM/CPU: Sampler (proses shell tiap detik) sekarang berhenti bila tidak ada overlay, rekaman, atau layar utama yang terlihat. Sebelumnya terus jalan selama proses hidup. Saat overlay tersembunyi, notifikasi disegarkan tiap 5 dtk (layar nyala) / 30 dtk (layar mati).
- Perbaikan: status "Overlay aktif/mati" di layar utama kini mengikuti status layanan sebenarnya. Sebelumnya hanya variabel di Activity, jadi setelah aplikasi dibuka ulang tampak "mati" padahal layanan dan notifikasi masih jalan.
- Contoh gaya di Settings memakai urutan baru `FPS 60`.
- Catatan: notifikasi sistem "PulseMonitor ditampilkan di atas aplikasi lain" dibuat Android/HyperOS, bukan aplikasi; muncul selama ada overlay.
- Belum dikompilasi/diuji di perangkat.

## v0.4.7: Probe GPU
- Statistik > "Probe GPU dan salin": membaca isi node GPU (gpufreqv2, gpufreq, GED, devfreq, kgsl) lalu menyalinnya ke clipboard. Dipakai untuk menemukan node frekuensi yang benar di Dimensity/Immortalis, karena nilai overlay (1430 MHz) dan aplikasi lain (338 MHz) berbeda.
- Belum dikompilasi/diuji di perangkat.

## v0.4.9: Perbaikan build GitHub
- Error kompilasi di MainActivity (Toast.makeText dengan `this` di dalam kartu Probe GPU): di dalam lambda SettingCard, `this` adalah ColumnScope, bukan Activity. Diganti `this@MainActivity`.
