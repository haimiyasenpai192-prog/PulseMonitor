package com.pulsemonitor

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Log ringan aplikasi: disimpan di memori dan di berkas, ditampilkan serta dibagikan dari layar Kesehatan & log. */
object AppLog {
    private const val MAX_LINES = 400
    private const val MAX_FILE = 120_000L
    private val lines = ArrayDeque<String>()
    private var file: File? = null
    private val fmt = SimpleDateFormat("MM-dd HH:mm:ss", Locale.US)

    @Synchronized fun init(c: Context) {
        if (file != null) return
        val f = File(c.applicationContext.filesDir, "applog.txt")
        file = f
        runCatching { f.readLines().takeLast(MAX_LINES).forEach { lines.addLast(it) } }
    }

    @Synchronized private fun add(level: String, tag: String, msg: String) {
        val l = "${fmt.format(Date())} $level/$tag ${msg.replace('\n', ' ')}".take(600)
        lines.addLast(l)
        while (lines.size > MAX_LINES) lines.removeFirst()
        val f = file ?: return
        runCatching {
            if (f.length() > MAX_FILE) f.writeText(lines.joinToString("\n") + "\n") else f.appendText(l + "\n")
        }
    }

    fun i(tag: String, msg: String) = add("I", tag, msg)
    fun w(tag: String, msg: String) = add("W", tag, msg)
    fun e(tag: String, msg: String, t: Throwable? = null) =
        add("E", tag, if (t == null) msg else "$msg: ${t.javaClass.simpleName} ${t.message}")

    @Synchronized fun dump(n: Int = 200): String = lines.toList().takeLast(n).joinToString("\n")

    @Synchronized fun clear() {
        lines.clear()
        runCatching { file?.writeText("") }
    }
}
