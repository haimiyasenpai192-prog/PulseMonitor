package com.pulsemonitor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.max

/**
 * Overlay gaya "Compact": bilah horizontal per baris.
 *   FPS  60                       16.7ms
 *   CPU  [=======     ]         3300MHz     bilah = beban CPU
 *   GPU  [===========·]          702MHz     bilah = beban GPU
 *   BAT 76%  TMP 33.1°C                    teks saja, tanpa bilah (baterai + suhu baterai)
 * (nama kelas dipertahankan dari versi cincin supaya OverlayService tidak perlu berubah)
 */
class RingOverlayView(ctx: Context) : View(ctx) {
    var snap = Snap()
    var rec = false
    var extra = ""                  // teks opsional (Touch Hz / Touch ms), satu baris dengan BAT/TMP
    var scale = 1f
    var bgColor = 0xEE101014.toInt()
    var strokeColor = 0x22FFFFFF
    var textColor = 0xFFFFFFFF.toInt()

    private val d = ctx.resources.displayMetrics.density
    private fun u(v: Float) = v * d * scale
    private val YEL = 0xFFFFD866.toInt()
    private val RED = 0xFFFF5C5C.toInt()

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val labP = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.LEFT }
    private val valP = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.RIGHT }
    private val bigP = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.LEFT }
    private val extraP = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.MONOSPACE; textAlign = Paint.Align.LEFT }
    private val rect = RectF()

    private class Row(val label: String, val pct: Int, val color: Int, val value: String)

    private fun batColor(p: Int) = when { p <= 15 -> RED; p <= 30 -> 0xFFFF9F43.toInt(); else -> 0xFF7CFFB2.toInt() }
    private fun tempColor(t: Float) = when { t >= 45f -> RED; t >= 40f -> YEL; else -> 0xFF7CFFB2.toInt() }
    private fun rows(): List<Row> {
        val s = snap; val off = withAlpha(textColor, 30)
        return listOf(
            Row("CPU", s.cpu, if (s.cpu >= 0) loadCol(s.cpu) else off, if (s.cpuMhz >= 0) "${s.cpuMhz}MHz" else "-"),
            Row("GPU", s.gpu, if (s.gpu >= 0) loadCol(s.gpu) else off, if (s.gpuMhz >= 0) "${s.gpuMhz}MHz" else "-")
        )
    }

    private fun batText() = if (snap.batPct >= 0) "${snap.batPct}%" else "-"
    private fun tmpText() = if (snap.tBat >= 0f) String.format(Locale.US, "%.0f", snap.tBat) else "-"

    private fun extraItems(): List<Pair<String, String>> =
        extra.split("  ").filter { it.isNotBlank() }.map { it.substringBefore(" ") to it.substringAfter(" ", "") }

    /** Teks nilai terlebar per label, hanya untuk menghitung lebar kotak. */
    private fun refValue(label: String) = when (label) {
        "TCH" -> "000Hz"
        "LAT" -> "000ms"
        else -> ""
    }

    private fun pad() = u(10f)
    private fun rowH() = u(16f)
    private fun rowGap() = u(6f)
    private fun labW() = u(32f)
    private fun barW() = u(72f)
    private fun gap() = u(8f)
    private fun valW(): Float { valP.textSize = u(11f); return max(valP.measureText("0000MHz"), valP.measureText("00.0°C")) }
    /** Ukuran teks baris bawah (BAT / TMP / TCH), sedikit lebih kecil dari label lain. */
    private fun bottomSz() = u(10.5f)
    private fun baseW() = pad() * 2 + labW() + barW() + gap() + valW()

    /** Jarak minimum antara BAT/TMP dan kolom kanan (TCH), serta antar item kanan. */
    private fun minGap() = u(10f)

    /** Lebar bagian kiri baris bawah: BAT dan TMP, jarak 10dp. */
    private fun leftRowW(): Float {
        labP.textSize = bottomSz()
        return labP.measureText("BAT " + batText()) + u(10f) + labP.measureText("TMP " + tmpText())
    }

    /** Lebar tiap item kanan (TCH/LAT), dihitung dengan teks terlebar supaya tidak berubah saat nilai berganti. */
    private fun extraWidths(): List<Float> {
        labP.textSize = bottomSz()
        return extraItems().map { (l, v) -> max(labP.measureText("$l $v"), labP.measureText("$l ${refValue(l)}")) }
    }

    private fun msText(): String =
        if (snap.idle) "idle" else if (snap.fps > 0) String.format(Locale.US, "%.1fms", 1000f / snap.fps) else ""

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val h = pad() * 2 + rowH() * 4 + rowGap() * 3
        val ew = extraWidths()
        val rightW = if (ew.isEmpty()) 0f else minGap() + ew.sum() + minGap() * (ew.size - 1)
        // Lebar dasar tetap; hanya melebar (tetap, tidak berubah saat disentuh) bila BAT + TMP + TCH tidak muat
        val need = pad() * 2 + leftRowW() + rightW
        val w = max(baseW(), need)
        setMeasuredDimension(ceil(w).toInt(), ceil(h).toInt())
    }

    private fun baseFor(cy: Float, paint: Paint) = cy - (paint.ascent() + paint.descent()) / 2f

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val rad = u(14f)
        p.style = Paint.Style.FILL; p.color = bgColor
        rect.set(0f, 0f, w, h); c.drawRoundRect(rect, rad, rad, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = d; p.color = strokeColor
        rect.set(d / 2, d / 2, w - d / 2, h - d / 2); c.drawRoundRect(rect, rad, rad, p)

        val x0 = pad(); val xBar = x0 + labW(); val xVal = xBar + barW() + gap() + valW()
        labP.textSize = u(11f); labP.color = textColor
        valP.textSize = u(11f); valP.color = YEL
        bigP.textSize = u(13f); bigP.color = YEL

        // Baris FPS: label, angka tebal, frametime di kolom kanan; titik merah saat merekam
        var cy = pad() + rowH() / 2f
        c.drawText("FPS", x0, baseFor(cy, labP), labP)
        var tx = xBar
        if (rec) { p.style = Paint.Style.FILL; p.color = RED; c.drawCircle(tx + u(3f), cy, u(3f), p); tx += u(10f) }
        c.drawText("${snap.fps}", tx, baseFor(cy, bigP), bigP)
        c.drawText(msText(), xVal, baseFor(cy, valP), valP)

        // Baris CPU / GPU / BAT: bilah tipis berujung bulat
        val bh = u(6f)
        rows().forEachIndexed { i, r ->
            cy = pad() + rowH() * (i + 1) + rowGap() * (i + 1) + rowH() / 2f
            labP.color = textColor
            c.drawText(r.label, x0, baseFor(cy, labP), labP)
            p.style = Paint.Style.FILL
            p.color = withAlpha(textColor, 16)
            rect.set(xBar, cy - bh / 2f, xBar + barW(), cy + bh / 2f); c.drawRoundRect(rect, bh / 2f, bh / 2f, p)
            if (r.pct > 0) {
                p.color = r.color
                val fw = max(bh, barW() * r.pct.coerceIn(0, 100) / 100f)
                rect.set(xBar, cy - bh / 2f, xBar + fw, cy + bh / 2f); c.drawRoundRect(rect, bh / 2f, bh / 2f, p)
            }
            valP.color = YEL
            c.drawText(r.value, xVal, baseFor(cy, valP), valP)
        }

        // Baris terakhir: BAT, TMP, lalu TCH/LAT berurutan dengan jarak sama (tanpa bilah)
        cy = pad() + rowH() * 3 + rowGap() * 3 + rowH() / 2f
        labP.textSize = bottomSz()
        val by = baseFor(cy, labP)
        val bat = batText(); val tmp = tmpText()
        var xx = x0
        labP.color = textColor; c.drawText("BAT", xx, by, labP); xx += labP.measureText("BAT ")
        labP.color = YEL; c.drawText(bat, xx, by, labP); xx += labP.measureText(bat) + u(10f)
        labP.color = textColor; c.drawText("TMP", xx, by, labP); xx += labP.measureText("TMP ")
        labP.color = YEL; c.drawText(tmp, xx, by, labP); xx += labP.measureText(tmp) + minGap()
        val items = extraItems(); val ew = extraWidths()
        for (i in items.indices) {   // TCH / LAT: lanjut setelah TMP dengan jarak sama; posisi tetap walau nilai berubah
            val (l, v) = items[i]
            labP.color = textColor; c.drawText(l, xx, by, labP)
            labP.color = YEL; c.drawText(v, xx + labP.measureText("$l "), by, labP)
            xx += max(ew[i], labP.measureText("$l $v")) + minGap()
        }
        labP.color = textColor; labP.textSize = u(11f)
    }
}
