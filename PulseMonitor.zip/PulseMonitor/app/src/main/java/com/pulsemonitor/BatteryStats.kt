package com.pulsemonitor

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.PowerManager
import android.os.SystemClock

/** Teks siap pakai untuk notifikasi. Contoh: "Discharging", "44% • 543 mA (2,0 W) • 38°C", "Active: 4,2%/h • Idle: 19,1%/h". */
class BatteryInfo(val status: String, val line2: String, val line3: String, val line4: String = "")

/**
 * Statistik baterai untuk notifikasi: status, persen, arus (mA) + daya (W), suhu, dan laju kuras per jam.
 * Active = layar menyala, Idle = layar mati. Dihitung sejak dicabut dari charger (sesi discharge),
 * dan tetap ditampilkan selama mengisi daya sampai sesi berikutnya dimulai.
 * Bila HP melaporkan charge counter, selisihnya dipakai agar laju lebih halus dari persen bulat.
 */
object BatteryStats {
    private const val MIN_MS = 120_000L     // di bawah 2 menit data terlalu sedikit, tampil "-"

    private var ctx: Context? = null
    private var screenOn = true
    private var lastAt = 0L
    private var lastP = Double.NaN
    private var lastUseC = false
    private var capUah = 0.0                // perkiraan kapasitas (satuan sama dengan charge counter)
    private var wasDischarging: Boolean? = null
    private var actMs = 0L; private var idleMs = 0L
    private var actDrop = 0.0; private var idleDrop = 0.0
    private var savedAt = 0L
    // Rincian sesi: muatan terpakai (µAh dari charge counter) per keadaan layar, dan pembagian layar mati: deep sleep vs awake
    private var actUah = 0.0; private var idleUah = 0.0
    private var offDeepMs = 0L; private var offAwakeMs = 0L
    private var lastCnt = 0L; private var lastU = 0L

    private fun prefs() = ctx!!.getSharedPreferences("battery_stats", Context.MODE_PRIVATE)

    @Synchronized fun init(c: Context) {
        if (ctx != null) return
        ctx = c.applicationContext
        screenOn = runCatching { ctx!!.getSystemService(PowerManager::class.java).isInteractive }.getOrDefault(true)
        val p = prefs()
        actMs = p.getLong("actMs", 0); idleMs = p.getLong("idleMs", 0)
        actDrop = p.getFloat("actDrop", 0f).toDouble(); idleDrop = p.getFloat("idleDrop", 0f).toDouble()
        capUah = p.getFloat("cap", 0f).toDouble()
        actUah = p.getLong("actUah", 0).toDouble(); idleUah = p.getLong("idleUah", 0).toDouble()
        offDeepMs = p.getLong("offDeep", 0); offAwakeMs = p.getLong("offAwake", 0)
        lastAt = SystemClock.elapsedRealtime(); lastU = SystemClock.uptimeMillis()
    }

    @Synchronized fun isScreenOn() = screenOn

    /** Dipanggil saat layar menyala/mati: selisih sampai saat ini dicatat ke keadaan lama dulu. */
    @Synchronized fun setScreen(on: Boolean) { tick(); screenOn = on }

    private fun rate(ms: Long, drop: Double): String =
        if (ms < MIN_MS) "-" else "%.1f%%/h".format(maxOf(0.0, drop) / (ms / 3_600_000.0))

    @Synchronized fun tick(): BatteryInfo? {
        val c = ctx ?: return null
        val i = runCatching { c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) }.getOrNull() ?: return null
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1); val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_UNKNOWN)
        val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        val mv = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
        val tRaw = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        val temp = if (tRaw != Int.MIN_VALUE) tRaw / 10f else -1f
        val bm = c.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager

        val status = if (!plugged) "Discharging" else when (st) {
            BatteryManager.BATTERY_STATUS_CHARGING -> "Charging"
            BatteryManager.BATTERY_STATUS_FULL -> "Full"
            else -> "Not charging"
        }
        val discharging = !plugged
        val now = SystemClock.elapsedRealtime()

        if (discharging) {
            if (wasDischarging == false) {      // baru dicabut dari charger: mulai sesi baru
                actMs = 0; idleMs = 0; actDrop = 0.0; idleDrop = 0.0; capUah = 0.0; lastP = Double.NaN
                actUah = 0.0; idleUah = 0.0; offDeepMs = 0; offAwakeMs = 0
            }
            val up = SystemClock.uptimeMillis()
            if (wasDischarging != true) { lastAt = now; lastU = up }
            val cnt = runCatching { bm?.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER) }.getOrNull() ?: 0L
            val useC = cnt > 0L && cnt != Long.MIN_VALUE && pct in 3..100
            if (useC && capUah <= 0.0) capUah = cnt * 100.0 / pct
            val p = if (useC && capUah > 0.0) cnt * 100.0 / capUah else pct.toDouble()
            if (pct >= 0) {
                // mode (counter / persen bulat) berubah di tengah jalan: lewati selisih agar tidak melonjak
                if (!lastP.isNaN() && lastUseC == useC) {
                    val dt = now - lastAt; val d = lastP - p
                    val dc = if (useC && lastCnt > 0L) (lastCnt - cnt).toDouble() else 0.0
                    val du = (up - lastU).coerceIn(0L, maxOf(0L, dt))
                    if (screenOn) { actMs += dt; actDrop += d; actUah += dc }
                    else {
                        idleMs += dt; idleDrop += d; idleUah += dc
                        offAwakeMs += du; offDeepMs += dt - du     // uptime = terjaga; sisanya deep sleep
                    }
                }
                lastP = p; lastUseC = useC; lastCnt = cnt
            }
            lastAt = now; lastU = up
        } else lastP = Double.NaN
        wasDischarging = discharging

        if (now - savedAt > 60_000L) {
            savedAt = now
            prefs().edit().putLong("actMs", actMs).putLong("idleMs", idleMs)
                .putFloat("actDrop", actDrop.toFloat()).putFloat("idleDrop", idleDrop.toFloat()).putFloat("cap", capUah.toFloat())
                .putLong("actUah", actUah.toLong()).putLong("idleUah", idleUah.toLong())
                .putLong("offDeep", offDeepMs).putLong("offAwake", offAwakeMs).apply()
        }

        // Arus: satuan beda antar HP (µA atau mA), ditebak dari besarnya; tanda (+/-) diabaikan
        val raw = runCatching { bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) }.getOrNull() ?: 0
        val parts = ArrayList<String>()
        if (pct >= 0) parts.add("$pct%")
        if (raw != 0 && raw != Int.MIN_VALUE) {
            val a = Math.abs(raw.toLong())
            val mA = if (a > 20_000L) a / 1000f else a.toFloat()
            parts.add(if (mv > 0) "%.0f mA (%.1f W)".format(mA, mA / 1000f * mv / 1000f) else "%.0f mA".format(mA))
        }
        if (temp in 1f..100f) parts.add("%.0f°C".format(temp))
        val line2 = if (parts.isEmpty()) "-" else parts.joinToString(" • ")
        val line3 = "Active: ${rate(actMs, actDrop)} • Idle: ${rate(idleMs, idleDrop)}"
        // Rincian ala RedFox Prism: Screen On / Screen Off (waktu, persen terpakai, mAh), lalu Deep sleep / Awake saat layar mati
        fun dur(ms: Long): String {
            val t = ms / 1000; val h = t / 3600; val m = (t % 3600) / 60; val sec = t % 60
            return if (h > 0) "${h}h ${m}m ${sec}s" else "${m}m ${sec}s"
        }
        fun seg(label: String, ms: Long, drop: Double, uah: Double): String {
            val mah = if (capUah > 0.0) " (%.0f mAh)".format(maxOf(0.0, uah) / 1000.0) else ""
            return "$label: ${dur(ms)} • %.1f%%$mah".format(maxOf(0.0, drop))
        }
        val offTot = offDeepMs + offAwakeMs
        val deepPct = if (offTot > 0) 100.0 * offDeepMs / offTot else 0.0
        val line4 = listOf(
            seg("Screen On", actMs, actDrop, actUah),
            seg("Screen Off", idleMs, idleDrop, idleUah),
            "Deep sleep: ${dur(offDeepMs)} • %.1f%%".format(deepPct),
            "Awake: ${dur(offAwakeMs)} • %.1f%%".format(if (offTot > 0) 100.0 - deepPct else 0.0)
        ).joinToString("\n")
        return BatteryInfo(status, line2, line3, line4)
    }
}
