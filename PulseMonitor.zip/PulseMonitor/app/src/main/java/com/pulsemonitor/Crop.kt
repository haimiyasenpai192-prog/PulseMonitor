package com.pulsemonitor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import android.graphics.Bitmap
import kotlin.math.max
import kotlin.math.min

/**
 * Layar potong gambar. Bingkai punya rasio tetap (mis. rasio kartu notifikasi); gambar digeser dengan satu jari,
 * diperbesar dengan dua jari atau slider. Gambar selalu menutup bingkai penuh, jadi hasilnya tidak punya tepi kosong.
 * [aspect] = lebar / tinggi bingkai. [onDone] menerima bagian gambar yang terpotong.
 */
@Composable
fun CropDialog(src: Bitmap, aspect: Float, title: String, onCancel: () -> Unit, onDone: (Bitmap) -> Unit) {
    Dialog(onDismissRequest = onCancel, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        var box by remember { mutableStateOf(IntSize.Zero) }
        var zoom by remember { mutableFloatStateOf(1f) }
        var off by remember { mutableStateOf(Offset.Zero) }
        val img = remember(src) { src.asImageBitmap() }

        // Bingkai: selebar mungkin di dalam area, dengan rasio [aspect]
        fun frame(): Size {
            if (box.width == 0 || box.height == 0) return Size.Zero
            val maxW = box.width * 0.92f; val maxH = box.height * 0.92f
            val w = min(maxW, maxH * aspect)
            return Size(w, w / aspect)
        }
        fun scale(f: Size) = max(f.width / src.width, f.height / src.height) * zoom
        fun clamp(o: Offset): Offset {
            val f = frame(); if (f == Size.Zero) return o
            val s = scale(f)
            val mx = max(0f, src.width * s / 2f - f.width / 2f); val my = max(0f, src.height * s / 2f - f.height / 2f)
            return Offset(o.x.coerceIn(-mx, mx), o.y.coerceIn(-my, my))
        }

        Column(Modifier.fillMaxSize().background(Color(0xFF0C0C0E)).statusBarsPadding().navigationBarsPadding().padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, color = Color.White, fontSize = 16.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
            Text("Geser gambar, cubit atau pakai slider untuk memperbesar.", color = Color.White, fontSize = 12.sp)
            Box(Modifier.weight(1f).fillMaxWidth().onSizeChanged { box = it }
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, z, _ ->
                        zoom = (zoom * z).coerceIn(1f, 5f)
                        off = clamp(off + pan)
                    }
                }) {
                Canvas(Modifier.fillMaxSize()) {
                    val f = frame(); if (f == Size.Zero) return@Canvas
                    val s = scale(f); val o = clamp(off)
                    val dw = src.width * s; val dh = src.height * s
                    val cx = size.width / 2f + o.x; val cy = size.height / 2f + o.y
                    drawImage(img, dstOffset = IntOffset((cx - dw / 2f).toInt(), (cy - dh / 2f).toInt()),
                        dstSize = IntSize(dw.toInt(), dh.toInt()),
                        filterQuality = androidx.compose.ui.graphics.FilterQuality.High)
                    // Gelapkan di luar bingkai
                    val fl = (size.width - f.width) / 2f; val ft = (size.height - f.height) / 2f
                    val scrim = Color(0xAA000000)
                    drawRect(scrim, Offset.Zero, Size(size.width, ft))
                    drawRect(scrim, Offset(0f, ft + f.height), Size(size.width, size.height - ft - f.height))
                    drawRect(scrim, Offset(0f, ft), Size(fl, f.height))
                    drawRect(scrim, Offset(fl + f.width, ft), Size(size.width - fl - f.width, f.height))
                    drawRect(Color.White, Offset(fl, ft), f, style = Stroke(width = 2.dp.toPx()))
                }
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Zoom", color = Color.White, fontSize = 13.sp)
                Box(Modifier.weight(1f)) {
                    AccSlider((zoom - 1f) / 4f, 0f..1f, { zoom = 1f + it * 4f; off = clamp(off) }) {}
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PillButton("Batal", filled = false, modifier = Modifier.weight(1f), onClick = onCancel)
                PillButton("Simpan", modifier = Modifier.weight(1f)) {
                    val f = frame()
                    if (f == Size.Zero) { onCancel(); return@PillButton }
                    val s = scale(f); val o = clamp(off)
                    // Bingkai dalam koordinat gambar asli
                    val cw = (f.width / s).coerceAtMost(src.width.toFloat()); val ch = (f.height / s).coerceAtMost(src.height.toFloat())
                    val cx = (src.width / 2f - o.x / s - cw / 2f).coerceIn(0f, src.width - cw)
                    val cy = (src.height / 2f - o.y / s - ch / 2f).coerceIn(0f, src.height - ch)
                    onDone(Bitmap.createBitmap(src, cx.toInt(), cy.toInt(), max(1, cw.toInt()).coerceAtMost(src.width - cx.toInt()),
                        max(1, ch.toInt()).coerceAtMost(src.height - cy.toInt())))
                }
            }
        }
    }
}
