package com.pulsemonitor

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.SystemClock
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import rikka.shizuku.Shizuku

data class Snap(
    val fps: Int = 0, val avg: Int = 0, val low: Int = 0, val ft: Float = 0f,
    val cpu: Int = -1, val gpu: Int = -1, val ramPct: Int = -1, val ramText: String = "-",
    val tCpu: Float = -1f, val tGpu: Float = -1f, val tBat: Float = -1f,
    val access: String = "-", val dbg: String = "", val hist: List<Int> = emptyList(),
    val pkg: String = "", val watt: Float = -1f,
    val batPct: Int = -1, val cpuMhz: Int = -1, val gpuMhz: Int = -1,
    val fpsRaw: Int = 0,          // FPS terukur apa adanya (untuk rekaman); fps bisa berisi pengganti saat layar statis
    val idle: Boolean = false     // true: layar statis, fps berisi refresh rate layar
)

object Shell {
    private val rootOk: Boolean by lazy {
        runCatching { ProcessBuilder("su", "-c", "id").start().inputStream.bufferedReader().readText().contains("uid=0") }
            .getOrDefault(false)
    }
    fun shizukuReady() = runCatching { Shizuku.pingBinder() && Shizuku.checkSelfPermission() == 0 }.getOrDefault(false)
    fun mode(): String = if (shizukuReady()) "Shizuku" else if (rootOk) "Root" else "-"

    fun exec(cmd: String): String {
        val p: Process = when (mode()) {
            // newProcess bersifat private di Shizuku 13.x, dipanggil via refleksi
            "Shizuku" -> Shizuku::class.java.getDeclaredMethod(
                "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
            ).apply { isAccessible = true }.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            "Root" -> ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
            else -> return ""
        }
        return runCatching { p.inputStream.bufferedReader().readText() }.getOrDefault("").also { p.destroy() }
    }
}

object Sampler {
    // Urutan prioritas jalur beban GPU. Tambahkan jalur baru di sini bila ada chipset lain.
    private const val GPU_PATHS = "/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage " +   // Adreno (Qualcomm)
        "/sys/class/kgsl/kgsl-3d0/gpubusy " +                // Adreno cadangan: "busy total" -> persen
        "/sys/kernel/ged/hal/gpu_utilization " +                                       // MediaTek (GED)
        "/sys/module/ged/parameters/gpu_loading " +                                    // MediaTek (GED, varian lain)
        "/proc/mali/utilization"                                                       // Mali lama

    val state = MutableStateFlow(Snap())
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var job: Job? = null
    private var prevTotal = 0L; private var prevIdle = 0L
    private val hist = ArrayDeque<Int>()

    fun start() {
        if (job?.isActive == true) return
        job = scope.launch {
            while (isActive) {
                // Jadwal tetap ~1 detik: lama tick (beberapa proses shell) dikurangkan dari jeda,
                // supaya sampel tidak melambat jadi 2-3 detik dan angka tidak meloncat-loncat.
                val t0 = SystemClock.elapsedRealtime()
                runCatching { tick() }
                delay((1000L - (SystemClock.elapsedRealtime() - t0)).coerceAtLeast(200L))
            }
        }
    }

    private fun tick() {
        val mode = Shell.mode()
        if (mode == "-") {
            state.value = Snap(tBat = batteryTemp(), batPct = batteryPct(), access = "-", dbg = "Suhu baterai: Intent (CPU/GPU butuh Shizuku/root)")
            return
        }
        val out = Shell.exec(
            "head -1 /proc/stat; echo ==; for f in $GPU_PATHS; do [ -r \$f ] && echo \"\$f:\$(cat \$f 2>/dev/null)\"; done; echo ==; " +
            "head -3 /proc/meminfo; echo ==; grep -H . /sys/class/thermal/thermal_zone*/type /sys/class/thermal/thermal_zone*/temp 2>/dev/null; " +
            "echo ==; cat /sys/class/kgsl/kgsl-3d0/temp 2>/dev/null; " +
            "echo ==; cat /sys/devices/system/cpu/cpu*/cpufreq/scaling_cur_freq 2>/dev/null; " +
            "echo ==; for f in /sys/class/kgsl/kgsl-3d0/gpuclk /sys/class/kgsl/kgsl-3d0/devfreq/cur_freq " +
            "/sys/class/devfreq/*mali*/cur_freq /sys/class/devfreq/*.gpu/cur_freq /sys/devices/platform/*mali*/cur_freq " +
            "/sys/kernel/ged/hal/current_freqency /sys/kernel/gpu/gpu_clock; " +
            "do [ -r \$f ] && echo \"\$f:\$(cat \$f 2>/dev/null | tr '\\n' ' ')\"; done"
        ).split("==")
        if (out.size < 4) return

        // CPU
        val c = out[0].trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        var cpu = -1
        if (c.size >= 5) {
            val total = c.take(8).sum(); val idle = c[3] + c[4]
            if (prevTotal > 0 && total > prevTotal) cpu = (100 * ((total - prevTotal) - (idle - prevIdle)) / (total - prevTotal)).toInt()
            prevTotal = total; prevIdle = idle
        }
        // GPU: Adreno (kgsl) dulu, lalu MediaTek (GED) / Mali. Ambil angka pertama 0..100 dari jalur
        // pertama yang terbaca; format tiap jalur berbeda (ada yang "45", ada yang "45 30 12").
        val gpu = out[1].lines().firstNotNullOfOrNull { line ->
            val nums = Regex("\\d+").findAll(line.substringAfter(':', "")).mapNotNull { it.value.toLongOrNull() }.toList()
            when {
                nums.isEmpty() -> null
                // gpubusy berisi dua angka "busy total": persen = busy / total
                line.substringBefore(':').endsWith("gpubusy") ->
                    nums.getOrNull(1)?.takeIf { it > 0 }?.let { (100 * nums[0] / it).toInt().coerceIn(0, 100) }
                else -> nums[0].toInt().takeIf { it in 0..100 }
            }
        } ?: -1
        // Frekuensi: CPU = tertinggi dari semua inti (kHz -> MHz); GPU dalam Hz atau kHz tergantung jalur
        val cpuMhz = out.getOrNull(5)?.lines()?.mapNotNull { it.trim().toLongOrNull() }?.maxOrNull()?.let { (it / 1000).toInt() } ?: -1
        val gpuMhz = parseGpuFreq(out.getOrNull(6) ?: "")
        // RAM
        fun kb(n: String) = Regex("$n:\\s+(\\d+)").find(out[2])?.groupValues?.get(1)?.toLongOrNull() ?: 0L
        val tot = kb("MemTotal"); val av = kb("MemAvailable")
        val ramPct = if (tot > 0) (100 * (tot - av) / tot).toInt() else -1
        val ramText = "%.1f / %.0f GB".format((tot - av) / 1048576f, tot / 1048576f)
        // Suhu: HAL thermal (utama) -> sysfs (cadangan); baterai dari Intent BATTERY_CHANGED
        // dumpsys thermalservice berat dan ikut membebani system_server; cukup tiap 3 detik
        val nowMs = SystemClock.elapsedRealtime()
        if (nowMs - halAt >= 3000L) { halCache = runCatching { thermalHal() }.getOrNull(); halAt = nowMs }
        val hal = halCache
        val sys = parseZones(out[3])
        val kgsl = out.getOrNull(4)?.trim()?.toFloatOrNull()?.let { norm(it) }?.takeIf { it in 5f..120f } ?: -1f
        fun pick(vararg c: Pair<String, Float>): Pair<Float, String> =
            c.firstOrNull { it.second >= 0f }?.let { it.second to it.first } ?: (-1f to "-")
        val tc = pick("HAL" to (hal?.t?.cpu ?: -1f), "HAL-soc" to (hal?.t?.soc ?: -1f), "sysfs" to sys.cpu)
        val tg = pick("HAL" to (hal?.t?.gpu ?: -1f), "sysfs" to sys.gpu, "kgsl" to kgsl)
        val tb = pick("Intent" to batteryTemp(), "HAL" to (hal?.t?.bat ?: -1f), "sysfs" to sys.bat)
        val tsk = pick("HAL" to (hal?.t?.skin ?: -1f), "sysfs" to sys.skin)
        val tempDbg = "CPU ${tc.second}, GPU ${tg.second}, BAT ${tb.second}, skin %.0f° (%s) | HAL: %s".format(
            tsk.first, tsk.second, if (hal != null) "${hal.n} sensor" else "tidak siap/kosong")

        // Saat merekam, kunci paket game supaya fokus yang pindah sebentar (tarik notifikasi,
        // keyboard, toast, overlay) tidak mengalihkan pengukuran ke aplikasi lain.
        if (!Recorder.active.value) pinPkg = null
        else if (pinPkg == null) pinPkg = targetPkg()?.takeIf { it != appCtx?.packageName && it !in SKIP_PKGS }

        val f = runCatching { fps() }.getOrDefault(0 to 0)
        if (f.first > 0) { hist.addLast(f.first); if (hist.size > 30) hist.removeFirst() }
        // Layar diam / adegan statis: game tidak menyerahkan frame baru, jadi selisih frame = 0.
        // Tahan nilai terakhir beberapa detik supaya tidak langsung 0; 0 sungguhan tetap muncul.
        var shown = f.first
        if (f.first > 0) { lastFps = f.first; lastFpsPkg = curPkg; zeroTicks = 0 }
        else if (lastFps > 0 && lastFpsPkg == curPkg && curPkg.isNotEmpty() && zeroTicks < HOLD_TICKS) { zeroTicks++; shown = lastFps }
        else lastFps = 0
        // Aplikasi biasa (tanpa SurfaceView) hanya menggambar saat ada perubahan, jadi layar diam = 0-5 FPS
        // dan itu normal, bukan lag. Tampilkan refresh rate layar (ditandai idle) alih-alih angka kecil itu.
        var idle = false
        if (shown < IDLE_FPS && !surfaceApp && curPkg.isNotEmpty()) {
            val hz = displayHz(); if (hz > 0) { shown = hz; idle = true }
        }
        state.value = Snap(
            fpsRaw = f.first, idle = idle,
            fps = shown, avg = if (hist.isEmpty()) 0 else hist.average().toInt(),
            low = if (f.second > 0) f.second else (hist.minOrNull() ?: 0),
            ft = if (shown > 0) 1000f / shown else 0f, cpu = cpu, gpu = gpu,
            ramPct = ramPct, ramText = ramText, tCpu = tc.first, tGpu = tg.first, tBat = tb.first, access = mode, hist = hist.toList(),
            dbg = "FPS: $fpsDbg\nSuhu: $tempDbg\nGPU clk: $gpuFreqDbg", pkg = curPkg, watt = batteryWatt(),
            batPct = batteryPct(), cpuMhz = cpuMhz, gpuMhz = gpuMhz
        )
        Recorder.onSample(state.value)
    }

    @Volatile private var gpuFreqDbg = "-"

    /**
     * Baca frekuensi GPU dari beberapa jalur (urutan = prioritas). Satuan ditebak per jalur:
     * Hz (>=10 juta), kHz (>=10 ribu), selain itu MHz. Hanya nilai 100..3500 MHz yang diterima,
     * supaya jalur bus/bandwidth (mis. gpubw) atau nilai indeks tidak terbaca sebagai MHz.
     */
    private fun parseGpuFreq(block: String): Int {
        val seen = ArrayList<String>()
        var pick = -1
        for (l in block.lines()) {
            val i = l.lastIndexOf(':'); if (i <= 0) continue
            val path = l.substring(0, i); val raw = l.substring(i + 1).trim()
            val nums = Regex("\\d+").findAll(raw).mapNotNull { it.value.toLongOrNull() }.toList()
            if (nums.isEmpty()) continue
            // current_freqency (GED MediaTek) berformat "indeks kHz": ambil angka terbesar; lainnya angka pertama
            val v = if (path.endsWith("current_freqency")) nums.max() else nums[0]
            val mhz = when {
                path.endsWith("gpu_clock") -> v
                v >= 10_000_000L -> v / 1_000_000
                v >= 10_000L -> v / 1000
                else -> v
            }.toInt()
            seen.add("${path.substringAfter("/sys/").take(40)}=$raw")
            if (pick < 0 && mhz in 100..3500) pick = mhz
        }
        gpuFreqDbg = if (seen.isEmpty()) "tidak ada jalur terbaca" else seen.joinToString("; ") + " -> " + (if (pick >= 0) "$pick MHz" else "tidak valid")
        return pick
    }

    private var fpsDbg = "-"
    @Volatile private var curPkg = ""
    @Volatile private var pinPkg: String? = null
    private var halCache: Hal? = null; private var halAt = -10_000L
    private var lastFps = 0; private var lastFpsPkg = ""; private var zeroTicks = 0
    private val HOLD_TICKS = 3
    private val IDLE_FPS = 15          // di bawah ini pada aplikasi non-game = layar statis, bukan "FPS rendah"
    @Volatile private var surfaceApp = false   // layer SurfaceView = game / video, menggambar terus-menerus

    private fun displayHz(): Int = runCatching {
        appCtx?.getSystemService(DisplayManager::class.java)?.getDisplay(0)?.refreshRate?.let { Math.round(it) }
    }.getOrNull() ?: -1
    // Paket yang bukan target pengukuran: shade notifikasi / SystemUI.
    private val SKIP_PKGS = setOf("com.android.systemui", "android")

    private var focusCache = ""; private var focusAt = -10_000L
    private var lastGame = ""; private var lastGameAt = 0L

    private fun focusPkg(): String? {
        val outs = listOf(
            Shell.exec("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp' | head -6"),
            Shell.exec("dumpsys activity activities | grep -E 'topResumedActivity|ResumedActivity' | head -4")
        )
        for (o in outs) for (l in o.lines()) {
            if (l.contains("=null")) continue
            Regex("u\\d+ ([\\w.]+)/").find(l)?.let { return it.groupValues[1] }
        }
        return null
    }

    /**
     * Paket yang diukur. Fokus dibaca tiap 2 detik saja (dumpsys window menahan kunci sistem).
     * Fokus sementara ke SystemUI / keyboard / PulseMonitor sendiri diabaikan selama 20 detik
     * setelah game terakhir di depan; saat merekam, paket dikunci (pinPkg).
     */
    private fun targetPkg(): String? {
        pinPkg?.let { return it }
        val now = SystemClock.elapsedRealtime()
        if (now - focusAt >= 2000L) { focusCache = focusPkg() ?: ""; focusAt = now }
        val p = focusCache
        val transient = p.isEmpty() || p == appCtx?.packageName || p in SKIP_PKGS || p.contains("inputmethod")
        if (!transient) { lastGame = p; lastGameAt = now; return p }
        if (lastGame.isNotEmpty() && now - lastGameAt < 20_000L) return lastGame
        return p.ifEmpty { null }
    }

    private class Ts(val at: Long, val total: Map<String, Long>, val queued: Map<String, Long>)
    private val tsWin = ArrayDeque<Ts>()
    private var tsReady = false
    @Volatile private var presentFps = 0f
    @Volatile private var queuedFps = 0f

    /**
     * SurfaceFlinger TimeStats per layer: totalFrames (frame yang benar-benar tampil di layar) dan
     * droppedFrames (frame yang diserahkan game tetapi dilewati karena layar sedang lebih lambat).
     * Waktu sampel = titik tengah eksekusi dumpsys, bukan sesudahnya, supaya jeda eksekusi
     * yang berubah-ubah tidak membuat selisih waktu (dan FPS) melenceng.
     */
    private fun timestats(): Ts {
        if (!tsReady) { Shell.exec("dumpsys SurfaceFlinger --timestats -clear -enable"); tsReady = true; tsWin.clear() }
        val t0 = SystemClock.elapsedRealtime()
        val txt = Shell.exec("dumpsys SurfaceFlinger --timestats -dump")
        val at = (t0 + SystemClock.elapsedRealtime()) / 2
        val total = HashMap<String, Long>(); val queued = HashMap<String, Long>()
        var name: String? = null
        for (l in txt.lines()) {
            val t = l.trim()
            val v = t.substringAfter('=', "").trim().toLongOrNull()
            when {
                t.startsWith("layerName") -> name = t.substringAfter('=').trim()
                name != null && v != null && t.startsWith("totalFrames") -> { total[name!!] = v; queued[name!!] = (queued[name!!] ?: 0L) + v }
                name != null && v != null && t.startsWith("droppedFrames") -> queued[name!!] = (queued[name!!] ?: 0L) + v
            }
        }
        if (total.isEmpty()) tsReady = false   // statistik belum aktif/ter-reset: aktifkan lagi di tick berikutnya
        return Ts(at, total, queued)
    }

    /**
     * FPS = frame yang diserahkan game per detik (total + dropped) dari layer game, jendela ~2,5 detik.
     * Memakai angka ini (bukan hanya frame yang tampil) karena saat layar tidak disentuh panel sering
     * menurunkan refresh rate; frame game yang dilewati tidak boleh dihitung sebagai FPS rendah.
     * Cadangan bila layer tidak ada: --latency.
     */
    private fun fps(): Pair<Int, Int> {
        val pkg = targetPkg()
        curPkg = pkg ?: ""
        if (pkg == null) { fpsDbg = "aplikasi fokus tidak terbaca"; return 0 to 0 }
        val cur = timestats()
        tsWin.addLast(cur)
        while (tsWin.size > 1 && cur.at - tsWin.first().at > 2500L) tsWin.removeFirst()
        val cand = cur.total.keys.filter { it.contains(pkg) }
        val base = tsWin.first()
        val dt = (cur.at - base.at) / 1000f
        var bestQ = 0f; var bestP = 0f
        if (dt >= 0.3f) for (k in cand) {
            val p0 = base.total[k] ?: continue
            val q0 = base.queued[k] ?: continue
            val p1 = cur.total[k] ?: continue; val q1 = cur.queued[k] ?: continue
            if (p1 >= p0 && q1 >= q0) { bestP = maxOf(bestP, (p1 - p0) / dt); bestQ = maxOf(bestQ, (q1 - q0) / dt) }
        }
        presentFps = bestP; queuedFps = bestQ
        surfaceApp = cand.any { it.startsWith("SurfaceView") }
        if (cand.isNotEmpty()) {
            fpsDbg = "$pkg | ${cand.size} layer${if (surfaceApp) " (SurfaceView)" else ""} | tampil %.0f, diserahkan %.0f | layar %d Hz%s".format(
                bestP, bestQ, displayHz(), if (pinPkg != null) " | terkunci" else "")
            return Math.round(bestQ) to 0
        }
        surfaceApp = false
        val lat = fpsLatency(pkg)
        fpsDbg = "timestats: $pkg tidak ada (${cur.total.size} layer) -> latency: $fpsDbg"
        return lat
    }

    // ---------- SUHU ----------
    @Volatile private var appCtx: Context? = null
    fun init(c: Context) { appCtx = c.applicationContext }

    private class Temps {
        var cpu = -1f; var gpu = -1f; var bat = -1f; var skin = -1f; var soc = -1f
        fun put(kind: String, v: Float) {
            when (kind) {
                "cpu" -> cpu = maxOf(cpu, v); "gpu" -> gpu = maxOf(gpu, v); "bat" -> bat = maxOf(bat, v)
                "skin" -> skin = maxOf(skin, v); "soc" -> soc = maxOf(soc, v)
            }
        }
    }
    private class Hal(val t: Temps, val n: Int)

    /** Satuan sysfs bisa milli-derajat (42000), desi-derajat (420), atau derajat (42). */
    private fun norm(raw: Float) = when { raw >= 1000f -> raw / 1000f; raw > 150f -> raw / 10f; else -> raw }

    /** Suhu baterai dari broadcast sticky BATTERY_CHANGED (satuan 1/10 °C). Tanpa izin, tanpa Shizuku/root. */
    private fun batteryTemp(): Float {
        val i = runCatching { appCtx?.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) }.getOrNull()
            ?: return -1f
        val raw = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        if (raw == Int.MIN_VALUE) return -1f
        return (raw / 10f).takeIf { it in 1f..100f } ?: -1f
    }

    /** Persen baterai dari broadcast sticky BATTERY_CHANGED. */
    private fun batteryPct(): Int {
        val i = runCatching { appCtx?.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) }.getOrNull() ?: return -1
        val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1); val sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        return if (l >= 0 && sc > 0) l * 100 / sc else -1
    }

    /** Daya (Watt) = |arus baterai| x tegangan. Satuan arus beda-beda antar HP (µA atau mA), ditebak dari besarnya. -1 bila tidak terbaca. */
    private fun batteryWatt(): Float {
        val ctx = appCtx ?: return -1f
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager ?: return -1f
        val raw = runCatching { bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) }.getOrDefault(0)
        if (raw == 0 || raw == Int.MIN_VALUE) return -1f
        val mv = runCatching {
            ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
        }.getOrNull() ?: 0
        if (mv <= 0) return -1f
        val a = Math.abs(raw.toLong())
        val amps = if (a > 20_000L) a / 1e6f else a / 1e3f
        return (amps * mv / 1000f).takeIf { it in 0f..60f } ?: -1f
    }

    /** Kelompokkan sensor: nama dulu (gpuss, cpuss, quiet_therm, ...), baru tipe HAL (0 CPU, 1 GPU, 2 BAT, 3 SKIN, 13 SOC). */
    private fun kindOf(type: Int, name: String): String? {
        val n = name.lowercase()
        return when {
            "gpu" in n || "g3d" in n || "mali" in n || "adreno" in n -> "gpu"
            "batt" in n -> "bat"
            "cpu" in n -> "cpu"
            "skin" in n || "quiet" in n -> "skin"
            else -> when (type) { 0 -> "cpu"; 1 -> "gpu"; 2 -> "bat"; 3 -> "skin"; 13 -> "soc"; else -> null }
        }
    }

    private val tempRe = Regex("Temperature\\{([^}]*mValue[^}]*)\\}")
    private val valRe = Regex("mValue\\s*=\\s*(-?[0-9.]+)")
    private val typeRe = Regex("mType\\s*=\\s*(-?\\d+)")
    private val nameRe = Regex("mName\\s*=\\s*([^,}]+)")
    private val halDown = Regex("(?i)hal\\s*ready:\\s*false")

    /** Semua sensor di `dumpsys thermalservice` (seksi "Current temperatures from HAL"). Null bila HAL belum siap/kosong. */
    private fun thermalHal(): Hal? {
        val out = Shell.exec("dumpsys thermalservice")
        if (out.isBlank() || halDown.containsMatchIn(out)) return null
        val i = out.indexOf("Current temperatures from HAL")
        var sec = if (i >= 0) out.substring(i) else out
        val j = sec.indexOf("Cached temperatures"); if (j > 0) sec = sec.substring(0, j)
        val t = Temps(); var n = 0
        for (m in tempRe.findAll(sec)) {
            val body = m.groupValues[1]
            val v = valRe.find(body)?.groupValues?.get(1)?.toFloatOrNull() ?: continue
            if (v !in 1f..150f) continue          // buang sensor tidak valid (NaN/0/-ribuan)
            val ty = typeRe.find(body)?.groupValues?.get(1)?.toIntOrNull() ?: -1
            val nm = nameRe.find(body)?.groupValues?.get(1)?.trim() ?: ""
            kindOf(ty, nm)?.let { t.put(it, v); n++ }
        }
        return if (n > 0) Hal(t, n) else null
    }

    /** Cadangan: /sys/class/thermal/thermal_zone*. Tidak memakai zona "soc" (di banyak HP itu persen baterai, bukan suhu). */
    private fun parseZones(block: String): Temps {
        val zType = HashMap<String, String>(); val zTemp = HashMap<String, Float>()
        for (l in block.lines()) {
            val m = Regex("thermal_zone(\\d+)/(type|temp):(.*)").find(l) ?: continue
            val (z, k, v) = m.destructured
            if (k == "type") zType[z] = v.trim() else v.trim().toFloatOrNull()?.let { zTemp[z] = norm(it) }
        }
        val t = Temps()
        for ((z, ty) in zType) {
            val v = zTemp[z]?.takeIf { it in 5f..120f } ?: continue
            kindOf(-1, ty)?.let { t.put(it, v) }
        }
        return t
    }

    /** FPS dari SurfaceFlinger latency layer aplikasi yang sedang fokus. Return (fps, 1% low). */
    private fun fpsLatency(pkg: String): Pair<Int, Int> {
        val all = Shell.exec("dumpsys SurfaceFlinger --list").lines().map { it.trim() }
            .filter { it.contains(pkg) && !it.startsWith("Background") }
        if (all.isEmpty()) { fpsDbg = "$pkg: layer tidak ditemukan"; return 0 to 0 }
        val ordered = all.sortedByDescending { (if (it.contains("SurfaceView")) 2 else 0) + (if (it.contains("BLAST")) 1 else 0) }
        for (layer in ordered.take(4)) {
            val rows = Shell.exec("dumpsys SurfaceFlinger --latency '$layer'").lines().drop(1)
                .map { it.trim().split(Regex("\\s+")) }
            for (col in intArrayOf(1, 2)) {
                val ts = rows.mapNotNull { it.getOrNull(col)?.toLongOrNull() }
                    .filter { it in 1 until Long.MAX_VALUE / 2 }.sorted()
                if (ts.size < 3) continue
                val recent = ts.filter { it >= ts.last() - 1_000_000_000L }
                if (recent.size < 2 || recent.last() == recent.first()) continue
                val fps = ((recent.size - 1) * 1e9 / (recent.last() - recent.first())).toInt()
                val deltas = ts.zipWithNext { a, b -> b - a }.filter { it > 0 }.sortedDescending()
                if (deltas.isEmpty()) continue
                val worst = deltas[(deltas.size / 100).coerceAtMost(deltas.size - 1)]
                fpsDbg = "$pkg | ${layer.take(36)} | ${ts.size} frame, kolom $col"
                return fps to (1e9 / worst).toInt()
            }
        }
        fpsDbg = "$pkg: ${ordered.size} layer, data latency kosong"
        return 0 to 0
    }
}
