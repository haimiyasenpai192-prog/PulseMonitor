package com.pulsemonitor

import android.app.Application
import android.content.Context
import java.io.File

/** Menyimpan jejak crash terakhir ke berkas; ditampilkan di layar utama pada pembukaan berikutnya. */
object CrashLog {
    private fun file(c: Context) = File(c.applicationContext.filesDir, "last_crash.txt")

    fun install(app: Application) {
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching { AppLog.e("CRASH", "thread ${t.name}", e) }
            runCatching {
                val trace = "${java.util.Date()}\nThread: ${t.name}\n${android.util.Log.getStackTraceString(e)}"
                file(app).writeText(trace)
                AppLog.keepCrash(app, trace)
            }
            runCatching { AppLog.exportNow() }
            old?.uncaughtException(t, e)
        }
    }

    /** Ambil lalu hapus jejak crash terakhir (null bila tidak ada). */
    fun take(c: Context): String? {
        val f = file(c)
        if (!f.exists()) return null
        val s = runCatching { f.readText() }.getOrNull()
        f.delete()
        return s?.ifBlank { null }
    }
}

class PulseApp : Application() {
    override fun onCreate() { super.onCreate(); AppLog.init(this); CrashLog.install(this); AppLog.i("App", "proses dimulai") }
}
