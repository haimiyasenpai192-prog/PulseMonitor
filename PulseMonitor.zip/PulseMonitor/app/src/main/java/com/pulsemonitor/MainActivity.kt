package com.pulsemonitor

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.graphics.Bitmap
import android.os.Build
import android.provider.Settings
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import rikka.shizuku.Shizuku

private val Grey = Color(0xFF8E8E99)
private val Card = Color(0xE0131316); private val Bg = Color(0xFF0C0C0E)
private fun acc() = Color(AppSettings.accent)

class MainActivity : ComponentActivity() {
    // Android 13+: tanpa izin ini notifikasi foreground service tidak muncul
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private var wallpaperBmp by mutableStateOf<Bitmap?>(null)
    private var dim by mutableFloatStateOf(0.6f)

    // Photo Picker: tanpa izin galeri. Di Android 10-12 otomatis jatuh ke pemilih dokumen.
    private val pickImage = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) Thread {
            if (WallpaperStore.save(this, uri)) wallpaperBmp = WallpaperStore.load(this)
        }.start()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); AppSettings.load(this); Sampler.init(this); Sampler.start()
        wallpaperBmp = WallpaperStore.load(this); dim = WallpaperStore.dim(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent {
            val s by Sampler.state.collectAsState()
            var page by remember { mutableStateOf("home") }
            if (page == "settings") SettingsScreen { page = "home" }
            else Screen(s) { page = "settings" }
        }
    }

    @Composable
    fun Screen(s: Snap, openSettings: () -> Unit) {
        var on by remember { mutableStateOf(false) }
        Box(Modifier.fillMaxSize().background(Bg)) {
        wallpaperBmp?.let { bmp ->
            Image(bmp.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(Bg.copy(alpha = dim)))   // peredam agar teks tetap terbaca
        }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp).statusBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("PULSEMONITOR", color = acc(), fontWeight = FontWeight.Bold, letterSpacing = 3.sp, modifier = Modifier.weight(1f))
                Text("⚙", color = Grey, fontSize = 24.sp, modifier = Modifier.clickable { openSettings() }.padding(6.dp))
            }
            // Kartu utama: FPS + grafik 30 detik terakhir
            Column(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(24.dp)).padding(horizontal = 18.dp, vertical = 14.dp)) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("${s.fps}", color = Color.White, fontSize = 64.sp, fontWeight = FontWeight.SemiBold)
                    Text(" FPS", color = acc(), modifier = Modifier.padding(bottom = 14.dp))
                }
                FpsGraph(s.hist, Modifier.fillMaxWidth().height(56.dp))
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), Arrangement.SpaceBetween) {
                Stat("AVG", "${s.avg}"); Stat("1% LOW", "${s.low}"); Stat("FRAMETIME", "%.1f ms".format(s.ft))
            }
            StatPill("CPU", pct(s.cpu), s.tCpu)
            StatPill("GPU", pct(s.gpu), s.tGpu)
            StatPill("RAM", pct(s.ramPct), null)
            StatPill("Baterai", "", s.tBat)
            Row(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(20.dp)).padding(16.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text("Overlay mengambang", color = Color.White, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                Switch(checked = on, onCheckedChange = {
                    if (it && !Settings.canDrawOverlays(this@MainActivity)) {
                        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                    } else {
                        on = it
                        val i = Intent(this@MainActivity, OverlayService::class.java)
                        if (it) startForegroundService(i) else stopService(i)
                    }
                })
            }
            Column(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(20.dp)).padding(16.dp)) {
                Text("Akses: ${if (s.access == "-") "belum ada" else s.access}", color = Color.White, fontWeight = FontWeight.Bold)
                if (s.access == "-") {
                    Text("Jalankan Shizuku lalu beri izin, atau gunakan perangkat root.", color = Grey, fontSize = 12.sp)
                    Button(onClick = { runCatching { if (Shizuku.pingBinder()) Shizuku.requestPermission(1) } }) { Text("Beri izin Shizuku") }
                }
            }
            Column(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(20.dp)).padding(16.dp)) {
                Text("Wallpaper", color = Color.White, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = {
                        pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }) { Text(if (wallpaperBmp == null) "Pilih gambar" else "Ganti gambar") }
                    if (wallpaperBmp != null) OutlinedButton(onClick = { WallpaperStore.clear(this@MainActivity); wallpaperBmp = null }) {
                        Text("Hapus")
                    }
                }
                if (wallpaperBmp != null) {
                    Text("Redupkan latar", color = Grey, fontSize = 12.sp)
                    Slider(value = dim, onValueChange = { dim = it },
                        onValueChangeFinished = { WallpaperStore.saveDim(this@MainActivity, dim) },
                        valueRange = 0.2f..0.9f)
                }
            }
            if (s.dbg.isNotEmpty()) Column(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(20.dp)).padding(16.dp)) {
                Text("Diagnostik", color = Color.White, fontWeight = FontWeight.Bold)
                Text(s.dbg, color = Grey, fontSize = 11.sp)
            }
        }
        }
    }
}

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    BackHandler(onBack = onBack)
    Box(Modifier.fillMaxSize().background(Bg)) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp).statusBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("←", color = Color.White, fontSize = 26.sp, modifier = Modifier.clickable { onBack() }.padding(end = 14.dp))
                Text("Pengaturan", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
            SettingCard("Warna aksen") {
                Swatches(AppSettings.ACCENTS, AppSettings.accent) { AppSettings.accent = it; AppSettings.save(ctx) }
            }
            SettingCard("Warna teks overlay") {
                Swatches(AppSettings.TEXTS, AppSettings.overlayText) { AppSettings.overlayText = it; AppSettings.save(ctx) }
            }
            SettingCard("Latar overlay") {
                Swatches(AppSettings.BGS, AppSettings.overlayBg) { AppSettings.overlayBg = it; AppSettings.save(ctx) }
                Text("Transparan ${AppSettings.alpha}%", color = Grey, fontSize = 12.sp)
                Slider(value = AppSettings.alpha / 100f,
                    onValueChange = { AppSettings.alpha = (it * 100).toInt().coerceIn(20, 100) },
                    onValueChangeFinished = { AppSettings.save(ctx) },
                    valueRange = 0.2f..1f)
            }
            SettingCard("Warna suhu") {
                Text("Berubah sesuai tingkat panas", color = Grey, fontSize = 12.sp)
                HeatLegend(30f, "Aman, di bawah 45°"); HeatLegend(50f, "Hangat, 45-54°")
                HeatLegend(60f, "Panas, 55-64°"); HeatLegend(70f, "Sangat panas, 65°+")
            }
            Text("Perubahan warna overlay muncul dalam sekitar 1 detik.", color = Grey, fontSize = 12.sp)
            OutlinedButton(onClick = { AppSettings.reset(ctx) }, modifier = Modifier.fillMaxWidth()) { Text("Kembalikan warna awal") }
        }
    }
}

@Composable
fun SettingCard(title: String, content: @Composable ColumnScope.() -> Unit) = Column(
    Modifier.fillMaxWidth().background(Card, RoundedCornerShape(20.dp)).padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
) { Text(title, color = Color.White, fontWeight = FontWeight.Bold); content() }

@Composable
fun Swatches(colors: List<Int>, selected: Int, onPick: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        colors.forEach { c ->
            Box(Modifier.size(34.dp).background(Color(c), CircleShape)
                .then(if (c == selected) Modifier.border(2.dp, Color.White, CircleShape) else Modifier)
                .clickable { onPick(c) })
        }
    }
}

@Composable
fun HeatLegend(t: Float, label: String) = Row(verticalAlignment = Alignment.CenterVertically) {
    Box(Modifier.size(12.dp).background(Color(heat(t)), CircleShape))
    Text(label, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(start = 10.dp))
}

/** Grafik FPS: garis + isi tipis di bawahnya, skala 0..maks (minimal 30). */
@Composable
fun FpsGraph(h: List<Int>, m: Modifier) {
    val col = acc()
    Canvas(m) {
        if (h.size < 2) return@Canvas
        val mx = maxOf(h.maxOrNull() ?: 30, 30).toFloat()
        val stepX = size.width / (h.size - 1)
        val line = Path(); val fill = Path()
        h.forEachIndexed { i, v ->
            val x = i * stepX; val y = size.height - (v / mx) * size.height
            if (i == 0) { line.moveTo(x, y); fill.moveTo(x, size.height); fill.lineTo(x, y) }
            else { line.lineTo(x, y); fill.lineTo(x, y) }
        }
        fill.lineTo(size.width, size.height); fill.close()
        drawPath(fill, col.copy(alpha = 0.14f))
        drawPath(line, col, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** Baris pil: label di kiri, beban dan suhu (berwarna sesuai panas) di kanan. */
@Composable
fun StatPill(label: String, use: String, t: Float?) {
    Row(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(50)).padding(horizontal = 22.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (use.isNotEmpty()) Text(use, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        if (t != null) Text(if (t >= 0) "%.0f°C".format(t) else "-", color = if (t >= 0) Color(heat(t)) else Grey,
            fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 14.dp))
    }
}

@Composable
fun Stat(l: String, v: String) = Column { Text(l, color = Grey, fontSize = 11.sp); Text(v, color = Color.White, fontSize = 19.sp) }
