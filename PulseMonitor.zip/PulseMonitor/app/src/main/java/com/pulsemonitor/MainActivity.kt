package com.pulsemonitor

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.graphics.Bitmap
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import rikka.shizuku.Shizuku

private val Grey = Color(0xFF8E8E99)
private val Bg = Color(0xFF0C0C0E)
// Panel besar di bawah (gaya WuWa Config); transparansinya diatur di tab Tampilan
private val Glass: Color get() = Color(0xFF101116).copy(alpha = AppSettings.panelAlpha / 100f)
// Baris/kartu di dalam panel: tetap solid di nilai bawaan, makin tembus saat slider diturunkan
private val Inner: Color get() = Color(0xFF181A21).copy(alpha = (AppSettings.panelAlpha / AppSettings.DEF_PANEL.toFloat()).coerceAtMost(1f))
// Warna tiap tab navigasi: Beranda biru, Statistik ungu, CPU oranye, Rekaman pink, Tampilan hijau, Settings kuning
private val NavColors = listOf(Color(0xFF6FA8FF), Color(0xFFA78BFA), Color(0xFFFF9F43), Color(0xFFF08FB8), Color(0xFF5BD68E), Color(0xFFE8B84A))
private val Pink = Color(0xFFD58FC4)
private val Blue = Color(0xFF6FA8FF)
private fun acc() = Color(AppSettings.accent)

class MainActivity : ComponentActivity() {
    // Android 13+: tanpa izin ini notifikasi foreground service tidak muncul
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private var wallpaperBmp by mutableStateOf<Bitmap?>(null)
    private var dim by mutableFloatStateOf(0.6f)
    private var overlayOn by mutableStateOf(OverlayService.overlayShown.value)
    private var reportId by mutableStateOf<Long?>(null)
    private var accessDlg by mutableStateOf(false)
    private var styleDlg by mutableStateOf(false)

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, r -> Access.onPermissionResult(r == PackageManager.PERMISSION_GRANTED) }
    private val binderListener = Shizuku.OnBinderReceivedListener { Access.refresh() }
    private val deadListener = Shizuku.OnBinderDeadListener { Access.refresh() }

    // Photo Picker: tanpa izin galeri. Di Android 10-12 otomatis jatuh ke pemilih dokumen.
    private val pickImage = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) Thread {
            if (WallpaperStore.save(this, uri)) wallpaperBmp = WallpaperStore.load(this)
        }.start()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); enableEdgeToEdge()
        AppSettings.load(this); Sampler.init(this)
        Shizuku.addRequestPermissionResultListener(permListener)
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        wallpaperBmp = WallpaperStore.load(this); dim = WallpaperStore.dim(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent {
            val s by Sampler.state.collectAsState()
            // Status tombol mengikuti keadaan layanan yang sebenarnya (tetap benar setelah aplikasi dibuka ulang)
            val shown by OverlayService.overlayShown.collectAsState()
            LaunchedEffect(shown) { overlayOn = shown }
            var tab by remember { mutableIntStateOf(0) }
            BackHandler(enabled = tab != 0) { tab = 0 }
            val rid = reportId
            BackHandler(enabled = rid != null) { reportId = null }
            AnimatedContent(targetState = rid, label = "page", transitionSpec = {
                if (targetState != null)   // buka laporan: masuk dari kanan, halaman lama bergeser sedikit
                    (slideInHorizontally(tween(320)) { it } + fadeIn(tween(320))) togetherWith
                        (slideOutHorizontally(tween(320)) { -it / 4 } + fadeOut(tween(220)))
                else                       // kembali: laporan keluar ke kanan
                    (slideInHorizontally(tween(320)) { -it / 4 } + fadeIn(tween(320))) togetherWith
                        (slideOutHorizontally(tween(320)) { it } + fadeOut(tween(220)))
            }) { id -> if (id != null) ReportScreen(id) else Screen(s, tab) { tab = it } }
        }
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        super.onDestroy()
    }

    override fun onStart() {
        super.onStart()
        Access.refresh()
        Sampler.uiVisible = true; Sampler.start()
    }

    override fun onStop() {
        super.onStop()
        // Aplikasi tidak terlihat: hentikan pembacaan sensor bila tidak ada overlay/rekaman yang memakainya
        Sampler.uiVisible = false
        if (!OverlayService.overlayShown.value && !Recorder.active.value) Sampler.stop()
    }

    private fun toggleOverlay() {
        val turnOn = !OverlayService.overlayShown.value
        if (turnOn && !Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val i = Intent(this, OverlayService::class.java)
        when {
            turnOn -> { playOverlaySound(); startForegroundService(i) }
            // Mode latar belakang: overlay disembunyikan, layanan (notifikasi) tetap hidup
            AppSettings.bgMode -> startForegroundService(i.setAction(OverlayService.ACTION_HIDE))
            else -> stopService(i)
        }
    }

    /** Saklar "Tetap aktif di latar belakang": nyala = layanan hidup tanpa overlay; mati = layanan berhenti bila overlay juga mati. */
    private fun applyBgMode(on: Boolean) {
        val i = Intent(this, OverlayService::class.java)
        if (on) { if (!OverlayService.alive) startForegroundService(i.setAction(OverlayService.ACTION_HIDE)) }
        else if (!OverlayService.overlayShown.value) stopService(i)
    }

    /** Suara notifikasi saat overlay dinyalakan (res/raw/overlay_on.m4a). Gagal memutar tidak boleh mengganggu overlay. */
    private fun playOverlaySound() {
        runCatching {
            val attrs = android.media.AudioAttributes.Builder()
                .setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            val mp = android.media.MediaPlayer.create(this, R.raw.overlay_on, attrs, android.media.AudioManager.AUDIO_SESSION_ID_GENERATE)
                ?: return
            mp.setOnCompletionListener { it.release() }
            mp.setOnErrorListener { p, _, _ -> p.release(); true }
            mp.start()
        }
    }

    @Composable
    fun Screen(s: Snap, tab: Int, setTab: (Int) -> Unit) {
        val titles = listOf("", "Detail sensor dan diagnostik", "Frekuensi dan beban CPU", "Rekam FPS dan lihat laporan", "Wallpaper dan warna overlay", "Gaya overlay")
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1A2038), Bg)))) {
            wallpaperBmp?.let { bmp ->
                Image(bmp.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                // makin gelap ke bawah supaya panel dan teks tetap terbaca
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
                    listOf(Bg.copy(alpha = dim * 0.35f), Bg.copy(alpha = dim)))))
            }
            // Kepala: judul besar + chip akses
            Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 24.dp, vertical = 20.dp),
                verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    Text("PulseMonitor", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                    AnimatedContent(targetState = titles[tab], label = "subtitle",
                        transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(120)) }) { t ->
                        if (t.isNotEmpty()) Text(t, color = Color(0xFFD0D0DA), fontSize = 15.sp)
                    }
                }
                Spacer(Modifier.width(14.dp))   // jarak judul dan chip akses
                val ok = s.access != "-"
                Row(Modifier.clip(RoundedCornerShape(50)).background(Color(0xB3101116))
                    .clickable(enabled = !ok) { Access.refresh(); accessDlg = true }.padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(11.dp).background(if (ok) Color(0xFF7CFFB2) else Color(0xFFFF5C5C), CircleShape))
                    Text(if (ok) s.access else "Beri izin", color = if (ok) Color(0xFF7CFFB2) else Color(0xFFFF8A8A),
                        fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(start = 8.dp))
                }
            }
            if (accessDlg) AccessDialog { accessDlg = false }
            // Panel bawah + navigasi
            Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(Modifier.fillMaxWidth().background(Glass, RoundedCornerShape(32.dp)).padding(10.dp)) {
                    AnimatedContent(targetState = tab, label = "tab", transitionSpec = {
                        val dir = if (targetState > initialState) 1 else -1   // geser sesuai arah tab
                        (slideInHorizontally(tween(260)) { it / 4 * dir } + fadeIn(tween(260))) togetherWith
                            (slideOutHorizontally(tween(200)) { -it / 4 * dir } + fadeOut(tween(160))) using SizeTransform(clip = true)
                    }) { t ->
                    when (t) {
                        0 -> HomeTab(s)
                        1 -> Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(10.dp)) { StatsTab(s) }
                        2 -> Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(10.dp)) { CpuTab(s) }
                        3 -> Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(10.dp)) { RecordTab(s) }
                        4 -> Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(10.dp)) { DisplayTab(); ColorContent() }
                        else -> Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(10.dp)) { SettingsContent() }
                    }
                    }
                }
                Box(Modifier.fillMaxWidth().background(Glass, RoundedCornerShape(32.dp)).padding(8.dp)) {
                    BoxWithConstraints(Modifier.fillMaxWidth()) {
                        val w = maxWidth / 6
                        val pill by animateColorAsState(NavColors[tab].copy(alpha = 0.28f), tween(260), label = "navPillCol")
                        val x by animateDpAsState(w * tab, spring(dampingRatio = 0.75f, stiffness = Spring.StiffnessMediumLow), label = "navPill")
                        // pil penanda meluncur ke tab terpilih
                        Box(Modifier.matchParentSize()) {
                            Box(Modifier.offset(x = x).width(w).fillMaxHeight().background(pill, RoundedCornerShape(26.dp)))
                        }
                        Row(Modifier.fillMaxWidth()) {
                            NavItem("⌂", "Beranda", tab == 0, NavColors[0]) { setTab(0) }
                            NavItem("▤", "Statistik", tab == 1, NavColors[1]) { setTab(1) }
                            NavItem("▣", "CPU", tab == 2, NavColors[2]) { setTab(2) }
                            NavItem("●", "Rekaman", tab == 3, NavColors[3]) { setTab(3) }
                            NavItem("◐", "Tampilan", tab == 4, NavColors[4]) { setTab(4) }
                            NavItem("⚙", "Settings", tab == 5, NavColors[5]) { setTab(5) }
                        }
                    }
                }
            }
        }
    }

    /** Tab CPU: frekuensi tiap inti (dua kolom) dan grafik beban CPU di dasar kartu. */
    @Composable
    private fun CpuTab(s: Snap) {
        val green = Color(0xFF6FAE68)
        if (s.access == "-") Text("Belum ada akses. Pilih Shizuku atau Root di tab Settings.", color = Color(0xFFE0B040), fontSize = 12.sp,
            modifier = Modifier.fillMaxWidth().background(Color(0x1FE0B040), RoundedCornerShape(16.dp)).padding(horizontal = 14.dp, vertical = 10.dp))
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Inner)) {
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Status CPU", color = green, fontSize = 17.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                Text(pct(s.cpu), color = loadColor(s.cpu), fontSize = 17.sp, fontWeight = FontWeight.Bold)
            }
            val peak = remember { intArrayOf(0) }
            peak[0] = maxOf(peak[0], s.coreMhz.maxOrNull() ?: 0)
            if (s.coreMhz.isEmpty()) {
                Text("Frekuensi belum terbaca", color = Grey, fontSize = 13.sp, modifier = Modifier.padding(16.dp))
            } else Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                s.coreMhz.withIndex().toList().chunked(2).forEach { pair ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        pair.forEach { (i, mhz) ->
                            val frac = if (mhz > 0 && peak[0] > 0) (mhz.toFloat() / peak[0]).coerceIn(0.03f, 1f) else 0f
                            val barCol = if (frac >= 0.95f) Color(0xFFFF9F43) else green
                            Column(Modifier.weight(1f).background(Color(0xFF101116), RoundedCornerShape(14.dp)).padding(horizontal = 12.dp, vertical = 10.dp)) {
                                Text("Inti $i", color = Grey, fontSize = 11.sp)
                                Text(if (mhz > 0) "$mhz MHz" else "Offline", color = if (mhz > 0) Color.White else Grey, fontSize = 17.sp, maxLines = 1)
                                Box(Modifier.padding(top = 6.dp).fillMaxWidth().height(4.dp).background(Color(0xFF2A2D38), RoundedCornerShape(2.dp))) {
                                    Box(Modifier.fillMaxWidth(frac).height(4.dp).background(barCol, RoundedCornerShape(2.dp)))
                                }
                            }
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
            CpuGraph(s.cpuHist, green, Modifier.fillMaxWidth().height(64.dp))
        }
    }

    @Composable
    private fun HomeTab(s: Snap) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // Status overlay + petunjuk singkat
            Row(Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(24.dp)).padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically) {
                val sc = if (overlayOn) Color(0xFF5FD38D) else Grey
                Box(Modifier.size(36.dp).border(3.dp, sc, CircleShape), contentAlignment = Alignment.Center) {
                    Text(if (overlayOn) "✓" else "–", color = sc, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
                Column(Modifier.padding(start = 14.dp).weight(1f)) {
                    Text(if (overlayOn) "Overlay aktif" else "Overlay mati", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                    Text(if (overlayOn) "Tahan overlay 1 detik untuk mulai rekam" else "Nyalakan untuk memantau FPS di atas game",
                        color = Grey, fontSize = 12.sp, maxLines = 1)
                }
            }
            // FPS dan frametime: dua kartu sama besar, FPS ditandai garis aksen
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BigCard("FPS", "${s.fps}", if (s.idle) "Layar diam" else "Frame per detik", true, Modifier.weight(1f))
                BigCard("Frametime", if (s.ft > 0f) "%.1f ms".format(s.ft) else "-", "Makin kecil makin halus", false, Modifier.weight(1f))
            }
            // Grafik 30 detik terakhir
            Column(Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(24.dp)).padding(horizontal = 18.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("FPS · 30 detik terakhir", color = Grey, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    Text("AVG ${if (s.avg > 0) s.avg else "-"}   LOW ${if (s.low > 0) s.low else "-"}", color = Grey, fontSize = 12.sp)
                }
                FpsGraph(s.hist, Modifier.fillMaxWidth().height(56.dp))
            }
            // Baris sensor: CPU / GPU / RAM / BAT, beban diberi warna, dipisah garis tipis
            Row(Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(24.dp)).padding(horizontal = 8.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Metric("CPU", pct(s.cpu), "", -1f, mainColor = loadColor(s.cpu)); MetricDivider()
                Metric("GPU", pct(s.gpu), "", -1f, mainColor = loadColor(s.gpu)); MetricDivider()
                Metric("RAM", pct(s.ramPct), "", -1f, mainColor = loadColor(s.ramPct)); MetricDivider()
                Metric("BAT", deg(s.tBat), "", -1f, mainTemp = s.tBat)
            }
            // Tombol utama
            Box(Modifier.fillMaxWidth().height(50.dp).clip(RoundedCornerShape(25.dp))
                .background(Brush.horizontalGradient(if (overlayOn) listOf(Color(0xFFE5677A), Pink) else listOf(Blue, Color(0xFF9A86E8), Pink)))
                .clickable { toggleOverlay() }, contentAlignment = Alignment.Center) {
                Text(if (overlayOn) "Matikan Overlay" else "Nyalakan Overlay", color = Color.White,
                    fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
    }

    private fun toggleRecord(s: Snap) {
        if (Recorder.active.value) {
            Thread {
                val r = Recorder.stop(this)
                runOnUiThread { Toast.makeText(this, if (r != null) "Rekaman tersimpan" else "Tidak ada data FPS yang terekam", Toast.LENGTH_SHORT).show() }
            }.start()
        } else {
            if (s.access == "-") { Toast.makeText(this, "Butuh Shizuku atau root untuk merekam", Toast.LENGTH_SHORT).show(); return }
            Recorder.start()
            if (!overlayOn) Toast.makeText(this, "Nyalakan overlay supaya rekaman tetap jalan saat kamu pindah ke game", Toast.LENGTH_LONG).show()
        }
    }

    private fun shareSummary(s: Session) {
        val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, Recorder.summary(s)) }
        startActivity(Intent.createChooser(i, "Bagikan laporan"))
    }

    @Composable
    private fun RecordTab(s: Snap) {
        val rec by Recorder.active.collectAsState()
        val n by Recorder.count.collectAsState()
        val ver by Recorder.version.collectAsState()
        var list by remember { mutableStateOf<List<Session>>(emptyList()) }
        LaunchedEffect(ver) { list = withContext(Dispatchers.IO) { Recorder.list(this@MainActivity) } }
        Column(Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(24.dp)).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (rec) {
                    val blink by rememberInfiniteTransition(label = "rec").animateFloat(1f, 0.25f,
                        infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "recDot")
                    Box(Modifier.padding(end = 12.dp).size(12.dp).graphicsLayer { alpha = blink }.background(Color(0xFFFF5C5C), CircleShape))
                }
                Column(Modifier.weight(1f)) {
                    Text(if (rec) "Merekam" else "Rekam FPS", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text(if (rec) "${s.fps} FPS saat ini" else "Tekan Mulai, lalu buka game.", color = Grey, fontSize = 12.sp)
                }
                if (rec) Text(fmtDur(n), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            }
            if (!rec) Text("Berhenti lewat tombol di notifikasi, atau tahan overlay sekitar 1 detik tanpa menggesernya.", color = Grey, fontSize = 12.sp)
            Box(Modifier.fillMaxWidth().height(46.dp).clip(RoundedCornerShape(23.dp))
                .background(Brush.horizontalGradient(if (rec) listOf(Color(0xFFE5677A), Pink) else listOf(Blue, Color(0xFF9A86E8), Pink)))
                .clickable { toggleRecord(s) }, contentAlignment = Alignment.Center) {
                Text(if (rec) "Berhenti dan simpan" else "Mulai rekam", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
        if (list.isEmpty()) {
            Column(Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(24.dp)).padding(horizontal = 16.dp, vertical = 22.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Belum ada rekaman", color = Color.White, fontWeight = FontWeight.Bold)
                Text("Hasil rekaman muncul di sini, lengkap dengan grafik dan laporan.", color = Grey, fontSize = 12.sp, textAlign = TextAlign.Center)
            }
        } else {
            SectionTitle("Riwayat · ${list.size}")
            list.forEach { r -> RecRow(r) { reportId = r.id } }
        }
    }

    @Composable
    private fun RecRow(r: Session, onClick: () -> Unit) {
        val st = remember(r.id) { r.stats() }
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Inner).clickable { onClick() }.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(r.label, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(fmtDate(r.id), color = Grey, fontSize = 12.sp, maxLines = 1)
            }
            Column(Modifier.padding(start = 12.dp), horizontalAlignment = Alignment.End) {
                Text(f1(st.avg), color = acc(), fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text("FPS  ·  ${fmtDur(r.dur)}", color = Grey, fontSize = 12.sp, maxLines = 1)
            }
            Text("›", color = Grey, fontSize = 22.sp, modifier = Modifier.padding(start = 10.dp))
        }
    }

    @Composable
    private fun ReportScreen(id: Long) {
        val sess by produceState<Session?>(null, id) { value = withContext(Dispatchers.IO) { Recorder.load(this@MainActivity, id) } }
        val ss = sess
        if (ss == null) {
            Box(Modifier.fillMaxSize().background(Color(0xFF101014)), contentAlignment = Alignment.Center) { Text("Memuat…", color = Grey) }
            return
        }
        ReportView(ss, onBack = { reportId = null }, onShare = { shareSummary(ss) },
            onCsv = {
                Thread {
                    val ok = Recorder.exportCsv(this, ss)
                    runOnUiThread { Toast.makeText(this, if (ok) "CSV tersimpan di folder Download" else "Gagal menyimpan CSV", Toast.LENGTH_SHORT).show() }
                }.start()
            },
            onDelete = { Recorder.delete(this, ss.id); reportId = null },
            onDesc = { t -> Thread { Recorder.saveDesc(this, ss, t) }.start() },
            wallpaper = wallpaperBmp, dim = dim)
    }

    @Composable
    private fun StatsTab(s: Snap) {
        var diag by remember { mutableStateOf(false) }
        if (s.access == "-") Text("Belum ada akses. Pilih Shizuku atau Root di tab Settings.", color = Color(0xFFE0B040), fontSize = 12.sp,
            modifier = Modifier.fillMaxWidth().background(Color(0x1FE0B040), RoundedCornerShape(16.dp)).padding(horizontal = 14.dp, vertical = 10.dp))
        SettingCard("Memori") {
            val m = s.mem
            if (m == null) {
                MeterRow("RAM", s.ramText, if (s.ramPct >= 0) s.ramPct / 100f else 0f, barLoad(s.ramPct))
                if (s.swapText.isNotEmpty()) MeterRow("Swap", s.swapText, usedFrac(s.swapText), Color(0xFFA78BFA))
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Ukuran RAM", color = Grey, fontSize = 13.sp, modifier = Modifier.weight(1f))
                    Text("${m.marketGb} GB", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
                MemBlock("RAM", m.ramTotal, m.ramUsed, m.ramFree, barLoad(s.ramPct))
                if (m.swapTotal > 0f) MemBlock(if (m.zram) "ZRAM" else "Swap", m.swapTotal, m.swapUsed, m.swapFree, Color(0xFFA78BFA))
            }
        }
        SettingCard("Suhu") {
            TempMeter("CPU", s.tCpu); TempMeter("GPU", s.tGpu); TempMeter("Baterai", s.tBat)
        }
        if (s.access != "-") SettingCard("Probe GPU") {
            Text("Membaca semua node GPU di HP ini dan menyalinnya ke clipboard, untuk mencari sumber frekuensi yang benar.", color = Grey, fontSize = 12.sp)
            PillButton("Probe GPU dan salin") {
                Toast.makeText(this@MainActivity, "Membaca node GPU...", Toast.LENGTH_SHORT).show()
                Thread {
                    val t = Sampler.gpuProbe()
                    this@MainActivity.runOnUiThread {
                        if (t.isBlank()) Toast.makeText(this@MainActivity, "Tidak ada hasil (butuh Shizuku/root)", Toast.LENGTH_SHORT).show()
                        else {
                            val cm = this@MainActivity.getSystemService(android.content.ClipboardManager::class.java)
                            cm.setPrimaryClip(android.content.ClipData.newPlainText("gpu-probe", t))
                            Toast.makeText(this@MainActivity, "Tersalin (${t.length} karakter). Tempel ke chat.", Toast.LENGTH_LONG).show()
                        }
                    }
                }.start()
            }
        }
        if (s.dbg.isNotEmpty()) SettingCard("Diagnostik") {
            PillButton(if (diag) "Sembunyikan" else "Tampilkan", filled = false) { diag = !diag }
            if (diag) Text(s.dbg, color = Grey, fontSize = 10.5.sp, lineHeight = 15.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
        }
    }

    @Composable
    private fun DisplayTab() {
        val ctx = LocalContext.current
        SectionTitle("Tampilan aplikasi")
        SettingCard("Wallpaper") {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PillButton(if (wallpaperBmp == null) "Pilih gambar" else "Ganti gambar") {
                    pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
                if (wallpaperBmp != null) PillButton("Hapus", filled = false) { WallpaperStore.clear(this@MainActivity); wallpaperBmp = null }
            }
            if (wallpaperBmp != null) {
                SliderLabel("Redupkan latar", "${(dim * 100).toInt()}%")
                AccSlider(dim, 0.2f..0.9f, { dim = it }) { WallpaperStore.saveDim(this@MainActivity, dim) }
            } else Text("Belum ada gambar. Pilih satu untuk jadi latar aplikasi.", color = Grey, fontSize = 12.sp)
        }
        SettingCard("Transparan panel") {
            SliderLabel("Seberapa tembus panel dan navigasi", "${AppSettings.panelAlpha}%")
            AccSlider(AppSettings.panelAlpha / 100f, 0.15f..1f, { AppSettings.panelAlpha = (it * 100).toInt().coerceIn(15, 100) }) { AppSettings.save(ctx) }
            PillButton("Kembalikan bawaan", filled = false) { AppSettings.panelAlpha = AppSettings.DEF_PANEL; AppSettings.save(ctx) }
        }
        SectionTitle("Overlay")
    }

    /** Pratinjau gaya overlay: warna dan latar mengikuti pengaturan, label redup dan suhu berwarna seperti overlay aslinya. */
    private fun previewText(idx: Int): AnnotatedString {
        val ac = Color(AppSettings.accent); val tx = Color(AppSettings.overlayText); val mu = tx.copy(alpha = 0.65f)
        fun heatC(t: Float) = Color(heat(t))
        return buildAnnotatedString {
            fun p(t: String, c: Color = Color.Unspecified, b: Boolean = false) =
                withStyle(SpanStyle(color = c, fontWeight = if (b) FontWeight.Bold else null)) { append(t) }
            p("FPS ", ac); p("60", b = true)
            when (idx) {
                0 -> { p("  CPU 35% "); p("42°", heatC(42f)); p("  GPU 45% "); p("41°", heatC(41f)); p("  BAT 85%") }
                else -> {
                    p("  16.7 ms", mu); p("\n")
                    if (idx == 2) { p("AVG ", mu); p("58"); p("   LOW ", mu); p("45"); p("\n") }
                    p("CPU ", mu); p("35%  "); p("42°", heatC(42f)); p("  1800 MHz", mu); p("\n")
                    p("GPU ", mu); p("45%  "); p("41°", heatC(41f)); p("  680 MHz", mu); p("\n")
                    if (idx == 1) { p("RAM ", mu); p("62%  "); p("7.1 / 11 GB", mu); p("\n") }
                    else { p("RAM ", mu); p("62%  7.1 / 11 GB"); p("\n") }
                    p("BAT ", mu); p("85%  "); p("36°", heatC(36f))
                    if (idx == 1) p("  2.4 W", mu)
                    else { p("\n"); p("PWR ", mu); p("2.4 W") }
                }
            }
        }
    }

    @Composable
    private fun StyleOption(idx: Int, title: String, sub: String, inDialog: Boolean = false, onPicked: () -> Unit = {}) {
        val ctx = LocalContext.current
        val sel = AppSettings.overlayStyle == idx
        val ac = acc()
        val border by animateColorAsState(if (sel) ac else Color(0x22FFFFFF), tween(200), label = "styBorder")
        val shape = RoundedCornerShape(20.dp)
        Column(Modifier.fillMaxWidth().clip(shape)
            .background(if (sel) ac.copy(alpha = 0.10f) else Color(0x12FFFFFF))
            .border(if (sel) 2.dp else 1.dp, border, shape)
            .clickable { AppSettings.overlayStyle = idx; AppSettings.save(ctx); onPicked() }.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(sub, color = Grey, fontSize = 12.sp)
                }
                Box(Modifier.size(24.dp).background(if (sel) ac else Color.Transparent, CircleShape)
                    .border(2.dp, if (sel) ac else Grey, CircleShape), contentAlignment = Alignment.Center) {
                    if (sel) Text("✓", color = Color(0xFF101014), fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
            val pv = RoundedCornerShape(if (idx == 0) 20.dp else 14.dp)
            Text(previewText(idx), color = Color(AppSettings.overlayText), fontSize = 10.5.sp, lineHeight = 15.sp,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, softWrap = idx != 0 || inDialog, maxLines = if (idx == 0 && !inDialog) 1 else Int.MAX_VALUE,
                modifier = Modifier.clip(pv).background(Color(withAlpha(AppSettings.overlayBg, AppSettings.alpha)))
                    .border(1.dp, Color(withAlpha(AppSettings.accent, 33)), pv)
                    .padding(horizontal = 12.dp, vertical = if (idx == 0) 6.dp else 9.dp))
        }
    }

    @Composable
    private fun SettingsContent() {
        val ctx = LocalContext.current
        val s by Sampler.state.collectAsState()
        // Setelah memilih metode, status mengikuti Access langsung (bukan menunggu tick Sampler)
        val auto = Access.choice == Access.AUTO
        val connected = if (auto) s.access != "-" else Access.status == 2
        val root = if (auto && connected) s.access == "Root" else Access.isRoot()
        SettingCard("Akses") {
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable { Access.refresh(); accessDlg = true }.padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).background(Color(0xFF0A0A1A), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                    if (root) ShieldIcon(Color(0xFFE49A72), Modifier.size(24.dp)) else PhoneIcon(Color(0xFF8E86F0), Modifier.size(24.dp))
                }
                Column(Modifier.weight(1f).padding(start = 14.dp)) {
                    Text(if (root) "Root" else "Shizuku", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text(when {
                        Access.busy > 0 -> "Memeriksa…"
                        connected -> "Terhubung"
                        Access.status == 1 -> "Ketuk untuk beri izin"
                        root -> "Root tidak tersedia"
                        else -> "Tidak berjalan"
                    }, color = if (connected) Color(0xFF5BD68E) else Color(0xFFE0B040), fontSize = 13.sp)
                }
                Text("›", color = Grey, fontSize = 22.sp)
            }
        }
        SettingCard("Latar belakang") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Tetap aktif di latar belakang", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    Text("Notifikasi baterai tetap hidup walau overlay dimatikan. Tanpa overlay dan tanpa pembacaan sensor, jadi ringan di RAM. Matikan saklar ini untuk menghapus notifikasi.",
                        color = Grey, fontSize = 12.sp)
                }
                Spacer(Modifier.width(12.dp))
                Switch(checked = AppSettings.bgMode, onCheckedChange = { on -> AppSettings.bgMode = on; AppSettings.save(ctx); applyBgMode(on) })
            }
        }
        // Satu baris: nama gaya yang aktif tampil di samping, ketuk untuk memilih gaya lain
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Inner).clickable { styleDlg = true }.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Gaya overlay", color = Color.White, fontWeight = FontWeight.Bold)
                Text("Ketuk untuk memilih bentuk overlay", color = Grey, fontSize = 12.sp)
            }
            Text(AppSettings.STYLES[AppSettings.overlayStyle], color = acc(), fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text("  ›", color = Grey, fontSize = 22.sp)
        }
        if (styleDlg) StyleDialog { styleDlg = false }
    }

    @Composable
    private fun StyleDialog(onDismiss: () -> Unit) {
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Color.Black,
            shape = RoundedCornerShape(28.dp),
            title = { Text("Gaya overlay", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 24.sp) },
            text = {
                Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Pratinjau mengikuti warna dan transparansi di tab Tampilan.", color = Color(0xFFA9B0B5), fontSize = 13.sp)
                    StyleOption(0, "Simple", "Satu baris: FPS, CPU, GPU, baterai", inDialog = true, onPicked = onDismiss)
                    StyleOption(1, "Compact", "Kartu kecil per komponen, dengan frekuensi", inDialog = true, onPicked = onDismiss)
                    StyleOption(2, "Normal", "Paling lengkap: rata-rata, low, RAM, daya, game", inDialog = true, onPicked = onDismiss)
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text("Batal", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
        )
    }

    @Composable
    private fun AccessDialog(onDismiss: () -> Unit) {
        val cur = Access.choice
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Color.Black,
            shape = RoundedCornerShape(28.dp),
            title = { Text("Izinkan Akses", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 24.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Pilih metode yang ingin dipakai untuk akses tingkat tinggi.", color = Color(0xFFA9B0B5))
                    AccessOption("Shizuku", "Tanpa root, jalan lewat Wireless Debugging atau ADB.",
                        Color(0xFF8E86F0), Color(0xFF13111F), cur == Access.SHIZUKU, { PhoneIcon(Color(0xFF8E86F0), Modifier.size(30.dp)) }) {
                        Access.select(Access.SHIZUKU); onDismiss()
                    }
                    AccessOption("Root", "Butuh perangkat yang di-root (Magisk, KernelSU, APatch, dll).",
                        Color(0xFFE49A72), Color(0xFF181412), cur == Access.ROOT, { ShieldIcon(Color(0xFFE49A72), Modifier.size(30.dp)) }) {
                        Access.select(Access.ROOT); onDismiss()
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text("Batal", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
        )
    }

    /** Warna overlay (bagian bawah tab Tampilan). */
    @Composable
    private fun ColorContent() {
        val ctx = LocalContext.current
        SettingCard("Ukuran overlay") {
            SliderLabel("Besar kecil", "${AppSettings.size}%")
            AccSlider(AppSettings.size / 100f, 0.6f..2f, { AppSettings.size = ((it * 100).toInt() / 5 * 5).coerceIn(60, 200) }) { AppSettings.save(ctx) }
            PillButton("Ukuran normal", filled = false) { AppSettings.size = AppSettings.DEF_SIZE; AppSettings.save(ctx) }
        }
        SettingCard("Warna aksen") {
            Swatches(AppSettings.ACCENTS, AppSettings.accent) { AppSettings.accent = it; AppSettings.save(ctx) }
        }
        SettingCard("Warna teks overlay") {
            Swatches(AppSettings.TEXTS, AppSettings.overlayText) { AppSettings.overlayText = it; AppSettings.save(ctx) }
        }
        SettingCard("Latar overlay") {
            Swatches(AppSettings.BGS, AppSettings.overlayBg) { AppSettings.overlayBg = it; AppSettings.save(ctx) }
            SliderLabel("Transparan", "${AppSettings.alpha}%")
            AccSlider(AppSettings.alpha / 100f, 0.2f..1f, { AppSettings.alpha = (it * 100).toInt().coerceIn(20, 100) }) { AppSettings.save(ctx) }
        }
        SettingCard("Warna suhu") {
            Text("Berubah sesuai tingkat panas", color = Grey, fontSize = 12.sp)
            HeatLegend(30f, "Aman, di bawah 45°"); HeatLegend(50f, "Hangat, 45-54°")
            HeatLegend(60f, "Panas, 55-64°"); HeatLegend(70f, "Sangat panas, 65°+")
        }
        Text("Perubahan warna overlay muncul dalam sekitar 1 detik.", color = Grey, fontSize = 12.sp)
        PillButton("Kembalikan warna awal", filled = false, modifier = Modifier.fillMaxWidth()) { AppSettings.reset(ctx) }
    }
}

@Composable
fun AccessOption(title: String, desc: String, accent: Color, bg: Color, selected: Boolean, icon: @Composable () -> Unit, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(bg)
        .border(if (selected) 2.dp else 1.dp, accent.copy(alpha = if (selected) 0.85f else 0.35f), RoundedCornerShape(20.dp))
        .clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        icon(); Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = accent, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Text(desc, color = Color(0xFFC4CACE), fontSize = 14.sp)
        }
    }
}

/** Ikon ponsel (Shizuku) dan perisai (Root), digambar langsung supaya tidak perlu pustaka ikon tambahan. */
@Composable
fun PhoneIcon(c: Color, m: Modifier) = Canvas(m) {
    val w = size.width * 0.55f; val h = size.height * 0.9f
    drawRoundRect(c, androidx.compose.ui.geometry.Offset((size.width - w) / 2, (size.height - h) / 2),
        androidx.compose.ui.geometry.Size(w, h), androidx.compose.ui.geometry.CornerRadius(size.width * 0.1f))
}

@Composable
fun ShieldIcon(c: Color, m: Modifier) = Canvas(m) {
    val w = size.width; val h = size.height
    val p = Path().apply {
        moveTo(w * 0.5f, h * 0.04f); lineTo(w * 0.92f, h * 0.2f); lineTo(w * 0.92f, h * 0.5f)
        cubicTo(w * 0.92f, h * 0.76f, w * 0.7f, h * 0.92f, w * 0.5f, h * 0.98f)
        cubicTo(w * 0.3f, h * 0.92f, w * 0.08f, h * 0.76f, w * 0.08f, h * 0.5f)
        lineTo(w * 0.08f, h * 0.2f); close()
    }
    drawPath(p, c)
}

@Composable
fun RowScope.NavItem(icon: String, label: String, selected: Boolean, color: Color, onClick: () -> Unit) {
    val col by animateColorAsState(if (selected) color else Grey, tween(220), label = "navCol")
    val sc by animateFloatAsState(if (selected) 1.15f else 1f, spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMedium), label = "navScale")
    Column(Modifier.weight(1f).clip(RoundedCornerShape(26.dp))
        .clickable { onClick() }.padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text(icon, color = col, fontSize = 22.sp, modifier = Modifier.graphicsLayer { scaleX = sc; scaleY = sc })
        Text(label, color = col, fontSize = 11.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

@Composable
fun BigCard(title: String, value: String, sub: String, selected: Boolean, m: Modifier) {
    val shape = RoundedCornerShape(24.dp)
    Column(m.background(Inner, shape)
        .then(if (selected) Modifier.border(1.5.dp, acc().copy(alpha = 0.85f), shape) else Modifier)
        .padding(horizontal = 16.dp, vertical = 10.dp)) {
        Text(title, color = Grey, fontSize = 13.sp)
        Text(value, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
        Text(sub, color = Grey, fontSize = 12.sp, maxLines = 1)
    }
}

/** Warna beban: hijau normal, kuning mulai berat, merah hampir penuh. */
fun loadColor(p: Int): Color = when {
    p < 0 -> Color.White
    p < 60 -> Color.White
    p < 85 -> Color(0xFFFFD866)
    else -> Color(0xFFFF6B6B)
}

@Composable
fun RowScope.MetricDivider() = Box(Modifier.width(1.dp).height(34.dp).background(Color(0x1FFFFFFF)))

@Composable
fun RowScope.Metric(label: String, main: String, sub: String, subTemp: Float, mainTemp: Float = -1f, mainColor: Color? = null) {
    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = Grey, fontSize = 12.sp)
        Text(main, color = mainColor ?: if (mainTemp >= 0) Color(heat(mainTemp)) else Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        if (sub.isNotEmpty()) Text(sub, color = if (subTemp >= 0) Color(heat(subTemp)) else Grey, fontSize = 13.sp, textAlign = TextAlign.Center)
    }
}

@Composable
fun InfoRow(label: String, value: String, t: Float? = null) {
    Row(Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(20.dp)).padding(horizontal = 18.dp, vertical = 14.dp)) {
        Text(label, color = Grey, modifier = Modifier.weight(1f))
        Text(value, color = if (t != null && t >= 0) Color(heat(t)) else Color.White, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SettingCard(title: String, content: @Composable ColumnScope.() -> Unit) = Column(
    Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(20.dp)).padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
) { Text(title, color = Color.White, fontWeight = FontWeight.Bold); content() }

@Composable
fun Swatches(colors: List<Int>, selected: Int, onPick: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        colors.forEach { c ->
            val on = c == selected
            Box(Modifier.size(38.dp).background(Color(c), CircleShape)
                .border(if (on) 2.5.dp else 1.dp, if (on) Color.White else Color(0x33FFFFFF), CircleShape)
                .clickable { onPick(c) }, contentAlignment = Alignment.Center) {
                if (on) Text("✓", color = if (Color(c).luminance() > 0.5f) Color(0xFF101014) else Color.White, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

@Composable
fun SectionTitle(t: String) = Text(t, color = Grey, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 6.dp, top = 4.dp))

@Composable
fun SliderLabel(label: String, value: String) = Row(Modifier.fillMaxWidth()) {
    Text(label, color = Grey, fontSize = 12.sp, modifier = Modifier.weight(1f))
    Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
}

@Composable
fun AccSlider(value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit, onDone: () -> Unit) {
    Slider(value = value, onValueChange = onChange, valueRange = range, onValueChangeFinished = onDone,
        colors = SliderDefaults.colors(thumbColor = acc(), activeTrackColor = acc(), inactiveTrackColor = Color(0x22FFFFFF)))
}

/** Tombol seragam: terisi (aksi utama) atau garis tepi (aksi sekunder). */
@Composable
fun PillButton(text: String, filled: Boolean = true, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(modifier.clip(shape)
        .then(if (filled) Modifier.background(Blue) else Modifier.border(1.dp, Color(0x33FFFFFF), shape))
        .clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 10.dp), contentAlignment = Alignment.Center) {
        Text(text, color = if (filled) Color(0xFF0C0C0E) else Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** Baris ukuran dengan batang: label + nilai di atas, batang tipis di bawah. */
@Composable
fun MeterRow(label: String, value: String, frac: Float, color: Color, valueColor: Color = Color.White) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Grey, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text(value, color = valueColor, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
        Box(Modifier.fillMaxWidth().height(5.dp).background(Color(0x1FFFFFFF), CircleShape)) {
            Box(Modifier.fillMaxWidth(frac.coerceIn(0f, 1f)).fillMaxHeight().background(color, CircleShape))
        }
    }
}

/** Blok memori: nama + total di atas, terpakai + bebas di tengah, batang di bawah. */
@Composable
fun MemBlock(label: String, total: Float, used: Float, free: Float, color: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f))
            Text("%.2f GB total".format(total), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("%.2f GB digunakan".format(used), color = Grey, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text("%.2f GB Bebas".format(free), color = Grey, fontSize = 12.sp)
        }
        Spacer(Modifier.height(2.dp))
        Box(Modifier.fillMaxWidth().height(8.dp).background(Color(0x1FFFFFFF), CircleShape)) {
            Box(Modifier.fillMaxWidth(if (total > 0f) (used / total).coerceIn(0f, 1f) else 0f).fillMaxHeight().background(color, CircleShape))
        }
    }
}

@Composable
fun TempMeter(label: String, t: Float) {
    if (t < 0f) { MeterRow(label, "-", 0f, Grey); return }
    val word = when { t < 45f -> "Aman"; t < 55f -> "Hangat"; t < 65f -> "Panas"; else -> "Sangat panas" }
    MeterRow(label, "${deg(t)}  $word", (t - 20f) / 70f, Color(heat(t)), Color(heat(t)))
}

/** Warna batang beban: aksen saat normal, kuning mulai berat, merah hampir penuh. */
@Composable
fun barLoad(p: Int): Color = when { p < 60 -> acc(); p < 85 -> Color(0xFFFFD866); else -> Color(0xFFFF6B6B) }

private fun usedFrac(txt: String): Float {
    val n = Regex("[0-9]+[.,]?[0-9]*").findAll(txt).map { it.value.replace(',', '.').toFloatOrNull() ?: 0f }.toList()
    return if (n.size >= 2 && n[1] > 0f) n[0] / n[1] else 0f
}

@Composable
fun HeatLegend(t: Float, label: String) = Row(verticalAlignment = Alignment.CenterVertically) {
    Box(Modifier.size(12.dp).background(Color(heat(t)), CircleShape))
    Text(label, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(start = 10.dp))
}

/** Grafik FPS: garis halus + isi tipis, skala 0..maks (kelipatan 10, minimal 30), garis bantu tipis, titik di nilai terakhir. */
/** Grafik area beban CPU 0..100%, menempel di dasar kartu. */
@Composable
fun CpuGraph(h: List<Int>, col: Color, m: Modifier) {
    Canvas(m) {
        if (h.size < 2) return@Canvas
        val stepX = size.width / (h.size - 1)
        fun py(v: Int) = size.height * (1f - 0.12f - 0.78f * v.coerceIn(0, 100) / 100f)
        val fill = Path(); fill.moveTo(0f, size.height); fill.lineTo(0f, py(h[0]))
        for (i in 1 until h.size) {
            val x0 = (i - 1) * stepX; val y0 = py(h[i - 1]); val x1 = i * stepX; val y1 = py(h[i])
            fill.quadraticBezierTo(x0, y0, (x0 + x1) / 2f, (y0 + y1) / 2f)
            if (i == h.size - 1) fill.lineTo(x1, y1)
        }
        fill.lineTo(size.width, size.height); fill.close()
        drawPath(fill, col.copy(alpha = 0.35f))
    }
}

@Composable
fun FpsGraph(h: List<Int>, m: Modifier) {
    val col = acc()
    Canvas(m) {
        val guide = Color(0x1AFFFFFF)
        for (i in 0..2) { val y = size.height * i / 2f; drawLine(guide, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f) }
        if (h.size < 2) return@Canvas
        val pad = 4.dp.toPx()
        val mx = (kotlin.math.ceil(maxOf(h.maxOrNull() ?: 30, 30) / 10f) * 10f)
        val stepX = size.width / (h.size - 1)
        fun px(i: Int) = i * stepX
        fun py(v: Int) = pad + (size.height - 2 * pad) * (1f - v / mx)
        val line = Path(); val fill = Path()
        line.moveTo(px(0), py(h[0])); fill.moveTo(px(0), size.height); fill.lineTo(px(0), py(h[0]))
        for (i in 1 until h.size) {
            // kurva halus lewat titik tengah antar sampel
            val x0 = px(i - 1); val y0 = py(h[i - 1]); val x1 = px(i); val y1 = py(h[i])
            val mxp = (x0 + x1) / 2f; val myp = (y0 + y1) / 2f
            line.quadraticBezierTo(x0, y0, mxp, myp); fill.quadraticBezierTo(x0, y0, mxp, myp)
            if (i == h.size - 1) { line.lineTo(x1, y1); fill.lineTo(x1, y1) }
        }
        fill.lineTo(size.width, size.height); fill.close()
        drawPath(fill, col.copy(alpha = 0.14f))
        drawPath(line, col, style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawCircle(col, 4.dp.toPx(), Offset(px(h.size - 1), py(h.last())))
    }
}

@Composable
fun Stat(l: String, v: String) = Column { Text(l, color = Grey, fontSize = 11.sp); Text(v, color = Color.White, fontSize = 19.sp) }
