package com.pulsemonitor

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue

/** Pengaturan warna. State Compose, jadi layar utama langsung berubah; overlay membacanya tiap detik. */
object AppSettings {
    val ACCENTS = listOf(0xFF3DF0FF.toInt(), 0xFF7CFFB2.toInt(), 0xFFA78BFA.toInt(), 0xFFFF9F43.toInt(), 0xFFFF6FB1.toInt())
    val TEXTS = listOf(0xFFFFFFFF.toInt(), 0xFF3DF0FF.toInt(), 0xFFFFD866.toInt(), 0xFF7CFFB2.toInt())
    val BGS = listOf(0xFF101014.toInt(), 0xFF1B1230.toInt(), 0xFF0B2A2E.toInt(), 0xFF1A2A52.toInt())
    private const val DEF_ALPHA = 70

    var accent by mutableIntStateOf(ACCENTS[0])
    var overlayText by mutableIntStateOf(TEXTS[0])
    var overlayBg by mutableIntStateOf(BGS[0])
    val STYLES = listOf("Simple", "Compact", "Normal")
    var overlayStyle by mutableIntStateOf(0)       // 0 Simple (satu baris), 1 Compact, 2 Normal
    var alpha by mutableIntStateOf(DEF_ALPHA)      // transparansi latar overlay, 20..100 persen
    @Volatile private var loaded = false

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun load(c: Context) {
        if (loaded) return
        val p = prefs(c)
        accent = p.getInt("accent", ACCENTS[0]); overlayText = p.getInt("text", TEXTS[0])
        overlayBg = p.getInt("bg", BGS[0]); alpha = p.getInt("alpha", DEF_ALPHA).coerceIn(20, 100)
        overlayStyle = p.getInt("style", 0).coerceIn(0, STYLES.size - 1)
        loaded = true
    }

    fun save(c: Context) {
        prefs(c).edit().putInt("accent", accent).putInt("text", overlayText).putInt("bg", overlayBg).putInt("alpha", alpha).putInt("style", overlayStyle).apply()
    }

    fun reset(c: Context) {
        accent = ACCENTS[0]; overlayText = TEXTS[0]; overlayBg = BGS[0]; alpha = DEF_ALPHA
        save(c)
    }
}

/** Warna RGB + transparansi dalam persen (0..100) jadi ARGB. */
fun withAlpha(rgb: Int, pct: Int): Int = (rgb and 0xFFFFFF) or ((pct.coerceIn(0, 100) * 255 / 100) shl 24)
