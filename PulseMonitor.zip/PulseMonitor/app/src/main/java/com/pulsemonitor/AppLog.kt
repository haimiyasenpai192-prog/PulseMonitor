package com.pulsemonitor

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Log ringan aplikasi: disimpan di memori dan di berkas, ditampilkan serta dibagikan dari layar Kesehatan & log. */
object AppLog {
    private const val MAX_LINES = 400
    private const val MAX_FILE = 120_000L
    private val lines = ArrayDeque<String>()
    private var file: File? = null
    private var appCtx: Context? = null
    private val exportPool = Executors.newSingleThreadScheduledExecutor { r -> Thread(r, "applog-export").apply { isDaemon = true } }
    private val exportPending = AtomicBoolean(false)
    private const val EXPORT_NAME = "PulseMonitor_log.txt"
    private const val EXPORT_DIR = "PulseMonitor"   // subfolder di dalam Download

    /** Bagian "PEMERIKSAAN" dari laporan kesehatan terakhir; ikut ditulis ke berkas log di Download bila ada. */
    @Volatile var checksText: String? = null
    private val fmt = SimpleDateFormat("MM-dd HH:mm:ss", Locale.US)

    @Synchronized fun init(c: Context) {
        if (file != null) return
        appCtx = c.applicationContext
        val f = File(c.applicationContext.filesDir, "applog.txt")
        file = f
        runCatching { f.readLines().takeLast(MAX_LINES).forEach { lines.addLast(it) } }
    }

    @Synchronized private fun add(level: String, tag: String, msg: String) {
        val l = "${fmt.format(Date())} $level/$tag ${msg.replace('\n', ' ')}".take(600)
        lines.addLast(l)
        while (lines.size > MAX_LINES) lines.removeFirst()
        val f = file ?: return
        runCatching {
            if (f.length() > MAX_FILE) f.writeText(lines.joinToString("\n") + "\n") else f.appendText(l + "\n")
        }
        exportAsync()
    }

    /** Jejak crash disimpan permanen (tidak ikut dihapus saat dialog crash ditutup) supaya tetap ada di berkas Download. */
    fun keepCrash(c: Context, trace: String) {
        runCatching { File(c.applicationContext.filesDir, "crash_keep.txt").writeText(trace) }
    }

    /** Tulis ulang berkas log di folder Download, digabung dan ditunda ~2 detik supaya tidak menulis tiap baris. */
    fun exportAsync() {
        if (appCtx == null || !exportPending.compareAndSet(false, true)) return
        runCatching { exportPool.schedule({ exportNow() }, 2, TimeUnit.SECONDS) }.onFailure { exportPending.set(false) }
    }

    /** Segera tulis Download/PulseMonitor_log.txt (dipakai juga saat crash). Berkas ditimpa, bukan dibuat baru. */
    fun exportNow(): Boolean {
        exportPending.set(false)
        val c = appCtx ?: return false
        return runCatching {
            val text = buildString {
                val head = checksText
                if (head != null) append(head).append('\n')
                else {
                    val ver = runCatching { c.packageManager.getPackageInfo(c.packageName, 0).let { "${it.versionName} (${it.longVersionCode})" } }.getOrDefault("?")
                    append("PulseMonitor log\n")
                    append("Aplikasi $ver · ${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT}) · ${Build.DISPLAY}\n")
                }
                append("\n== LOG (terbaru di bawah) ==\n").append(dump(MAX_LINES)).append('\n')
                val crash = runCatching { File(c.filesDir, "crash_keep.txt").readText() }.getOrNull()
                if (!crash.isNullOrBlank()) append("\n== CRASH TERAKHIR ==\n").append(crash).append('\n')
            }
            val cr = c.contentResolver
            val coll = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            val existing = cr.query(coll, arrayOf(MediaStore.Downloads._ID),
                "${MediaStore.Downloads.DISPLAY_NAME}=? AND ${MediaStore.Downloads.RELATIVE_PATH} LIKE ?",
                arrayOf(EXPORT_NAME, Environment.DIRECTORY_DOWNLOADS + "/" + EXPORT_DIR + "%"), null)?.use {
                if (it.moveToFirst()) ContentUris.withAppendedId(coll, it.getLong(0)) else null
            }
            val uri = existing ?: cr.insert(coll, ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, EXPORT_NAME)
                put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + EXPORT_DIR)
            })!!
            cr.openOutputStream(uri, "wt")!!.use { it.write(text.toByteArray()) }
            true
        }.getOrElse { false }
    }

    fun i(tag: String, msg: String) = add("I", tag, msg)
    fun w(tag: String, msg: String) = add("W", tag, msg)
    fun e(tag: String, msg: String, t: Throwable? = null) =
        add("E", tag, if (t == null) msg else "$msg: ${t.javaClass.simpleName} ${t.message}")

    @Synchronized fun dump(n: Int = 200): String = lines.toList().takeLast(n).joinToString("\n")

    @Synchronized fun clear() {
        lines.clear()
        runCatching { file?.writeText("") }
        runCatching { appCtx?.let { File(it.filesDir, "crash_keep.txt").delete() } }
        exportAsync()
    }
}
