package com.pulsemonitor

import android.content.Context
import android.graphics.Bitmap
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.graphics.graphicsLayer
import kotlin.math.ceil
import kotlin.math.floor

private val Bgr = Color(0xFF101014)
private val CardC = Color(0xFF1D1E24)
private val Muted = Color(0xFF8E8E99)
private val Peri = Color(0xFFD3D7DC)
private val CBlue = Color(0xFF4C8DFF)
private val CGreen = Color(0xFF4CC38A)
private val CAmber = Color(0xFFF5B83D)
private val CPink = Color(0xFFE5677A)
private val COrange = Color(0xFFB07CFF)
private val clusterColors = listOf(CBlue, CGreen, CAmber, COrange)   // Cluster pertama biru, kedua hijau, ketiga kuning, ...

/** Warna kartu: semi-transparan bila ada wallpaper, supaya gambar latar tetap terlihat. */
private val LocalCard = compositionLocalOf { CardC }

class Series(val name: String, val color: Color, val v: List<Float>)

fun appIcon(ctx: Context, pkg: String): Bitmap? = runCatching {
    val d = ctx.packageManager.getApplicationIcon(pkg)
    val bmp = Bitmap.createBitmap(192, 192, Bitmap.Config.ARGB_8888)
    d.setBounds(0, 0, 192, 192); d.draw(android.graphics.Canvas(bmp)); bmp
}.getOrNull()

/** Laporan satu rekaman: header, catatan, satu kartu ringkasan, lalu tiga grafik. */
@Composable
fun ReportView(s: Session, onBack: () -> Unit, onShare: () -> Unit, onSave: () -> Unit = {}, onCsv: () -> Unit, onDelete: () -> Unit, onDesc: (String) -> Unit,
               wallpaper: Bitmap? = null, dim: Float = 0.6f) {
    val ctx = LocalContext.current
    val st = remember(s) { s.stats() }
    val icon = remember(s.pkg) { appIcon(ctx, s.pkg) }
    var desc by remember(s.id) { mutableStateOf(s.desc) }
    var confirm by remember { mutableStateOf(false) }
    LaunchedEffect(desc) { if (desc != s.desc) { delay(600); onDesc(desc) } }
    // Catatan yang baru diketik dan langsung ditinggal (<0,6 detik) tetap tersimpan
    val latestDesc by rememberUpdatedState(desc)
    DisposableEffect(s.id) { onDispose { if (latestDesc != s.desc) onDesc(latestDesc) } }
    // "Yakin hapus?" tidak boleh menggantung selamanya
    LaunchedEffect(confirm) { if (confirm) { delay(3000); confirm = false } }

    val card = if (wallpaper != null) Color(0xFF1E1F26).copy(alpha = 0.30f) else CardC
    CompositionLocalProvider(LocalCard provides card) {
    Box(Modifier.fillMaxSize().background(Bgr)) {
    if (wallpaper != null) {
        Image(wallpaper.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        // Teks banyak: redam minimal 32% supaya tetap terbaca, mengikuti slider "Redupkan latar" (dikali 0,6) bila lebih gelap
        Box(Modifier.fillMaxSize().background(Bgr.copy(alpha = (dim * 0.6f).coerceAtLeast(0.32f))))
    }
    Column(Modifier.fillMaxSize().imePadding().verticalScroll(rememberScrollState())
        .statusBarsPadding().navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.size(44.dp).clip(CircleShape).clickable { onBack() }, contentAlignment = Alignment.Center) {
                Text("←", color = Color.White, fontSize = 26.sp)
            }
            Spacer(Modifier.weight(1f))
            Pill("Bagikan", onShare); Pill("Simpan", onSave); Pill("CSV", onCsv)
            Pill(if (confirm) "Yakin?" else "Hapus", { if (confirm) onDelete() else confirm = true },
                if (confirm) Color(0xFF5A2530) else card)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) Image(icon.asImageBitmap(), null, Modifier.size(56.dp).clip(RoundedCornerShape(13.dp)))
            else Box(Modifier.size(56.dp).background(card, RoundedCornerShape(13.dp)))
            Column(Modifier.padding(start = 14.dp).weight(1f)) {
                Text(s.label, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 2, lineHeight = 26.sp, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                Text("${fmtDate(s.id)} · ${fmtDur(s.dur)}" + (if (s.res.isNotBlank()) " · ${s.res}" else ""), color = Color(0xFFC4C6CE), fontSize = 12.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.padding(top = 3.dp))
            }
        }
        Box(Modifier.fillMaxWidth().background(card, RoundedCornerShape(18.dp)).padding(horizontal = 16.dp, vertical = 13.dp)) {
            BasicTextField(desc, { desc = it }, textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                cursorBrush = SolidColor(Color.White), modifier = Modifier.fillMaxWidth(),
                decorationBox = { inner -> if (desc.isEmpty()) Text("Tambah catatan", color = Muted, fontSize = 15.sp); inner() })
        }
        // Statistik: dua kotak terpisah per halaman (geser kiri-kanan). Kotak atas = tiga kolom besar, kotak bawah = daftar dua kolom
        val pages = remember(s) { reportPages(s, st) }
        val pager = androidx.compose.foundation.pager.rememberPagerState { pages.size }
        val pageWidthPx = with(androidx.compose.ui.platform.LocalDensity.current) {
            androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp.dp.toPx()
        }
        Column(Modifier.fillMaxWidth()) {
            // beyondViewportPageCount = 1: halaman sebelah sudah dikomposisi sebelum jari menyentuh, jadi tidak patah di awal geseran
            androidx.compose.foundation.pager.HorizontalPager(pager, Modifier.fillMaxWidth(), pageSpacing = 16.dp,
                beyondViewportPageCount = 1) { pg ->
                // Posisi halaman dibaca lewat lambda di fase gambar (bukan komposisi) supaya geseran tidak memicu recompose tiap frame
                val flow = remember(pg, pageWidthPx) { PageFlow({ pg - (pager.currentPage + pager.currentPageOffsetFraction) }, pageWidthPx) }
                Column(Modifier.fillMaxWidth().graphicsLayer {
                    val off = kotlin.math.abs(flow.signed()).coerceIn(0f, 1f)
                    alpha = 1f - 0.35f * off
                    val sc = 1f - 0.04f * off
                    scaleX = sc; scaleY = sc
                }, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTopCard(pages[pg].top, flow, card)
                    StatListCard(pages[pg].rows, flow, card)
                }
            }
            // Titik penanda: yang aktif melebar dan memutih mengikuti geseran; tap titik untuk pindah halaman dengan animasi
            val pageScope = rememberCoroutineScope()
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                repeat(pages.size) { i ->
                    val near = (1f - (((pager.currentPage - i) + pager.currentPageOffsetFraction).let { if (it < 0f) -it else it })).coerceIn(0f, 1f)
                    Box(Modifier.padding(horizontal = 3.dp).height(6.dp).width((6f + 12f * near).dp)
                        .clip(CircleShape)
                        .background(androidx.compose.ui.graphics.lerp(Color(0x55FFFFFF), Color.White, near))
                        .clickable { pageScope.launch { pager.animateScrollToPage(i) } })
                }
            }
        }
        // Grafik: kartu pekat dan rapat satu sama lain (gaya laporan referensi), urutan FPS -> CPU -> Frekuensi -> GPU -> Daya -> Baterai
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            LineChart("FPS", s.t, listOf(
                Series("FPS", CBlue, s.fps),
                Series("Frametime", CGreen, s.fps.map { if (it > 0f) 1000f / it else -1f }),
                Series("Temperatur", CAmber, s.temp)), fromZero = true)
            if (s.clusters.isNotEmpty()) LineChart("Beban CPU (%)", s.t,
                s.clusters.mapIndexed { i, c -> Series("Cluster $c", clusterColors[i % clusterColors.size], s.clCpu.getOrElse(i) { emptyList() }) } +
                    Series("Total", CPink, s.cpu), endLabels = false)
            if (s.clFreq.isNotEmpty()) LineChart("Frekuensi CPU (MHz)", s.t,
                s.clusters.mapIndexed { i, c -> Series("Cluster $c", clusterColors[i % clusterColors.size], s.clFreq.getOrElse(i) { emptyList() }) },
                endLabels = false)
            LineChart("Frekuensi GPU (MHz)", s.t, listOf(Series("Frekuensi", CBlue, s.gpuMhz)))
            LineChart("GPU", s.t, listOf(Series("Beban", CGreen, s.gpu), Series("Suhu", CAmber, s.tGpu)), endLabels = false)
            LineChart("Daya (W)", s.t, listOf(Series("Daya (Watt)", CBlue, s.watt)), endLabels = false)
            LineChart("Baterai", s.t, listOf(Series("Suhu", CGreen, s.tBat), Series("Level", CAmber, s.batLvl)))
        }
    }
    }
    }
}

@Composable
private fun Pill(text: String, onClick: () -> Unit, bg: Color = Color.Unspecified) {
    val fill = if (bg == Color.Unspecified) LocalCard.current else bg
    Text(text, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(fill).clickable { onClick() }.padding(horizontal = 12.dp, vertical = 9.dp))
}

/** Posisi satu halaman pager terhadap tengah, dalam satuan halaman: 0 = pas di tengah, +1 = satu halaman di kanan, -1 = di kiri.
 *  Dibaca lewat lambda supaya hanya dievaluasi di fase gambar (tidak memicu recompose saat geser). */
private class PageFlow(val signed: () -> Float, val widthPx: Float)

/** Animasi geser: sel yang urutannya (k) makin besar bergeser sedikit lebih jauh searah halamannya, lalu merapat ke tempatnya,
 *  jadi isi kartu terasa "mengalir" mengikuti jari. Murni translasi horizontal (tidak memudar / naik-turun) supaya mulus. */
private fun Modifier.stagger(flow: PageFlow, k: Int): Modifier = this.graphicsLayer {
    translationX = flow.signed().coerceIn(-1f, 1f) * flow.widthPx * 0.025f * k
}

/** Satu halaman laporan: kotak atas (3 angka besar) + kotak bawah (daftar dua kolom, baris terakhir boleh ganjil). */
class ReportPage(val top: List<Triple<String, String, String>>, val rows: List<Triple<String, String, String>>)

private fun tMax(v: List<Float>): String = v.filter { it >= 0f }.maxOrNull()?.let { "%.0f".format(it) } ?: "-"

fun reportPages(s: Session, st: Stats): List<ReportPage> {
    val p = statPages(s, st)
    val a = p[0]; val b = p[1]
    return listOf(
        ReportPage(
            listOf(a[0], a[1], a[2]),
            listOf(Triple("Varians FPS", a[3].second, ""), a[5].copy(third = ""), Triple("Kehalusan", a[4].second, ""), b[2].copy(third = ""), Triple("Daya (watt)", a[7].second, ""), Triple("Temperatur", a[6].second, ""))
        ),
        ReportPage(
            listOf(b[4], b[5], b[3]),
            listOf(b[0].copy(third = ""), b[1].copy(third = ""), b[7].copy(third = ""), b[6].copy(third = ""),
                Triple("Suhu CPU", tMax(s.tCpu), ""), Triple("Suhu GPU", tMax(s.tGpu), ""))
        )
    )
}

/** Kotak atas: tiga kolom sejajar, label huruf besar, angka besar, satuan di bawah. */
@Composable
private fun StatTopCard(items: List<Triple<String, String, String>>, flow: PageFlow, card: Color) {
    Row(Modifier.fillMaxWidth().background(card, RoundedCornerShape(20.dp)).padding(horizontal = 12.dp, vertical = 14.dp)) {
        items.forEachIndexed { k, (label, value, unit) ->
            Column(Modifier.weight(1f).stagger(flow, k), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(label.uppercase(), color = Color(0xFFC4C6CE), fontSize = 10.sp, maxLines = 1, softWrap = false)
                Text(value, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false,
                    modifier = Modifier.padding(top = 2.dp))
                Text(unit, color = Muted, fontSize = 10.sp, maxLines = 1)
            }
        }
    }
}

/** Kotak bawah: daftar dua kolom (label kiri, nilai kanan, garis tipis antar baris). Selalu 3 baris supaya tinggi tiap halaman sama. */
@Composable
private fun StatListCard(items: List<Triple<String, String, String>>, flow: PageFlow, card: Color) {
    val rows = items.chunked(2)
    Column(Modifier.fillMaxWidth().background(card, RoundedCornerShape(20.dp)).padding(horizontal = 16.dp, vertical = 6.dp)) {
        rows.forEachIndexed { ri, row ->
            Row(Modifier.fillMaxWidth()) {
                for (ci in 0..1) {
                    val cell = row.getOrNull(ci)
                    Box(Modifier.weight(1f).stagger(flow, ri * 2 + ci + 3)) { if (cell != null) StatRow(cell, ri < rows.size - 1) }
                    if (ci == 0) Spacer(Modifier.width(22.dp))
                }
            }
        }
        // Isi kurang dari 3 baris: tambah ruang kosong supaya tinggi kartu tiap halaman tetap sama
        for (i in rows.size until 3) Spacer(Modifier.fillMaxWidth().height(40.dp))
    }
}

@Composable
private fun StatRow(t: Triple<String, String, String>, divider: Boolean) {
    val (label, value, unit) = t
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().height(40.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Color(0xFFC4C6CE), fontSize = 14.sp, maxLines = 1, softWrap = false, modifier = Modifier.weight(1f))
            Text(if (unit == "%" && value != "-") "$value%" else value, color = Color.White, fontSize = 16.sp,
                fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
            if (unit.isNotBlank() && unit != "%") Text(" $unit", color = Muted, fontSize = 11.sp, maxLines = 1, softWrap = false)
        }
        if (divider) Box(Modifier.fillMaxWidth().height(0.5.dp).background(Color(0x22FFFFFF)))
    }
}

/** Isi kartu statistik: dua halaman, tiap halaman 8 sel (atas, nilai, bawah). Dipakai layar laporan dan gambar bagikan. */
fun statPages(s: Session, st: Stats): List<List<Triple<String, String, String>>> {
    fun pct(v: Float) = if (v >= 0f) "%.0f".format(v) else "-"
    return listOf(
        listOf(
            Triple("Maks", f1(st.max), "FPS"), Triple("Min", f1(st.min), "FPS"),
            Triple("Rata-rata", f1(st.avg), "FPS"), Triple("Varians", f1(st.sd), "FPS"),
            Triple("Relatif", f1(st.smooth), "Kehalusan"), Triple("5% low", f1(st.low5), "FPS"),
            Triple("MAX", if (st.maxTemp >= 0f) "%.0f".format(st.maxTemp) else "-", "Temperatur"),
            Triple("Daya", if (st.avgWatt >= 0f) f1(st.avgWatt) else "-", "Watt")
        ),
        listOf(
            Triple("CPU", pct(s.cpu.avgValid()), "%"), Triple("GPU", pct(s.gpu.avgValid()), "%"),
            Triple("RAM", pct(s.ram.avgValid()), "%"), Triple("1% low", f1(st.low1), "FPS"),
            Triple("Frame avg", f1(st.ftAvg), "ms"), Triple("Frame maks", f1(st.ftMax), "ms"),
            Triple("Drop", st.drops.toString(), "detik"), Triple("Energi", if (st.energyMwh >= 0f) "%.0f".format(st.energyMwh) else "-", "mWh")
        )
    )
}

/** True bila dua seri hampir identik di semua titik (selisih <= 0,5 dan sama-sama ada/tidak ada datanya). */
private fun sameLine(a: List<Float>, b: List<Float>): Boolean {
    val m = minOf(a.size, b.size)
    if (m == 0) return false
    for (i in 0 until m) {
        val x = a[i]; val y = b[i]
        if ((x < 0f) != (y < 0f)) return false
        if (x >= 0f && kotlin.math.abs(x - y) > 0.5f) return false
    }
    return true
}

/** Sumbu Y gaya laporan: selalu 6 petak sama besar. fromZero: 0 sampai nilai maksimum data (mis. 0, 12, 24 ... 71).
 *  Bukan fromZero (suhu): batas dibulatkan dan lebar dibuat kelipatan 6 supaya label tetap bilangan bulat. */
class AxisY(val lo: Float, val hi: Float) {
    val rows = 6
    val step: Float get() = (hi - lo) / rows
    fun fmt(v: Float): String { val d = if (step >= 1f) 0 else if (step >= 0.1f) 1 else 2; return "%.${d}f".format(v) }
}

fun axisY(mn: Float, mx: Float, fromZero: Boolean): AxisY {
    if (fromZero) return AxisY(0f, mx.coerceAtLeast(1f))
    val lo0 = floor(mn); val hi0 = ceil(mx)
    val span = (ceil((hi0 - lo0).coerceAtLeast(1f) / 6f) * 6f).coerceAtLeast(6f)
    val lo = lo0 - floor((span - (hi0 - lo0)) / 2f)
    return AxisY(lo, lo + span)
}

/** Label sumbu waktu: 14s, 1m10s, 2m, 1h05m. Rentang sangat pendek (< 10 detik) memakai satu desimal. */
fun fmtAxisTime(sec: Float, span: Float): String {
    if (span < 10f) return "%.1fs".format(sec)
    val s = Math.round(sec)
    return when {
        s >= 3600 -> "${s / 3600}h${"%02d".format(s % 3600 / 60)}m"
        s >= 60 -> if (s % 60 == 0) "${s / 60}m" else "${s / 60}m${s % 60}s"
        else -> "${s}s"
    }
}

/** Grafik garis: grid titik-titik, label sumbu, nilai terakhir tiap seri di kanan, legenda di bawah. Nilai < 0 = putus.
 *  Seri tanpa data sama sekali disembunyikan; grafik tanpa data tidak ditampilkan. fromZero=false: sumbu Y mengikuti rentang data (suhu). */
@Composable
fun LineChart(title: String, t: List<Float>, series: List<Series>, fromZero: Boolean = true, card: Color = LocalCard.current, endLabels: Boolean = true) {
    val tm = rememberTextMeasurer()
    val n = t.size
    val shown = series.filter { sr -> sr.v.any { it >= 0f } }
    if (shown.isEmpty() || n < 2) return
    Column(Modifier.fillMaxWidth().background(card, RoundedCornerShape(14.dp)).padding(16.dp)) {
        Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        Canvas(Modifier.fillMaxWidth().padding(top = 12.dp).height(170.dp)) {
            val lbl = TextStyle(color = Muted, fontSize = 11.sp)
            val left = 36.dp.toPx(); val right = 34.dp.toPx(); val bottom = 22.dp.toPx(); val top = 6.dp.toPx()
            val w = size.width - left - right; val h = size.height - top - bottom
            val all = shown.flatMap { it.v }.filter { it >= 0f }
            val ax = axisY(all.min(), all.max(), fromZero)
            val yMin = ax.lo; val yMax = ax.hi; val rows = ax.rows
            fun yOf(v: Float) = top + h - ((v - yMin) / (yMax - yMin)) * h
            val tEnd = t.last().coerceAtLeast(1f)
            // Grid titik-titik (bukan garis putus), tipis dan redup
            val dot = PathEffect.dashPathEffect(floatArrayOf(0.1f, 4.dp.toPx()))
            val grid = Color(0x66FFFFFF)
            val gw = 1.2.dp.toPx()
            for (i in 0..rows) {
                val v = yMin + i * ax.step
                val y = yOf(v)
                drawLine(grid, Offset(left, y), Offset(left + w, y), strokeWidth = gw, cap = StrokeCap.Round, pathEffect = dot)
                val text = ax.fmt(v)
                val sz = tm.measure(text, lbl).size
                drawText(tm, text, Offset(left - 6.dp.toPx() - sz.width, y - sz.height / 2f), lbl)
            }
            // Sumbu waktu: 5 petak sama lebar dari 0 sampai akhir rekaman (0s, 14s, 28s, ... 1m10s)
            for (k in 0..5) {
                val tv = tEnd * k / 5f
                val x = left + w * (k / 5f)
                drawLine(grid, Offset(x, top), Offset(x, top + h), strokeWidth = gw, cap = StrokeCap.Round, pathEffect = dot)
                val text = fmtAxisTime(tv, tEnd)
                val sz = tm.measure(text, lbl).size
                val tx = (x - sz.width / 2f).coerceIn(0f, size.width - sz.width)
                drawText(tm, text, Offset(tx, top + h + 4.dp.toPx()), lbl)
            }
            // Garis; titik terakhir selalu ikut walau data diperkecil
            val stride = maxOf(1, n / 500)
            val gap = tm.measure("0", TextStyle(fontSize = 12.sp)).size.height.toFloat()   // tinggi satu label angka
            // Seri yang nilainya sama persis (mis. suhu CPU = GPU) tidak saling menimpa: tiap seri dalam satu kelompok kembar
            // digeser sejauh satu tinggi label, jadi dua garis sejajar yang tiap ujungnya tepat di angkanya.
            val twinOff = shown.map { sr ->
                val grp = shown.filter { o -> o === sr || sameLine(o.v, sr.v) }
                if (grp.size > 1) (grp.indexOf(sr) - (grp.size - 1) / 2f) * gap else 0f
            }
            // Posisi label nilai terakhir: sejajar ujung garis; yang berdekatan direnggangkan seperlunya, lalu tiap kelompok
            // dipusatkan lagi ke tengah ujung garisnya.
            class End(val idx: Int, val text: String, val want: Float) { var y = want }
            val ends = if (!endLabels) emptyList() else shown.mapIndexedNotNull { si, sr ->
                sr.v.lastOrNull { it >= 0f }?.let { lv -> End(si, ax.fmt(lv), yOf(lv) + twinOff[si]) }
            }.sortedBy { it.want }
            for (j in 1 until ends.size) if (ends[j].y - ends[j - 1].y < gap - 0.5f) ends[j].y = ends[j - 1].y + gap
            var cs = 0
            while (cs < ends.size) {
                var ce = cs
                while (ce + 1 < ends.size && ends[ce + 1].y - ends[ce].y <= gap + 0.5f) ce++
                if (ce > cs) {
                    var sw = 0f; var sy = 0f
                    for (q in cs..ce) { sw += ends[q].want; sy += ends[q].y }
                    val shift = (sw - sy) / (ce - cs + 1)
                    for (q in cs..ce) ends[q].y += shift
                }
                cs = ce + 1
            }
            val endY = HashMap<Int, Float>(); ends.forEach { endY[it.idx] = it.y }
            shown.forEachIndexed { si, sr ->
                val p = Path(); var open = false; var i = 0
                val m = minOf(n, sr.v.size)
                var px = 0f; var py = 0f
                while (i < m) {
                    val v = sr.v[i]
                    if (v < 0f) open = false else {
                        val x = left + w * (t[i] / tEnd); val y = yOf(v) + twinOff[si]
                        val ly = endY[si]
                        if (i == m - 1 && ly != null && open && kotlin.math.abs(ly - y) > 0.5f && x - px > 1f) {
                            // Ujung garis dibelokkan ke posisi labelnya hanya di ~10dp terakhir (bentuk data di depannya tidak berubah),
                            // jadi garis selalu berujung tepat di angkanya (mis. CPU 29 dan GPU 29 yang ujungnya sama).
                            val tx = x - minOf(10.dp.toPx(), (x - px) / 2f)
                            p.lineTo(tx, py + (y - py) * (tx - px) / (x - px))
                            p.lineTo(x, ly)
                        } else if (!open) { p.moveTo(x, if (i == m - 1 && ly != null) ly else y); open = true } else p.lineTo(x, y)
                        px = x; py = y
                    }
                    i = if (i >= m - 1) m else minOf(i + stride, m - 1)
                }
                drawPath(p, sr.color, style = Stroke(width = 1.2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            ends.forEach { e ->
                val sz = tm.measure(e.text, TextStyle(fontSize = 12.sp)).size
                drawText(tm, e.text, Offset(left + w + 5.dp.toPx(), e.y - sz.height / 2f), TextStyle(color = shown[e.idx].color, fontSize = 12.sp))
            }
        }
        // 4 seri atau lebih (mis. Cluster 0/4/7 + Total): legenda dirapatkan supaya muat satu baris di layar HP
        val tight = shown.size > 3
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(if (tight) 10.dp else 16.dp)) {
            shown.forEach { sr ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(if (tight) 8.dp else 10.dp).background(sr.color, CircleShape))
                    Text(sr.name, color = Color.White, fontSize = if (tight) 11.sp else 13.sp, maxLines = 1, softWrap = false, modifier = Modifier.padding(start = if (tight) 4.dp else 6.dp))
                }
            }
        }
    }
}
