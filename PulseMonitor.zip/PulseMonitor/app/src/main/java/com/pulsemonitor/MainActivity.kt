package com.pulsemonitor

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.graphics.Bitmap
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import rikka.shizuku.Shizuku

private val Grey = Color(0xFF8E8E99)
private val Bg = Color(0xFF0C0C0E)
// Panel besar di bawah (gaya WuWa Config); transparansinya diatur di tab Tampilan
private val Glass: Color get() = Color(0xFF101116).copy(alpha = AppSettings.panelAlpha / 100f)
// Baris/kartu di dalam panel: tetap solid di nilai bawaan, makin tembus saat slider diturunkan
private val Inner: Color get() = Color(0xFF181A21).copy(alpha = (AppSettings.panelAlpha / AppSettings.DEF_PANEL.toFloat()).coerceAtMost(1f))
// Warna tiap tab navigasi: Beranda biru, Statistik ungu, Rekaman pink, Tampilan hijau, Settings kuning
private val NavColors = listOf(Color(0xFF6FA8FF), Color(0xFFA78BFA), Color(0xFFF08FB8), Color(0xFF5BD68E), Color(0xFFE8B84A))
private val Pink = Color(0xFFD58FC4)
private val Blue = Color(0xFF6FA8FF)
private fun acc() = Color(AppSettings.accent)

class MainActivity : ComponentActivity() {
    // Android 13+: tanpa izin ini notifikasi foreground service tidak muncul
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private var wallpaperBmp by mutableStateOf<Bitmap?>(null)
    private var dim by mutableFloatStateOf(0.6f)
    private var overlayOn by mutableStateOf(OverlayService.overlayShown.value)
    private var reportId by mutableStateOf<Long?>(null)
    private var accessDlg by mutableStateOf(false)

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, r -> Access.onPermissionResult(r == PackageManager.PERMISSION_GRANTED) }
    private val binderListener = Shizuku.OnBinderReceivedListener { Access.refresh() }
    private val deadListener = Shizuku.OnBinderDeadListener { Access.refresh() }

    // Photo Picker: tanpa izin galeri. Di Android 10-12 otomatis jatuh ke pemilih dokumen.
    private val pickImage = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) Thread {
            if (WallpaperStore.save(this, uri)) wallpaperBmp = WallpaperStore.load(this)
        }.start()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); enableEdgeToEdge()
        AppSettings.load(this); Sampler.init(this)
        Shizuku.addRequestPermissionResultListener(permListener)
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        wallpaperBmp = WallpaperStore.load(this); dim = WallpaperStore.dim(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent {
            val s by Sampler.state.collectAsState()
            // Status tombol mengikuti keadaan layanan yang sebenarnya (tetap benar setelah aplikasi dibuka ulang)
            val shown by OverlayService.overlayShown.collectAsState()
            LaunchedEffect(shown) { overlayOn = shown }
            var tab by remember { mutableIntStateOf(0) }
            BackHandler(enabled = tab != 0) { tab = 0 }
            val rid = reportId
            BackHandler(enabled = rid != null) { reportId = null }
            AnimatedContent(targetState = rid, label = "page", transitionSpec = {
                if (targetState != null)   // buka laporan: masuk dari kanan, halaman lama bergeser sedikit
                    (slideInHorizontally(tween(320)) { it } + fadeIn(tween(320))) togetherWith
                        (slideOutHorizontally(tween(320)) { -it / 4 } + fadeOut(tween(220)))
                else                       // kembali: laporan keluar ke kanan
                    (slideInHorizontally(tween(320)) { -it / 4 } + fadeIn(tween(320))) togetherWith
                        (slideOutHorizontally(tween(320)) { it } + fadeOut(tween(220)))
            }) { id -> if (id != null) ReportScreen(id) else Screen(s, tab) { tab = it } }
        }
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        super.onDestroy()
    }

    override fun onStart() {
        super.onStart()
        Access.refresh()
        Sampler.uiVisible = true; Sampler.start()
    }

    override fun onStop() {
        super.onStop()
        // Aplikasi tidak terlihat: hentikan pembacaan sensor bila tidak ada overlay/rekaman yang memakainya
        Sampler.uiVisible = false
        if (!OverlayService.overlayShown.value && !Recorder.active.value) Sampler.stop()
    }

    private fun toggleOverlay() {
        val turnOn = !OverlayService.overlayShown.value
        if (turnOn && !Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val i = Intent(this, OverlayService::class.java)
        when {
            turnOn -> { playOverlaySound(); startForegroundService(i) }
            // Mode latar belakang: overlay disembunyikan, layanan (notifikasi) tetap hidup
            AppSettings.bgMode -> startForegroundService(i.setAction(OverlayService.ACTION_HIDE))
            else -> stopService(i)
        }
    }

    /** Saklar "Tetap aktif di latar belakang": nyala = layanan hidup tanpa overlay; mati = layanan berhenti bila overlay juga mati. */
    private fun applyBgMode(on: Boolean) {
        val i = Intent(this, OverlayService::class.java)
        if (on) { if (!OverlayService.alive) startForegroundService(i.setAction(OverlayService.ACTION_HIDE)) }
        else if (!OverlayService.overlayShown.value) stopService(i)
    }

    /** Suara notifikasi saat overlay dinyalakan (res/raw/overlay_on.m4a). Gagal memutar tidak boleh mengganggu overlay. */
    private fun playOverlaySound() {
        runCatching {
            val attrs = android.media.AudioAttributes.Builder()
                .setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            val mp = android.media.MediaPlayer.create(this, R.raw.overlay_on, attrs, android.media.AudioManager.AUDIO_SESSION_ID_GENERATE)
                ?: return
            mp.setOnCompletionListener { it.release() }
            mp.setOnErrorListener { p, _, _ -> p.release(); true }
            mp.start()
        }
    }

    @Composable
    fun Screen(s: Snap, tab: Int, setTab: (Int) -> Unit) {
        val titles = listOf("", "Detail sensor dan diagnostik", "Rekam FPS dan lihat laporan", "Wallpaper dan warna overlay", "Gaya overlay")
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1A2038), Bg)))) {
            wallpaperBmp?.let { bmp ->
                Image(bmp.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                // makin gelap ke bawah supaya panel dan teks tetap terbaca
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
                    listOf(Bg.copy(alpha = dim * 0.35f), Bg.copy(alpha = dim)))))
            }
            // Kepala: judul besar + chip akses
            Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 24.dp, vertical = 20.dp),
                verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    Text("PulseMonitor", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                    AnimatedContent(targetState = titles[tab], label = "subtitle",
                        transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(120)) }) { t ->
                        if (t.isNotEmpty()) Text(t, color = Color(0xFFD0D0DA), fontSize = 15.sp)
                    }
                }
                Spacer(Modifier.width(14.dp))   // jarak judul dan chip akses
                val ok = s.access != "-"
                Row(Modifier.clip(RoundedCornerShape(50)).background(Color(0xB3101116))
                    .clickable(enabled = !ok) { Access.refresh(); accessDlg = true }.padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(11.dp).background(if (ok) Color(0xFF7CFFB2) else Color(0xFFFF5C5C), CircleShape))
                    Text(if (ok) s.access else "Beri izin", color = if (ok) Color(0xFF7CFFB2) else Color(0xFFFF8A8A),
                        fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(start = 8.dp))
                }
            }
            if (accessDlg) AccessDialog { accessDlg = false }
            // Panel bawah + navigasi
            Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(Modifier.fillMaxWidth().background(Glass, RoundedCornerShape(32.dp)).padding(10.dp)) {
                    AnimatedContent(targetState = tab, label = "tab", transitionSpec = {
                        val dir = if (targetState > initialState) 1 else -1   // geser sesuai arah tab
                        (slideInHorizontally(tween(260)) { it / 4 * dir } + fadeIn(tween(260))) togetherWith
                            (slideOutHorizontally(tween(200)) { -it / 4 * dir } + fadeOut(tween(160))) using SizeTransform(clip = true)
                    }) { t ->
                    when (t) {
                        0 -> HomeTab(s)
                        1 -> Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(10.dp)) { StatsTab(s) }
                        2 -> Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(10.dp)) { RecordTab(s) }
                        3 -> Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(10.dp)) { DisplayTab(); ColorContent() }
                        else -> Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(10.dp)) { SettingsContent() }
                    }
                    }
                }
                Box(Modifier.fillMaxWidth().background(Glass, RoundedCornerShape(32.dp)).padding(8.dp)) {
                    BoxWithConstraints(Modifier.fillMaxWidth()) {
                        val w = maxWidth / 5
                        val pill by animateColorAsState(NavColors[tab].copy(alpha = 0.28f), tween(260), label = "navPillCol")
                        val x by animateDpAsState(w * tab, spring(dampingRatio = 0.75f, stiffness = Spring.StiffnessMediumLow), label = "navPill")
                        // pil penanda meluncur ke tab terpilih
                        Box(Modifier.matchParentSize()) {
                            Box(Modifier.offset(x = x).width(w).fillMaxHeight().background(pill, RoundedCornerShape(26.dp)))
                        }
                        Row(Modifier.fillMaxWidth()) {
                            NavItem("⌂", "Beranda", tab == 0, NavColors[0]) { setTab(0) }
                            NavItem("▤", "Statistik", tab == 1, NavColors[1]) { setTab(1) }
                            NavItem("●", "Rekaman", tab == 2, NavColors[2]) { setTab(2) }
                            NavItem("◐", "Tampilan", tab == 3, NavColors[3]) { setTab(3) }
                            NavItem("⚙", "Settings", tab == 4, NavColors[4]) { setTab(4) }
                        }
                    }
                }
            }
        }
    }

    @Composable
    private fun HomeTab(s: Snap) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // Status overlay (seperti "Config terpasang")
            Row(Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(24.dp)).padding(horizontal = 16.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(38.dp).border(3.dp, if (overlayOn) Color(0xFF5FD38D) else Grey, CircleShape),
                    contentAlignment = Alignment.Center) {
                    Text(if (overlayOn) "✓" else "–", color = if (overlayOn) Color(0xFF5FD38D) else Grey,
                        fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
                Text(if (overlayOn) "Overlay aktif" else "Overlay mati", color = Color.White,
                    fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 14.dp))
            }
            // Dua kartu besar: FPS dan frametime (seperti Flagship / Balanced)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BigCard("FPS", "${s.fps}", "Frame per detik", true, Modifier.weight(1f))
                BigCard("Frametime", "%.1f ms".format(s.ft), "Makin kecil makin halus", false, Modifier.weight(1f))
            }
            // Grafik 30 detik terakhir
            Column(Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(24.dp)).padding(horizontal = 18.dp, vertical = 10.dp)) {
                FpsGraph(s.hist, Modifier.fillMaxWidth().height(36.dp))
            }
            // Baris sensor: CPU / GPU / RAM / BAT
            Row(Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(24.dp)).padding(horizontal = 12.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Metric("CPU", pct(s.cpu), "", -1f)
                Metric("GPU", pct(s.gpu), "", -1f)
                Metric("RAM", pct(s.ramPct), "", -1f)
                Metric("BAT", deg(s.tBat), "", -1f, mainTemp = s.tBat)
            }
            // Tombol utama bergradien (seperti "Install")
            Box(Modifier.fillMaxWidth().height(50.dp).clip(RoundedCornerShape(25.dp))
                .background(Brush.horizontalGradient(if (overlayOn) listOf(Color(0xFFE5677A), Pink) else listOf(Blue, Color(0xFF9A86E8), Pink)))
                .clickable { toggleOverlay() }, contentAlignment = Alignment.Center) {
                Text(if (overlayOn) "Matikan Overlay" else "Nyalakan Overlay", color = Color.White,
                    fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
    }

    private fun toggleRecord(s: Snap) {
        if (Recorder.active.value) {
            Thread {
                val r = Recorder.stop(this)
                runOnUiThread { Toast.makeText(this, if (r != null) "Rekaman tersimpan" else "Tidak ada data FPS yang terekam", Toast.LENGTH_SHORT).show() }
            }.start()
        } else {
            if (s.access == "-") { Toast.makeText(this, "Butuh Shizuku atau root untuk merekam", Toast.LENGTH_SHORT).show(); return }
            Recorder.start()
            if (!overlayOn) Toast.makeText(this, "Nyalakan overlay supaya rekaman tetap jalan saat kamu pindah ke game", Toast.LENGTH_LONG).show()
        }
    }

    private fun shareSummary(s: Session) {
        val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, Recorder.summary(s)) }
        startActivity(Intent.createChooser(i, "Bagikan laporan"))
    }

    @Composable
    private fun RecordTab(s: Snap) {
        val rec by Recorder.active.collectAsState()
        val n by Recorder.count.collectAsState()
        val ver by Recorder.version.collectAsState()
        var list by remember { mutableStateOf<List<Session>>(emptyList()) }
        LaunchedEffect(ver) { list = withContext(Dispatchers.IO) { Recorder.list(this@MainActivity) } }
        Column(Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(20.dp)).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(if (rec) "Merekam…  ${fmtDur(n)}  •  ${s.fps} FPS" else "Rekam FPS", color = Color.White, fontWeight = FontWeight.Bold)
            if (!rec) Text("Tekan Mulai, lalu buka game. Berhenti lewat tombol di notifikasi, atau tahan overlay sekitar 1 detik tanpa menggesernya.",
                color = Grey, fontSize = 12.sp)
            Box(Modifier.fillMaxWidth().height(46.dp).clip(RoundedCornerShape(23.dp))
                .background(Brush.horizontalGradient(if (rec) listOf(Color(0xFFE5677A), Pink) else listOf(Blue, Color(0xFF9A86E8), Pink)))
                .clickable { toggleRecord(s) }, contentAlignment = Alignment.Center) {
                Text(if (rec) "Berhenti dan simpan" else "Mulai rekam", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
        if (list.isEmpty()) Text("Belum ada rekaman.", color = Grey, fontSize = 13.sp, modifier = Modifier.padding(start = 6.dp))
        else list.forEach { r -> RecRow(r) { reportId = r.id } }
    }

    @Composable
    private fun RecRow(r: Session, onClick: () -> Unit) {
        val st = remember(r.id) { r.stats() }
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Inner).clickable { onClick() }.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(r.label, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(fmtDate(r.id), color = Grey, fontSize = 12.sp, maxLines = 1)
            }
            Column(Modifier.padding(start = 12.dp), horizontalAlignment = Alignment.End) {
                Text(f1(st.avg), color = acc(), fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text("FPS  •  ${fmtDur(r.dur)}", color = Grey, fontSize = 12.sp, maxLines = 1)
            }
        }
    }

    @Composable
    private fun ReportScreen(id: Long) {
        val sess by produceState<Session?>(null, id) { value = withContext(Dispatchers.IO) { Recorder.load(this@MainActivity, id) } }
        val ss = sess
        if (ss == null) {
            Box(Modifier.fillMaxSize().background(Color(0xFF101014)), contentAlignment = Alignment.Center) { Text("Memuat…", color = Grey) }
            return
        }
        ReportView(ss, onBack = { reportId = null }, onShare = { shareSummary(ss) },
            onCsv = {
                Thread {
                    val ok = Recorder.exportCsv(this, ss)
                    runOnUiThread { Toast.makeText(this, if (ok) "CSV tersimpan di folder Download" else "Gagal menyimpan CSV", Toast.LENGTH_SHORT).show() }
                }.start()
            },
            onDelete = { Recorder.delete(this, ss.id); reportId = null },
            onDesc = { t -> Thread { Recorder.saveDesc(this, ss, t) }.start() },
            wallpaper = wallpaperBmp, dim = dim)
    }

    @Composable
    private fun StatsTab(s: Snap) {
        InfoRow("RAM", s.ramText)
        if (s.swapText.isNotEmpty()) InfoRow("Swap", s.swapText)
        InfoRow("Suhu CPU", deg(s.tCpu), s.tCpu); InfoRow("Suhu GPU", deg(s.tGpu), s.tGpu); InfoRow("Suhu baterai", deg(s.tBat), s.tBat)
        if (s.access == "-") Text("Belum ada akses. Pilih Shizuku atau Root di tab Settings.", color = Grey, fontSize = 12.sp)
        if (s.access != "-") SettingCard("Probe GPU") {
            Text("Membaca semua node GPU di HP ini dan menyalinnya ke clipboard, untuk mencari sumber frekuensi yang benar.", color = Grey, fontSize = 12.sp)
            Button(onClick = {
                Toast.makeText(this@MainActivity, "Membaca node GPU...", Toast.LENGTH_SHORT).show()
                Thread {
                    val t = Sampler.gpuProbe()
                    this@MainActivity.runOnUiThread {
                        if (t.isBlank()) Toast.makeText(this@MainActivity, "Tidak ada hasil (butuh Shizuku/root)", Toast.LENGTH_SHORT).show()
                        else {
                            val cm = this@MainActivity.getSystemService(android.content.ClipboardManager::class.java)
                            cm.setPrimaryClip(android.content.ClipData.newPlainText("gpu-probe", t))
                            Toast.makeText(this@MainActivity, "Tersalin (${t.length} karakter). Tempel ke chat.", Toast.LENGTH_LONG).show()
                        }
                    }
                }.start()
            }) { Text("Probe GPU dan salin") }
        }
        if (s.dbg.isNotEmpty()) Column(Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(20.dp)).padding(16.dp)) {
            Text("Diagnostik", color = Color.White, fontWeight = FontWeight.Bold)
            Text(s.dbg, color = Grey, fontSize = 11.sp)
        }
    }

    @Composable
    private fun DisplayTab() {
        val ctx = LocalContext.current
        SettingCard("Transparan panel") {
            Text("Atur seberapa tembus panel dan navigasi, supaya wallpaper lebih terlihat. ${AppSettings.panelAlpha}%", color = Grey, fontSize = 12.sp)
            Slider(value = AppSettings.panelAlpha / 100f,
                onValueChange = { AppSettings.panelAlpha = (it * 100).toInt().coerceIn(15, 100) },
                onValueChangeFinished = { AppSettings.save(ctx) },
                valueRange = 0.15f..1f)
            OutlinedButton(onClick = { AppSettings.panelAlpha = AppSettings.DEF_PANEL; AppSettings.save(ctx) }) { Text("Kembalikan bawaan") }
        }
        Column(Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(20.dp)).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Wallpaper", color = Color.White, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = {
                    pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }) { Text(if (wallpaperBmp == null) "Pilih gambar" else "Ganti gambar") }
                if (wallpaperBmp != null) OutlinedButton(onClick = { WallpaperStore.clear(this@MainActivity); wallpaperBmp = null }) {
                    Text("Hapus")
                }
            }
            if (wallpaperBmp != null) {
                Text("Redupkan latar", color = Grey, fontSize = 12.sp)
                Slider(value = dim, onValueChange = { dim = it },
                    onValueChangeFinished = { WallpaperStore.saveDim(this@MainActivity, dim) },
                    valueRange = 0.2f..0.9f)
            }
        }
    }

    @Composable
    private fun StyleOption(idx: Int, title: String, sub: String, preview: String) {
        val ctx = LocalContext.current
        val sel = AppSettings.overlayStyle == idx
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable { AppSettings.overlayStyle = idx; AppSettings.save(ctx) }
            .padding(vertical = 6.dp), verticalAlignment = Alignment.Top) {
            Box(Modifier.padding(top = 2.dp, end = 12.dp).size(22.dp).border(2.dp, if (sel) Blue else Grey, CircleShape), contentAlignment = Alignment.Center) {
                if (sel) Box(Modifier.size(12.dp).background(Blue, CircleShape))
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold)
                Text(sub, color = Grey, fontSize = 12.sp)
                Text(preview, color = Color(AppSettings.overlayText), fontSize = 11.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                    modifier = Modifier.background(Color(withAlpha(AppSettings.overlayBg, AppSettings.alpha)), RoundedCornerShape(if (idx == 0) 20.dp else 10.dp))
                        .padding(horizontal = 10.dp, vertical = if (idx == 0) 5.dp else 7.dp))
            }
        }
    }

    @Composable
    private fun SettingsContent() {
        val ctx = LocalContext.current
        val s by Sampler.state.collectAsState()
        val connected = s.access != "-"
        val root = if (connected) s.access == "Root" else Access.isRoot()
        SettingCard("Akses") {
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable { Access.refresh(); accessDlg = true }.padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).background(Color(0xFF0A0A1A), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                    if (root) ShieldIcon(Color(0xFFE49A72), Modifier.size(24.dp)) else PhoneIcon(Color(0xFF8E86F0), Modifier.size(24.dp))
                }
                Column(Modifier.weight(1f).padding(start = 14.dp)) {
                    Text(if (root) "Root" else "Shizuku", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text(when {
                        connected -> "Terhubung"
                        Access.status == 1 -> "Ketuk untuk beri izin"
                        root -> "Root tidak tersedia"
                        else -> "Tidak berjalan"
                    }, color = if (connected) Color(0xFF5BD68E) else Color(0xFFE0B040), fontSize = 13.sp)
                }
                Text("›", color = Grey, fontSize = 22.sp)
            }
        }
        SettingCard("Latar belakang") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Tetap aktif di latar belakang", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    Text("Notifikasi baterai tetap hidup walau overlay dimatikan. Tanpa overlay dan tanpa pembacaan sensor, jadi ringan di RAM. Matikan saklar ini untuk menghapus notifikasi.",
                        color = Grey, fontSize = 12.sp)
                }
                Spacer(Modifier.width(12.dp))
                Switch(checked = AppSettings.bgMode, onCheckedChange = { on -> AppSettings.bgMode = on; AppSettings.save(ctx); applyBgMode(on) })
            }
        }
        SettingCard("Gaya overlay") {
            StyleOption(0, "Simple", "Satu baris: FPS, CPU, GPU, baterai", "FPS 60  CPU 35% 42°  GPU 45% 41°  BAT 85%")
            StyleOption(1, "Compact", "Kartu kecil per komponen, dengan frekuensi", "FPS 60  16.7 ms\nCPU 35%  42°  1800 MHz\nGPU 45%  41°  680 MHz\nRAM 62%\nBAT 85%  36°  2.4 W")
            StyleOption(2, "Normal", "Paling lengkap: rata-rata, low, RAM, daya, game", "FPS 60  16.7 ms\nAVG 58   LOW 45\nCPU 35%  42°  1800 MHz\nGPU 45%  41°  680 MHz\nRAM 62%  7.1 / 11 GB\nBAT 85%  36°\nPWR 2.4 W")
        }
    }

    @Composable
    private fun AccessDialog(onDismiss: () -> Unit) {
        val cur = Access.choice
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Color.Black,
            shape = RoundedCornerShape(28.dp),
            title = { Text("Izinkan Akses", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 24.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Pilih metode yang ingin dipakai untuk akses tingkat tinggi.", color = Color(0xFFA9B0B5))
                    AccessOption("Shizuku", "Tanpa root, jalan lewat Wireless Debugging atau ADB.",
                        Color(0xFF8E86F0), Color(0xFF13111F), cur == Access.SHIZUKU, { PhoneIcon(Color(0xFF8E86F0), Modifier.size(30.dp)) }) {
                        Access.select(Access.SHIZUKU); onDismiss()
                    }
                    AccessOption("Root", "Butuh perangkat yang di-root (Magisk, KernelSU, APatch, dll).",
                        Color(0xFFE49A72), Color(0xFF181412), cur == Access.ROOT, { ShieldIcon(Color(0xFFE49A72), Modifier.size(30.dp)) }) {
                        Access.select(Access.ROOT); onDismiss()
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text("Batal", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
        )
    }

    /** Warna overlay: dipindah ke tab Tampilan. */
    @Composable
    private fun ColorContent() {
        val ctx = LocalContext.current
        SettingCard("Warna aksen") {
            Swatches(AppSettings.ACCENTS, AppSettings.accent) { AppSettings.accent = it; AppSettings.save(ctx) }
        }
        SettingCard("Warna teks overlay") {
            Swatches(AppSettings.TEXTS, AppSettings.overlayText) { AppSettings.overlayText = it; AppSettings.save(ctx) }
        }
        SettingCard("Latar overlay") {
            Swatches(AppSettings.BGS, AppSettings.overlayBg) { AppSettings.overlayBg = it; AppSettings.save(ctx) }
            Text("Transparan ${AppSettings.alpha}%", color = Grey, fontSize = 12.sp)
            Slider(value = AppSettings.alpha / 100f,
                onValueChange = { AppSettings.alpha = (it * 100).toInt().coerceIn(20, 100) },
                onValueChangeFinished = { AppSettings.save(ctx) },
                valueRange = 0.2f..1f)
        }
        SettingCard("Warna suhu") {
            Text("Berubah sesuai tingkat panas", color = Grey, fontSize = 12.sp)
            HeatLegend(30f, "Aman, di bawah 45°"); HeatLegend(50f, "Hangat, 45-54°")
            HeatLegend(60f, "Panas, 55-64°"); HeatLegend(70f, "Sangat panas, 65°+")
        }
        Text("Perubahan warna overlay muncul dalam sekitar 1 detik.", color = Grey, fontSize = 12.sp)
        OutlinedButton(onClick = { AppSettings.reset(ctx) }, modifier = Modifier.fillMaxWidth()) { Text("Kembalikan warna awal") }
    }
}

@Composable
fun AccessOption(title: String, desc: String, accent: Color, bg: Color, selected: Boolean, icon: @Composable () -> Unit, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(bg)
        .border(if (selected) 2.dp else 1.dp, accent.copy(alpha = if (selected) 0.85f else 0.35f), RoundedCornerShape(20.dp))
        .clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        icon(); Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = accent, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Text(desc, color = Color(0xFFC4CACE), fontSize = 14.sp)
        }
    }
}

/** Ikon ponsel (Shizuku) dan perisai (Root), digambar langsung supaya tidak perlu pustaka ikon tambahan. */
@Composable
fun PhoneIcon(c: Color, m: Modifier) = Canvas(m) {
    val w = size.width * 0.55f; val h = size.height * 0.9f
    drawRoundRect(c, androidx.compose.ui.geometry.Offset((size.width - w) / 2, (size.height - h) / 2),
        androidx.compose.ui.geometry.Size(w, h), androidx.compose.ui.geometry.CornerRadius(size.width * 0.1f))
}

@Composable
fun ShieldIcon(c: Color, m: Modifier) = Canvas(m) {
    val w = size.width; val h = size.height
    val p = Path().apply {
        moveTo(w * 0.5f, h * 0.04f); lineTo(w * 0.92f, h * 0.2f); lineTo(w * 0.92f, h * 0.5f)
        cubicTo(w * 0.92f, h * 0.76f, w * 0.7f, h * 0.92f, w * 0.5f, h * 0.98f)
        cubicTo(w * 0.3f, h * 0.92f, w * 0.08f, h * 0.76f, w * 0.08f, h * 0.5f)
        lineTo(w * 0.08f, h * 0.2f); close()
    }
    drawPath(p, c)
}

@Composable
fun RowScope.NavItem(icon: String, label: String, selected: Boolean, color: Color, onClick: () -> Unit) {
    val col by animateColorAsState(if (selected) color else Grey, tween(220), label = "navCol")
    val sc by animateFloatAsState(if (selected) 1.15f else 1f, spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMedium), label = "navScale")
    Column(Modifier.weight(1f).clip(RoundedCornerShape(26.dp))
        .clickable { onClick() }.padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text(icon, color = col, fontSize = 22.sp, modifier = Modifier.graphicsLayer { scaleX = sc; scaleY = sc })
        Text(label, color = col, fontSize = 11.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

@Composable
fun BigCard(title: String, value: String, sub: String, selected: Boolean, m: Modifier) {
    Column(m.background(if (selected) Color.Black else Inner, RoundedCornerShape(24.dp))
        .then(if (selected) Modifier.border(2.5.dp, Color(0xFF8E86F0), RoundedCornerShape(24.dp)) else Modifier)
        .padding(horizontal = 16.dp, vertical = 10.dp)) {
        Text(title, color = Grey, fontSize = 13.sp)
        Text(value, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
        Text(sub, color = Grey, fontSize = 12.sp)
    }
}

@Composable
fun RowScope.Metric(label: String, main: String, sub: String, subTemp: Float, mainTemp: Float = -1f) {
    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = Grey, fontSize = 12.sp)
        Text(main, color = if (mainTemp >= 0) Color(heat(mainTemp)) else Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        if (sub.isNotEmpty()) Text(sub, color = if (subTemp >= 0) Color(heat(subTemp)) else Grey, fontSize = 13.sp, textAlign = TextAlign.Center)
    }
}

@Composable
fun InfoRow(label: String, value: String, t: Float? = null) {
    Row(Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(20.dp)).padding(horizontal = 18.dp, vertical = 14.dp)) {
        Text(label, color = Grey, modifier = Modifier.weight(1f))
        Text(value, color = if (t != null && t >= 0) Color(heat(t)) else Color.White, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SettingCard(title: String, content: @Composable ColumnScope.() -> Unit) = Column(
    Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(20.dp)).padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
) { Text(title, color = Color.White, fontWeight = FontWeight.Bold); content() }

@Composable
fun Swatches(colors: List<Int>, selected: Int, onPick: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        colors.forEach { c ->
            Box(Modifier.size(34.dp).background(Color(c), CircleShape)
                .then(if (c == selected) Modifier.border(2.dp, Color.White, CircleShape) else Modifier)
                .clickable { onPick(c) })
        }
    }
}

@Composable
fun HeatLegend(t: Float, label: String) = Row(verticalAlignment = Alignment.CenterVertically) {
    Box(Modifier.size(12.dp).background(Color(heat(t)), CircleShape))
    Text(label, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(start = 10.dp))
}

/** Grafik FPS: garis + isi tipis di bawahnya, skala 0..maks (minimal 30). */
@Composable
fun FpsGraph(h: List<Int>, m: Modifier) {
    val col = acc()
    Canvas(m) {
        if (h.size < 2) return@Canvas
        val mx = maxOf(h.maxOrNull() ?: 30, 30).toFloat()
        val stepX = size.width / (h.size - 1)
        val line = Path(); val fill = Path()
        h.forEachIndexed { i, v ->
            val x = i * stepX; val y = size.height - (v / mx) * size.height
            if (i == 0) { line.moveTo(x, y); fill.moveTo(x, size.height); fill.lineTo(x, y) }
            else { line.lineTo(x, y); fill.lineTo(x, y) }
        }
        fill.lineTo(size.width, size.height); fill.close()
        drawPath(fill, col.copy(alpha = 0.14f))
        drawPath(line, col, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

@Composable
fun Stat(l: String, v: String) = Column { Text(l, color = Grey, fontSize = 11.sp); Text(v, color = Color.White, fontSize = 19.sp) }
