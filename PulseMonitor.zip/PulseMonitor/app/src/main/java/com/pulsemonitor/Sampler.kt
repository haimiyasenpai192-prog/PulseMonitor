package com.pulsemonitor

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import rikka.shizuku.Shizuku

data class Snap(
    val fps: Int = 0, val avg: Int = 0, val low: Int = 0, val ft: Float = 0f,
    val cpu: Int = -1, val gpu: Int = -1, val ramPct: Int = -1, val ramText: String = "-",
    val temp: Float = -1f, val access: String = "-"
)

object Shell {
    private val rootOk: Boolean by lazy {
        runCatching { ProcessBuilder("su", "-c", "id").start().inputStream.bufferedReader().readText().contains("uid=0") }
            .getOrDefault(false)
    }
    fun shizukuReady() = runCatching { Shizuku.pingBinder() && Shizuku.checkSelfPermission() == 0 }.getOrDefault(false)
    fun mode(): String = if (shizukuReady()) "Shizuku" else if (rootOk) "Root" else "-"

    fun exec(cmd: String): String {
        val p: Process = when (mode()) {
            // newProcess bersifat private di Shizuku 13.x, dipanggil via refleksi
            "Shizuku" -> Shizuku::class.java.getDeclaredMethod(
                "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
            ).apply { isAccessible = true }.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            "Root" -> ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
            else -> return ""
        }
        return runCatching { p.inputStream.bufferedReader().readText() }.getOrDefault("").also { p.destroy() }
    }
}

object Sampler {
    // Urutan prioritas jalur beban GPU. Tambahkan jalur baru di sini bila ada chipset lain.
    private const val GPU_PATHS = "/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage " +   // Adreno (Qualcomm)
        "/sys/kernel/ged/hal/gpu_utilization " +                                       // MediaTek (GED)
        "/sys/module/ged/parameters/gpu_loading " +                                    // MediaTek (GED, varian lain)
        "/proc/mali/utilization"                                                       // Mali lama

    val state = MutableStateFlow(Snap())
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var job: Job? = null
    private var prevTotal = 0L; private var prevIdle = 0L
    private val hist = ArrayDeque<Int>()

    fun start() {
        if (job?.isActive == true) return
        job = scope.launch {
            while (isActive) {
                runCatching { tick() }
                delay(1000)
            }
        }
    }

    private fun tick() {
        val mode = Shell.mode()
        if (mode == "-") { state.value = Snap(access = "-"); return }
        val out = Shell.exec(
            "head -1 /proc/stat; echo ==; for f in $GPU_PATHS; do [ -r \$f ] && echo \"\$f:\$(cat \$f 2>/dev/null)\"; done; echo ==; " +
            "head -3 /proc/meminfo; echo ==; grep -H . /sys/class/thermal/thermal_zone*/type /sys/class/thermal/thermal_zone*/temp 2>/dev/null"
        ).split("==")
        if (out.size < 4) return

        // CPU
        val c = out[0].trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        var cpu = -1
        if (c.size >= 5) {
            val total = c.take(8).sum(); val idle = c[3] + c[4]
            if (prevTotal > 0 && total > prevTotal) cpu = (100 * ((total - prevTotal) - (idle - prevIdle)) / (total - prevTotal)).toInt()
            prevTotal = total; prevIdle = idle
        }
        // GPU: Adreno (kgsl) dulu, lalu MediaTek (GED) / Mali. Ambil angka pertama 0..100 dari jalur
        // pertama yang terbaca; format tiap jalur berbeda (ada yang "45", ada yang "45 30 12").
        val gpu = out[1].lines().firstNotNullOfOrNull { line ->
            Regex("\\d+").find(line.substringAfter(':', ""))?.value?.toIntOrNull()?.takeIf { it in 0..100 }
        } ?: -1
        // RAM
        fun kb(n: String) = Regex("$n:\\s+(\\d+)").find(out[2])?.groupValues?.get(1)?.toLongOrNull() ?: 0L
        val tot = kb("MemTotal"); val av = kb("MemAvailable")
        val ramPct = if (tot > 0) (100 * (tot - av) / tot).toInt() else -1
        val ramText = "%.1f / %.0f GB".format((tot - av) / 1048576f, tot / 1048576f)
        // Suhu: zona bertipe cpu/soc/battery
        val lines = out[3].lines()
        val zType = HashMap<String, String>(); val zTemp = HashMap<String, Float>()
        for (l in lines) {
            val m = Regex("thermal_zone(\\d+)/(type|temp):(.*)").find(l) ?: continue
            val (z, k, v) = m.destructured
            if (k == "type") zType[z] = v.trim() else v.trim().toFloatOrNull()?.let { zTemp[z] = if (it > 1000) it / 1000 else it }
        }
        val pick = zType.entries.firstOrNull { it.value.contains("cpu", true) || it.value.contains("soc", true) }
            ?: zType.entries.firstOrNull { it.value.contains("battery", true) }
        val temp = pick?.let { zTemp[it.key] } ?: -1f

        val f = runCatching { fps() }.getOrDefault(0 to 0)
        if (f.first > 0) { hist.addLast(f.first); if (hist.size > 30) hist.removeFirst() }
        state.value = Snap(
            fps = f.first, avg = if (hist.isEmpty()) 0 else hist.average().toInt(), low = f.second,
            ft = if (f.first > 0) 1000f / f.first else 0f, cpu = cpu, gpu = gpu,
            ramPct = ramPct, ramText = ramText, temp = temp, access = mode
        )
    }

    /** FPS dari SurfaceFlinger latency layer aplikasi yang sedang fokus. Return (fps, 1% low). */
    private fun fps(): Pair<Int, Int> {
        val pkg = Regex("([\\w.]+)/").find(Shell.exec("dumpsys window | grep -m1 mCurrentFocus"))?.groupValues?.get(1) ?: return 0 to 0
        val layers = Shell.exec("dumpsys SurfaceFlinger --list").lines().filter { it.contains(pkg) && !it.startsWith("Background") }
        val layer = layers.firstOrNull { it.contains("SurfaceView") } ?: layers.firstOrNull() ?: return 0 to 0
        val ts = Shell.exec("dumpsys SurfaceFlinger --latency '$layer'").lines().drop(1)
            .mapNotNull { it.trim().split(Regex("\\s+")).getOrNull(1)?.toLongOrNull() }
            .filter { it in 1 until Long.MAX_VALUE / 2 }
        if (ts.size < 3) return 0 to 0
        val recent = ts.filter { it >= ts.last() - 1_000_000_000L }
        if (recent.size < 2) return 0 to 0
        val fps = ((recent.size - 1) * 1e9 / (recent.last() - recent.first())).toInt()
        val deltas = ts.zipWithNext { a, b -> b - a }.filter { it > 0 }.sortedDescending()
        if (deltas.isEmpty()) return 0 to 0
        val worst = deltas[(deltas.size / 100).coerceAtMost(deltas.size - 1)]
        return fps to (1e9 / worst).toInt()
    }
}
