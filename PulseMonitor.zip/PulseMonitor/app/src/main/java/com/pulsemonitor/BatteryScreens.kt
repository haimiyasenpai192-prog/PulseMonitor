package com.pulsemonitor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val BgB = Color(0xFF101014)
private val CardB = Color(0xFF1D1E24)
private val MutedB = Color(0xFF8E8E99)
private val BlueB = Color(0xFF4C8DFF)
private val GreenB = Color(0xFF4CC38A)
private val AmberB = Color(0xFFF5B83D)
private val BarB = Color(0xFFAAB8FF)

private fun durHm(sec: Int): String {
    val h = sec / 3600; val m = (sec % 3600) / 60; val s = sec % 60
    return if (h > 0) "${h}j ${m}m" else if (m > 0) "${m}m ${s}d" else "${s}d"
}

private fun durMs(ms: Long): String {
    val t = ms / 1000; val h = t / 3600; val m = (t % 3600) / 60; val s = t % 60
    return if (h > 0) "${h}j ${m}m" else if (m > 0) "${m}m ${s}d" else "${s}d"
}

private fun pctTxt(v: Float) = if (v >= 0f) "%.0f%%".format(v) else "-"

private fun whenTxt(id: Long): String = SimpleDateFormat("d MMM · HH:mm", Locale.getDefault()).format(Date(id))

@Composable
private fun TopBar(onBack: () -> Unit, trailing: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(Modifier.size(44.dp).clip(CircleShape).clickable { onBack() }, contentAlignment = Alignment.Center) {
            Text("←", color = Color.White, fontSize = 26.sp)
        }
        Spacer(Modifier.weight(1f))
        trailing()
    }
}

@Composable
private fun SmallPill(text: String, bg: Color = CardB, onClick: () -> Unit) {
    Box(Modifier.clip(CircleShape).background(bg).clickable { onClick() }.padding(horizontal = 16.dp, vertical = 9.dp)) {
        Text(text, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun StatCell(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = MutedB, fontSize = 11.sp, maxLines = 1)
        Text(value, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.padding(top = 2.dp))
    }
}

/** Daftar sesi baterai: yang sedang berjalan di atas, lalu yang sudah selesai. */
@Composable
fun BatteryListScreen(onBack: () -> Unit, onOpen: (Long) -> Unit) {
    val ctx = LocalContext.current
    val ver by BatteryHistory.version.collectAsState()
    val list by produceState<List<BatSession>?>(null, ver / 3) { value = withContext(Dispatchers.IO) { BatteryHistory.list(ctx) } }
    val l = list
    Column(Modifier.fillMaxSize().background(BgB).statusBarsPadding().navigationBarsPadding()
        .verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        TopBar(onBack)
        Text("Riwayat baterai", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Direkam otomatis selama aplikasi dibuka, dan terus berlanjut di latar belakang bila overlay atau notifikasi aktif. Ketuk sesi untuk melihat grafik dan pemakaian per aplikasi.",
            color = MutedB, fontSize = 12.sp, lineHeight = 16.sp)
        if (l == null) Text("Memuat…", color = MutedB, modifier = Modifier.padding(top = 12.dp))
        else if (l.isEmpty()) Text("Belum ada sesi. Sesi mulai terekam otomatis begitu aplikasi terbuka, tunggu beberapa detik lalu buka lagi halaman ini.",
            color = MutedB, fontSize = 13.sp, modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp), textAlign = TextAlign.Center)
        else l.forEach { SessionRow(it) { onOpen(it.id) } }
    }
}

@Composable
private fun SessionRow(s: BatSession, onClick: () -> Unit) {
    val status = if (s.open) "Berjalan" else if (s.charging) "Mengisi" else "Terpakai"
    val tint = if (s.open) BlueB else if (s.charging) GreenB else AmberB
    val spark = remember(s.id, s.n) {
        val f = s.level.filter { it >= 0f }
        if (f.size <= 60) f else List(60) { i -> f[(i * (f.size - 1)) / 59] }
    }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(CardB).clickable { onClick() }.padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(whenTxt(s.id), color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text(status, color = tint, fontSize = 12.sp, fontWeight = FontWeight.Medium,
                modifier = Modifier.background(tint.copy(alpha = 0.15f), CircleShape).padding(horizontal = 10.dp, vertical = 3.dp))
        }
        Row(verticalAlignment = Alignment.Bottom) {
            Text("${pctTxt(s.startPct)} → ${pctTxt(s.endPct)}", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            Text("  ${durHm(s.dur)}", color = MutedB, fontSize = 12.sp, modifier = Modifier.padding(bottom = 3.dp))
        }
        if (spark.size >= 2) Canvas(Modifier.fillMaxWidth().height(28.dp)) {
            var lo = spark.min(); var hi = spark.max()
            if (hi - lo < 4f) { val m = (hi + lo) / 2f; lo = m - 2f; hi = m + 2f }
            val p = Path()
            spark.forEachIndexed { i, v ->
                val x = size.width * i / (spark.size - 1); val y = size.height * (1f - (v - lo) / (hi - lo))
                if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
            drawPath(p, BlueB, style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Rata-rata" to (if (s.avgW >= 0f) "%.1f W".format(s.avgW) else "-"),
                "Suhu maks" to (if (s.peakTemp >= 0f) "%.0f°C".format(s.peakTemp) else "-")).forEach { (k, v) ->
                Row(Modifier.background(Color.White.copy(alpha = 0.06f), CircleShape).padding(horizontal = 10.dp, vertical = 4.dp)) {
                    Text("$k ", color = MutedB, fontSize = 11.sp)
                    Text(v, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

/** Detail satu sesi: ringkasan, grafik level / daya / suhu, lalu pemakaian per aplikasi. */
@Composable
fun BatteryDetailScreen(id: Long, onBack: () -> Unit, onDeleted: () -> Unit) {
    val ctx = LocalContext.current
    val ver by BatteryHistory.version.collectAsState()
    val ses by produceState<BatSession?>(null, id, ver / 3) { value = withContext(Dispatchers.IO) { BatteryHistory.load(ctx, id) } }
    val s = ses
    var reload by remember { mutableIntStateOf(0) }
    var liveApps by remember { mutableStateOf<List<AppUse>?>(null) }
    var liveDone by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    LaunchedEffect(id, reload) {
        liveDone = false
        liveApps = withContext(Dispatchers.IO) { BatteryHistory.liveApps(ctx, id) }
        liveDone = true
    }
    LaunchedEffect(confirm) { if (confirm) { delay(3000); confirm = false } }

    Column(Modifier.fillMaxSize().background(BgB).statusBarsPadding().navigationBarsPadding()
        .verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TopBar(onBack) {
            if (s != null && s.open) SmallPill("Segarkan") { reload++ }
            if (s != null && !s.open) SmallPill(if (confirm) "Yakin hapus?" else "Hapus", if (confirm) Color(0xFF5A2530) else CardB) {
                if (confirm) { BatteryHistory.delete(ctx, id); onDeleted() } else confirm = true
            }
        }
        Text("Detail sesi", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        if (s == null) { Text("Memuat…", color = MutedB); return@Column }
        val status = if (s.open) "Sedang berjalan" else if (s.charging) "Mengisi daya" else "Tidak mengisi daya"
        Text("${whenTxt(s.id)}  ·  ${durHm(s.dur)}  ·  $status", color = Color(0xFFC4C6CE), fontSize = 12.sp)

        val delta = if (s.startPct >= 0f && s.endPct >= 0f) kotlin.math.abs(s.endPct - s.startPct) else -1f
        Row(Modifier.fillMaxWidth().background(CardB, RoundedCornerShape(18.dp)).padding(horizontal = 8.dp, vertical = 12.dp)) {
            StatCell("AWAL", pctTxt(s.startPct), Modifier.weight(1f))
            StatCell("AKHIR", pctTxt(s.endPct), Modifier.weight(1f))
            StatCell(if (s.charging) "TERISI" else "TERPAKAI", pctTxt(delta), Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth().background(CardB, RoundedCornerShape(18.dp)).padding(horizontal = 8.dp, vertical = 12.dp)) {
            StatCell("DAYA MAKS", if (s.peakW >= 0f) "%.1f W".format(s.peakW) else "-", Modifier.weight(1f))
            StatCell("RATA-RATA", if (s.avgW >= 0f) "%.1f W".format(s.avgW) else "-", Modifier.weight(1f))
            StatCell("SUHU MAKS", if (s.peakTemp >= 0f) "%.0f°C".format(s.peakTemp) else "-", Modifier.weight(1f))
        }
        if (s.n < 2) Text("Data masih sedikit, grafik muncul setelah beberapa menit.", color = MutedB, fontSize = 12.sp)
        LineChart(if (s.charging) "Timeline isi daya" else "Timeline kuras baterai", s.t, listOf(
            Series("Level", BlueB, s.level), Series("Daya", GreenB, s.watt), Series("Suhu", AmberB, s.temp)))

        Text("Pemakaian aplikasi", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
        val apps: List<AppUse> = (if (s.open) liveApps else s.apps).orEmpty()
        val waiting = s.open && !liveDone
        when {
            waiting -> Note("Membaca statistik baterai…")
            apps.isEmpty() -> Note(
                if (Access.status != 2) "Pemakaian per aplikasi butuh akses Shizuku atau Root. Pilih di tab Settings."
                else if (s.open) "Belum ada data aplikasi untuk sesi ini. Foto awal statistik mungkin belum terbaca; coba Segarkan beberapa saat lagi."
                else "Data aplikasi tidak terbaca untuk sesi ini (statistik sistem tidak tersedia saat sesi berakhir)."
            )
            else -> {
                val total = apps.sumOf { it.mah.toDouble() }.toFloat().coerceAtLeast(0.001f)
                val top = apps.maxOf { it.mah }.coerceAtLeast(0.001f)
                apps.take(15).forEach { AppRow(it, it.mah / top, it.mah / total * 100f) }
                Text("Dihitung dari statistik baterai sistem sejak sesi dimulai. Angka bisa beda tipis dengan Setelan Android.",
                    color = MutedB, fontSize = 11.sp, lineHeight = 15.sp, modifier = Modifier.padding(horizontal = 4.dp))
            }
        }
    }
}

@Composable
private fun Note(text: String) {
    Text(text, color = MutedB, fontSize = 13.sp, lineHeight = 18.sp,
        modifier = Modifier.fillMaxWidth().background(CardB, RoundedCornerShape(18.dp)).padding(16.dp))
}

@Composable
private fun AppRow(u: AppUse, frac: Float, share: Float) {
    val ctx = LocalContext.current
    val icon = remember(u.pkg) { if (u.pkg.isNotEmpty()) appIcon(ctx, u.pkg) else null }
    val detail = (if (u.ms >= 0L) durMs(u.ms) + " • " else "") + "%.1f mAh".format(u.mah)
    Row(Modifier.fillMaxWidth().background(CardB, RoundedCornerShape(20.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        if (icon != null) Image(icon.asImageBitmap(), null, Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)))
        else Box(Modifier.size(48.dp).background(Color(0xFF262833), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
            Text(u.label.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        Column(Modifier.weight(1f).padding(start = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(u.label, color = Color.White, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                Text(detail, color = MutedB, fontSize = 12.sp, maxLines = 1, softWrap = false, modifier = Modifier.padding(start = 8.dp))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f).height(8.dp).clip(CircleShape).background(Color(0xFF2E3140))) {
                    Box(Modifier.fillMaxWidth(frac.coerceIn(0.03f, 1f)).fillMaxHeight().background(BarB, CircleShape))
                }
                Text("%.1f%%".format(share), color = Color.White, fontSize = 14.sp, textAlign = TextAlign.End,
                    modifier = Modifier.padding(start = 10.dp).widthIn(min = 46.dp))
            }
        }
    }
}
