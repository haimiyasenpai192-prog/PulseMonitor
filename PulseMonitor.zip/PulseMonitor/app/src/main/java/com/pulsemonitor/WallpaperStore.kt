package com.pulsemonitor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import java.io.File

/** Menyimpan wallpaper latar aplikasi. Gambar disalin ke
 *  penyimpanan internal, jadi tidak bergantung pada izin galeri dan tetap ada walau file aslinya dihapus. */
object WallpaperStore {
    private const val MAX_SIDE = 3072   // sisi terpanjang setelah diperkecil (cukup tajam untuk layar HP QHD+), masih aman untuk RAM
    private const val PREFS = "pulse"
    private const val KEY_DIM = "dim"

    private fun file(c: Context) = File(c.filesDir, "wallpaper.jpg")

    /** Baca gambar pilihan, diperkecil (maks 3072 px) dan sudah diputar sesuai EXIF. Dipakai layar potong dan penyimpanan. */
    fun decodePreview(c: Context, uri: Uri): Bitmap? = runCatching {
        ImageDecoder.decodeBitmap(ImageDecoder.createSource(c.contentResolver, uri)) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE   // bitmap hardware tidak bisa di-compress
            // Perkecil hanya jika benar-benar lebih besar dari batas, dengan skala halus (bukan kelipatan 2) supaya tetap tajam
            val longest = maxOf(info.size.width, info.size.height)
            if (longest > MAX_SIDE) {
                val k = MAX_SIDE.toFloat() / longest
                decoder.setTargetSize((info.size.width * k).toInt().coerceAtLeast(1), (info.size.height * k).toInt().coerceAtLeast(1))
            }
        }
    }.getOrNull()

    private fun writeTo(c: Context, bmp: Bitmap, target: File): Boolean = runCatching {
        val tmp = File(c.filesDir, target.name + ".tmp")
        tmp.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 97, it) }
        check(tmp.renameTo(target) || (target.delete() && tmp.renameTo(target)))
    }.isSuccess

    private fun saveTo(c: Context, uri: Uri, target: File): Boolean {
        val bmp = decodePreview(c, uri) ?: return false
        return writeTo(c, bmp, target).also { bmp.recycle() }
    }

    /** Simpan hasil potong (sudah dalam rasio yang diinginkan). */
    fun saveCropped(c: Context, bmp: Bitmap): Boolean = writeTo(c, bmp, file(c))

    // ---------- Wallpaper aplikasi ----------
    fun save(c: Context, uri: Uri): Boolean = saveTo(c, uri, file(c))

    fun load(c: Context): Bitmap? = file(c).takeIf { it.exists() }?.let {
        BitmapFactory.decodeFile(it.path, BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 })
    }

    fun clear(c: Context) { file(c).delete() }

    fun dim(c: Context): Float = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getFloat(KEY_DIM, 0.6f)

    fun saveDim(c: Context, v: Float) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putFloat(KEY_DIM, v).apply()
    }

    /** Bersihkan sisa fitur wallpaper notifikasi (gambar dan pengaturan redupnya) dari versi lama. */
    fun purgeNotifLeftovers(c: Context) {
        File(c.filesDir, "notif_wallpaper.jpg").delete()
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove("notif_dim").apply()
    }
}
