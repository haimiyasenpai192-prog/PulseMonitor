package com.pulsemonitor

import android.content.Context
import android.os.Build
import android.os.SystemClock

/**
 * Sumber FPS dari sistem (Android 14+), meniru cara redfox: daemon [TaskFpsDaemon] (hak shell/root) mendaftar
 * IWindowManager.registerTaskFpsCallback dan sistem mengirim FPS frame yang benar-benar tampil untuk task game.
 * Sampler memakai angka ini bila ada dan segar; bila tidak, jatuh ke jalur lama (dumpsys SurfaceFlinger timestats).
 *
 * Daemon dijalankan sebagai proses terpisah dari APK ini (app_process), dibaca baris demi baris lewat stdout.
 */
object TaskFps {
    private const val MAX_AGE_MS = 4000L

    private class R(val fps: Float, val ageMs: Long, val task: Int, val pkg: String, val cb: Long, val at: Long)

    @Volatile private var last: R? = null
    @Volatile private var proc: Process? = null
    @Volatile private var thread: Thread? = null
    @Volatile private var gen = 0
    @Volatile private var giveUp = false
    @Volatile private var want = ""
    @Volatile private var sent = "\u0000"
    @Volatile var status = "mati"; private set

    fun supported() = Build.VERSION.SDK_INT >= 34 && !giveUp

    @Synchronized fun start(ctx: Context) {
        if (Build.VERSION.SDK_INT < 34) { status = "butuh Android 14+"; return }
        if (giveUp || thread?.isAlive == true) return
        val apk = ctx.applicationContext.applicationInfo.sourceDir
        val g = ++gen
        thread = Thread({ supervise(apk, g) }, "taskfps").apply { isDaemon = true; start() }
    }

    @Synchronized fun stop() {
        gen++
        val p = proc
        if (p != null) {
            runCatching { p.outputStream.write("STOP\n".toByteArray()); p.outputStream.flush() }
            runCatching { p.destroy() }
        }
        thread?.interrupt(); thread = null; proc = null; last = null
        status = "mati"
    }

    /** Paket yang ingin diukur (kosong = task fokus). Dikirim ke daemon hanya saat berubah. */
    fun track(pkg: String) { want = pkg; sendPkg(pkg, false) }

    /** FPS dari sistem untuk [pkg]; null bila belum ada, basi, atau task yang terukur bukan milik [pkg]. */
    fun read(pkg: String): Float? {
        val r = last ?: return null
        if (pkg.isEmpty() || r.fps < 0f || r.ageMs < 0L || r.pkg != pkg) return null
        val age = (SystemClock.elapsedRealtime() - r.at) + r.ageMs
        return if (age <= MAX_AGE_MS) r.fps else null
    }

    fun diag(): String {
        val r = last
        return "TaskFps: $status" + (r?.let { " | task ${it.task} ${it.pkg} | %.1f fps | umur ${it.ageMs} ms | cb=${it.cb}".format(it.fps) } ?: "")
    }

    private fun sendPkg(pkg: String, force: Boolean) {
        val p = proc ?: return
        if (!force && pkg == sent) return
        runCatching { p.outputStream.write("PKG $pkg\n".toByteArray()); p.outputStream.flush(); sent = pkg }
    }

    private fun sleep(ms: Long) { try { Thread.sleep(ms) } catch (_: InterruptedException) {} }

    private fun supervise(apk: String, g: Int) {
        var quick = 0
        while (g == gen && !giveUp) {
            if (Shell.mode() == "-") { status = "menunggu akses"; sleep(3000); continue }
            val t0 = SystemClock.elapsedRealtime()
            runCatching { runOnce(apk, g) }.onFailure { AppLog.w("TaskFps", "daemon gagal: $it") }
            if (g != gen || giveUp) break
            quick = if (SystemClock.elapsedRealtime() - t0 < 5000L) quick + 1 else 0
            if (quick >= 5) {
                giveUp = true; status = "gagal berulang, pakai timestats"
                AppLog.w("TaskFps", "daemon mati <5 dtk 5x berturut-turut, dinonaktifkan sampai aplikasi dibuka ulang")
                break
            }
            status = "restart"; sleep(1500)
        }
        if (g == gen) last = null
    }

    private fun runOnce(apk: String, g: Int) {
        val cmd = "export CLASSPATH='$apk'; exec app_process /system/bin --nice-name=pulse_fps com.pulsemonitor.TaskFpsDaemon 2>&1"
        val p = Shell.spawn(cmd) ?: return
        proc = p; sent = "\u0000"; status = "memulai"
        sendPkg(want, true)
        try {
            p.inputStream.bufferedReader().use { r ->
                while (g == gen) {
                    val l = r.readLine() ?: break
                    handle(l, g)
                }
            }
        } finally {
            runCatching { p.destroy() }
            if (proc === p) proc = null
        }
    }

    private fun handle(l: String, g: Int) {
        if (g != gen) return
        when {
            l.startsWith("FPS ") -> {
                val s = l.split(' ')
                if (s.size < 6) return
                last = R(s[1].toFloatOrNull() ?: -1f, s[2].toLongOrNull() ?: -1L, s[3].toIntOrNull() ?: -1,
                    s[4], s[5].toLongOrNull() ?: 0L, SystemClock.elapsedRealtime())
                status = "aktif"
            }
            l.startsWith("UNSUPPORTED") -> {
                giveUp = true; status = "tidak didukung: ${l.removePrefix("UNSUPPORTED").trim()}"
                AppLog.w("TaskFps", l.take(200))
            }
            l.startsWith("LOG ") -> AppLog.i("TaskFps", l.substring(4).take(200))
            l == "EXIT" -> {}
            l.isNotBlank() -> AppLog.i("TaskFps", "daemon: ${l.take(160)}")
        }
    }
}
