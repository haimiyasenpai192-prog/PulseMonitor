package com.pulsemonitor

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import rikka.shizuku.Shizuku

/**
 * Pilihan metode akses tingkat tinggi: Shizuku atau Root. Dipilih lewat dialog "Izinkan Akses" di tab Settings.
 * AUTO = belum pernah memilih (perilaku lama: Shizuku kalau siap, kalau tidak coba root).
 */
object Access {
    const val REQ = 4711
    const val AUTO = -1
    const val SHIZUKU = 0
    const val ROOT = 1

    /** Metode yang dipilih pengguna. */
    var choice by mutableIntStateOf(AUTO); private set
    /** 0 = tidak berjalan / tidak tersedia, 1 = belum diizinkan, 2 = terhubung (untuk metode aktif). */
    var status by mutableIntStateOf(0); private set
    /** Hasil pengecekan su: 0 = tidak ada su, 1 = ditolak / belum dicek, 2 = root aktif. */
    @Volatile var rootState = 1; private set

    private var prefs: SharedPreferences? = null
    private var appCtx: Context? = null
    private var pendingRoot = false
    private var awaitingShizuku = false
    private val main = Handler(Looper.getMainLooper())

    fun init(ctx: Context) {
        if (appCtx != null) return
        val app = ctx.applicationContext
        appCtx = app
        prefs = app.getSharedPreferences("access", Context.MODE_PRIVATE)
        choice = prefs?.getInt("mode", AUTO) ?: AUTO
        if (choice == ROOT) probeRootAsync()
        refresh()
    }

    fun isRoot() = choice == ROOT

    fun refresh() {
        status = if (choice == ROOT) rootState else shizukuStatus()
    }

    private fun shizukuStatus(): Int = try {
        when {
            !Shizuku.pingBinder() -> 0
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> 2
            else -> 1
        }
    } catch (_: Throwable) { 0 }

    /** Minta su; Magisk/KernelSU/APatch menampilkan dialog izin kalau belum pernah diizinkan. */
    private fun probeRootAsync() {
        Thread {
            val s = try {
                val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
                val out = p.inputStream.bufferedReader().readText()
                if (p.waitFor() == 0 && out.contains("uid=0")) 2 else 1
            } catch (_: java.io.IOException) { 0 } catch (_: Throwable) { 1 }
            rootState = s
            main.post {
                refresh()
                if (pendingRoot) {
                    pendingRoot = false
                    val c = appCtx
                    if (c != null) when (s) {
                        2 -> Notifier.accessSelected(c, "Root")
                        0 -> Notifier.accessFailed(c, "Root", "Root tidak tersedia di perangkat ini.")
                        else -> Notifier.accessFailed(c, "Root", "Izin root ditolak.")
                    }
                }
            }
        }.start()
    }

    /**
     * Dipanggil saat pengguna memilih metode di dialog "Izinkan Akses".
     * Berhasil -> suara + notifikasi khusus. Gagal / ditolak -> notifikasi dengan suara bawaan HP.
     */
    fun select(m: Int) {
        val c = appCtx ?: return
        awaitingShizuku = false
        choice = m
        prefs?.edit()?.putInt("mode", m)?.apply()
        if (m == ROOT) {
            pendingRoot = true
            rootState = 1
            refresh()
            probeRootAsync()
            return
        }
        pendingRoot = false
        refresh()
        when (status) {
            2 -> Notifier.accessSelected(c, "Shizuku")
            1 -> {
                val blocked = try { Shizuku.shouldShowRequestPermissionRationale() } catch (_: Throwable) { false }
                if (blocked) Notifier.accessFailed(c, "Shizuku", "Izin Shizuku ditolak. Aktifkan lewat aplikasi Shizuku.")
                else { awaitingShizuku = true; requestPermission() }
            }
            else -> Notifier.accessFailed(c, "Shizuku", "Shizuku belum berjalan. Nyalakan dulu Shizuku.")
        }
    }

    /** Ketuk saat belum diizinkan: ulangi permintaan sesuai metode yang aktif. */
    fun requestPermission() {
        if (choice == ROOT) { probeRootAsync(); return }
        try { if (Shizuku.pingBinder() && !Shizuku.shouldShowRequestPermissionRationale()) Shizuku.requestPermission(REQ) } catch (_: Throwable) {}
    }

    /** Hasil dialog izin Shizuku. */
    fun onPermissionResult(granted: Boolean) {
        refresh()
        if (!awaitingShizuku) return
        awaitingShizuku = false
        val c = appCtx ?: return
        if (granted) Notifier.accessSelected(c, "Shizuku")
        else Notifier.accessFailed(c, "Shizuku", "Izin Shizuku ditolak.")
    }
}
