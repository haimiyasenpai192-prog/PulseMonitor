package com.pulsemonitor

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import rikka.shizuku.Shizuku

data class Snap(
    val fps: Int = 0, val avg: Int = 0, val low: Int = 0, val ft: Float = 0f,
    val cpu: Int = -1, val gpu: Int = -1, val ramPct: Int = -1, val ramText: String = "-",
    val temp: Float = -1f, val access: String = "-", val dbg: String = ""
)

object Shell {
    private val rootOk: Boolean by lazy {
        runCatching { ProcessBuilder("su", "-c", "id").start().inputStream.bufferedReader().readText().contains("uid=0") }
            .getOrDefault(false)
    }
    fun shizukuReady() = runCatching { Shizuku.pingBinder() && Shizuku.checkSelfPermission() == 0 }.getOrDefault(false)
    fun mode(): String = if (shizukuReady()) "Shizuku" else if (rootOk) "Root" else "-"

    fun exec(cmd: String): String {
        val p: Process = when (mode()) {
            // newProcess bersifat private di Shizuku 13.x, dipanggil via refleksi
            "Shizuku" -> Shizuku::class.java.getDeclaredMethod(
                "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
            ).apply { isAccessible = true }.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            "Root" -> ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
            else -> return ""
        }
        return runCatching { p.inputStream.bufferedReader().readText() }.getOrDefault("").also { p.destroy() }
    }
}

object Sampler {
    // Urutan prioritas jalur beban GPU. Tambahkan jalur baru di sini bila ada chipset lain.
    private const val GPU_PATHS = "/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage " +   // Adreno (Qualcomm)
        "/sys/kernel/ged/hal/gpu_utilization " +                                       // MediaTek (GED)
        "/sys/module/ged/parameters/gpu_loading " +                                    // MediaTek (GED, varian lain)
        "/proc/mali/utilization"                                                       // Mali lama

    val state = MutableStateFlow(Snap())
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var job: Job? = null
    private var prevTotal = 0L; private var prevIdle = 0L
    private val hist = ArrayDeque<Int>()

    fun start() {
        if (job?.isActive == true) return
        job = scope.launch {
            while (isActive) {
                runCatching { tick() }
                delay(1000)
            }
        }
    }

    private fun tick() {
        val mode = Shell.mode()
        if (mode == "-") { state.value = Snap(access = "-"); return }
        val out = Shell.exec(
            "head -1 /proc/stat; echo ==; for f in $GPU_PATHS; do [ -r \$f ] && echo \"\$f:\$(cat \$f 2>/dev/null)\"; done; echo ==; " +
            "head -3 /proc/meminfo; echo ==; grep -H . /sys/class/thermal/thermal_zone*/type /sys/class/thermal/thermal_zone*/temp 2>/dev/null"
        ).split("==")
        if (out.size < 4) return

        // CPU
        val c = out[0].trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        var cpu = -1
        if (c.size >= 5) {
            val total = c.take(8).sum(); val idle = c[3] + c[4]
            if (prevTotal > 0 && total > prevTotal) cpu = (100 * ((total - prevTotal) - (idle - prevIdle)) / (total - prevTotal)).toInt()
            prevTotal = total; prevIdle = idle
        }
        // GPU: Adreno (kgsl) dulu, lalu MediaTek (GED) / Mali. Ambil angka pertama 0..100 dari jalur
        // pertama yang terbaca; format tiap jalur berbeda (ada yang "45", ada yang "45 30 12").
        val gpu = out[1].lines().firstNotNullOfOrNull { line ->
            Regex("\\d+").find(line.substringAfter(':', ""))?.value?.toIntOrNull()?.takeIf { it in 0..100 }
        } ?: -1
        // RAM
        fun kb(n: String) = Regex("$n:\\s+(\\d+)").find(out[2])?.groupValues?.get(1)?.toLongOrNull() ?: 0L
        val tot = kb("MemTotal"); val av = kb("MemAvailable")
        val ramPct = if (tot > 0) (100 * (tot - av) / tot).toInt() else -1
        val ramText = "%.1f / %.0f GB".format((tot - av) / 1048576f, tot / 1048576f)
        // Suhu: zona bertipe cpu/soc/battery
        val lines = out[3].lines()
        val zType = HashMap<String, String>(); val zTemp = HashMap<String, Float>()
        for (l in lines) {
            val m = Regex("thermal_zone(\\d+)/(type|temp):(.*)").find(l) ?: continue
            val (z, k, v) = m.destructured
            if (k == "type") zType[z] = v.trim() else v.trim().toFloatOrNull()?.let { zTemp[z] = if (it > 1000) it / 1000 else it }
        }
        val cpuKeys = listOf("cpu", "soc", "tsens", "cluster", "big", "little")
        val cands = zType.entries.filter { e -> cpuKeys.any { e.value.contains(it, true) } }
            .mapNotNull { e -> zTemp[e.key]?.takeIf { it in 15f..120f }?.let { e.value to it } }
        val best = cands.maxByOrNull { it.second }
            ?: zType.entries.firstOrNull { it.value.contains("battery", true) }
                ?.let { e -> zTemp[e.key]?.takeIf { it in 5f..90f }?.let { e.value to it } }
        val sysTemp = best?.second ?: -1f
        val sysDbg = if (best != null) "${best.first} (${cands.size} zona CPU)" else "tidak ada zona valid (${zType.size} zona)"

        // Suhu utama: thermal HAL (sama seperti FrameX), sysfs hanya cadangan
        val th = runCatching { thermal() }.getOrNull()
        val temp = th?.second ?: sysTemp
        val tempDbg = if (th != null) "HAL ${th.first}" else "sysfs $sysDbg"

        val f = runCatching { fps() }.getOrDefault(0 to 0)
        if (f.first > 0) { hist.addLast(f.first); if (hist.size > 30) hist.removeFirst() }
        state.value = Snap(
            fps = f.first, avg = if (hist.isEmpty()) 0 else hist.average().toInt(),
            low = if (f.second > 0) f.second else (hist.minOrNull() ?: 0),
            ft = if (f.first > 0) 1000f / f.first else 0f, cpu = cpu, gpu = gpu,
            ramPct = ramPct, ramText = ramText, temp = temp, access = mode,
            dbg = "FPS: $fpsDbg\nSuhu: $tempDbg"
        )
    }

    private var fpsDbg = "-"

    private fun focusPkg(): String? {
        val outs = listOf(
            Shell.exec("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp' | head -6"),
            Shell.exec("dumpsys activity activities | grep -E 'topResumedActivity|ResumedActivity' | head -4")
        )
        for (o in outs) for (l in o.lines()) {
            if (l.contains("=null")) continue
            Regex("u\\d+ ([\\w.]+)/").find(l)?.let { return it.groupValues[1] }
        }
        return null
    }

    private var tsPrev = HashMap<String, Long>()
    private var tsPrevAt = 0L
    private var tsReady = false

    /** SurfaceFlinger TimeStats: layer -> total frame yang sudah dipresentasikan. */
    private fun timestats(): Map<String, Long> {
        if (!tsReady) { Shell.exec("dumpsys SurfaceFlinger --timestats -clear -enable"); tsReady = true }
        val res = HashMap<String, Long>()
        var name: String? = null
        for (l in Shell.exec("dumpsys SurfaceFlinger --timestats -dump").lines()) {
            val t = l.trim()
            if (t.startsWith("layerName")) name = t.substringAfter('=').trim()
            else if (name != null && t.startsWith("totalFrames")) {
                res[name!!] = t.substringAfter('=').trim().toLongOrNull() ?: 0L; name = null
            }
        }
        if (res.isEmpty()) tsReady = false   // statistik belum aktif/ter-reset: aktifkan lagi di tick berikutnya
        return res
    }

    /** FPS = selisih totalFrames layer aplikasi fokus per detik. Cadangan: --latency. */
    private fun fps(): Pair<Int, Int> {
        val pkg = focusPkg()
        if (pkg == null) { fpsDbg = "aplikasi fokus tidak terbaca"; return 0 to 0 }
        val stats = timestats()
        val now = System.currentTimeMillis()
        val dt = (now - tsPrevAt) / 1000f
        val cand = stats.filter { it.key.contains(pkg) }
        var best = 0f
        for ((k, v) in cand) {
            val prev = tsPrev[k] ?: continue
            if (dt > 0.3f && v >= prev) best = maxOf(best, (v - prev) / dt)
        }
        tsPrev = HashMap(stats); tsPrevAt = now
        if (cand.isNotEmpty()) {
            fpsDbg = "$pkg | timestats ${cand.size} layer, ${stats.size} total"
            return best.toInt() to 0
        }
        val lat = fpsLatency()
        fpsDbg = "timestats: $pkg tidak ada (${stats.size} layer) -> latency: $fpsDbg"
        return lat
    }

    /** Suhu dari thermal HAL: CPU, lalu SoC, skin, baterai. */
    private fun thermal(): Pair<String, Float>? {
        val out = Shell.exec("dumpsys thermalservice")
        val i = out.indexOf("Current temperatures from HAL")
        if (i < 0) return null
        val temps = ArrayList<Triple<Int, String, Float>>()
        for (l in out.substring(i).lines().drop(1)) {
            val t = l.trim()
            if (!t.startsWith("Temperature{")) { if (temps.isNotEmpty()) break else continue }
            val v = Regex("mValue\\s*=\\s*(-?[0-9.]+)").find(t)?.groupValues?.get(1)?.toFloatOrNull() ?: continue
            val ty = Regex("mType\\s*=\\s*(\\d+)").find(t)?.groupValues?.get(1)?.toIntOrNull() ?: -1
            val nm = Regex("mName\\s*=\\s*([^\\s,}]+)").find(t)?.groupValues?.get(1) ?: "?"
            if (v in 1f..150f) temps.add(Triple(ty, nm, v))
        }
        for (type in intArrayOf(0, 13, 3, 2)) {      // CPU, SOC, SKIN, BATTERY
            temps.filter { it.first == type }.maxByOrNull { it.third }?.let { return "${it.second} (tipe $type)" to it.third }
        }
        return temps.maxByOrNull { it.third }?.let { "${it.second} (tipe ${it.first})" to it.third }
    }

    /** FPS dari SurfaceFlinger latency layer aplikasi yang sedang fokus. Return (fps, 1% low). */
    private fun fpsLatency(): Pair<Int, Int> {
        val pkg = focusPkg()
        if (pkg == null) { fpsDbg = "aplikasi fokus tidak terbaca"; return 0 to 0 }
        val all = Shell.exec("dumpsys SurfaceFlinger --list").lines().map { it.trim() }
            .filter { it.contains(pkg) && !it.startsWith("Background") }
        if (all.isEmpty()) { fpsDbg = "$pkg: layer tidak ditemukan"; return 0 to 0 }
        val ordered = all.sortedByDescending { (if (it.contains("SurfaceView")) 2 else 0) + (if (it.contains("BLAST")) 1 else 0) }
        for (layer in ordered.take(4)) {
            val rows = Shell.exec("dumpsys SurfaceFlinger --latency '$layer'").lines().drop(1)
                .map { it.trim().split(Regex("\\s+")) }
            for (col in intArrayOf(1, 2)) {
                val ts = rows.mapNotNull { it.getOrNull(col)?.toLongOrNull() }
                    .filter { it in 1 until Long.MAX_VALUE / 2 }.sorted()
                if (ts.size < 3) continue
                val recent = ts.filter { it >= ts.last() - 1_000_000_000L }
                if (recent.size < 2 || recent.last() == recent.first()) continue
                val fps = ((recent.size - 1) * 1e9 / (recent.last() - recent.first())).toInt()
                val deltas = ts.zipWithNext { a, b -> b - a }.filter { it > 0 }.sortedDescending()
                if (deltas.isEmpty()) continue
                val worst = deltas[(deltas.size / 100).coerceAtMost(deltas.size - 1)]
                fpsDbg = "$pkg | ${layer.take(36)} | ${ts.size} frame, kolom $col"
                return fps to (1e9 / worst).toInt()
            }
        }
        fpsDbg = "$pkg: ${ordered.size} layer, data latency kosong"
        return 0 to 0
    }
}
