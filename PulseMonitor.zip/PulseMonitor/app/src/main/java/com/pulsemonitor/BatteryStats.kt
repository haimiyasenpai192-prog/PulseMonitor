package com.pulsemonitor

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.PowerManager
import android.os.SystemClock

/** Teks siap pakai untuk notifikasi. Contoh: "Discharging", "44% • 543 mA (2,0 W) • 38°C", "Active: 4,2%/h • Idle: 19,1%/h". */
class BatteryInfo(
    val status: String, val line2: String, val line3: String, val line4: String = "",
    // Data terstruktur untuk tampilan notifikasi kustom
    val pct: Int = -1, val current: String = "-", val power: String = "-", val temp: String = "-",
    val activeRate: String = "-", val idleRate: String = "-",
    val screenOn: String = "-", val screenOnDetail: String = "-",
    val screenOff: String = "-", val screenOffDetail: String = "-",
    val deep: String = "-", val awake: String = "-"
)

/**
 * Statistik baterai untuk notifikasi: status, persen, arus (mA) + daya (W), suhu, dan laju kuras per jam.
 * Active = layar menyala, Idle = layar mati. Dihitung sejak dicabut dari charger (sesi discharge),
 * dan tetap ditampilkan selama mengisi daya sampai sesi berikutnya dimulai.
 * Bila HP melaporkan charge counter, selisihnya dipakai agar laju lebih halus dari persen bulat.
 */
object BatteryStats {
    private const val MIN_MS = 120_000L     // di bawah 2 menit data terlalu sedikit, tampil "-"

    private var ctx: Context? = null
    private var screenOn = true
    private var lastAt = 0L
    private var lastP = Double.NaN
    private var lastUseC = false
    private var capUah = 0.0                // perkiraan kapasitas (satuan sama dengan charge counter)
    private var wasDischarging: Boolean? = null
    private var actMs = 0L; private var idleMs = 0L
    private var actDrop = 0.0; private var idleDrop = 0.0
    private var savedAt = 0L
    // Rincian sesi: muatan terpakai (µAh dari charge counter) per keadaan layar, dan pembagian layar mati: deep sleep vs awake
    private var actUah = 0.0; private var idleUah = 0.0
    private var offDeepMs = 0L; private var offAwakeMs = 0L
    private var lastCnt = 0L; private var lastU = 0L

    private fun prefs() = ctx!!.getSharedPreferences("battery_stats", Context.MODE_PRIVATE)

    @Synchronized fun init(c: Context) {
        if (ctx != null) return
        ctx = c.applicationContext
        screenOn = runCatching { ctx!!.getSystemService(PowerManager::class.java).isInteractive }.getOrDefault(true)
        val p = prefs()
        actMs = p.getLong("actMs", 0); idleMs = p.getLong("idleMs", 0)
        actDrop = p.getFloat("actDrop", 0f).toDouble(); idleDrop = p.getFloat("idleDrop", 0f).toDouble()
        capUah = p.getFloat("cap", 0f).toDouble()
        actUah = p.getLong("actUah", 0).toDouble(); idleUah = p.getLong("idleUah", 0).toDouble()
        offDeepMs = p.getLong("offDeep", 0); offAwakeMs = p.getLong("offAwake", 0)
        lastAt = SystemClock.elapsedRealtime(); lastU = SystemClock.uptimeMillis()
    }

    // ---------- Suhu baterai segar ----------
    // Broadcast BATTERY_CHANGED di banyak HP baru terbarui tiap puluhan detik, jadi suhu di notifikasi tertinggal dari
    // aplikasi yang membaca file sistem langsung (mis. DevCheck). Di sini file suhu dibaca langsung; bila tidak boleh
    // dibaca aplikasi biasa, dibaca lewat Shizuku/root di thread terpisah (hasilnya dipakai pada pembacaan berikutnya).
    private const val TEMP_PATH = "/sys/class/power_supply/battery/temp"
    @Volatile private var sysTemp = -1f
    private var sysTempAt = 0L
    private var sysTempBusy = false
    private var directTempOk = true

    private fun tempFromRaw(raw: Int): Float {
        val v = when { raw >= 1000 -> raw / 1000f; raw > 150 -> raw / 10f; else -> raw.toFloat() }
        return Math.floor(v.toDouble()).toFloat().takeIf { it in 1f..100f } ?: -1f   // dipotong ke bawah, sama seperti sebelumnya
    }

    /** Suhu baterai terbaru (°C, dipotong ke bawah), atau -1 bila file sistem tidak terbaca. */
    fun freshTemp(): Float {
        if (directTempOk) {
            val raw = runCatching { java.io.File(TEMP_PATH).readText().trim().toInt() }.getOrNull()
            if (raw != null) return tempFromRaw(raw) else directTempOk = false
        }
        val now = SystemClock.elapsedRealtime()
        if (!sysTempBusy && now - sysTempAt >= 2000L && runCatching { Shell.mode() }.getOrDefault("-") != "-") {
            sysTempBusy = true; sysTempAt = now
            Thread {
                try { Shell.exec("cat $TEMP_PATH").trim().toIntOrNull()?.let { sysTemp = tempFromRaw(it) } }
                catch (_: Throwable) {} finally { sysTempBusy = false }
            }.start()
        }
        return sysTemp
    }

    @Synchronized fun isScreenOn() = screenOn

    /** Dipanggil saat layar menyala/mati: selisih sampai saat ini dicatat ke keadaan lama dulu. */
    @Synchronized fun setScreen(on: Boolean) { tick(); screenOn = on }

    private fun rate(ms: Long, drop: Double): String =
        if (ms < MIN_MS) "-" else "%.1f%%/j".format(maxOf(0.0, drop) / (ms / 3_600_000.0))

    @Synchronized fun tick(): BatteryInfo? {
        val c = ctx ?: return null
        val i = runCatching { c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) }.getOrNull() ?: return null
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1); val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val pct = if (level >= 0 && scale > 0) Math.round(level * 100f / scale) else -1
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_UNKNOWN)
        val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        val mv = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
        val tRaw = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        // Dipotong ke bawah (39,6 -> 39), bukan dibulatkan, supaya sama dengan DevCheck
        val tIntent = if (tRaw != Int.MIN_VALUE) (tRaw / 10).toFloat() else -1f
        val temp = freshTemp().takeIf { it > 0f } ?: tIntent     // file sistem (segar) dulu, broadcast sebagai cadangan
        val bm = c.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager

        val status = if (!plugged) "Tidak mengisi daya" else when (st) {
            BatteryManager.BATTERY_STATUS_CHARGING -> "Mengisi daya"
            BatteryManager.BATTERY_STATUS_FULL -> "Penuh"
            else -> "Terhubung, tidak mengisi"
        }
        val discharging = !plugged
        val now = SystemClock.elapsedRealtime()

        if (discharging) {
            if (wasDischarging == false) {      // baru dicabut dari charger: mulai sesi baru
                actMs = 0; idleMs = 0; actDrop = 0.0; idleDrop = 0.0; capUah = 0.0; lastP = Double.NaN
                actUah = 0.0; idleUah = 0.0; offDeepMs = 0; offAwakeMs = 0
            }
            val up = SystemClock.uptimeMillis()
            if (wasDischarging != true) { lastAt = now; lastU = up }
            val cnt = runCatching { bm?.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER) }.getOrNull() ?: 0L
            val useC = cnt > 0L && cnt != Long.MIN_VALUE && pct in 3..100
            if (useC && capUah <= 0.0) capUah = cnt * 100.0 / pct
            val p = if (useC && capUah > 0.0) cnt * 100.0 / capUah else pct.toDouble()
            if (pct >= 0) {
                // mode (counter / persen bulat) berubah di tengah jalan: lewati selisih agar tidak melonjak
                if (!lastP.isNaN() && lastUseC == useC) {
                    val dt = now - lastAt; val d = lastP - p
                    val dc = if (useC && lastCnt > 0L) (lastCnt - cnt).toDouble() else 0.0
                    val du = (up - lastU).coerceIn(0L, maxOf(0L, dt))
                    if (screenOn) { actMs += dt; actDrop += d; actUah += dc }
                    else {
                        idleMs += dt; idleDrop += d; idleUah += dc
                        offAwakeMs += du; offDeepMs += dt - du     // uptime = terjaga; sisanya deep sleep
                    }
                }
                lastP = p; lastUseC = useC; lastCnt = cnt
            }
            lastAt = now; lastU = up
        } else lastP = Double.NaN
        wasDischarging = discharging

        if (now - savedAt > 60_000L) {
            savedAt = now
            prefs().edit().putLong("actMs", actMs).putLong("idleMs", idleMs)
                .putFloat("actDrop", actDrop.toFloat()).putFloat("idleDrop", idleDrop.toFloat()).putFloat("cap", capUah.toFloat())
                .putLong("actUah", actUah.toLong()).putLong("idleUah", idleUah.toLong())
                .putLong("offDeep", offDeepMs).putLong("offAwake", offAwakeMs).apply()
        }

        // Arus: satuan beda antar HP (µA atau mA), ditebak dari besarnya; tanda (+/-) diabaikan
        val raw = runCatching { bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) }.getOrNull() ?: 0
        val parts = ArrayList<String>()
        var curTxt = "-"; var wTxt = "-"
        if (pct >= 0) parts.add("$pct%")
        if (raw != 0 && raw != Int.MIN_VALUE) {
            val a = Math.abs(raw.toLong())
            val mA = if (a > 20_000L) a / 1000f else a.toFloat()
            curTxt = "%.0f mA".format(mA)
            if (mv > 0) wTxt = "%.1f W".format(mA / 1000f * mv / 1000f)
            parts.add(if (mv > 0) "%.0f mA (%.1f W)".format(mA, mA / 1000f * mv / 1000f) else "%.0f mA".format(mA))
        }
        if (temp in 1f..100f) parts.add("%.0f°C".format(temp))
        // Riwayat baterai (grafik level / daya / suhu + pemakaian per aplikasi), lihat BatteryHistory
        runCatching {
            val wF = if (raw != 0 && raw != Int.MIN_VALUE && mv > 0) {
                val a = Math.abs(raw.toLong()); val mA = if (a > 20_000L) a / 1000f else a.toFloat()
                mA / 1000f * mv / 1000f
            } else -1f
            BatteryHistory.onSample(c, plugged, pct, wF, if (temp in 1f..100f) temp else -1f)
        }
        val line2 = if (parts.isEmpty()) "-" else parts.joinToString(" • ")
        val line3 = "Aktif: ${rate(actMs, actDrop)} • Diam: ${rate(idleMs, idleDrop)}"
        // Rincian ala RedFox Prism: Screen On / Screen Off (waktu, persen terpakai, mAh), lalu Deep sleep / Awake saat layar mati
        fun dur(ms: Long): String {
            val t = ms / 1000; val h = t / 3600; val m = (t % 3600) / 60; val sec = t % 60
            return if (h > 0) "${h}j ${m}m ${sec}d" else "${m}m ${sec}d"
        }
        fun seg(label: String, ms: Long, drop: Double, uah: Double): String {
            val mah = if (capUah > 0.0) " (%.0f mAh)".format(maxOf(0.0, uah) / 1000.0) else ""
            return "$label: ${dur(ms)} • %.1f%%$mah".format(maxOf(0.0, drop))
        }
        val offTot = offDeepMs + offAwakeMs
        val deepPct = if (offTot > 0) 100.0 * offDeepMs / offTot else 0.0
        val line4 = listOf(
            seg("Layar Nyala", actMs, actDrop, actUah),
            seg("Layar Mati", idleMs, idleDrop, idleUah),
            "Tidur lelap: ${dur(offDeepMs)} • %.1f%%".format(deepPct),
            "Terjaga: ${dur(offAwakeMs)} • %.1f%%".format(if (offTot > 0) 100.0 - deepPct else 0.0)
        ).joinToString("\n")
        fun detail(drop: Double, uah: Double): String {
            val mah = if (capUah > 0.0) " • %.0f mAh".format(maxOf(0.0, uah) / 1000.0) else ""
            return "%.1f%%$mah".format(maxOf(0.0, drop))
        }
        return BatteryInfo(status, line2, line3, line4,
            pct = pct, current = curTxt, power = wTxt,
            temp = if (temp in 1f..100f) "%.0f°C".format(temp) else "-",
            activeRate = rate(actMs, actDrop), idleRate = rate(idleMs, idleDrop),
            screenOn = dur(actMs), screenOnDetail = detail(actDrop, actUah),
            screenOff = dur(idleMs), screenOffDetail = detail(idleDrop, idleUah),
            deep = dur(offDeepMs), awake = dur(offAwakeMs))
    }
}
