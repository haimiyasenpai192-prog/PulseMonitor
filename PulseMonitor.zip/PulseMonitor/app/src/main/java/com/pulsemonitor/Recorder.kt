package com.pulsemonitor

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Satu sesi rekaman. Semua list sama panjang: satu nilai per sampel (kira-kira per detik). Nilai -1 = tidak terbaca. */
class Session(
    val id: Long, val pkg: String, val label: String, val res: String, var desc: String,
    val t: List<Float>, val fps: List<Float>, val cpu: List<Float>, val gpu: List<Float>, val ram: List<Float>,
    val tCpu: List<Float>, val tGpu: List<Float>, val tBat: List<Float>, val watt: List<Float>,
    val tSkin: List<Float> = emptyList(),   // suhu HP (sensor skin); kosong pada rekaman lama
    val clusters: List<Int> = emptyList(),   // inti pertama tiap cluster CPU (mis. 0, 4, 7); kosong pada rekaman lama
    val clCpu: List<List<Float>> = emptyList(),   // beban CPU (%) per cluster, urut sama dengan clusters
    val clFreq: List<List<Float>> = emptyList(),   // frekuensi CPU (MHz) per cluster, urut sama dengan clusters; kosong pada rekaman lama
    val gpuMhz: List<Float> = emptyList(),   // frekuensi GPU (MHz)
    val appMb: List<Float> = emptyList(),    // memori proses game (MB)
    val ramMb: List<Float> = emptyList(),    // RAM perangkat terpakai (MB)
    val swapMb: List<Float> = emptyList(),   // swap / ZRAM terpakai (MB)
    val batLvl: List<Float> = emptyList(),   // level baterai (%)
    // Dari timestamp frame asli (--latency); kosong pada rekaman lama / bila tidak terbaca
    val fN: List<Float> = emptyList(),       // jumlah frame per sampel
    val fMax: List<Float> = emptyList(),     // frametime terburuk per sampel (ms)
    val jank: List<Float> = emptyList(),     // jumlah Jank per sampel
    val bigJank: List<Float> = emptyList(),  // jumlah BigJank per sampel
    val fTop: List<List<Float>> = emptyList() // frametime terburuk (ms, maks 12) per sampel, untuk 5% / 1% low sungguhan
) {
    val n: Int get() = fps.size
    /** Potongan " · 1920x886" untuk header laporan; kosong bila resolusi game tidak terbaca. */
    val resPart: String get() = if (res.isBlank()) "" else "  ·  $res"
    /** Suhu HP per sampel: sensor skin; bila tidak terbaca pakai suhu baterai (sensor terdekat ke badan HP). */
    val phoneTemp: List<Float> get() = List(n) { i ->
        val sk = tSkin.getOrElse(i) { -1f }; if (sk >= 0f) sk else tBat[i]
    }
    val dur: Int get() = (t.lastOrNull() ?: 0f).roundToInt()
    /** Suhu tunggal untuk grafik FPS: suhu baterai. */
    val temp: List<Float> get() = List(n) { i -> tBat[i] }
}

class Stats(
    val max: Float, val min: Float, val avg: Float, val sd: Float, val smooth: Float, val low5: Float,
    val maxTemp: Float, val avgWatt: Float,
    val low1: Float = 0f, val ftAvg: Float = 0f, val ftMax: Float = 0f, val drops: Int = 0, val energyMwh: Float = -1f,
    val jank: Int = 0, val bigJank: Int = 0, val frameBased: Boolean = false   // frameBased: low5 / low1 / ftMax dari frame asli
)

/** Ringkasan dari frame asli. null bila datanya tidak cukup / tidak menutupi rekaman (lalu dipakai hitungan lama dari FPS per detik). */
class FrameLows(val low5: Float, val low1: Float, val maxMs: Float, val jank: Int, val bigJank: Int, val frames: Int)

/**
 * 5% / 1% low = 1000 / rata-rata frametime dari 5% / 1% frame TERBURUK di seluruh rekaman (definisi PerfDog),
 * bukan rata-rata FPS per detik. Dipakai hanya bila jumlah frame terbaca >= 70% dari yang diharapkan dari FPS rekaman,
 * supaya frame yang terlewat (buffer latency penuh di > 120 FPS) tidak membuat angkanya menyesatkan.
 */
fun Session.frameLows(): FrameLows? {
    val total = fN.filter { it > 0f }.sum().toInt()
    val expected = fps.filter { it > 0f }.sum()
    if (total < 60 || total < expected * 0.7f) return null
    val top = fTop.flatten().sortedDescending()
    if (top.isEmpty()) return null
    fun low(pct: Int): Float {
        val k = maxOf(1, total * pct / 100).coerceAtMost(top.size)
        val ms = top.take(k).average().toFloat()
        return if (ms > 0f) 1000f / ms else 0f
    }
    return FrameLows(low(5), low(1), top.first(), jank.filter { it > 0f }.sum().toInt(), bigJank.filter { it > 0f }.sum().toInt(), total)
}

fun Session.stats(): Stats {
    // despike(): lonjakan satu sampel (glitch baca di awal rekaman / dumpsys telat) tidak boleh jadi MAKS 100 / MIN 0,8 dan frametime 1250 ms.
    // Penurunan FPS yang bertahan >= 2 sampel tetap terhitung sebagai lag sungguhan.
    val f = capFps(fps).despike().filter { it > 0f }
    if (f.isEmpty()) return Stats(0f, 0f, 0f, 0f, 0f, 0f, -1f, -1f)
    val avg = f.average().toFloat()
    val sd = sqrt(f.map { (it - avg) * (it - avg) }.average()).toFloat()
    val sorted = f.sorted(); val k = maxOf(1, sorted.size * 5 / 100)
    val low = sorted.take(k).average().toFloat()
    val smooth = if (avg > 0f) (100f * (1f - sd / avg)).coerceIn(0f, 100f) else 0f
    val mt = phoneTemp.despike().filter { it >= 0f }.maxOrNull() ?: -1f
    val low1 = sorted.take(maxOf(1, sorted.size / 100)).average().toFloat()
    val fts = f.map { 1000f / it }
    val w = watt.avgValid()
    val energy = if (w >= 0f) w * dur / 3.6f else -1f   // mWh = W x detik / 3,6
    val fl = frameLows()
    return Stats(f.maxOrNull() ?: 0f, f.minOrNull() ?: 0f, avg, sd, smooth, fl?.low5 ?: low, mt, w,
        low1 = fl?.low1 ?: low1, ftAvg = fts.average().toFloat(), ftMax = fl?.maxMs ?: (fts.maxOrNull() ?: 0f),
        drops = f.count { it < avg * 0.7f }, energyMwh = energy,
        jank = fl?.jank ?: 0, bigJank = fl?.bigJank ?: 0, frameBased = fl != null)
}

/** Batas atas FPS dari rekaman itu sendiri: game yang di-cap 60 tidak mungkin tampil 100. Batas = persentil 90 x 1,05 (game 60 -> ~63).
 *  Hanya MEMOTONG nilai yang melewati batas; FPS yang turun (loading / lag sungguhan) tidak disentuh. Nilai < 0 dibiarkan. */
fun capFps(v: List<Float>): List<Float> {
    val ok = v.filter { it > 0f }.sorted()
    if (ok.size < 10) return v
    val cap = ok[((ok.size - 1) * 0.9f).toInt()] * 1.05f
    return v.map { if (it > cap) cap else it }
}

/** Buang lonjakan satu sampel (glitch sensor): tiap titik diganti median tiga titik di sekitarnya; ujung memakai yang lebih kecil dari dua titik. */
fun List<Float>.despike(): List<Float> = when {
    size < 3 -> this
    else -> List(size) { i ->
        when (i) {
            0 -> minOf(this[0], this[1]).let { if (this[1] < 0f) this[0] else it }
            size - 1 -> minOf(this[i], this[i - 1]).let { if (this[i - 1] < 0f) this[i] else it }
            else -> listOf(this[i - 1], this[i], this[i + 1]).sorted()[1]
        }
    }
}

fun List<Float>.avgValid(): Float { val v = filter { it >= 0f }; return if (v.isEmpty()) -1f else v.average().toFloat() }
fun List<Float>.maxValid(): Float = filter { it >= 0f }.maxOrNull() ?: -1f
fun fmtDur(sec: Int) = "%d:%02d".format(sec / 60, sec % 60)
fun fmtDate(ms: Long): String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(ms))
fun f1(x: Float) = "%.1f".format(x)

/** Merekam Snap dari Sampler. Disimpan sebagai JSON di filesDir/records. */
object Recorder {
    val active = MutableStateFlow(false)
    val count = MutableStateFlow(0)       // jumlah sampel yang sudah terekam
    val version = MutableStateFlow(0)     // naik tiap ada rekaman baru/dihapus, supaya daftar dimuat ulang
    private val buf = ArrayList<Snap>()
    private val ts = ArrayList<Long>()
    private var stopping = false
    /** Alasan stop() terakhir mengembalikan null; ditampilkan di toast supaya mudah didiagnosis. */
    @Volatile var lastFail = ""
    private val resCount = HashMap<String, Int>()   // resolusi render game -> jumlah pembacaan

    /** Dipanggil Sampler: resolusi render game yang terbaca saat merekam. */
    @Synchronized fun onRes(w: Int, h: Int) {
        if (!active.value || stopping) return
        val k = "${w}x$h"; resCount[k] = (resCount[k] ?: 0) + 1
    }

    /** Sudah ada pembacaan resolusi game di rekaman ini? */
    @Synchronized fun hasRes() = resCount.isNotEmpty()

    @Synchronized fun start() {
        if (active.value) return
        buf.clear(); ts.clear(); resCount.clear(); count.value = 0; stopping = false; active.value = true
    }

    /** Dipanggil Sampler tiap tick. */
    @Synchronized fun onSample(s: Snap) {
        if (!active.value || stopping) return
        buf.add(s); ts.add(System.currentTimeMillis()); count.value = buf.size
    }

    /** Hentikan dan simpan. Null bila tidak ada data FPS. Panggil dari thread latar (menulis file). */
    fun stop(ctx: Context): Session? {
        var data: List<Snap> = emptyList(); var times: List<Long> = emptyList(); var gameRes: String? = null
        synchronized(this) {
            if (!active.value || stopping) { lastFail = "rekaman tidak aktif / sedang berhenti"; return null }
            stopping = true; data = ArrayList(buf); times = ArrayList(ts)
            gameRes = resCount.maxByOrNull { it.value }?.key
        }
        try {
            val first0 = data.indexOfFirst { it.fpsRaw > 0 }; val last = data.indexOfLast { it.fpsRaw > 0 }
            if (first0 < 0) { lastFail = "${data.size} sampel, tidak ada FPS terbaca | ${Sampler.fpsDiag()}"; return null }
            // Semua sampel dipakai sejak FPS pertama terbaca: rekaman langsung jalan, tanpa membuang detik awal.
            val first = first0
            val d = data.subList(first, last + 1); val tt = times.subList(first, last + 1)
            val own = ctx.packageName
            fun top(l: List<Snap>) = l.filter { !Sampler.isIgnoredPkg(it.pkg, own) }
                .groupingBy { it.pkg }.eachCount().maxByOrNull { it.value }?.key
            // Nama game: paket terbanyak di sampel ber-FPS; bila kosong, seluruh sampel; bila masih kosong, app terakhir di depan
            val pkg = top(d.filter { it.fpsRaw > 0 }) ?: top(data)
                ?: Sampler.lastGamePkg().takeIf { !Sampler.isIgnoredPkg(it, own) } ?: ""
            val label = if (pkg.isEmpty()) "Rekaman" else runCatching {
                val pm = ctx.packageManager; pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
            }.getOrDefault(pkg)
            // Resolusi game = ukuran buffer layer game di SurfaceFlinger (resolusi render), BUKAN ukuran layar HP.
            // Urutan: pembacaan terbanyak selama rekaman -> baca ulang sekarang -> cache terakhir -> GameUserSettings.ini.
            // GameUserSettings.ini hanya dipakai bila ukurannya BEDA dari layar HP (game Unreal Engine sering menulis
            // ukuran layar HP di file itu). Ukuran layar HP tidak lagi dipakai sebagai cadangan: bila resolusi game
            // tidak terbaca, kolom resolusi dikosongkan daripada menampilkan resolusi layar yang menyesatkan.
            fun fmt(p: Pair<Int, Int>) = "${maxOf(p.first, p.second)}x${minOf(p.first, p.second)}"
            val scr = Sampler.realScreenRes()?.let { fmt(it) }
            val res = gameRes
                ?: Sampler.readResNow(pkg)?.let { fmt(it) }
                ?: Sampler.cachedRes(pkg)?.let { fmt(it) }
                ?: Sampler.iniRes(pkg)?.let { fmt(it) }?.takeIf { it != scr }
                ?: ""
            val cids = d.flatMap { sn -> sn.clusterCpu.map { it.first } }.distinct().sorted()
            val s = Session(
                id = System.currentTimeMillis(), pkg = pkg, label = label, res = res, desc = "",
                t = tt.map { (it - tt[0]) / 1000f }, fps = d.map { if (it.fpsRawF > 0f) it.fpsRawF else it.fpsRaw.toFloat() },
                cpu = d.map { it.cpu.toFloat() }, gpu = d.map { it.gpu.toFloat() }, ram = d.map { it.ramPct.toFloat() },
                tCpu = d.map { it.tCpu }, tGpu = d.map { it.tGpu }, tBat = d.map { it.tBat }, watt = d.map { it.watt }, tSkin = d.map { it.tSkin },
                clusters = cids,
                clCpu = cids.map { id -> d.map { sn -> sn.clusterCpu.firstOrNull { it.first == id }?.second?.toFloat() ?: -1f } },
                // Frekuensi cluster = yang tertinggi di antara inti-intinya (inti pertama bisa saja mati), -1 bila tidak terbaca
                clFreq = cids.mapIndexed { ci, id ->
                    val end = cids.getOrElse(ci + 1) { Int.MAX_VALUE }
                    d.map { sn -> sn.coreMhz.withIndex().filter { it.index in id until end && it.value > 0 }.maxOfOrNull { it.value }?.toFloat() ?: -1f }
                }.takeIf { fr -> fr.any { l -> l.any { it >= 0f } } } ?: emptyList(),
                gpuMhz = d.map { it.gpuMhz.toFloat() },
                appMb = d.map { it.appMb },
                ramMb = d.map { sn -> sn.mem?.let { it.ramUsed * 1000f } ?: -1f },
                swapMb = d.map { sn -> sn.mem?.takeIf { it.swapTotal > 0f }?.let { it.swapUsed * 1000f } ?: -1f },
                batLvl = d.map { it.batPct.toFloat() },
                fN = d.map { it.ftN.toFloat() }, fMax = d.map { it.ftMaxMs }, jank = d.map { it.jank.toFloat() },
                bigJank = d.map { it.bigJank.toFloat() }, fTop = d.map { it.ftTop }
            )
            // Ringkasan frametime ke log: mentah vs setelah dibersihkan, supaya kelihatan kalau grafik "terlalu bagus" karena glitch dibuang
            runCatching {
                val raw = s.fps.filter { it > 0f }
                if (raw.isNotEmpty()) {
                    val cl = capFps(s.fps).despike().filter { it > 0f }
                    AppLog.i("FT-RINGKAS", "${s.label} ${s.dur}s | mentah: FPS %.1f-%.1f, ft maks %.0f ms | bersih: FPS %.1f-%.1f, ft maks %.0f ms | sampel dibuang/dipotong: %d".format(
                        raw.min(), raw.max(), 1000f / raw.min(), cl.min(), cl.max(), 1000f / cl.min(),
                        s.fps.zip(capFps(s.fps).despike()).count { (a, b) -> a > 0f && Math.abs(a - b) > 0.05f }))
                }
            }
            save(ctx, s)
            return s
        } finally {
            synchronized(this) { stopping = false; active.value = false; buf.clear(); ts.clear(); resCount.clear(); count.value = 0 }
            version.value = version.value + 1
        }
    }

    private fun dir(c: Context) = File(c.filesDir, "records").also { it.mkdirs() }

    private fun arr(l: List<Float>) = JSONArray().also { a -> l.forEach { a.put(Math.round(it * 10f) / 10.0) } }

    private fun toJson(s: Session) = JSONObject().apply {
        put("id", s.id); put("pkg", s.pkg); put("label", s.label); put("res", s.res); put("desc", s.desc)
        put("t", arr(s.t)); put("fps", arr(s.fps)); put("cpu", arr(s.cpu)); put("gpu", arr(s.gpu)); put("ram", arr(s.ram))
        put("tCpu", arr(s.tCpu)); put("tGpu", arr(s.tGpu)); put("tBat", arr(s.tBat)); put("tSkin", arr(s.tSkin)); put("watt", arr(s.watt))
        put("clusters", JSONArray().also { a -> s.clusters.forEach { a.put(it) } })
        put("clCpu", JSONArray().also { a -> s.clCpu.forEach { a.put(arr(it)) } })
        put("clFreq", JSONArray().also { a -> s.clFreq.forEach { a.put(arr(it)) } })
        put("gpuMhz", arr(s.gpuMhz)); put("appMb", arr(s.appMb)); put("ramMb", arr(s.ramMb)); put("swapMb", arr(s.swapMb)); put("batLvl", arr(s.batLvl))
        put("fN", arr(s.fN)); put("fMax", arr(s.fMax)); put("jank", arr(s.jank)); put("bigJank", arr(s.bigJank))
        put("fTop", JSONArray().also { a -> s.fTop.forEach { a.put(arr(it)) } })
    }

    private fun floats(o: JSONObject, k: String): List<Float> {
        val a = o.optJSONArray(k) ?: return emptyList()
        return List(a.length()) { a.optDouble(it, -1.0).toFloat() }
    }

    /** Samakan panjang list dengan jumlah sampel FPS. Rekaman lama / berkas rusak yang kurang kolom tidak lagi bikin crash atau CSV gagal. */
    private fun fit(l: List<Float>, n: Int, fill: Float) = if (l.size >= n) l.take(n) else l + List(n - l.size) { fill }

    private fun parse(txt: String): Session {
        val o = JSONObject(txt)
        val fps = floats(o, "fps"); val n = fps.size
        val t = floats(o, "t").let { if (it.size >= n) it.take(n) else it + List(n - it.size) { i -> (it.size + i).toFloat() } }
        return Session(
            o.getLong("id"), o.optString("pkg"), o.optString("label"), o.optString("res"), o.optString("desc"),
            t, fps, fit(floats(o, "cpu"), n, -1f), fit(floats(o, "gpu"), n, -1f), fit(floats(o, "ram"), n, -1f),
            fit(floats(o, "tCpu"), n, -1f), fit(floats(o, "tGpu"), n, -1f), fit(floats(o, "tBat"), n, -1f), fit(floats(o, "watt"), n, -1f),
            fit(floats(o, "tSkin"), n, -1f),
            clusters = o.optJSONArray("clusters")?.let { a -> List(a.length()) { a.optInt(it, 0) } } ?: emptyList(),
            clCpu = o.optJSONArray("clCpu")?.let { a ->
                List(a.length()) { k -> a.optJSONArray(k)?.let { b -> fit(List(b.length()) { b.optDouble(it, -1.0).toFloat() }, n, -1f) } ?: List(n) { -1f } }
            } ?: emptyList(),
            clFreq = o.optJSONArray("clFreq")?.let { a ->
                List(a.length()) { k -> a.optJSONArray(k)?.let { b -> fit(List(b.length()) { b.optDouble(it, -1.0).toFloat() }, n, -1f) } ?: List(n) { -1f } }
            } ?: emptyList(),
            gpuMhz = opt(o, "gpuMhz", n), appMb = opt(o, "appMb", n), ramMb = opt(o, "ramMb", n), swapMb = opt(o, "swapMb", n), batLvl = opt(o, "batLvl", n),
            fN = opt(o, "fN", n), fMax = opt(o, "fMax", n), jank = opt(o, "jank", n), bigJank = opt(o, "bigJank", n),
            fTop = o.optJSONArray("fTop")?.let { a ->
                List(a.length()) { k -> a.optJSONArray(k)?.let { b -> List(b.length()) { b.optDouble(it, 0.0).toFloat() } } ?: emptyList() }
            } ?: emptyList()
        )
    }

    /** Kolom opsional: kosong bila rekaman lama tidak punya kolom itu. */
    private fun opt(o: JSONObject, k: String, n: Int): List<Float> = floats(o, k).let { if (it.isEmpty()) it else fit(it, n, -1f) }

    fun save(c: Context, s: Session) {
        val f = File(dir(c), "${s.id}.json"); val tmp = File(dir(c), "${s.id}.tmp")
        tmp.writeText(toJson(s).toString())
        if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f) }
    }

    fun saveDesc(c: Context, s: Session, text: String) { s.desc = text; runCatching { save(c, s) } }

    fun load(c: Context, id: Long): Session? = runCatching { parse(File(dir(c), "$id.json").readText()) }.getOrNull()

    fun list(c: Context): List<Session> =
        dir(c).listFiles { f -> f.extension == "json" }?.mapNotNull { f -> runCatching { parse(f.readText()) }.getOrNull() }
            ?.sortedByDescending { it.id } ?: emptyList()

    fun delete(c: Context, id: Long) { File(dir(c), "$id.json").delete(); version.value = version.value + 1 }

    fun csv(s: Session): String {
        val sb = StringBuilder("time_s,fps,frametime_ms,cpu_pct,gpu_pct,ram_pct,temp_cpu,temp_gpu,temp_bat,temp_hp,power_w" +
            s.clusters.joinToString("") { ",cpu_cluster$it" } +
            (if (s.clFreq.isNotEmpty()) s.clusters.joinToString("") { ",freq_cluster${it}_mhz" } else "") +
            csvExtra(s).joinToString("") { "," + it.first } + "\n")
        for (i in 0 until s.n) {
            val f = s.fps[i]
            sb.append("%.1f,%.1f,%.1f,%.0f,%.0f,%.0f,%.1f,%.1f,%.1f,%.1f,%.2f\n".format(
                Locale.US, s.t[i], f, if (f > 0f) 1000f / f else 0f, s.cpu[i], s.gpu[i], s.ram[i],
                s.tCpu[i], s.tGpu[i], s.tBat[i], s.phoneTemp[i], s.watt[i]))
            sb.setLength(sb.length - 1)
            s.clCpu.forEach { sb.append(",%.0f".format(Locale.US, it.getOrElse(i) { -1f })) }
            s.clFreq.forEach { sb.append(",%.0f".format(Locale.US, it.getOrElse(i) { -1f })) }
            csvExtra(s).forEach { sb.append(",%.0f".format(Locale.US, it.second.getOrElse(i) { -1f })) }
            sb.append('\n')
        }
        return sb.toString()
    }

    private fun csvExtra(s: Session) = listOf("gpu_mhz" to s.gpuMhz, "app_mb" to s.appMb, "ram_mb" to s.ramMb, "swap_mb" to s.swapMb, "battery_pct" to s.batLvl,
        "frame_max_ms" to s.fMax, "jank" to s.jank, "big_jank" to s.bigJank)
        .filter { it.second.isNotEmpty() }

    /** Simpan CSV ke folder Download (MediaStore, tanpa izin storage). */
    fun exportCsv(c: Context, s: Session): Boolean = runCatching {
        val safe = s.label.replace(Regex("[^A-Za-z0-9]+"), "_")
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date(s.id))
        val cv = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, "PulseMonitor_${safe}_$stamp.csv")
            put(MediaStore.Downloads.MIME_TYPE, "text/csv")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val uri = c.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)!!
        c.contentResolver.openOutputStream(uri)!!.use { it.write(csv(s).toByteArray()) }
    }.isSuccess

    fun summary(s: Session): String {
        val st = s.stats()
        return buildString {
            append("Pulse Monitor - ${s.label}\n${fmtDate(s.id)}  (${fmtDur(s.dur)}${if (s.res.isBlank()) "" else ", " + s.res})\n")
            if (s.desc.isNotBlank()) append("${s.desc}\n")
            append("FPS rata-rata ${f1(st.avg)}\n")
            append("5% low ${f1(st.low5)} FPS, kehalusan relatif ${f1(st.smooth)}\n")
            if (st.frameBased) append("1% low ${f1(st.low1)} FPS, frame terburuk ${f1(st.ftMax)} ms, Jank ${st.jank}, BigJank ${st.bigJank}\n")
            if (st.maxTemp >= 0f) append("Suhu HP ${"%.0f".format(st.maxTemp)}°C\n")
            if (st.avgWatt >= 0f) append("Daya rata-rata ${f1(st.avgWatt)} W\n")
        }
    }
}
