package com.pulsemonitor

import android.content.Context
import android.os.SystemClock
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.max

/** Pemakaian satu aplikasi selama satu sesi baterai. ms < 0 = waktu di layar tidak terbaca. */
class AppUse(val pkg: String, val label: String, val mah: Float, val ms: Long)

/** Satu sesi baterai: dari dicabut sampai dicolok lagi (terpakai), atau dari dicolok sampai dicabut (mengisi). */
class BatSession(
    val id: Long, val charging: Boolean, val open: Boolean,
    val t: List<Float>, val level: List<Float>, val watt: List<Float>, val temp: List<Float>,
    val apps: List<AppUse>
) {
    val n: Int get() = t.size
    val dur: Int get() = (t.lastOrNull() ?: 0f).toInt()
    val startPct: Float get() = level.firstOrNull { it >= 0f } ?: -1f
    val endPct: Float get() = level.lastOrNull { it >= 0f } ?: -1f
    val peakW: Float get() = watt.filter { it >= 0f }.maxOrNull() ?: -1f
    val avgW: Float get() = watt.avgValid()
    val peakTemp: Float get() = temp.filter { it >= 0f }.maxOrNull() ?: -1f
}

/**
 * Pemakaian baterai per aplikasi, dibaca dari `dumpsys batterystats` (perlu Shizuku/Root).
 * Bagian "Estimated power use (mAh)" memuat baris `Uid u0a317: 270.1 ( cpu=... )`, itu yang dipakai Setelan Android.
 * Waktu di depan layar dibaca dari baris "Foreground activities" per UID (kalau ROM menyediakannya).
 */
object AppPower {
    class Entry(val mah: Float, val ms: Long)

    private const val POWER_MARK = "Estimated power use"
    private val UID_LINE = Regex("""^\s*Uid\s+(\S+?):\s*([0-9]+(?:[.,][0-9]+)?)""")
    private val HEADER = Regex("""^ {2}(\S+):\s*$""")
    private val FG = Regex("""Foreground activities:\s*(.*)""")
    private val DUR = Regex("""(\d+)(ms|d|h|m|s)""")
    private val USER_APP = Regex("""^u(\d+)a(\d+)$""")

    private fun parseDur(s: String): Long {
        var total = 0L
        for (m in DUR.findAll(s)) {
            val v = m.groupValues[1].toLong()
            total += when (m.groupValues[2]) {
                "d" -> v * 86_400_000L; "h" -> v * 3_600_000L; "m" -> v * 60_000L; "s" -> v * 1000L; else -> v
            }
        }
        return total
    }

    /** Foto statistik saat ini: nama UID -> (mAh, ms di depan). Null bila tidak ada akses atau keluaran kosong. */
    @Volatile private var lastWhy = ""
    private fun why(r: String) { if (r != lastWhy) { lastWhy = r; if (r == "ok") AppLog.i("AppPower", "snapshot berhasil lagi") else AppLog.w("AppPower", "snapshot gagal: $r") } }

    fun snapshot(): Map<String, Entry>? {
        val mode = Shell.mode()
        if (mode == "-") { why("tidak ada akses Shizuku/Root"); return null }
        val out = runCatching { Shell.exec("dumpsys batterystats") }.onFailure { why("dumpsys error: ${it.javaClass.simpleName} ${it.message}") }.getOrDefault("")
        if (out.isBlank()) { why("keluaran dumpsys batterystats kosong (mode $mode)"); return null }
        val mah = HashMap<String, Float>(); val ms = HashMap<String, Long>()
        var inPower = false; var cur: String? = null
        for (line in out.lineSequence()) {
            if (!inPower && line.contains(POWER_MARK)) { inPower = true; continue }
            if (inPower) {
                val indent = line.length - line.trimStart().length
                if (line.isNotBlank() && indent <= 2) inPower = false
                else {
                    val m = UID_LINE.find(line)
                    if (m != null) {
                        val v = m.groupValues[2].replace(',', '.').toFloatOrNull()
                        if (v != null && !mah.containsKey(m.groupValues[1])) mah[m.groupValues[1]] = v
                    }
                    continue
                }
            }
            val h = HEADER.find(line)
            if (h != null) cur = h.groupValues[1]
            val c = cur
            if (c != null) {
                val f = FG.find(line)
                if (f != null) ms[c] = max(ms[c] ?: 0L, parseDur(f.groupValues[1]))
            }
        }
        if (mah.isEmpty()) { why("bagian 'Estimated power use' tidak terbaca (${out.length} karakter)"); return null }
        why("ok")
        return mah.mapValues { (k, v) -> Entry(v, ms[k] ?: -1L) }
    }

    /** Selisih dua foto. Bila statistik sistem ter-reset di antaranya (total mengecil), nilai sekarang dipakai apa adanya. */
    fun diff(now: Map<String, Entry>, base: Map<String, Entry>?): Map<String, Entry> {
        if (base == null || base.isEmpty()) return now
        val tNow = now.values.sumOf { it.mah.toDouble() }; val tBase = base.values.sumOf { it.mah.toDouble() }
        if (tNow + 0.5 < tBase) return now
        return now.mapValues { (k, e) ->
            val b = base[k]
            when {
                b == null -> e
                e.ms >= 0L && b.ms >= 0L -> Entry(max(0f, e.mah - b.mah), max(0L, e.ms - b.ms))
                else -> Entry(max(0f, e.mah - b.mah), -1L)
            }
        }
    }

    private fun uidOf(name: String): Int? {
        val m = USER_APP.find(name)
        if (m != null) return m.groupValues[1].toInt() * 100_000 + 10_000 + m.groupValues[2].toInt()
        return name.toIntOrNull()
    }

    private fun sysLabel(name: String, uid: Int?): String = when (uid) {
        0 -> "Kernel (root)"; 1000 -> "Sistem Android"; 1001 -> "Radio / telepon"; 1013 -> "Media server"; 2000 -> "Shell"
        null -> name
        else -> "UID $uid"
    }

    /** Ubah foto/selisih jadi daftar aplikasi (nama + ikon dari PackageManager), urut dari yang terboros. */
    fun toUses(ctx: Context, m: Map<String, Entry>): List<AppUse> {
        val pm = ctx.packageManager
        val acc = LinkedHashMap<String, AppUse>()
        for ((name, e) in m) {
            if (e.mah < 0.5f) continue
            val uid = uidOf(name)
            val pkg = if (uid != null && uid >= 10_000) runCatching { pm.getPackagesForUid(uid)?.firstOrNull() }.getOrNull() else null
            val label = if (pkg != null) runCatching { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() }.getOrDefault(pkg)
                else sysLabel(name, uid)
            val key = pkg ?: name
            val old = acc[key]
            acc[key] = if (old == null) AppUse(pkg ?: "", label, e.mah, e.ms)
                else AppUse(old.pkg, old.label, old.mah + e.mah, if (old.ms >= 0L && e.ms >= 0L) old.ms + e.ms else max(old.ms, e.ms))
        }
        return acc.values.sortedByDescending { it.mah }
    }
}

/**
 * Perekam riwayat baterai: tiap ~10 detik mencatat level, daya (W), dan suhu selama layanan berjalan.
 * Sesi baru dimulai tiap kali status colokan berubah. Untuk sesi "terpakai", foto statistik per aplikasi diambil
 * di awal dan di akhir sesi; selisihnya = pemakaian aplikasi selama sesi itu. Dipanggil dari BatteryStats.tick().
 */
object BatteryHistory {
    val version = MutableStateFlow(0)
    private const val EVERY_MS = 10_000L
    private const val KEEP = 40
    private const val MAX_PTS = 6000
    private const val STALE_MS = 6 * 3_600_000L

    private class Live(val id: Long, val charging: Boolean) {
        val t = ArrayList<Float>(); val lv = ArrayList<Float>(); val w = ArrayList<Float>(); val tp = ArrayList<Float>()
        var base: Map<String, AppPower.Entry>? = null
        var lastSample = 0L; var lastSave = 0L
        var baseTry = 0L; var baseRunning = false
    }

    private var ctx: Context? = null
    private var cur: Live? = null

    private fun dir(c: Context) = File(c.filesDir, "battery").also { it.mkdirs() }
    private fun jsonFiles(c: Context): List<File> = dir(c).listFiles { f -> f.extension == "json" }?.toList() ?: emptyList()

    private fun arr(l: List<Float>) = JSONArray().also { a -> l.forEach { a.put(Math.round(it * 10f) / 10.0) } }

    private fun floats(o: JSONObject, k: String): List<Float> {
        val a = o.optJSONArray(k) ?: return emptyList()
        return List(a.length()) { a.optDouble(it, -1.0).toFloat() }
    }

    @Synchronized fun init(c: Context) {
        if (ctx != null) return
        ctx = c.applicationContext
        // Layanan/aplikasi sempat mati: lanjutkan sesi yang masih terbuka, kecuali sudah basi
        val last = jsonFiles(ctx!!).maxByOrNull { it.nameWithoutExtension.toLongOrNull() ?: 0L } ?: return
        val s = runCatching { readLive(last) }.getOrNull() ?: return
        val lastAt = s.id + ((s.t.lastOrNull() ?: 0f) * 1000f).toLong()
        if (System.currentTimeMillis() - lastAt > STALE_MS) finish(s) else cur = s
    }

    private fun readLive(f: File): Live? {
        val o = JSONObject(f.readText())
        if (!o.optBoolean("open")) return null
        val s = Live(o.getLong("id"), o.optBoolean("charging"))
        val t = floats(o, "t"); val n = t.size
        fun fit(l: List<Float>) = if (l.size >= n) l.take(n) else l + List(n - l.size) { -1f }
        s.t.addAll(t); s.lv.addAll(fit(floats(o, "lv"))); s.w.addAll(fit(floats(o, "w"))); s.tp.addAll(fit(floats(o, "tp")))
        val b = o.optJSONObject("base")
        if (b != null) {
            val m = HashMap<String, AppPower.Entry>()
            b.keys().forEach { k -> val a = b.getJSONArray(k); m[k] = AppPower.Entry(a.getDouble(0).toFloat(), a.getLong(1)) }
            s.base = m
        }
        return s
    }

    /** Dipanggil tiap tick BatteryStats. watt < 0 / temp < 0 = tidak terbaca. */
    @Synchronized fun onSample(c: Context, plugged: Boolean, pct: Int, watt: Float, temp: Float) {
        if (ctx == null) init(c)
        if (pct < 0) return
        val now = SystemClock.elapsedRealtime()
        var s = cur
        if (s != null && s.charging != plugged) { finish(s); s = null }
        if (s == null) {
            s = Live(System.currentTimeMillis(), plugged); cur = s
            AppLog.i("Baterai", "sesi baru dimulai (${if (plugged) "mengisi daya" else "terpakai"}, level $pct%)")
            startBase(s)
        } else if (now - s.lastSample < EVERY_MS) return
        // Foto awal gagal diambil (mis. akses Shizuku/Root belum siap saat sesi dimulai): coba lagi tiap 30 detik
        if (s.base == null && now - s.baseTry > 30_000L) { s.baseTry = now; startBase(s) }
        s.lastSample = now
        s.t.add((System.currentTimeMillis() - s.id) / 1000f)
        s.lv.add(pct.toFloat()); s.w.add(watt); s.tp.add(temp)
        if (s.t.size > MAX_PTS) decimate(s)
        if (now - s.lastSave > 60_000L || s.t.size <= 2) { s.lastSave = now; save(s, true) }
        version.value = version.value + 1
    }

    /** Foto awal untuk sesi (terpakai maupun mengisi daya), diambil di thread sendiri (dumpsys bisa makan 1-3 detik). */
    private fun startBase(s: Live) {
        if (s.baseRunning) return
        s.baseRunning = true
        Thread {
            val snap = runCatching { AppPower.snapshot() }.getOrNull()
            synchronized(this) { s.baseRunning = false; if (snap != null) s.base = snap; if (cur === s && snap != null) save(s, true) }
            if (snap != null) AppLog.i("Baterai", "foto awal pemakaian aplikasi OK (${snap.size} UID)") else AppLog.w("Baterai", "foto awal gagal, dicoba lagi 30 detik")
        }.start()
    }

    private fun finish(s: Live) {
        val c = ctx ?: return
        if (cur === s) cur = null
        if (s.t.size < 3) { File(dir(c), "${s.id}.json").delete(); AppLog.i("Baterai", "sesi dibuang (kurang dari 3 titik)"); return }
        AppLog.i("Baterai", "sesi selesai: ${s.t.size} titik, foto awal ${if (s.base != null) "ada" else "tidak ada"}")
        save(s, false)
        val base = s.base
        if (base != null) Thread {
            val now = runCatching { AppPower.snapshot() }.getOrNull()
            if (now != null) {
                val uses = AppPower.toUses(c, AppPower.diff(now, base))
                synchronized(this) { save(s, false, uses) }
            }
            synchronized(this) { prune(c); version.value = version.value + 1 }
        }.start() else prune(c)
        version.value = version.value + 1
    }

    private fun decimate(s: Live) {
        fun <T> thin(l: ArrayList<T>) {
            val keep = ArrayList<T>()
            l.forEachIndexed { i, v -> if (i % 2 == 0 || i == l.lastIndex) keep.add(v) }
            l.clear(); l.addAll(keep)
        }
        thin(s.t); thin(s.lv); thin(s.w); thin(s.tp)
    }

    private fun save(s: Live, open: Boolean, apps: List<AppUse> = emptyList()) {
        val c = ctx ?: return
        val o = JSONObject().apply {
            put("id", s.id); put("charging", s.charging); put("open", open)
            put("t", arr(s.t)); put("lv", arr(s.lv)); put("w", arr(s.w)); put("tp", arr(s.tp))
            val b = s.base
            if (open && b != null) put("base", JSONObject().also { j ->
                b.forEach { (k, e) -> j.put(k, JSONArray().put(e.mah.toDouble()).put(e.ms)) }
            })
            put("apps", JSONArray().also { a ->
                apps.forEach { u -> a.put(JSONObject().put("p", u.pkg).put("l", u.label).put("m", u.mah.toDouble()).put("t", u.ms)) }
            })
        }
        val f = File(dir(c), "${s.id}.json"); val tmp = File(dir(c), "${s.id}.tmp")
        runCatching { tmp.writeText(o.toString()); if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f) } }
    }

    private fun prune(c: Context) {
        jsonFiles(c).sortedByDescending { it.nameWithoutExtension.toLongOrNull() ?: 0L }.drop(KEEP).forEach { it.delete() }
    }

    private fun parse(txt: String): BatSession {
        val o = JSONObject(txt)
        val t = floats(o, "t"); val n = t.size
        fun fit(l: List<Float>) = if (l.size >= n) l.take(n) else l + List(n - l.size) { -1f }
        val a = o.optJSONArray("apps")
        val apps: List<AppUse> = if (a == null) emptyList() else List(a.length()) { i ->
            val j = a.getJSONObject(i)
            AppUse(j.optString("p"), j.optString("l"), j.optDouble("m", 0.0).toFloat(), j.optLong("t", -1L))
        }
        return BatSession(o.getLong("id"), o.optBoolean("charging"), o.optBoolean("open"), t,
            fit(floats(o, "lv")), fit(floats(o, "w")), fit(floats(o, "tp")), apps)
    }

    @Synchronized fun current(): BatSession? = cur?.let { s ->
        BatSession(s.id, s.charging, true, s.t.toList(), s.lv.toList(), s.w.toList(), s.tp.toList(), emptyList())
    }

    /** Sesi berjalan (kalau ada) di paling atas, lalu sesi tersimpan dari yang terbaru. Panggil dari thread latar. */
    fun list(c: Context): List<BatSession> {
        val now = current()
        val saved = jsonFiles(c).mapNotNull { f -> runCatching { parse(f.readText()) }.getOrNull() }
            .filter { it.id != now?.id }.sortedByDescending { it.id }
        return listOfNotNull(now) + saved
    }

    fun load(c: Context, id: Long): BatSession? =
        current()?.takeIf { it.id == id } ?: runCatching { parse(File(dir(c), "$id.json").readText()) }.getOrNull()

    fun delete(c: Context, id: Long) {
        if (current()?.id == id) return
        File(dir(c), "$id.json").delete(); version.value = version.value + 1
    }

    class Health(val hasCur: Boolean, val charging: Boolean, val points: Int, val lastAgeS: Long, val hasBase: Boolean, val saved: Int)

    /** Ringkasan keadaan perekaman untuk layar Kesehatan & log. */
    @Synchronized fun health(c: Context): Health {
        val s = cur
        val saved = runCatching { jsonFiles(c).size }.getOrDefault(0)
        return Health(s != null, s?.charging ?: false, s?.t?.size ?: 0,
            if (s != null && s.lastSample > 0L) (SystemClock.elapsedRealtime() - s.lastSample) / 1000L else -1L,
            s?.base != null, saved)
    }

    /** Pemakaian aplikasi untuk sesi yang masih berjalan: foto sekarang dikurangi foto awal. Null bila tidak bisa dihitung. */
    fun liveApps(c: Context, id: Long): List<AppUse>? {
        val base = synchronized(this) { cur?.takeIf { it.id == id }?.base } ?: return null
        val now = runCatching { AppPower.snapshot() }.getOrNull() ?: return null
        return AppPower.toUses(c, AppPower.diff(now, base))
    }
}
