package com.pulsemonitor

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.SystemClock
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import rikka.shizuku.Shizuku

/** Rincian memori dalam GB untuk kartu Statistik; swapTotal = 0 bila HP tidak punya swap. */
data class MemInfo(
    val marketGb: Int = 0, val ramTotal: Float = 0f, val ramUsed: Float = 0f, val ramFree: Float = 0f,
    val swapTotal: Float = 0f, val swapUsed: Float = 0f, val swapFree: Float = 0f, val zram: Boolean = false,
    val extraTotal: Float = 0f, val extraUsed: Float = 0f   // swap non-zram (mis. berkas swap "RAM tambahan") bila zram juga ada
)

/** Hasil baca memori: rincian + teks ringkas untuk tampilan lama. */
class MemRead(val mem: MemInfo, val ramPct: Int, val ramText: String, val swapText: String)

data class Snap(
    val fps: Int = 0, val avg: Int = 0, val low: Int = 0, val ft: Float = 0f,
    val cpu: Int = -1, val gpu: Int = -1, val ramPct: Int = -1, val ramText: String = "-", val swapText: String = "",
    val mem: MemInfo? = null,
    val tCpu: Float = -1f, val tGpu: Float = -1f, val tBat: Float = -1f, val tSkin: Float = -1f,   // tSkin = suhu permukaan HP
    val access: String = "-", val dbg: String = "", val hist: List<Int> = emptyList(),
    val pkg: String = "", val watt: Float = -1f,
    val batPct: Int = -1, val cpuMhz: Int = -1, val gpuMhz: Int = -1,
    val fpsRaw: Int = 0,          // FPS terukur apa adanya (untuk rekaman); fps bisa berisi pengganti saat layar statis
    val fpsRawF: Float = 0f,      // fpsRaw dengan desimal (mis. 60,2) untuk rekaman; 0 bila tidak tersedia
    val idle: Boolean = false,    // true: layar statis, fps berisi refresh rate layar
    val coreMhz: List<Int> = emptyList(),   // frekuensi tiap inti CPU (MHz), -1 = offline / tidak terbaca
    val cpuHist: List<Int> = emptyList(),   // beban CPU 60 detik terakhir (persen)
    val touchHz: Int = -1                   // touch rate (Hz): -1 = fitur mati, 0 = tidak sedang menyentuh
)

object Shell {
    // Hanya dipakai saat pengguna belum memilih metode (Access.AUTO)
    private val rootOk: Boolean by lazy {
        runCatching { ProcessBuilder("su", "-c", "id").start().inputStream.bufferedReader().readText().contains("uid=0") }
            .getOrDefault(false)
    }
    fun shizukuReady() = runCatching { Shizuku.pingBinder() && Shizuku.checkSelfPermission() == 0 }.getOrDefault(false)
    /** Mengikuti pilihan di Settings. Belum memilih: Shizuku kalau siap, kalau tidak root. */
    fun mode(): String = when (Access.choice) {
        Access.ROOT -> if (Access.rootState == 2) "Root" else "-"
        Access.SHIZUKU -> if (shizukuReady()) "Shizuku" else "-"
        else -> if (shizukuReady()) "Shizuku" else if (rootOk) "Root" else "-"
    }

    /** Proses shell yang terus berjalan (dibaca baris demi baris oleh pemanggil). Null bila tidak ada akses. */
    fun spawn(cmd: String): Process? = when (mode()) {
        "Shizuku" -> Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        ).apply { isAccessible = true }.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        "Root" -> ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        else -> null
    }

    fun exec(cmd: String): String {
        val p: Process = when (mode()) {
            // newProcess bersifat private di Shizuku 13.x, dipanggil via refleksi
            "Shizuku" -> Shizuku::class.java.getDeclaredMethod(
                "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
            ).apply { isAccessible = true }.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            "Root" -> ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
            else -> return ""
        }
        return runCatching { p.inputStream.bufferedReader().readText() }.getOrDefault("").also { p.destroy() }
    }
}

object Sampler {
    // Urutan prioritas jalur beban GPU. Tambahkan jalur baru di sini bila ada chipset lain.
    private const val GPU_PATHS = "/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage " +   // Adreno (Qualcomm)
        "/sys/class/kgsl/kgsl-3d0/gpubusy " +                // Adreno cadangan: "busy total" -> persen
        "/sys/kernel/ged/hal/gpu_utilization " +                                       // MediaTek (GED)
        "/sys/module/ged/parameters/gpu_loading " +                                    // MediaTek (GED, varian lain)
        "/proc/mali/utilization"                                                       // Mali lama

    val state = MutableStateFlow(Snap())
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var job: Job? = null
    private var prevTotal = 0L; private var prevIdle = 0L
    private val hist = ArrayDeque<Int>()      // FPS terukur (untuk avg / low)
    private val cH = ArrayDeque<Int>()        // beban CPU (untuk grafik Status CPU di tab Statistik)
    private val gHist = ArrayDeque<Int>()     // FPS yang ditampilkan (untuk grafik): sama dengan angka FPS di layar

    /** true selama layar utama aplikasi terlihat; layanan latar belakang tidak boleh mematikan Sampler saat itu. */
    @Volatile var uiVisible = false

    /** Hentikan pembacaan (proses shell tiap detik). Dipanggil saat tidak ada overlay, rekaman, maupun layar utama. */
    fun stop() {
        job?.cancel(); job = null
        prevTotal = 0L; prevIdle = 0L; prevTrans = null
        hist.clear(); gHist.clear(); cH.clear()
    }

    fun start() {
        if (job?.isActive == true) return
        job = scope.launch {
            while (isActive) {
                // Jadwal tetap ~1 detik: lama tick (beberapa proses shell) dikurangkan dari jeda,
                // supaya sampel tidak melambat jadi 2-3 detik dan angka tidak meloncat-loncat.
                val t0 = SystemClock.elapsedRealtime()
                runCatching { tick() }
                delay((1000L - (SystemClock.elapsedRealtime() - t0)).coerceAtLeast(200L))
            }
        }
    }

    private fun tick() {
        val mode = Shell.mode()
        if (mode == "-") {
            val mr = runCatching {
                readMem(java.io.File("/proc/meminfo").readText(), runCatching { java.io.File("/proc/swaps").readText() }.getOrDefault(""))
            }.getOrNull()
            state.value = Snap(tBat = batteryTemp(), batPct = batteryPct(), access = "-", dbg = "Suhu baterai: Intent (CPU/GPU butuh Shizuku/root)",
                mem = mr?.mem, ramPct = mr?.ramPct ?: -1, ramText = mr?.ramText ?: "-", swapText = mr?.swapText ?: "")
            return
        }
        val out = Shell.exec(
            "head -1 /proc/stat; echo ==; for n in 1 2 3 4 5 6; do for f in $GPU_PATHS; do [ -r \$f ] && echo \"\$f:\$(cat \$f 2>/dev/null)\"; done; [ \$n -lt 6 ] && sleep 0.07; done; echo ==; " +
            "grep -E '^(MemTotal|MemAvailable|SwapTotal|SwapFree):' /proc/meminfo; echo ==; grep -H . /sys/class/thermal/thermal_zone*/type /sys/class/thermal/thermal_zone*/temp 2>/dev/null; " +
            "echo ==; cat /sys/class/kgsl/kgsl-3d0/temp 2>/dev/null; " +
            "echo ==; for d in /sys/devices/system/cpu/cpu[0-9]*; do [ -r \$d/cpufreq/scaling_cur_freq ] && echo \"\${d##*/}:\$(cat \$d/cpufreq/scaling_cur_freq 2>/dev/null):\$(cat \$d/cpufreq/cpuinfo_cur_freq 2>/dev/null)\"; done; " +
            "echo ==; for n in 1 2 3 4; do for f in /sys/class/kgsl/kgsl-3d0/devfreq/cur_freq /sys/class/kgsl/kgsl-3d0/gpuclk " +
            "/sys/class/kgsl/kgsl-3d0/clock_mhz /sys/class/devfreq/*kgsl*/cur_freq " +
            "/sys/class/devfreq/*mali*/cur_freq /sys/class/devfreq/*.gpu/cur_freq /sys/devices/platform/*mali*/cur_freq " +
            "/sys/kernel/ged/hal/current_freqency /sys/kernel/gpu/gpu_clock; " +
            "do [ -r \$f ] && echo \"\$f:\$(cat \$f 2>/dev/null | tr '\\n' ' ')\"; done; [ \$n -lt 4 ] && sleep 0.05; done; " +
            "[ -r /proc/gpufreqv2/gpufreq_status ] && grep -i -E 'freq' /proc/gpufreqv2/gpufreq_status 2>/dev/null | head -12 | sed 's/^/GPUFREQV2:/'; " +
            "echo ==; for d in /sys/class/kgsl/kgsl-3d0/devfreq /sys/class/devfreq/*kgsl* /sys/class/devfreq/*mali* /sys/class/devfreq/*.gpu; do " +
            "[ -r \$d/trans_stat ] && { echo \"##\$d\"; cat \$d/trans_stat 2>/dev/null; }; done; " +
            "echo ==; for f in /sys/class/kgsl/kgsl-3d0/devfreq/max_freq /sys/class/kgsl/kgsl-3d0/devfreq/min_freq /sys/class/kgsl/kgsl-3d0/max_gpuclk " +
            "/sys/class/kgsl/kgsl-3d0/thermal_pwrlevel /sys/class/kgsl/kgsl-3d0/max_pwrlevel /sys/class/kgsl/kgsl-3d0/devfreq/available_frequencies " +
            "/sys/class/devfreq/*kgsl*/max_freq /sys/class/devfreq/*mali*/max_freq /sys/class/devfreq/*.gpu/max_freq; " +
            "do [ -r \$f ] && echo \"\$f:\$(cat \$f 2>/dev/null | tr '\\n' ' ')\"; done; echo ==; cat /proc/swaps 2>/dev/null"
        ).split("==")
        if (out.size < 4) return

        // CPU
        val c = out[0].trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        var cpu = -1
        if (c.size >= 5) {
            val total = c.take(8).sum(); val idle = c[3] + c[4]
            if (prevTotal > 0 && total > prevTotal) cpu = (100 * ((total - prevTotal) - (idle - prevIdle)) / (total - prevTotal)).toInt()
            prevTotal = total; prevIdle = idle
        }
        // Beban GPU: Adreno (kgsl) dulu, lalu MediaTek (GED) / Mali. Tiap jalur dibaca 6x dalam ~0,4 detik lalu dirata-rata,
        // karena GED/kgsl melaporkan beban sesaat; satu pembacaan bisa kebetulan kena momen GPU nganggur (0%) walau FPS penuh.
        // Format tiap jalur berbeda (ada yang "45", ada yang "45 30 12"); jalur pertama (urutan prioritas) yang punya sampel dipakai.
        val loadBy = LinkedHashMap<String, MutableList<Int>>()
        for (line in out[1].lines()) {
            val path = line.substringBefore(':')
            val nums = Regex("\\d+").findAll(line.substringAfter(':', "")).mapNotNull { it.value.toLongOrNull() }.toList()
            val v: Int = when {
                nums.isEmpty() -> null
                // gpubusy berisi dua angka "busy total": persen = busy / total
                path.endsWith("gpubusy") -> nums.getOrNull(1)?.takeIf { it > 0 }?.let { (100 * nums[0] / it).toInt().coerceIn(0, 100) }
                else -> nums[0].toInt().takeIf { it in 0..100 }
            } ?: continue
            loadBy.getOrPut(path) { ArrayList() }.add(v)
        }
        val loadPick = loadBy.entries.firstOrNull { it.value.isNotEmpty() }
        val gpu = loadPick?.let { Math.round(it.value.average()).toInt() } ?: -1
        gpuLoadDbg = loadPick?.let { "${it.key.substringAfter("/sys/").take(40)}=${it.value.joinToString("/")} -> $gpu%" } ?: "tidak ada jalur terbaca"
        // Frekuensi: CPU = tertinggi dari semua inti (kHz -> MHz); GPU dalam Hz atau kHz tergantung jalur
        val cpuMhz = parseCpuFreq(out.getOrNull(5) ?: "")
        val gpuInst = parseGpuFreq(out.getOrNull(6) ?: "")
        // Rata-rata berbobot waktu (trans_stat) lebih mewakili naik-turun frekuensi dalam 1 detik; cadangan: nilai sesaat
        // Dipakai frekuensi tertinggi yang benar-benar dipakai GPU (>=5% jendela) atau sampel sesaat tertinggi;
        // rata-rata berbobot membuat angka mentok di tengah dan tidak pernah menyentuh frekuensi puncak.
        gpuLimDbg = (out.getOrNull(8) ?: "").lines().map { it.trim() }.filter { it.isNotEmpty() }
            .joinToString("; ") { it.replace("/sys/class/", "").take(90) }.ifEmpty { "tidak terbaca" }
        val gpuTrans = transAvg(out.getOrNull(7) ?: "")
        // trans_stat (jika ada) = rata-rata berbobot waktu; kalau tidak, nilai sesaat dari sumber yang tidak macet
        // MediaTek: devfreq Mali (governor dummy) tidak diperbarui, trans_stat-nya bisa menempel di satu frekuensi;
        // GED current_freqency adalah sumber yang cocok dengan aplikasi lain, jadi dipakai langsung (tanpa trans_stat).
        val preferInst = gpuPickPath?.let { it.endsWith("current_freqency") || it == "gpufreqv2" } ?: false
        val gpuMhz = (if (!preferInst && gpuTrans > 0) gpuTrans else gpuInst).takeIf { it > 0 } ?: -1
        // RAM + swap/zram
        val mr = readMem(out[2], out.getOrNull(9) ?: "")
        val ramPct = mr.ramPct; val ramText = mr.ramText; val swapText = mr.swapText; val mem = mr.mem
        // Suhu: HAL thermal (utama) -> sysfs (cadangan); baterai dari Intent BATTERY_CHANGED
        // dumpsys thermalservice berat dan ikut membebani system_server; cukup tiap 3 detik
        val nowMs = SystemClock.elapsedRealtime()
        if (nowMs - halAt >= 3000L) {
            // Pembacaan HAL yang gagal sesaat (dumpsys lambat saat game berat) tidak boleh membuang data lama,
            // kalau tidak suhu pindah ke sysfs yang nilainya bisa beda dan memunculkan lonjakan palsu
            val h = runCatching { thermalHal() }.getOrNull()
            if (h != null) { halCache = h; halOkAt = nowMs } else if (nowMs - halOkAt > 30_000L) halCache = null
            halAt = nowMs
        }
        val hal = halCache
        val sys = parseZones(out[3])
        val kgsl = out.getOrNull(4)?.trim()?.toFloatOrNull()?.let { norm(it) }?.takeIf { it in 5f..120f } ?: -1f
        fun pick(vararg c: Pair<String, Float>): Pair<Float, String> =
            c.firstOrNull { it.second >= 0f }?.let { it.second to it.first } ?: (-1f to "-")
        val tc = pick("HAL" to (hal?.t?.cpu ?: -1f), "HAL-soc" to (hal?.t?.soc ?: -1f), "sysfs" to sys.cpu)
        val tg = pick("HAL" to (hal?.t?.gpu ?: -1f), "sysfs" to sys.gpu, "kgsl" to kgsl)
        val tb = pick("Intent" to batteryTemp(), "HAL" to (hal?.t?.bat ?: -1f), "sysfs" to sys.bat)
        val tsk = pick("HAL" to (hal?.t?.skin ?: -1f), "sysfs" to sys.skin)
        val tempDbg = "CPU ${tc.second}, GPU ${tg.second}, BAT ${tb.second}, skin %.0f° (%s) | HAL: %s".format(
            tsk.first, tsk.second, if (hal != null) "${hal.n} sensor" else "tidak siap/kosong")

        // Saat merekam, kunci paket game supaya fokus yang pindah sebentar (tarik notifikasi,
        // keyboard, toast, overlay) tidak mengalihkan pengukuran ke aplikasi lain.
        if (!Recorder.active.value) pinPkg = null
        else if (pinPkg == null) pinPkg = targetPkg()?.takeIf { !isIgnoredPkg(it, appCtx?.packageName ?: "") }
        if (!Recorder.active.value) { resTick = 0; idleResRead() } else sampleGameRes()

        val f = runCatching { fps() }.getOrDefault(0 to 0)
        if (f.first > 0) { hist.addLast(f.first); if (hist.size > 30) hist.removeFirst() }
        // Layar diam / adegan statis: game tidak menyerahkan frame baru, jadi selisih frame = 0.
        // Tahan nilai terakhir beberapa detik supaya tidak langsung 0; 0 sungguhan tetap muncul.
        var shown = f.first
        if (f.first > 0) { lastFps = f.first; lastFpsPkg = curPkg; zeroTicks = 0 }
        else if (lastFps > 0 && lastFpsPkg == curPkg && curPkg.isNotEmpty() && zeroTicks < HOLD_TICKS) { zeroTicks++; shown = lastFps }
        else lastFps = 0
        // Aplikasi biasa (tanpa SurfaceView) hanya menggambar saat ada perubahan, jadi layar diam = 0-5 FPS
        // dan itu normal, bukan lag. Tampilkan refresh rate layar (ditandai idle) alih-alih angka kecil itu.
        var idle = false
        if (shown < IDLE_FPS && !surfaceApp && curPkg.isNotEmpty()) {
            val hz = displayHz(); if (hz > 0) { shown = hz; idle = true }
        }
        // Grafik mengikuti angka yang tampil (termasuk tahan nilai terakhir dan refresh rate saat idle), bukan FPS mentah,
        // supaya garisnya tidak jatuh ke bawah saat angkanya tetap 60
        gHist.addLast(shown); if (gHist.size > 30) gHist.removeFirst()
        if (cpu >= 0) { cH.addLast(cpu); if (cH.size > 60) cH.removeFirst() }
        state.value = Snap(
            fpsRaw = f.first, idle = idle,
            fpsRawF = if (queuedFps > 0f && Math.round(queuedFps) == f.first) queuedFps else f.first.toFloat(),
            fps = shown, avg = if (hist.isEmpty()) 0 else hist.average().toInt(),
            low = if (f.second > 0) f.second else (hist.minOrNull() ?: 0),
            ft = if (shown > 0) 1000f / shown else 0f, cpu = cpu, gpu = gpu,
            ramPct = ramPct, ramText = ramText, swapText = swapText, mem = mem, tCpu = tc.first, tGpu = tg.first, tBat = tb.first, tSkin = tsk.first, access = mode, hist = gHist.toList(),
            dbg = "FPS: $fpsDbg\nSuhu: $tempDbg\nCPU clk: $cpuFreqDbg\nGPU clk: $gpuFreqDbg\nGPU beban: $gpuLoadDbg\nGPU trans_stat: $transDbg\nGPU batas: $gpuLimDbg\nResolusi: $resDbg", pkg = curPkg, watt = batteryWatt(),
            batPct = batteryPct(), cpuMhz = cpuMhz, gpuMhz = gpuMhz,
            coreMhz = parseCoreFreqs(out.getOrNull(5) ?: ""), cpuHist = cH.toList()
        )
        Recorder.onSample(state.value)
    }

    /**
     * Baca RAM dan swap. Satuan GB desimal (1 GB = 10^9 byte, seperti DevCheck); /proc/meminfo dalam kB (1024 byte).
     * RAM terpakai = MemTotal - MemAvailable. ZRAM dihitung dari /proc/swaps (hanya perangkat zram) supaya swap lain
     * (berkas swap "RAM tambahan") tidak ikut tercampur ke angka ZRAM; bila /proc/swaps tak terbaca, pakai SwapTotal/SwapFree.
     */
    private fun readMem(meminfo: String, swaps: String): MemRead {
        val gb = 1024f / 1_000_000_000f
        fun kb(n: String) = Regex("(?m)^$n:\\s+(\\d+)").find(meminfo)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
        val tot = kb("MemTotal"); val av = kb("MemAvailable")
        val ramPct = if (tot > 0) (100 * (tot - av).coerceIn(0L, tot) / tot).toInt() else -1
        var zT = 0L; var zU = 0L; var oT = 0L; var oU = 0L; var any = false
        for (l in swaps.lineSequence()) {
            val f = l.trim().split(Regex("\\s+"))
            if (f.size < 4 || f[0] == "Filename") continue
            val size = f[2].toLongOrNull() ?: continue; val used = f[3].toLongOrNull() ?: continue
            any = true
            if (f[0].contains("zram", ignoreCase = true)) { zT += size; zU += used } else { oT += size; oU += used }
        }
        val zram = zT > 0
        val swT: Long; val swU: Long; val exT: Long; val exU: Long
        if (any) { if (zram) { swT = zT; swU = zU; exT = oT; exU = oU } else { swT = oT; swU = oU; exT = 0; exU = 0 } }
        else { swT = kb("SwapTotal"); swU = (swT - kb("SwapFree")).coerceAtLeast(0L); exT = 0; exU = 0 }
        val ramText = "%.1f / %.0f GB".format((tot - av) * gb, tot * gb)
        val swapText = if (swT > 0) "%.1f / %.1f GB".format(swU * gb, swT * gb) else ""
        // Ukuran RAM "di kotak" = ukuran umum terdekat di atas MemTotal (kernel menyisihkan sebagian)
        val totGb = tot / 1048576f
        val market = listOf(2, 3, 4, 6, 8, 10, 12, 16, 18, 20, 24, 32).firstOrNull { it >= totGb - 0.01f } ?: Math.ceil(totGb.toDouble()).toInt()
        val mem = MemInfo(market, tot * gb, (tot - av).coerceAtLeast(0L) * gb, av * gb, swT * gb, swU * gb, (swT - swU).coerceAtLeast(0L) * gb, zram, exT * gb, exU * gb)
        return MemRead(mem, ramPct, ramText, swapText)
    }

    // ---- Resolusi render game (ukuran buffer layer game di SurfaceFlinger), bukan resolusi layar ----
    @Volatile private var resBusy = false
    private var resTick = 0
    private val BUF_RE = Regex("""activeBuffer=\[\s*(\d+)\s*x\s*(\d+)""")
    private val BUF_RE2 = Regex("""(?i)buffer\w*[ =:\[(]+\s*(\d{3,5})\s*[x\u00d7]\s*(\d{3,5})""")

    /** Resolusi render terakhir yang berhasil dibaca per paket. Dipakai saat rekaman dimulai / berhenti, supaya tidak perlu menunggu. */
    private val resCache = java.util.concurrent.ConcurrentHashMap<String, Pair<Int, Int>>()
    fun cachedRes(pkg: String): Pair<Int, Int>? = resCache[pkg]
    private var resIdleTick = 0

    /** Baca resolusi layer paket ini di thread terpisah (supaya tick tidak melambat); simpan ke cache dan ke rekaman yang sedang jalan. */
    private fun readResAsync(pkg: String) {
        if (pkg.isEmpty() || resBusy) return
        resBusy = true
        scope.launch {
            try {
                val r = parseGameRes(Shell.exec("dumpsys SurfaceFlinger"), pkg)
                if (r != null) { resCache[pkg] = r; Recorder.onRes(r.first, r.second) }
            } catch (_: Throwable) {
            } finally { resBusy = false }
        }
    }

    /** Saat merekam: tiap ~8 detik baca ukuran buffer layer game (2 detik selama belum ada hasil). */
    private fun sampleGameRes() {
        val pkg = pinPkg ?: return
        if (resTick++ % (if (Recorder.hasRes()) 8 else 2) != 0) return
        readResAsync(pkg)
    }

    /**
     * Di luar rekaman: selagi game (layer SurfaceView) ada di depan, baca resolusinya sekali (lalu segarkan tiap ~1 menit),
     * jadi saat tombol rekam ditekan di dalam game, resolusi game sudah diketahui.
     */
    private fun idleResRead() {
        val p = curPkg
        if (p.isEmpty() || !surfaceApp || isIgnoredPkg(p, appCtx?.packageName ?: "")) return
        val every = if (resCache.containsKey(p)) 60 else 10
        if (resIdleTick++ % every == 0) readResAsync(p)
    }

    /** Dipanggil tepat sebelum Recorder.start(): baca ulang fokus dan resolusi game yang sedang di depan, sekarang juga. */
    fun onRecordStartRes() {
        resTick = 0
        val p = lastGame.ifEmpty { curPkg }
        if (p.isNotEmpty() && !isIgnoredPkg(p, appCtx?.packageName ?: "")) readResAsync(p)
    }

    @Volatile private var resDbg = "-"

    /**
     * Diagnostik resolusi: ambil cuplikan dump SurfaceFlinger di sekitar layer game (nama layer + beberapa baris sesudahnya)
     * supaya format dump di HP ini kelihatan dan pembacanya bisa disesuaikan. Panggil dari thread latar.
     */
    fun resProbe(): String {
        val pkg = pinPkg ?: lastGame.ifEmpty { curPkg }
        if (pkg.isEmpty() || isIgnoredPkg(pkg, appCtx?.packageName ?: "")) return "Game belum terdeteksi. Buka game dulu, nyalakan overlay, lalu coba lagi."
        val sb = StringBuilder("Paket: $pkg\nHasil pembacaan: $resDbg\n")
        sb.append("wm size: ").append(Shell.exec("wm size").trim().replace("\n", " | ")).append("\n")
        sb.append("Android: ").append(android.os.Build.VERSION.RELEASE).append(" (SDK ").append(android.os.Build.VERSION.SDK_INT).append(")\n\n")
        val txt = Shell.exec("dumpsys SurfaceFlinger")
        val lines = txt.lines()
        sb.append("Panjang dump: ${txt.length} karakter, ${lines.size} baris\n")
        val hits = lines.indices.filter { lines[it].contains(pkg) }
        sb.append("Baris yang menyebut paket: ${hits.size}\n\n")
        val shown = HashSet<Int>()
        var n = 0
        // SurfaceView lebih dulu, lalu sisanya
        for (i in hits.sortedByDescending { lines[it].contains("SurfaceView") }) {
            if (n >= 5 || sb.length > 9000) break
            if (i in shown) continue
            n++
            sb.append("--- baris $i ---\n")
            for (j in maxOf(0, i - 1)..minOf(i + 14, lines.lastIndex)) { shown.add(j); sb.append(lines[j].trim().take(170)).append('\n') }
            sb.append('\n')
        }
        // Baris yang memuat ukuran buffer di mana pun dalam dump (maks 12)
        val keys = Regex("(?i)activeBuffer|bufferSize|geomBuffer|Source Crop|crop=")
        val extra = lines.filter { keys.containsMatchIn(it) }.take(12)
        if (extra.isNotEmpty()) { sb.append("--- baris ukuran buffer (umum) ---\n"); extra.forEach { sb.append(it.trim().take(170)).append('\n') } }
        return sb.toString()
    }

    /** Cadangan ketiga (format dump baru): geomBufferSize / bufferSize di beberapa baris sesudah nama layer game. */
    private fun snapshotBufferSize(txt: String, pkg: String): Pair<Int, Int>? {
        val rx = Regex("""(?i)(?:geomBufferSize|bufferSize)\D{1,8}(-?\d+)\D+(-?\d+)(?:\D+(-?\d+)\D+(-?\d+))?""")
        val lines = txt.lines()
        var best: Pair<Int, Int>? = null; var bestScore = -1L
        for (i in lines.indices) {
            val l = lines[i]
            if (!l.contains(pkg) || l.contains("Background for")) continue
            for (j in i..minOf(i + 15, lines.lastIndex)) {
                val m = rx.find(lines[j]) ?: continue
                val g = m.groupValues
                val w: Int; val h: Int
                if (g[3].isNotEmpty() && g[4].isNotEmpty()) { w = g[3].toInt() - g[1].toInt(); h = g[4].toInt() - g[2].toInt() }
                else { w = g[1].toInt(); h = g[2].toInt() }
                if (w < 100 || h < 100) continue
                val score = (if (l.contains("SurfaceView")) 1L shl 40 else 0L) + w.toLong() * h
                if (score > bestScore) { bestScore = score; best = w to h }
                break
            }
        }
        return best
    }

    /**
     * Cadangan bila activeBuffer tidak ada di dump: tabel "HWC layers" memuat Source Crop (L T R B) tiap layer,
     * yaitu bagian buffer yang ditampilkan = ukuran render game. Nama layer di satu baris, angkanya di baris sesudahnya.
     */
    private fun hwcSourceCrop(txt: String, pkg: String): Pair<Int, Int>? {
        val num = Regex("""(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)""")
        val lines = txt.lines()
        var best: Pair<Int, Int>? = null; var bestScore = -1L
        for (i in lines.indices) {
            val l = lines[i]
            if (!l.contains(pkg) || l.contains("Background for")) continue
            for (j in i..minOf(i + 2, lines.lastIndex)) {
                val m = num.find(lines[j]) ?: continue
                val w = (m.groupValues[3].toFloat() - m.groupValues[1].toFloat()).toInt()
                val h = (m.groupValues[4].toFloat() - m.groupValues[2].toFloat()).toInt()
                if (w < 100 || h < 100) break
                val score = (if (l.contains("SurfaceView")) 1L shl 40 else 0L) + w.toLong() * h
                if (score > bestScore) { bestScore = score; best = w to h }
                break
            }
        }
        return best
    }

    /** Baca resolusi render paket ini sekarang juga (blokir; panggil dari thread latar). Orientasi apa adanya dari buffer. */
    fun readResNow(pkg: String): Pair<Int, Int>? = runCatching {
        if (pkg.isEmpty()) null else parseGameRes(Shell.exec("dumpsys SurfaceFlinger"), pkg, normalize = false)
    }.getOrNull()

    /**
     * Resolusi yang diset game sendiri (game Unreal Engine: GameUserSettings.ini, ResolutionSizeX/Y).
     * Dipakai di laporan supaya yang tampil resolusi game, bukan ukuran layar HP. Butuh Shizuku/root; null bila file tak terbaca.
     */
    fun iniRes(pkg: String): Pair<Int, Int>? = runCatching {
        if (pkg.isEmpty()) return@runCatching null
        val txt = Shell.exec("cat /sdcard/Android/data/$pkg/files/UnrealEngine/Saved/Config/Android/GameUserSettings.ini")
        fun v(k: String) = Regex("(?m)^" + k + "=(\\d+)").find(txt)?.groupValues?.get(1)?.toIntOrNull()
        val w = v("ResolutionSizeX"); val h = v("ResolutionSizeY")
        if (w != null && h != null && w >= 100 && h >= 100) maxOf(w, h) to minOf(w, h) else null
    }.getOrNull()

    /** Ukuran layar asli (termasuk area status/navigasi), bukan displayMetrics yang tanpa bar sistem. */
    fun realScreenRes(): Pair<Int, Int>? = runCatching {
        val pt = android.graphics.Point()
        @Suppress("DEPRECATION")
        appCtx?.getSystemService(DisplayManager::class.java)?.getDisplay(0)?.getRealSize(pt)
        if (pt.x > 0 && pt.y > 0) pt.x to pt.y else null
    }.getOrNull()

    /** Cari layer milik paket game (utamakan SurfaceView), ambil ukuran activeBuffer-nya. Null bila tidak terbaca. */
    private fun parseGameRes(txt: String, pkg: String, normalize: Boolean = true): Pair<Int, Int>? {
        if (txt.isEmpty()) return null
        var best: Pair<Int, Int>? = null; var bestScore = -1L
        var header: String? = null; var found: Pair<Int, Int>? = null
        fun flush() {
            val h = header ?: return; val f = found ?: return
            if (!h.contains(pkg) || h.contains("Background for")) return
            val score = (if (h.contains("SurfaceView")) 1L shl 40 else 0L) + f.first.toLong() * f.second
            if (score > bestScore) { bestScore = score; best = f }
        }
        for (l in txt.lineSequence()) {
            if (l.startsWith("+ ") || l.startsWith("* ")) { flush(); header = l; found = null; continue }
            if (header == null || found != null) continue
            val m = BUF_RE.find(l) ?: BUF_RE2.find(l) ?: continue
            val w = m.groupValues[1].toIntOrNull() ?: continue; val h2 = m.groupValues[2].toIntOrNull() ?: continue
            if (w >= 100 && h2 >= 100) found = w to h2
        }
        flush()
        var r: Pair<Int, Int>? = best
        var src = "activeBuffer"
        if (r == null) { r = hwcSourceCrop(txt, pkg); src = "HWC crop" }
        if (r == null) { r = snapshotBufferSize(txt, pkg); src = "bufferSize" }
        if (r == null) {
            val hits = txt.lineSequence().filter { it.contains(pkg) }.toList()
            val sample = hits.take(2).joinToString(" | ") { it.trim().take(90) }
            resDbg = "tidak terbaca ($pkg, ${txt.length} karakter, ${hits.size} baris cocok) $sample"
            return null
        }
        resDbg = "$src ${r.first}x${r.second}"
        if (!normalize) return r
        // Samakan orientasi dengan layar saat ini (buffer kadang dilaporkan terputar)
        val pt = android.graphics.Point()
        @Suppress("DEPRECATION")
        appCtx?.getSystemService(DisplayManager::class.java)?.getDisplay(0)?.getRealSize(pt)
        val hi = maxOf(r.first, r.second); val lo = minOf(r.first, r.second)
        return if (pt.x == 0 && pt.y == 0) r else if (pt.x >= pt.y) hi to lo else lo to hi
    }

    @Volatile private var transDbg = "-"
    private var prevTrans: Map<Long, Long>? = null
    private var prevTransDir = ""

    /**
     * Frekuensi GPU rata-rata selama ~1 detik terakhir dari devfreq trans_stat (waktu tiap frekuensi, ms).
     * Hasil = jumlah(frekuensi x selisih waktu) / jumlah selisih waktu, jadi ikut naik-turun mengikuti beban,
     * tidak menempel di satu angka seperti pembacaan sesaat. -1 bila trans_stat tidak ada / belum ada selisih.
     */
    private fun transAvg(block: String): Int {
        var dir = ""; val cur = LinkedHashMap<Long, Long>()
        val row = Regex("^\\*?\\s*(\\d+):\\s*(.*)$")
        for (raw in block.lines()) {
            val l = raw.trim()
            if (l.startsWith("##")) { if (cur.isNotEmpty()) break; dir = l.drop(2); continue }
            val m = row.find(l) ?: continue
            val f = m.groupValues[1].toLongOrNull() ?: continue
            val t = m.groupValues[2].trim().split(Regex("\\s+")).mapNotNull { it.toLongOrNull() }.lastOrNull() ?: continue
            cur[f] = t
        }
        if (cur.isEmpty()) { transDbg = "tidak ada"; prevTrans = null; return -1 }
        val prev = prevTrans
        prevTrans = cur; val sameDir = prevTransDir == dir; prevTransDir = dir
        if (prev == null || !sameDir) { transDbg = "${dir.substringAfter("/sys/")}: mengukur..."; return -1 }
        var tot = 0L; var sum = 0.0
        val parts = ArrayList<String>()
        val used = ArrayList<Pair<Double, Long>>()
        for ((f, t) in cur) {
            val d = t - (prev[f] ?: t)
            if (d <= 0) continue
            val mhz = when { f >= 10_000_000L -> f / 1e6; f >= 10_000L -> f / 1e3; else -> f.toDouble() }
            tot += d; sum += mhz * d; parts.add("%.0f:%dms".format(mhz, d)); used.add(mhz to d)
        }
        if (tot < 300L) { transDbg = "${dir.substringAfter("/sys/")}: selisih waktu kecil ($tot ms)"; return -1 }
        val avg = Math.round(sum / tot).toInt()
        // Puncak = frekuensi tertinggi yang dipakai minimal 5% dari jendela (min 40 ms), supaya lonjakan sesaat tidak dihitung
        val peak = used.filter { it.second >= maxOf(40L, tot / 20) }.maxOfOrNull { it.first }?.let { Math.round(it).toInt() } ?: avg
        transDbg = "${dir.substringAfter("/sys/")}: ${parts.joinToString(" ")} -> rata2 $avg, puncak $peak MHz"
        return if (peak in 100..3500) peak else -1
    }

    /**
     * Dump semua node GPU yang mungkin ada (Adreno / Mali / MediaTek gpufreq + GED) beserta isinya, untuk mencari
     * node yang benar di HP tertentu. Dijalankan sekali saat tombol "Probe GPU" ditekan, bukan tiap detik.
     */
    fun gpuProbe(): String {
        if (Shell.mode() == "-") return ""
        val cmd = "for d in /proc/gpufreqv2 /proc/gpufreq /sys/kernel/ged/hal /sys/kernel/gpu /sys/class/devfreq /sys/class/kgsl/kgsl-3d0; do " +
            "echo \"## ls \$d\"; ls \$d 2>&1 | head -80; done; " +
            "for f in /proc/gpufreqv2/gpufreq_status /proc/gpufreqv2/gpu_working_opp_table /proc/gpufreq/gpufreq_var_dump " +
            "/sys/kernel/ged/hal/current_freqency /sys/kernel/ged/hal/gpu_utilization /sys/kernel/ged/hal/total_gpu_freq " +
            "/sys/kernel/gpu/gpu_clock /sys/kernel/gpu/gpu_busy /sys/class/devfreq/*/cur_freq /sys/class/devfreq/*/min_freq " +
            "/sys/class/devfreq/*/max_freq /sys/class/devfreq/*/governor /sys/class/kgsl/kgsl-3d0/gpuclk; do " +
            "[ -e \$f ] && { echo \"## \$f\"; cat \$f 2>&1 | head -c 1800; echo; }; done; " +
            "echo \"## getprop\"; getprop ro.board.platform; getprop ro.hardware; getprop ro.product.model"
        return Shell.exec(cmd).take(16000)
    }

    @Volatile private var gpuFreqDbg = "-"
    @Volatile private var gpuLimDbg = "-"
    @Volatile private var gpuLoadDbg = "-"

    /**
     * Baca frekuensi GPU dari beberapa jalur (urutan = prioritas). Tiap jalur dibaca 4x per tick (jarak 50 ms)
     * dan diambil nilai tertingginya, supaya lonjakan frekuensi dalam satu detik ikut terbaca dan angkanya
     * tidak terlihat macet. Satuan ditebak per jalur: Hz (>=10 juta), kHz (>=10 ribu), selain itu MHz.
     * Hanya nilai 100..3500 MHz yang diterima, supaya jalur bus/bandwidth tidak terbaca sebagai MHz.
     */
    private val gpuHist = HashMap<String, ArrayDeque<Int>>()
    @Volatile private var gpuPickPath: String? = null

    private fun parseGpuFreq(block: String): Int {
        val mhzBy = LinkedHashMap<String, MutableList<Int>>()
        val rawBy = LinkedHashMap<String, MutableList<String>>()
        for (l in block.lines()) {
            if (l.indexOf(':') <= 0) continue
            // GPUFREQV2:<baris asli> : ambil angka kHz pada baris yang menyebut cur/current/real freq
            if (l.startsWith("GPUFREQV2:")) {
                val body = l.substring(10)
                if (!Regex("(?i)(cur|real|now|actual)").containsMatchIn(body)) continue
                val kHz = Regex("\\d{5,8}").findAll(body).mapNotNull { it.value.toLongOrNull() }.firstOrNull() ?: continue
                val mhz = (if (kHz >= 10_000_000L) kHz / 1_000_000 else kHz / 1000).toInt()
                mhzBy.getOrPut("gpufreqv2") { ArrayList() }.add(mhz)
                rawBy.getOrPut("gpufreqv2") { ArrayList() }.add(body.trim().take(40))
                continue
            }
            val i = l.lastIndexOf(':')
            val path = l.substring(0, i); val raw = l.substring(i + 1).trim()
            val nums = Regex("\\d+").findAll(raw).mapNotNull { it.value.toLongOrNull() }.toList()
            if (nums.isEmpty()) continue
            // current_freqency (GED MediaTek) berformat "indeks kHz": ambil angka terbesar; lainnya angka pertama
            val v = if (path.endsWith("current_freqency")) nums.max() else nums[0]
            val mhz = when {
                path.endsWith("gpu_clock") || path.endsWith("clock_mhz") -> v
                v >= 10_000_000L -> v / 1_000_000
                v >= 10_000L -> v / 1000
                else -> v
            }.toInt()
            mhzBy.getOrPut(path) { ArrayList() }.add(mhz)
            rawBy.getOrPut(path) { ArrayList() }.add(raw)
        }
        // Nilai tiap sumber pada tick ini = sampel TERAKHIR yang valid (nilai paling baru, bukan puncak).
        val cur = LinkedHashMap<String, Int>()
        for ((path, list) in mhzBy) list.lastOrNull { it in 100..3500 }?.let { cur[path] = it }
        // Deteksi sumber macet: simpan 8 tick terakhir per sumber.
        for ((path, v) in cur) { val h = gpuHist.getOrPut(path) { ArrayDeque() }; h.addLast(v); while (h.size > 8) h.removeFirst() }
        fun stuck(path: String) = gpuHist[path]?.let { it.size >= 8 && it.distinct().size == 1 } ?: false
        fun moving(path: String) = gpuHist[path]?.let { it.size >= 8 && it.distinct().size > 1 } ?: false
        // Prioritas biasa; bila sumber teratas macet padahal ada sumber lain yang bergerak, pakai yang bergerak.
        // MediaTek: GED current_freqency didahulukan, lalu gpufreqv2 (di Dimensity bisa 26 MHz saat GPU tidur), baru sumber lain.
        val ordered = cur.keys.sortedBy { when { it.endsWith("current_freqency") -> 0; it == "gpufreqv2" -> 2; else -> 1 } }
        var pickPath = ordered.firstOrNull()
        if (pickPath != null && stuck(pickPath)) ordered.firstOrNull { moving(it) }?.let { pickPath = it }
        gpuPickPath = pickPath
        val pick = pickPath?.let { cur[it] } ?: -1
        val seen = mhzBy.keys.map { p ->
            val flag = if (stuck(p)) " [MACET]" else if (moving(p)) " [bergerak]" else ""
            "${p.substringAfter("/sys/").take(40)}=${rawBy[p]!!.distinct().joinToString("/")}$flag"
        }
        gpuFreqDbg = if (seen.isEmpty()) "tidak ada jalur terbaca" else seen.joinToString("; ") +
            " -> " + (if (pick >= 0) "$pick MHz (${pickPath!!.substringAfterLast('/')})" else "tidak valid")
        return pick
    }

    @Volatile private var cpuFreqDbg = "-"

    /**
     * Frekuensi CPU: scaling_cur_freq (sama dengan yang dibaca DevCheck dan kebanyakan aplikasi), tertinggi antar inti.
     * cpuinfo_cur_freq hanya dipakai bila scaling_cur_freq tidak terbaca; nilainya ikut ditampilkan di Diagnostik
     * sebagai "(i...)" bila berbeda, karena di MediaTek kedua node ini bisa jauh berbeda.
     */
    private fun parseCpuFreq(block: String): Int {
        var best = -1; val parts = ArrayList<String>()
        for (l in block.lines()) {
            val f = l.trim().split(':'); if (f.size < 2 || !f[0].startsWith("cpu")) continue
            val scaling = f[1].trim().toLongOrNull()?.takeIf { it > 0 }
            val info = f.getOrNull(2)?.trim()?.toLongOrNull()?.takeIf { it > 0 }
            val kHz = scaling ?: info ?: continue
            val mhz = (kHz / 1000).toInt()
            parts.add("${f[0].removePrefix("cpu")}=$mhz" + if (info != null && info != kHz) "(i${info / 1000})" else "")
            if (mhz in 100..5000 && mhz > best) best = mhz
        }
        cpuFreqDbg = if (parts.isEmpty()) "tidak terbaca" else parts.joinToString(" ") + " -> $best MHz"
        return best
    }

    /** Frekuensi tiap inti, urut nomor inti; inti yang mati / tidak terbaca = -1. */
    private fun parseCoreFreqs(block: String): List<Int> {
        val m = java.util.TreeMap<Int, Int>()
        for (l in block.lines()) {
            val f = l.trim().split(':'); if (f.size < 2 || !f[0].startsWith("cpu")) continue
            val idx = f[0].removePrefix("cpu").toIntOrNull() ?: continue
            val kHz = f[1].trim().toLongOrNull()?.takeIf { it > 0 } ?: f.getOrNull(2)?.trim()?.toLongOrNull()?.takeIf { it > 0 }
            m[idx] = if (kHz != null) (kHz / 1000).toInt() else -1
        }
        if (m.isEmpty()) return emptyList()
        return (0..m.lastKey()).map { m[it] ?: -1 }
    }

    private var fpsDbg = "-"
    @Volatile private var curPkg = ""
    @Volatile private var pinPkg: String? = null
    private var halCache: Hal? = null; private var halAt = -10_000L; private var halOkAt = -100_000L
    private var lastFps = 0; private var lastFpsPkg = ""; private var zeroTicks = 0
    private val HOLD_TICKS = 3
    private val IDLE_FPS = 15          // di bawah ini pada aplikasi non-game = layar statis, bukan "FPS rendah"
    @Volatile private var surfaceApp = false   // layer SurfaceView = game / video, menggambar terus-menerus

    private fun displayHz(): Int = runCatching {
        appCtx?.getSystemService(DisplayManager::class.java)?.getDisplay(0)?.refreshRate?.let { Math.round(it) }
    }.getOrNull() ?: -1
    // Paket yang bukan target pengukuran: shade notifikasi / SystemUI.
    private val SKIP_PKGS = setOf("com.android.systemui", "android", "com.miui.screenrecorder", "com.miui.securitycenter", "com.miui.gamebooster")
    /** Paket yang bukan target: SystemUI, keyboard, perekam layar, sidebar Game Turbo, dan PulseMonitor sendiri. */
    fun isIgnoredPkg(p: String, own: String) = p.isEmpty() || p == own || p in SKIP_PKGS ||
        p.contains("inputmethod") || p.contains("screenrecord") || p.contains("gamebooster")
    /** Aplikasi terakhir yang benar-benar di depan (bukan SystemUI/keyboard/perekam layar). */
    fun lastGamePkg(): String = lastGame

    private var focusCache = ""; private var focusAt = -10_000L
    /** Dipanggil tepat sebelum Recorder.start(): paksa baca ulang fokus supaya game langsung terkunci, tanpa menunggu cache 2 detik. */
    fun onRecordStart() { focusAt = -10_000L; pinPkg = null; onRecordStartRes() }
    private var lastGame = ""; private var lastGameAt = 0L

    private fun focusPkg(): String? {
        val outs = listOf(
            Shell.exec("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp' | head -6"),
            Shell.exec("dumpsys activity activities | grep -E 'topResumedActivity|ResumedActivity' | head -4")
        )
        for (o in outs) for (l in o.lines()) {
            if (l.contains("=null")) continue
            Regex("u\\d+ ([\\w.]+)/").find(l)?.let { return it.groupValues[1] }
        }
        return null
    }

    /**
     * Paket yang diukur. Fokus dibaca tiap 2 detik saja (dumpsys window menahan kunci sistem).
     * Fokus sementara ke SystemUI / keyboard / PulseMonitor sendiri diabaikan selama 20 detik
     * setelah game terakhir di depan; saat merekam, paket dikunci (pinPkg).
     */
    private fun targetPkg(): String? {
        pinPkg?.let { return it }
        val now = SystemClock.elapsedRealtime()
        if (now - focusAt >= 2000L) { focusCache = focusPkg() ?: ""; focusAt = now }
        val p = focusCache
        val transient = isIgnoredPkg(p, appCtx?.packageName ?: "")
        if (!transient) { lastGame = p; lastGameAt = now; return p }
        if (lastGame.isNotEmpty() && now - lastGameAt < 20_000L) return lastGame
        return p.ifEmpty { null }
    }

    private class Ts(val at: Long, val total: Map<String, Long>, val queued: Map<String, Long>)
    private val tsWin = ArrayDeque<Ts>()
    private var tsReady = false
    @Volatile private var presentFps = 0f
    @Volatile private var queuedFps = 0f

    /**
     * SurfaceFlinger TimeStats per layer: totalFrames (frame yang benar-benar tampil di layar) dan
     * droppedFrames (frame yang diserahkan game tetapi dilewati karena layar sedang lebih lambat).
     * Waktu sampel = titik tengah eksekusi dumpsys, bukan sesudahnya, supaya jeda eksekusi
     * yang berubah-ubah tidak membuat selisih waktu (dan FPS) melenceng.
     */
    private fun timestats(): Ts {
        if (!tsReady) { Shell.exec("dumpsys SurfaceFlinger --timestats -clear -enable"); tsReady = true; tsWin.clear() }
        val t0 = SystemClock.elapsedRealtime()
        val txt = Shell.exec("dumpsys SurfaceFlinger --timestats -dump")
        val at = (t0 + SystemClock.elapsedRealtime()) / 2
        val total = HashMap<String, Long>(); val queued = HashMap<String, Long>()
        var name: String? = null
        for (l in txt.lines()) {
            val t = l.trim()
            val v = t.substringAfter('=', "").trim().toLongOrNull()
            when {
                t.startsWith("layerName") -> name = t.substringAfter('=').trim()
                name != null && v != null && t.startsWith("totalFrames") -> { total[name!!] = v; queued[name!!] = (queued[name!!] ?: 0L) + v }
                name != null && v != null && t.startsWith("droppedFrames") -> queued[name!!] = (queued[name!!] ?: 0L) + v
            }
        }
        if (total.isEmpty()) tsReady = false   // statistik belum aktif/ter-reset: aktifkan lagi di tick berikutnya
        return Ts(at, total, queued)
    }

    /** Paket (bukan PulseMonitor/SystemUI/keyboard) dengan frame paling banyak diserahkan dalam jendela terakhir; null bila tidak ada yang aktif. */
    private fun busiestLayerPkg(cur: Ts, own: String): String? {
        val base = tsWin.first()
        val dt = (cur.at - base.at) / 1000f
        if (dt < 0.3f) return null
        val rx = Regex("([A-Za-z][A-Za-z0-9_]*(?:\\.[A-Za-z0-9_]+)+)/")
        var best: String? = null; var bestRate = 0f
        for ((k, q1) in cur.queued) {
            val q0 = base.queued[k] ?: continue
            if (q1 < q0) continue
            val pk = rx.find(k)?.groupValues?.get(1) ?: continue
            if (isIgnoredPkg(pk, own)) continue
            var rate = (q1 - q0) / dt
            if (k.startsWith("SurfaceView")) rate += 1f   // lapisan game (SurfaceView) menang bila seri dengan UI biasa
            if (rate > bestRate) { bestRate = rate; best = pk }
        }
        return best?.takeIf { bestRate >= 5f }
    }

    /**
     * FPS = frame yang diserahkan game per detik (total + dropped) dari layer game, jendela ~2,5 detik.
     * Memakai angka ini (bukan hanya frame yang tampil) karena saat layar tidak disentuh panel sering
     * menurunkan refresh rate; frame game yang dilewati tidak boleh dihitung sebagai FPS rendah.
     * Cadangan bila layer tidak ada: --latency.
     */
    private fun fps(): Pair<Int, Int> {
        val focus = targetPkg()
        val own = appCtx?.packageName ?: ""
        val cur = timestats()
        tsWin.addLast(cur)
        while (tsWin.size > 1 && cur.at - tsWin.first().at > 2500L) tsWin.removeFirst()
        // Fokus jatuh ke PulseMonitor sendiri / SystemUI (mis. PulseMonitor dibuka sebagai jendela kecil di atas game,
        // atau layar terbelah): game di belakangnya tetap menggambar. Pakai paket dari layer yang paling aktif.
        var found: String? = null
        if (focus == null || isIgnoredPkg(focus, own)) {
            found = busiestLayerPkg(cur, own)
            if (found != null && Recorder.active.value && pinPkg == null) pinPkg = found
        }
        val pkg: String? = found ?: focus
        curPkg = pkg ?: ""
        if (pkg == null) { fpsDbg = "aplikasi fokus tidak terbaca"; return 0 to 0 }
        val cand = cur.total.keys.filter { it.contains(pkg) }
        val base = tsWin.first()
        val dt = (cur.at - base.at) / 1000f
        var bestQ = 0f; var bestP = 0f
        if (dt >= 0.3f) for (k in cand) {
            val p0 = base.total[k] ?: continue
            val q0 = base.queued[k] ?: continue
            val p1 = cur.total[k] ?: continue; val q1 = cur.queued[k] ?: continue
            if (p1 >= p0 && q1 >= q0) { bestP = maxOf(bestP, (p1 - p0) / dt); bestQ = maxOf(bestQ, (q1 - q0) / dt) }
        }
        presentFps = bestP; queuedFps = bestQ
        surfaceApp = cand.any { it.startsWith("SurfaceView") }
        if (cand.isNotEmpty()) {
            fpsDbg = "$pkg | ${cand.size} layer${if (surfaceApp) " (SurfaceView)" else ""} | tampil %.0f, diserahkan %.0f | layar %d Hz%s".format(
                bestP, bestQ, displayHz(), if (pinPkg != null) " | terkunci" else "")
            return Math.round(bestQ) to 0
        }
        surfaceApp = false
        val lat = fpsLatency(pkg)
        fpsDbg = "timestats: $pkg tidak ada (${cur.total.size} layer) -> latency: $fpsDbg"
        return lat
    }

    // ---------- SUHU ----------
    @Volatile private var appCtx: Context? = null
    fun init(c: Context) { appCtx = c.applicationContext; Access.init(c) }

    private class Temps {
        var cpu = -1f; var gpu = -1f; var bat = -1f; var skin = -1f; var soc = -1f
        fun put(kind: String, v: Float) {
            when (kind) {
                "cpu" -> cpu = maxOf(cpu, v); "gpu" -> gpu = maxOf(gpu, v); "bat" -> bat = maxOf(bat, v)
                "skin" -> skin = maxOf(skin, v); "soc" -> soc = maxOf(soc, v)
            }
        }
    }
    private class Hal(val t: Temps, val n: Int)

    /** Satuan sysfs bisa milli-derajat (42000), desi-derajat (420), atau derajat (42). */
    private fun norm(raw: Float) = when { raw >= 1000f -> raw / 1000f; raw > 150f -> raw / 10f; else -> raw }

    /** Suhu baterai dari broadcast sticky BATTERY_CHANGED (satuan 1/10 °C). Tanpa izin, tanpa Shizuku/root. */
    private fun batteryTemp(): Float {
        val i = runCatching { appCtx?.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) }.getOrNull()
            ?: return -1f
        val raw = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        if (raw == Int.MIN_VALUE) return -1f
        return (raw / 10f).takeIf { it in 1f..100f } ?: -1f
    }

    /** Persen baterai dari broadcast sticky BATTERY_CHANGED. */
    private fun batteryPct(): Int {
        val i = runCatching { appCtx?.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) }.getOrNull() ?: return -1
        val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1); val sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        return if (l >= 0 && sc > 0) l * 100 / sc else -1
    }

    /** Daya (Watt) = |arus baterai| x tegangan. Satuan arus beda-beda antar HP (µA atau mA), ditebak dari besarnya. -1 bila tidak terbaca. */
    private fun batteryWatt(): Float {
        val ctx = appCtx ?: return -1f
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager ?: return -1f
        val raw = runCatching { bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) }.getOrDefault(0)
        if (raw == 0 || raw == Int.MIN_VALUE) return -1f
        val mv = runCatching {
            ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
        }.getOrNull() ?: 0
        if (mv <= 0) return -1f
        val a = Math.abs(raw.toLong())
        val amps = if (a > 20_000L) a / 1e6f else a / 1e3f
        return (amps * mv / 1000f).takeIf { it in 0f..60f } ?: -1f
    }

    /** Kelompokkan sensor: nama dulu (gpuss, cpuss, quiet_therm, ...), baru tipe HAL (0 CPU, 1 GPU, 2 BAT, 3 SKIN, 13 SOC). */
    private fun kindOf(type: Int, name: String): String? {
        val n = name.lowercase()
        return when {
            "gpu" in n || "g3d" in n || "mali" in n || "adreno" in n -> "gpu"
            "batt" in n -> "bat"
            "cpu" in n -> "cpu"
            "skin" in n || "quiet" in n -> "skin"
            else -> when (type) { 0 -> "cpu"; 1 -> "gpu"; 2 -> "bat"; 3 -> "skin"; 13 -> "soc"; else -> null }
        }
    }

    private val tempRe = Regex("Temperature\\{([^}]*mValue[^}]*)\\}")
    private val valRe = Regex("mValue\\s*=\\s*(-?[0-9.]+)")
    private val typeRe = Regex("mType\\s*=\\s*(-?\\d+)")
    private val nameRe = Regex("mName\\s*=\\s*([^,}]+)")
    private val halDown = Regex("(?i)hal\\s*ready:\\s*false")

    /** Semua sensor di `dumpsys thermalservice` (seksi "Current temperatures from HAL"). Null bila HAL belum siap/kosong. */
    private fun thermalHal(): Hal? {
        val out = Shell.exec("dumpsys thermalservice")
        if (out.isBlank() || halDown.containsMatchIn(out)) return null
        val i = out.indexOf("Current temperatures from HAL")
        var sec = if (i >= 0) out.substring(i) else out
        val j = sec.indexOf("Cached temperatures"); if (j > 0) sec = sec.substring(0, j)
        val t = Temps(); var n = 0
        for (m in tempRe.findAll(sec)) {
            val body = m.groupValues[1]
            val v = valRe.find(body)?.groupValues?.get(1)?.toFloatOrNull() ?: continue
            if (v !in 1f..150f) continue          // buang sensor tidak valid (NaN/0/-ribuan)
            val ty = typeRe.find(body)?.groupValues?.get(1)?.toIntOrNull() ?: -1
            val nm = nameRe.find(body)?.groupValues?.get(1)?.trim() ?: ""
            kindOf(ty, nm)?.let { t.put(it, v); n++ }
        }
        return if (n > 0) Hal(t, n) else null
    }

    /** Cadangan: /sys/class/thermal/thermal_zone*. Tidak memakai zona "soc" (di banyak HP itu persen baterai, bukan suhu). */
    private fun parseZones(block: String): Temps {
        val zType = HashMap<String, String>(); val zTemp = HashMap<String, Float>()
        for (l in block.lines()) {
            val m = Regex("thermal_zone(\\d+)/(type|temp):(.*)").find(l) ?: continue
            val (z, k, v) = m.destructured
            if (k == "type") zType[z] = v.trim() else v.trim().toFloatOrNull()?.let { zTemp[z] = norm(it) }
        }
        val t = Temps()
        for ((z, ty) in zType) {
            val v = zTemp[z]?.takeIf { it in 5f..120f } ?: continue
            kindOf(-1, ty)?.let { t.put(it, v) }
        }
        return t
    }

    /** FPS dari SurfaceFlinger latency layer aplikasi yang sedang fokus. Return (fps, 1% low). */
    private fun fpsLatency(pkg: String): Pair<Int, Int> {
        val all = Shell.exec("dumpsys SurfaceFlinger --list").lines().map { it.trim() }
            .filter { it.contains(pkg) && !it.startsWith("Background") }
        if (all.isEmpty()) { fpsDbg = "$pkg: layer tidak ditemukan"; return 0 to 0 }
        val ordered = all.sortedByDescending { (if (it.contains("SurfaceView")) 2 else 0) + (if (it.contains("BLAST")) 1 else 0) }
        for (layer in ordered.take(4)) {
            val rows = Shell.exec("dumpsys SurfaceFlinger --latency '$layer'").lines().drop(1)
                .map { it.trim().split(Regex("\\s+")) }
            for (col in intArrayOf(1, 2)) {
                val ts = rows.mapNotNull { it.getOrNull(col)?.toLongOrNull() }
                    .filter { it in 1 until Long.MAX_VALUE / 2 }.sorted()
                if (ts.size < 3) continue
                val recent = ts.filter { it >= ts.last() - 1_000_000_000L }
                if (recent.size < 2 || recent.last() == recent.first()) continue
                val fps = ((recent.size - 1) * 1e9 / (recent.last() - recent.first())).toInt()
                val deltas = ts.zipWithNext { a, b -> b - a }.filter { it > 0 }.sortedDescending()
                if (deltas.isEmpty()) continue
                val worst = deltas[(deltas.size / 100).coerceAtMost(deltas.size - 1)]
                fpsDbg = "$pkg | ${layer.take(36)} | ${ts.size} frame, kolom $col"
                return fps to (1e9 / worst).toInt()
            }
        }
        fpsDbg = "$pkg: ${ordered.size} layer, data latency kosong"
        return 0 to 0
    }
}
