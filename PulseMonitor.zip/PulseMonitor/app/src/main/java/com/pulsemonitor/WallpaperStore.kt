package com.pulsemonitor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import java.io.File

/** Menyimpan wallpaper latar aplikasi. Gambar disalin ke penyimpanan internal, jadi tidak
 *  bergantung pada izin galeri dan tetap ada walau file aslinya dihapus. */
object WallpaperStore {
    private const val MAX_SIDE = 1600   // sisi terpanjang setelah diperkecil, hemat RAM
    private const val PREFS = "pulse"
    private const val KEY_DIM = "dim"

    private fun file(c: Context) = File(c.filesDir, "wallpaper.jpg")

    fun save(c: Context, uri: Uri): Boolean = runCatching {
        // ImageDecoder otomatis memutar gambar sesuai EXIF dan mendukung downsample
        val src = ImageDecoder.createSource(c.contentResolver, uri)
        val bmp = ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE   // bitmap hardware tidak bisa di-compress
            var sample = 1
            while (maxOf(info.size.width, info.size.height) / sample > MAX_SIDE) sample *= 2
            if (sample > 1) decoder.setTargetSampleSize(sample)
        }
        val tmp = File(c.filesDir, "wallpaper.tmp")
        tmp.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        bmp.recycle()
        check(tmp.renameTo(file(c)) || (file(c).delete() && tmp.renameTo(file(c))))
    }.isSuccess

    fun load(c: Context): Bitmap? = file(c).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }

    fun clear(c: Context) { file(c).delete(); notifCache = null; notifColorCache = null }

    // Bitmap latar notifikasi: kecil (hemat memori RemoteViews), di-crop, diredupkan, sudut membulat. Disimpan di memori
    // selama gambar dan redupnya sama, karena notifikasi disegarkan tiap beberapa detik.
    private const val NW = 560; private const val NH = 240
    private var notifCache: Triple<Long, Float, Bitmap>? = null

    @Synchronized
    fun notifBitmap(c: Context): Bitmap? {
        val f = file(c).takeIf { it.exists() } ?: return null
        val d = dim(c)
        notifCache?.let { if (it.first == f.lastModified() && it.second == d) return it.third }
        val src = BitmapFactory.decodeFile(f.path) ?: return null
        val out = Bitmap.createBitmap(NW, NH, Bitmap.Config.ARGB_8888)
        val cv = android.graphics.Canvas(out)
        val scale = maxOf(NW.toFloat() / src.width, NH.toFloat() / src.height)
        val w = src.width * scale; val h = src.height * scale
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG or android.graphics.Paint.FILTER_BITMAP_FLAG)
        cv.drawBitmap(src, null, android.graphics.RectF((NW - w) / 2f, (NH - h) / 2f, (NW + w) / 2f, (NH + h) / 2f), paint)
        cv.drawColor(((d.coerceIn(0f, 1f) * 255).toInt() shl 24))     // redupkan: hitam transparan, supaya teks putih tetap terbaca
        // Pudarkan keempat tepi ke warna kartu (rata-rata gambar), jadi kotak gambar tidak terlihat dan kartu tampak satu gambar utuh
        val avg = averageColor(out)
        val fade = 56f
        fun edge(x0: Float, y0: Float, x1: Float, y1: Float, l: Float, t: Float, r: Float, b: Float) {
            val p = android.graphics.Paint().apply {
                shader = android.graphics.LinearGradient(x0, y0, x1, y1, avg, avg and 0x00FFFFFF, android.graphics.Shader.TileMode.CLAMP)
            }
            cv.drawRect(l, t, r, b, p)
        }
        val w2 = NW.toFloat(); val h2 = NH.toFloat()
        edge(0f, 0f, fade, 0f, 0f, 0f, fade, h2)
        edge(w2, 0f, w2 - fade, 0f, w2 - fade, 0f, w2, h2)
        edge(0f, 0f, 0f, fade, 0f, 0f, w2, fade)
        edge(0f, h2, 0f, h2 - fade, 0f, h2 - fade, w2, h2)
        notifColorCache = avg
        src.recycle()
        notifCache = Triple(f.lastModified(), d, out)
        return out
    }

    // Warna rata-rata bitmap notifikasi (sudah diredupkan). Dipakai sebagai warna latar seluruh kartu notifikasi
    // (header + tombol yang digambar sistem), supaya wallpaper terlihat menyatu dan "full".
    private var notifColorCache: Int? = null

    private fun averageColor(b: Bitmap): Int {
        var r = 0L; var g = 0L; var bl = 0L; var n = 0L
        val sx = maxOf(1, b.width / 24); val sy = maxOf(1, b.height / 12)
        var y = 0
        while (y < b.height) {
            var x = 0
            while (x < b.width) {
                val p = b.getPixel(x, y)
                if ((p ushr 24) > 200) { r += (p shr 16) and 0xFF; g += (p shr 8) and 0xFF; bl += p and 0xFF; n++ }
                x += sx
            }
            y += sy
        }
        if (n == 0L) return 0xFF202124.toInt()
        return (0xFF shl 24) or ((r / n).toInt() shl 16) or ((g / n).toInt() shl 8) or (bl / n).toInt()
    }

    /** Warna latar kartu notifikasi dari wallpaper; null bila tidak ada wallpaper. Panggil setelah notifBitmap(). */
    @Synchronized
    fun notifColor(c: Context): Int? { notifBitmap(c) ?: return null; return notifColorCache }

    fun dim(c: Context): Float = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getFloat(KEY_DIM, 0.6f)

    fun saveDim(c: Context, v: Float) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putFloat(KEY_DIM, v).apply()
    }
}
