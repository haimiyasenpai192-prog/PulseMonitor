package com.pulsemonitor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.max

/**
 * Overlay gaya "Normal": bilah horizontal per baris.
 *   FPS  60                       16.7ms
 *   CPU  [=======     ]         3300MHz     bilah = beban CPU
 *   GPU  [===========·]          702MHz     bilah = beban GPU
 *   BAT  [========    ]          76%        bilah = persen baterai
 *   TMP  [=====       ]          33.1°C     bilah = suhu baterai (skala 0-60°C)
 * (nama kelas dipertahankan dari versi cincin supaya OverlayService tidak perlu berubah)
 */
class RingOverlayView(ctx: Context) : View(ctx) {
    var snap = Snap()
    var rec = false
    var extra = ""                  // baris kecil opsional (Touch Hz / Touch ms) di bawah bilah
    var scale = 1f
    var bgColor = 0xEE101014.toInt()
    var strokeColor = 0x22FFFFFF
    var textColor = 0xFFFFFFFF.toInt()

    private val d = ctx.resources.displayMetrics.density
    private fun u(v: Float) = v * d * scale
    private val YEL = 0xFFFFD866.toInt()
    private val RED = 0xFFFF5C5C.toInt()

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val labP = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.LEFT }
    private val valP = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.RIGHT }
    private val bigP = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.LEFT }
    private val extraP = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.MONOSPACE; textAlign = Paint.Align.LEFT }
    private val rect = RectF()

    private class Row(val label: String, val pct: Int, val color: Int, val value: String)

    private fun batColor(p: Int) = when { p <= 15 -> RED; p <= 30 -> 0xFFFF9F43.toInt(); else -> 0xFF7CFFB2.toInt() }
    private fun tempColor(t: Float) = when { t >= 45f -> RED; t >= 40f -> YEL; else -> 0xFF7CFFB2.toInt() }
    private fun rows(): List<Row> {
        val s = snap; val off = withAlpha(textColor, 30)
        return listOf(
            Row("CPU", s.cpu, if (s.cpu >= 0) loadCol(s.cpu) else off, if (s.cpuMhz >= 0) "${s.cpuMhz}MHz" else "-"),
            Row("GPU", s.gpu, if (s.gpu >= 0) loadCol(s.gpu) else off, if (s.gpuMhz >= 0) "${s.gpuMhz}MHz" else "-"),
            Row("BAT", s.batPct, if (s.batPct >= 0) batColor(s.batPct) else off,
                if (s.batPct >= 0) "${s.batPct}%" else "-"),
            Row("TMP", if (s.tBat >= 0f) (s.tBat / 60f * 100f).toInt() else -1, if (s.tBat >= 0f) tempColor(s.tBat) else off,
                if (s.tBat >= 0f) String.format(Locale.US, "%.1f°C", s.tBat) else "-")
        )
    }

    private fun pad() = u(10f)
    private fun rowH() = u(16f)
    private fun rowGap() = u(6f)
    private fun labW() = u(32f)
    private fun barW() = u(86f)
    private fun gap() = u(8f)
    private fun valW(): Float { valP.textSize = u(11f); return max(valP.measureText("0000MHz"), valP.measureText("00.0°C")) }

    private fun msText(): String =
        if (snap.idle) "idle" else if (snap.fps > 0) String.format(Locale.US, "%.1fms", 1000f / snap.fps) else ""

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        var w = pad() * 2 + labW() + barW() + gap() + valW()
        var h = pad() * 2 + rowH() * 5 + rowGap() * 4
        if (extra.isNotEmpty()) {
            extraP.textSize = u(9f)
            h += extraP.fontSpacing + u(4f)
            w = max(w, pad() * 2 + extraP.measureText(extra))
        }
        setMeasuredDimension(ceil(w).toInt(), ceil(h).toInt())
    }

    private fun baseFor(cy: Float, paint: Paint) = cy - (paint.ascent() + paint.descent()) / 2f

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val rad = u(14f)
        p.style = Paint.Style.FILL; p.color = bgColor
        rect.set(0f, 0f, w, h); c.drawRoundRect(rect, rad, rad, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = d; p.color = strokeColor
        rect.set(d / 2, d / 2, w - d / 2, h - d / 2); c.drawRoundRect(rect, rad, rad, p)

        val x0 = pad(); val xBar = x0 + labW(); val xVal = xBar + barW() + gap() + valW()
        labP.textSize = u(11f); labP.color = textColor
        valP.textSize = u(11f); valP.color = YEL
        bigP.textSize = u(13f); bigP.color = textColor

        // Baris FPS: label, angka tebal, frametime di kolom kanan; titik merah saat merekam
        var cy = pad() + rowH() / 2f
        c.drawText("FPS", x0, baseFor(cy, labP), labP)
        var tx = xBar
        if (rec) { p.style = Paint.Style.FILL; p.color = RED; c.drawCircle(tx + u(3f), cy, u(3f), p); tx += u(10f) }
        c.drawText("${snap.fps}", tx, baseFor(cy, bigP), bigP)
        c.drawText(msText(), xVal, baseFor(cy, valP), valP)

        // Baris CPU / GPU / BAT: bilah tipis berujung bulat
        val bh = u(6f)
        rows().forEachIndexed { i, r ->
            cy = pad() + rowH() * (i + 1) + rowGap() * (i + 1) + rowH() / 2f
            labP.color = textColor
            c.drawText(r.label, x0, baseFor(cy, labP), labP)
            p.style = Paint.Style.FILL
            p.color = withAlpha(textColor, 16)
            rect.set(xBar, cy - bh / 2f, xBar + barW(), cy + bh / 2f); c.drawRoundRect(rect, bh / 2f, bh / 2f, p)
            if (r.pct > 0) {
                p.color = r.color
                val fw = max(bh, barW() * r.pct.coerceIn(0, 100) / 100f)
                rect.set(xBar, cy - bh / 2f, xBar + fw, cy + bh / 2f); c.drawRoundRect(rect, bh / 2f, bh / 2f, p)
            }
            valP.color = YEL
            c.drawText(r.value, xVal, baseFor(cy, valP), valP)
        }

        if (extra.isNotEmpty()) {
            extraP.textSize = u(9f); extraP.color = withAlpha(textColor, 65)
            c.drawText(extra, x0, h - pad() - extraP.descent() + u(1f), extraP)
        }
    }
}
