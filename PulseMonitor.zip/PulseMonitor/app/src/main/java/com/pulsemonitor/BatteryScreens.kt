package com.pulsemonitor

import android.content.Context
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import android.graphics.Bitmap
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.layout.ContentScale
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val BgB = Color(0xFF101014)
private val CardB = Color(0xFF1D1E24)
private val ChipB = Color(0xFF262833)
// Warna kartu mengikuti ada/tidaknya wallpaper: solid bila tanpa wallpaper, transparan (sama seperti kartu di Beranda) bila ada
private val LocalCardB = compositionLocalOf { CardB }
private val LocalChipB = compositionLocalOf { ChipB }
private val WallBg = Color(0xFF0C0C0E)

/** Latar halaman: wallpaper aplikasi + lapisan gelap (sama seperti Beranda), atau warna polos bila belum ada wallpaper. */
@Composable
private fun WallpaperPage(wallpaper: Bitmap?, dim: Float, content: @Composable () -> Unit) {
    Box(Modifier.fillMaxSize().background(BgB)) {
        if (wallpaper != null) {
            Image(wallpaper.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop,
                filterQuality = androidx.compose.ui.graphics.FilterQuality.High)
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
                listOf(WallBg.copy(alpha = dim * 0.12f), WallBg.copy(alpha = dim * 0.8f)))))
        }
        CompositionLocalProvider(
            LocalCardB provides (if (wallpaper != null) Color(0xFF1E1F26).copy(alpha = 0.30f) else CardB),
            LocalChipB provides (if (wallpaper != null) Color(0xFF2A2C36).copy(alpha = 0.45f) else ChipB),
        ) { content() }
    }
}
private val MutedB = Color.White
private val BlueB = Color(0xFF4C8DFF)
private val GreenB = Color(0xFF4CC38A)
private val AmberB = Color(0xFFF5B83D)
private val BarB = Color(0xFFAAB8FF)

private fun durHm(sec: Int): String {
    val h = sec / 3600; val m = (sec % 3600) / 60; val s = sec % 60
    return if (h > 0) "${h}j ${m}m" else if (m > 0) "${m}m ${s}d" else "${s}d"
}

private fun durMs(ms: Long): String {
    val t = ms / 1000; val h = t / 3600; val m = (t % 3600) / 60; val s = t % 60
    return if (h > 0) "${h}j ${m}m" else if (m > 0) "${m}m ${s}d" else "${s}d"
}

private fun pctTxt(v: Float) = if (v >= 0f) "%.0f%%".format(v) else "-"

private fun whenTxt(id: Long): String = SimpleDateFormat("d MMM · HH:mm", Locale.getDefault()).format(Date(id))

@Composable
private fun TopBar(onBack: () -> Unit, trailing: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(Modifier.size(44.dp).clip(CircleShape).clickable { onBack() }, contentAlignment = Alignment.Center) {
            Text("←", color = Color.White, fontSize = 26.sp)
        }
        Spacer(Modifier.weight(1f))
        trailing()
    }
}

@Composable
private fun SmallPill(text: String, bg: Color = LocalCardB.current, onClick: () -> Unit) {
    Box(Modifier.clip(CircleShape).background(bg).clickable { onClick() }.padding(horizontal = 16.dp, vertical = 9.dp)) {
        Text(text, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun StatCell(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = MutedB, fontSize = 11.sp, maxLines = 1)
        Text(value, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.padding(top = 2.dp))
    }
}

private const val CYCLE_MS = 24 * 3_600_000L

private fun timeTxt(id: Long): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(id))

private fun tintOf(s: BatSession): Color = if (s.open) BlueB else if (s.charging) GreenB else AmberB

/** Awal siklus 24 jam. Disimpan, dan dimulai ulang (reset) begitu sudah lewat 24 jam. Data sesi di penyimpanan tidak dihapus. */
private fun cycleStart(ctx: Context, all: List<BatSession>): Long {
    val p = ctx.getSharedPreferences("battery_cycle", Context.MODE_PRIVATE)
    val now = System.currentTimeMillis()
    var start = p.getLong("start", 0L)
    if (start == 0L) {
        start = all.map { it.id }.filter { it >= now - CYCLE_MS }.minOrNull() ?: now
        p.edit().putLong("start", start).apply()
    } else if (now - start >= CYCLE_MS) {
        start = now
        p.edit().putLong("start", start).apply()
    }
    return start
}

/** Daftar sesi baterai dalam satu siklus 24 jam: grafik batang perubahan level di atas, lalu daftar ringkas. */
@Composable
fun BatteryListScreen(onBack: () -> Unit, onOpen: (Long) -> Unit, wallpaper: Bitmap? = null, dim: Float = 0.6f) {
    val ctx = LocalContext.current
    val ver by BatteryHistory.version.collectAsState()
    val data by produceState<Pair<List<BatSession>, Long>?>(null, ver / 3) {
        value = withContext(Dispatchers.IO) {
            val all = BatteryHistory.list(ctx)
            val st = cycleStart(ctx, all)
            all.filter { it.open || it.id >= st } to st
        }
    }
    val d = data
    WallpaperPage(wallpaper, dim) {
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
        .verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        TopBar(onBack)
        Text("Riwayat baterai", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Menampilkan 24 jam terakhir, lalu reset otomatis dan mulai lagi dari awal. Direkam selama aplikasi dibuka, dan terus berlanjut di latar belakang bila overlay atau notifikasi aktif. Ketuk sesi untuk melihat grafik dan pemakaian per aplikasi.",
            color = MutedB, fontSize = 12.sp, lineHeight = 16.sp)
        if (d == null) Text("Memuat…", color = MutedB, modifier = Modifier.padding(top = 12.dp))
        else if (d.first.isEmpty()) Text("Belum ada sesi. Sesi mulai terekam otomatis begitu aplikasi terbuka, tunggu beberapa detik lalu buka lagi halaman ini.",
            color = MutedB, fontSize = 13.sp, modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp), textAlign = TextAlign.Center)
        else {
            ChangeChart(d.first, d.second)
            d.first.forEach { SessionRow(it) { onOpen(it.id) } }
        }
    }
    }
}

/** Batang perubahan level tiap sesi (maksimal 8 sesi terbaru), warna mengikuti status sesi. */
@Composable
private fun ChangeChart(l: List<BatSession>, start: Long) {
    val bars = l.sortedBy { it.id }.takeLast(8)
    val left = (start + CYCLE_MS - System.currentTimeMillis()).coerceAtLeast(0L)
    Column(Modifier.fillMaxWidth().background(LocalCardB.current, RoundedCornerShape(18.dp))
        .padding(start = 14.dp, end = 14.dp, top = 12.dp, bottom = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Perubahan level per sesi", color = MutedB, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text("Reset ${durHm((left / 1000L).toInt())}", color = MutedB, fontSize = 11.sp)
        }
        Row(Modifier.fillMaxWidth().height(96.dp).padding(top = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Bottom) {
            bars.forEach { s ->
                val delta = if (s.startPct >= 0f && s.endPct >= 0f) s.endPct - s.startPct else 0f
                val h = (kotlin.math.abs(delta) / 100f * 56f).coerceAtLeast(4f)
                val sign = if (delta > 0f) "+" else if (delta < 0f) "−" else ""
                Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Bottom) {
                    Text("$sign${kotlin.math.abs(delta).toInt()}%", color = Color.White, fontSize = 11.sp, maxLines = 1)
                    Spacer(Modifier.height(3.dp))
                    Box(Modifier.width(24.dp).height(h.dp).background(tintOf(s),
                        RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp, bottomStart = 2.dp, bottomEnd = 2.dp)))
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            bars.forEach { s ->
                Text(timeTxt(s.id), color = MutedB, fontSize = 10.sp, maxLines = 1, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun SessionRow(s: BatSession, onClick: () -> Unit) {
    val status = if (s.open) "Berjalan" else if (s.charging) "Mengisi" else "Terpakai"
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(LocalCardB.current).clickable { onClick() }
        .padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(timeTxt(s.id), color = Color.White, fontWeight = FontWeight.Medium, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Text("${pctTxt(s.startPct)} → ${pctTxt(s.endPct)}", color = MutedB, fontSize = 12.sp, modifier = Modifier.padding(end = 10.dp))
        Text(status, color = tintOf(s), fontSize = 12.sp)
    }
}

private fun durLong(sec: Int): String {
    val h = sec / 3600; val m = (sec % 3600) / 60; val sc = sec % 60
    return if (h > 0) "${h}j ${m}m ${sc}d" else if (m > 0) "${m}m ${sc}d" else "${sc}d"
}

private fun fullTxt(ms: Long): String = SimpleDateFormat("d MMM HH:mm:ss", Locale.getDefault()).format(Date(ms))

private fun rateTxt(r: Float): String = if (r.isNaN()) "-" else "%+.2f%%/j".format(r)

private val InkB = Color.White

/** Kartu ringkasan (desain B): selisih persen dan durasi, garis waktu vertikal dari level awal ke akhir, lalu chip status dan jumlah layar menyala. Warna mengikuti status sesi. */
@Composable
private fun SummaryCard(s: BatSession) {
    val tint = tintOf(s)
    val has = s.startPct >= 0f && s.endPct >= 0f
    val delta = if (has) s.endPct - s.startPct else 0f
    val sign = if (delta > 0f) "+" else if (delta < 0f) "\u2212" else ""
    val endMs = s.id + s.dur * 1000L
    val startColor = if (s.charging) AmberB else GreenB
    Column(Modifier.fillMaxWidth().background(LocalCardB.current, RoundedCornerShape(24.dp)).padding(18.dp)) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text("$sign${kotlin.math.abs(delta).toInt()}%", color = tint, fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Text(durLong(s.dur), color = InkB, fontSize = 14.sp, modifier = Modifier.padding(start = 10.dp, bottom = 5.dp))
        }
        Row(Modifier.fillMaxWidth().padding(top = 16.dp).height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Column(Modifier.fillMaxHeight().padding(top = 6.dp, bottom = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(12.dp).clip(CircleShape).background(startColor))
                Box(Modifier.weight(1f).width(3.dp).background(Brush.verticalGradient(listOf(startColor, tint))))
                Box(Modifier.size(12.dp).clip(CircleShape).background(tint))
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                Column {
                    Text(pctTxt(s.startPct), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(fullTxt(s.id) + " \u00b7 " + (if (s.charging) "Mulai mengisi" else "Dicabut dari charger"), color = InkB, fontSize = 12.sp)
                }
                Column {
                    Text(pctTxt(s.endPct), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(fullTxt(endMs) + " \u00b7 " + (if (s.open) "Berjalan" else if (s.charging) "Dicabut" else "Dicolok"), color = InkB, fontSize = 12.sp)
                }
            }
        }
        Row(Modifier.padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text((if (s.open) "Berjalan" else "Selesai") + " \u00b7 " + (if (s.charging) "Mengisi" else "Terpakai"),
                color = tint, fontSize = 12.sp, fontWeight = FontWeight.Medium,
                modifier = Modifier.background(tint.copy(alpha = 0.15f), RoundedCornerShape(14.dp)).padding(horizontal = 12.dp, vertical = 5.dp))
            Text("Layar " + (s.x?.let { "${it.toggles}x" } ?: "-"), color = InkB, fontSize = 12.sp,
                modifier = Modifier.background(LocalChipB.current, RoundedCornerShape(14.dp)).padding(horizontal = 12.dp, vertical = 5.dp))
        }
    }
}

@Composable
private fun MetricItem(label: String, value: String, modifier: Modifier, icon: @Composable () -> Unit) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(24.dp), contentAlignment = Alignment.Center) { icon() }
        Column(Modifier.padding(start = 10.dp)) {
            Text(label, color = MutedB, fontSize = 11.sp, maxLines = 1)
            Text(value, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
    }
}

/** Metrik baterai: tegangan rata-rata/min/maks, daya rata-rata, suhu rata-rata, dan total energi (mAh). Dua kolom. */
@Composable
private fun MetricsCard(s: BatSession) {
    fun f(v: Float, fmt: String) = if (v > 0f) fmt.format(v) else "-"
    Column(Modifier.fillMaxWidth().background(LocalCardB.current, RoundedCornerShape(24.dp)).padding(horizontal = 18.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Metrik baterai", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        Row { 
            MetricItem("Tegangan rata-rata", f(s.avgV, "%.2f V"), Modifier.weight(1f)) { VoltIcon(BlueB) }
            MetricItem("Tegangan min", f(s.minV, "%.2f V"), Modifier.weight(1f)) { ChevronIcon(Color.White, false) }
        }
        Row {
            MetricItem("Tegangan maks", f(s.maxV, "%.2f V"), Modifier.weight(1f)) { ChevronIcon(Color.White, true) }
            MetricItem("Daya rata-rata", if (s.avgW >= 0f) "%.2f W".format(s.avgW) else "-", Modifier.weight(1f)) { BatteryNavIcon(GreenB) }
        }
        Row {
            MetricItem("Suhu rata-rata", if (s.avgTemp >= 0f) "%.1f °C".format(s.avgTemp) else "-", Modifier.weight(1f)) { ThermIcon(AmberB) }
            MetricItem("Total energi", f(s.energyMah, "%.1f mAh"), Modifier.weight(1f)) { BatteryNavIcon(Color(0xFFA78BFA)) }
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String, icon: @Composable () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(24.dp), contentAlignment = Alignment.Center) { icon() }
        Column(Modifier.padding(start = 10.dp)) {
            Text(label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1)
            Text(value, color = InkB, fontSize = 14.sp, maxLines = 1)
        }
    }
}

/** Waktu besar: "1j 52m" dengan sisa detik di bawahnya; kalau kurang dari sejam, "21m 58d" dengan keterangan "total". */
private fun bigTime(ms: Long?): Pair<String, String> {
    if (ms == null) return "-" to ""
    val sec = (ms / 1000L).toInt()
    val h = sec / 3600; val m = (sec % 3600) / 60; val sc = sec % 60
    return if (h > 0) "${h}j ${m}m" to "$sc detik" else if (m > 0) "${m}m ${sc}d" to "total" else "${sc}d" to "total"
}

@Composable
private fun MiniStat(label: String, value: String) {
    Column(Modifier.fillMaxWidth().background(LocalChipB.current, RoundedCornerShape(12.dp)).padding(horizontal = 10.dp, vertical = 8.dp)) {
        Text(label, color = MutedB, fontSize = 11.sp, maxLines = 1)
        Text(value, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

/** Dua kartu berdampingan (desain C): Layar menyala (waktu besar, laju, perubahan) dan Layar mati (waktu besar, laju, terjaga, tidur lelap). */
@Composable
private fun ScreenCards(s: BatSession) {
    val x = s.x
    fun t(ms: Long?) = if (ms == null) "-" else durLong((ms / 1000L).toInt())
    val on = bigTime(x?.onMs)
    val off = bigTime(x?.offMs)
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Column(Modifier.weight(1f).fillMaxHeight().background(LocalCardB.current, RoundedCornerShape(24.dp)).padding(horizontal = 14.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Layar menyala", color = AmberB, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Text(on.first, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.padding(top = 2.dp))
            Text(on.second, color = MutedB, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
            MiniStat("Laju", if (x == null) "-" else rateTxt(s.rateOn))
            MiniStat("Perubahan", if (x == null) "-" else "%+.0f%%".format(x.dOn))
        }
        Column(Modifier.weight(1f).fillMaxHeight().background(LocalCardB.current, RoundedCornerShape(24.dp)).padding(horizontal = 14.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Layar mati", color = BlueB, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Text(off.first, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.padding(top = 2.dp))
            Text(off.second, color = MutedB, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
            MiniStat("Laju", if (x == null) "-" else rateTxt(s.rateOff))
            MiniStat("Terjaga", t(x?.awakeMs))
            MiniStat("Tidur lelap", t(x?.deepMs))
        }
    }
}

@Composable
private fun VoltIcon(color: Color) {
    Canvas(Modifier.size(22.dp)) {
        val w = size.width
        drawCircle(color, radius = w * 0.44f, center = center, style = Stroke(width = 1.8.dp.toPx()))
        val p = Path().apply {
            moveTo(w * 0.57f, w * 0.24f); lineTo(w * 0.38f, w * 0.54f); lineTo(w * 0.56f, w * 0.54f); lineTo(w * 0.44f, w * 0.78f)
        }
        drawPath(p, color, style = Stroke(width = 1.6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** Ikon panah kecil ke bawah (min) atau ke atas (maks). */
@Composable
private fun ChevronIcon(color: Color, up: Boolean) {
    Canvas(Modifier.size(22.dp)) {
        val w = size.width
        val y1 = if (up) 0.62f else 0.38f; val y2 = if (up) 0.35f else 0.65f
        val p = Path().apply { moveTo(w * 0.2f, w * y1); lineTo(w * 0.5f, w * y2); lineTo(w * 0.8f, w * y1) }
        drawPath(p, color, style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** Ikon termometer. */
@Composable
private fun ThermIcon(color: Color) {
    Canvas(Modifier.size(22.dp)) {
        val w = size.width
        drawRoundRect(color, topLeft = androidx.compose.ui.geometry.Offset(w * 0.40f, w * 0.08f),
            size = androidx.compose.ui.geometry.Size(w * 0.20f, w * 0.55f),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * 0.10f))
        drawCircle(color, radius = w * 0.18f, center = androidx.compose.ui.geometry.Offset(w * 0.5f, w * 0.74f))
    }
}

/** Detail satu sesi: ringkasan, grafik level / daya / suhu, lalu pemakaian per aplikasi. */
@Composable
fun BatteryDetailScreen(id: Long, onBack: () -> Unit, onDeleted: () -> Unit, wallpaper: Bitmap? = null, dim: Float = 0.6f) {
    val ctx = LocalContext.current
    val ver by BatteryHistory.version.collectAsState()
    val ses by produceState<BatSession?>(null, id, ver / 3) { value = withContext(Dispatchers.IO) { BatteryHistory.load(ctx, id) } }
    val s = ses
    var reload by remember { mutableIntStateOf(0) }
    var liveApps by remember { mutableStateOf<List<AppUse>?>(null) }
    var liveDone by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    val isOpen = s?.open == true
    // Sesi berjalan: daftar aplikasi dimuat ulang otomatis tiap 10 detik selama layar ini terbuka, tanpa perlu menekan Segarkan
    LaunchedEffect(id, reload, isOpen) {
        liveDone = false
        while (true) {
            liveApps = withContext(Dispatchers.IO) { BatteryHistory.liveApps(ctx, id) }
            liveDone = true
            if (!isOpen) break
            delay(10_000L)
        }
    }
    LaunchedEffect(confirm) { if (confirm) { delay(3000); confirm = false } }

    WallpaperPage(wallpaper, dim) {
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
        .verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TopBar(onBack) {
            if (s != null && s.open) SmallPill("Segarkan") { reload++ }
            if (s != null && !s.open) SmallPill(if (confirm) "Yakin hapus?" else "Hapus", if (confirm) Color(0xFF5A2530) else LocalCardB.current) {
                if (confirm) { BatteryHistory.delete(ctx, id); onDeleted() } else confirm = true
            }
        }
        Text("Detail sesi", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        if (s == null) { Text("Memuat…", color = MutedB); return@Column }
        SummaryCard(s)
        MetricsCard(s)
        ScreenCards(s)
        if (s.x == null) Text("Sesi ini direkam sebelum rincian tegangan, energi, dan waktu layar ditambahkan, jadi bagian itu kosong. Sesi baru akan lengkap.",
            color = MutedB, fontSize = 12.sp, lineHeight = 16.sp, modifier = Modifier.padding(horizontal = 4.dp))
        if (s.n < 2) Text("Data masih sedikit, grafik muncul setelah beberapa menit.", color = MutedB, fontSize = 12.sp)
        LineChart(if (s.charging) "Timeline isi daya" else "Timeline kuras baterai", s.t, listOf(
            Series("Level", BlueB, s.level), Series("Daya", GreenB, s.watt), Series("Suhu", AmberB, s.temp)), card = LocalCardB.current)

        Text("Pemakaian aplikasi", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
        val apps: List<AppUse> = (if (s.open) liveApps else s.apps).orEmpty()
        val waiting = s.open && !liveDone
        when {
            waiting -> Note("Membaca statistik baterai…")
            apps.isEmpty() -> Note(
                if (Access.status != 2) "Pemakaian per aplikasi butuh akses Shizuku atau Root. Pilih di tab Settings."
                else if (s.open) "Belum ada data aplikasi untuk sesi ini. Foto awal statistik mungkin belum terbaca; coba Segarkan beberapa saat lagi."
                else "Data aplikasi tidak terbaca untuk sesi ini (statistik sistem tidak tersedia saat sesi berakhir)."
            )
            else -> {
                val total = apps.sumOf { it.mah.toDouble() }.toFloat().coerceAtLeast(0.001f)
                val top = apps.maxOf { it.mah }.coerceAtLeast(0.001f)
                apps.take(15).forEach { AppRow(it, it.mah / top, it.mah / total * 100f) }
                Text("Dihitung dari statistik baterai sistem sejak sesi dimulai. Angka bisa beda tipis dengan Setelan Android.",
                    color = MutedB, fontSize = 11.sp, lineHeight = 15.sp, modifier = Modifier.padding(horizontal = 4.dp))
            }
        }
    }
    }
}

@Composable
private fun Note(text: String) {
    Text(text, color = MutedB, fontSize = 13.sp, lineHeight = 18.sp,
        modifier = Modifier.fillMaxWidth().background(LocalCardB.current, RoundedCornerShape(18.dp)).padding(16.dp))
}

@Composable
private fun AppRow(u: AppUse, frac: Float, share: Float) {
    val ctx = LocalContext.current
    val icon = remember(u.pkg) { if (u.pkg.isNotEmpty()) appIcon(ctx, u.pkg) else null }
    val detail = (if (u.ms >= 0L) durMs(u.ms) + " • " else "") + "%.1f mAh".format(u.mah)
    Row(Modifier.fillMaxWidth().background(LocalCardB.current, RoundedCornerShape(20.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        if (icon != null) Image(icon.asImageBitmap(), null, Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)))
        else Box(Modifier.size(48.dp).background(LocalChipB.current, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
            Text(u.label.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        Column(Modifier.weight(1f).padding(start = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(u.label, color = Color.White, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                Text(detail, color = MutedB, fontSize = 12.sp, maxLines = 1, softWrap = false, modifier = Modifier.padding(start = 8.dp))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f).height(8.dp).clip(CircleShape).background(Color(0xFF2E3140))) {
                    Box(Modifier.fillMaxWidth(frac.coerceIn(0.03f, 1f)).fillMaxHeight().background(BarB, CircleShape))
                }
                Text("%.1f%%".format(share), color = Color.White, fontSize = 14.sp, textAlign = TextAlign.End,
                    modifier = Modifier.padding(start = 10.dp).widthIn(min = 46.dp))
            }
        }
    }
}
