package com.pulsemonitor

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Build
import android.os.IBinder
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.Calendar

/** Satu aplikasi di daftar DexOpt. */
class DexApp(val pkg: String, val label: String, val system: Boolean)

/** Satu baris log: ok true = berhasil, false = gagal. */
class DexLog(val ok: Boolean, val text: String)

/** Status proses DexOpt yang sedang / baru saja berjalan. */
class DexProgress(
    val running: Boolean = false, val done: Int = 0, val total: Int = 0,
    val current: String = "", val failed: Int = 0, val message: String = ""
)

/**
 * DexOpt: mengompilasi ulang aplikasi terpasang dengan filter kompiler pilihan lewat `cmd package compile`
 * (butuh Shizuku atau Root). Aplikasi yang dimatikan di daftar dilewati.
 */
object DexOpt {
    /** Filter kompiler yang ditawarkan (urutan sama dengan dropdown). */
    val PROFILES = listOf("everything", "everything-profile", "speed", "speed-profile")

    val progress = MutableStateFlow(DexProgress())
    /** Log per aplikasi untuk proses terakhir (maks 300 baris, terbaru di bawah). */
    val log = MutableStateFlow<List<DexLog>>(emptyList())
    private fun addLog(l: DexLog) { log.value = (log.value + l).takeLast(300) }
    @Volatile private var cancel = false

    private fun prefs(c: Context): SharedPreferences = c.applicationContext.getSharedPreferences("dexopt", Context.MODE_PRIVATE)

    fun profile(c: Context): String = prefs(c).getString("profile", "speed-profile")?.takeIf { it in PROFILES } ?: "speed-profile"
    fun setProfile(c: Context, v: String) = prefs(c).edit().putString("profile", v).apply()
    fun systemApp(c: Context) = prefs(c).getBoolean("system", true)
    fun setSystemApp(c: Context, v: Boolean) = prefs(c).edit().putBoolean("system", v).apply()
    fun scheduled(c: Context) = prefs(c).getBoolean("scheduled", false)
    fun setScheduled(c: Context, v: Boolean) { prefs(c).edit().putBoolean("scheduled", v).apply(); applySchedule(c) }
    fun hideSystemInList(c: Context) = prefs(c).getBoolean("hideSys", false)
    fun setHideSystemInList(c: Context, v: Boolean) = prefs(c).edit().putBoolean("hideSys", v).apply()

    /** Paket yang dimatikan (dilewati saat DexOpt). */
    fun ignored(c: Context): Set<String> = prefs(c).getStringSet("ignored", emptySet())?.toSet() ?: emptySet()
    fun setIgnored(c: Context, pkg: String, ignore: Boolean) {
        val s = ignored(c).toMutableSet()
        if (ignore) s.add(pkg) else s.remove(pkg)
        prefs(c).edit().putStringSet("ignored", s).apply()
    }

    fun hasAccess() = Shell.mode() != "-"

    /** Semua aplikasi terpasang, urut nama. Dipanggil dari thread latar. */
    fun listApps(c: Context): List<DexApp> {
        val pm = c.packageManager
        return runCatching {
            pm.getInstalledApplications(0).map {
                val sys = (it.flags and ApplicationInfo.FLAG_SYSTEM) != 0 && (it.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
                DexApp(it.packageName, runCatching { pm.getApplicationLabel(it).toString() }.getOrDefault(it.packageName), sys)
            }.sortedBy { it.label.lowercase() }
        }.getOrDefault(emptyList())
    }

    /** Ikon aplikasi sebagai bitmap kecil (null bila gagal). */
    fun icon(c: Context, pkg: String, px: Int = 96): Bitmap? = runCatching {
        val d = c.packageManager.getApplicationIcon(pkg)
        val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, px, px); d.draw(Canvas(bmp)); bmp
    }.getOrNull()

    fun targets(c: Context): List<DexApp> {
        val ign = ignored(c)
        val sys = systemApp(c)
        return listApps(c).filter { it.pkg !in ign && (sys || !it.system) }
    }

    /** Mulai lewat layanan latar depan supaya proses panjang tidak dimatikan sistem. */
    fun start(c: Context) {
        if (progress.value.running) return
        if (!hasAccess()) { progress.value = DexProgress(message = "Akses Shizuku/Root belum aktif"); return }
        ContextCompat.startForegroundService(c, Intent(c, DexOptService::class.java))
    }

    fun stop() { cancel = true }

    /** Dijalankan DexOptService di thread latar. [onTick] dipanggil tiap satu aplikasi selesai. */
    fun runBlocking(c: Context, onTick: (DexProgress) -> Unit) {
        if (progress.value.running) return
        cancel = false
        log.value = emptyList()
        val filter = profile(c)
        val list = targets(c)
        var failed = 0
        progress.value = DexProgress(true, 0, list.size, "", 0, "Memulai")
        AppLog.i("DexOpt", "mulai: filter=$filter, ${list.size} aplikasi")
        for ((i, app) in list.withIndex()) {
            if (cancel) break
            val p = DexProgress(true, i, list.size, app.label, failed, "Mengompilasi")
            progress.value = p; onTick(p)
            val out = runCatching { Shell.exec("cmd package compile -m $filter -f ${app.pkg} 2>&1") }.getOrDefault("")
            if (!out.contains("Success", ignoreCase = true)) {
                failed++
                addLog(DexLog(false, app.label))
                AppLog.w("DexOpt", "gagal ${app.pkg}: ${out.trim().take(120)}")
            } else addLog(DexLog(true, app.label))
        }
        val msg = if (cancel) "Dihentikan" else "Selesai"
        val last = list.size.coerceAtLeast(0)
        progress.value = DexProgress(false, if (cancel) progress.value.done else last, list.size, "", failed, msg)
        AppLog.i("DexOpt", "$msg: ${progress.value.done}/${list.size}, gagal $failed")
        cancel = false
    }

    // ---------- Jadwal harian (sekitar 03:00) ----------
    private fun alarmIntent(c: Context): PendingIntent =
        PendingIntent.getBroadcast(c, 7301, Intent(c, DexOptReceiver::class.java).setAction(DexOptReceiver.ACTION_RUN),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun applySchedule(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java) ?: return
        am.cancel(alarmIntent(c))
        if (!scheduled(c)) return
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 3); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis() + 60_000L) add(Calendar.DAY_OF_YEAR, 1)
        }
        runCatching {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.set(AlarmManager.RTC_WAKEUP, cal.timeInMillis, alarmIntent(c))
            else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, alarmIntent(c))
        }
    }
}

/** Alarm harian: jalankan DexOpt lalu jadwalkan lagi untuk besok. Juga memulihkan jadwal setelah HP menyala ulang. */
class DexOptReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        when (i.action) {
            ACTION_RUN -> { runCatching { DexOpt.start(c) }; DexOpt.applySchedule(c) }
            Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED -> DexOpt.applySchedule(c)
        }
    }
    companion object { const val ACTION_RUN = "com.pulsemonitor.DEXOPT_RUN" }
}

/** Layanan latar depan yang menjalankan DexOpt sampai selesai dan menampilkan progresnya di notifikasi. */
class DexOptService : Service() {
    override fun onBind(p0: Intent?): IBinder? = null

    private fun notif(text: String, done: Int, total: Int): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CH) == null)
            nm.createNotificationChannel(NotificationChannel(CH, "DexOpt", NotificationManager.IMPORTANCE_LOW))
        return Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat_pulse).setContentTitle("DexOpt").setContentText(text)
            .setOngoing(true).setOnlyAlertOnce(true).setProgress(total, done, total == 0).build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = notif("Memulai", 0, 0)
        if (Build.VERSION.SDK_INT >= 34) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(ID, n)
        Thread {
            val nm = getSystemService(NotificationManager::class.java)
            try {
                DexOpt.runBlocking(this) { p -> nm.notify(ID, notif("${p.done + 1}/${p.total} · ${p.current}", p.done, p.total)) }
            } finally {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }.apply { name = "dexopt"; start() }
        return START_NOT_STICKY
    }

    companion object { private const val CH = "dexopt"; private const val ID = 7302 }
}
