package com.pulsemonitor

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Hasil satu pemeriksaan. level: 0 = OK, 1 = peringatan, 2 = gagal. */
class Check(val name: String, val level: Int, val detail: String, val extra: String = "")

object HealthCheck {
    private fun ok(n: String, d: String) = Check(n, 0, d)
    private fun warn(n: String, d: String, x: String = "") = Check(n, 1, d, x)
    private fun fail(n: String, d: String, x: String = "") = Check(n, 2, d, x)

    /** Jalankan semua pemeriksaan. Memanggil dumpsys, jadi harus dari thread latar. */
    fun run(c: Context, s: Snap): List<Check> {
        val out = ArrayList<Check>()
        val mode = Shell.mode()
        val pilihan = when (Access.choice) { Access.SHIZUKU -> "Shizuku"; Access.ROOT -> "Root"; else -> "otomatis" }
        out += if (mode != "-") ok("Akses Shizuku/Root", "Mode aktif: $mode (pilihan: $pilihan)")
        else fail("Akses Shizuku/Root", "Tidak ada akses (pilihan: $pilihan, Shizuku siap=${Shell.shizukuReady()}, root=${Access.rootState}). Fitur yang butuh akses tidak jalan.")

        val overlay = Settings.canDrawOverlays(c)
        out += if (overlay) ok("Izin overlay", "Diizinkan") else warn("Izin overlay", "Belum diizinkan (hanya perlu untuk overlay)")
        val notif = if (Build.VERSION.SDK_INT >= 33)
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        else androidx.core.app.NotificationManagerCompat.from(c).areNotificationsEnabled()
        out += if (notif) ok("Izin notifikasi", "Diizinkan") else warn("Izin notifikasi", "Belum diizinkan (notifikasi latar belakang tidak tampil)")
        out += ok("Layanan", "Overlay ${if (OverlayService.overlayShown.value) "aktif" else "mati"} · Mode latar belakang ${if (AppSettings.bgMode) "nyala" else "mati"}")

        // Statistik baterai sistem (sumber daftar pemakaian aplikasi)
        if (mode == "-") out += warn("Statistik baterai sistem", "Dilewati karena tidak ada akses")
        else {
            val t0 = System.currentTimeMillis()
            val raw = runCatching { Shell.exec("dumpsys batterystats") }
            val ms = System.currentTimeMillis() - t0
            val txt = raw.getOrDefault("")
            if (raw.isFailure) out += fail("Statistik baterai sistem", "dumpsys error: ${raw.exceptionOrNull()?.javaClass?.simpleName} ${raw.exceptionOrNull()?.message}")
            else if (txt.isBlank()) out += fail("Statistik baterai sistem", "Keluaran dumpsys batterystats kosong ($ms ms)")
            else {
                val lines = txt.lines()
                val at = lines.indexOfFirst { it.contains("Estimated power use") }
                val snap = runCatching { AppPower.snapshot() }.getOrNull()
                val excerpt = if (at >= 0) lines.drop(at).take(14).joinToString("\n")
                else lines.filter { it.isNotBlank() }.take(12).joinToString("\n")
                out += when {
                    snap != null && snap.isNotEmpty() -> ok("Statistik baterai sistem", "Terbaca: ${snap.size} UID, ${txt.length} karakter, $ms ms")
                    at < 0 -> fail("Statistik baterai sistem", "Bagian 'Estimated power use' tidak ada di keluaran (${txt.length} karakter, $ms ms)", excerpt)
                    else -> fail("Statistik baterai sistem", "Bagian 'Estimated power use' ada tapi barisnya tidak terbaca", excerpt)
                }
            }
        }

        // Perekaman riwayat baterai
        val h = BatteryHistory.health(c)
        out += when {
            !h.hasCur -> warn("Perekaman riwayat baterai", "Belum ada sesi berjalan di proses ini. Tersimpan: ${h.saved} sesi")
            h.lastAgeS > 120 -> warn("Perekaman riwayat baterai", "Sesi ${if (h.charging) "isi daya" else "kuras"} ada, tapi sampel terakhir ${h.lastAgeS} detik lalu (perekaman berhenti? aplikasi di latar belakang tanpa Mode latar belakang)")
            !h.hasBase -> warn("Perekaman riwayat baterai", "Merekam (${h.points} titik) tapi foto awal pemakaian aplikasi belum ada, dicoba ulang tiap 30 detik")
            else -> ok("Perekaman riwayat baterai", "Merekam: ${h.points} titik, foto awal ada, ${h.saved} sesi tersimpan")
        }

        // Pembacaan sensor Sampler
        fun sensor(name: String, good: Boolean, okTxt: String, badTxt: String) { out += if (good) ok(name, okTxt) else warn(name, badTxt) }
        sensor("Beban CPU", s.cpu >= 0, "${s.cpu}%", "Tidak terbaca")
        sensor("Frekuensi CPU", s.coreMhz.any { it > 0 }, "${s.coreMhz.size} inti terbaca", "Tidak terbaca")
        sensor("Suhu", s.tCpu >= 0f || s.tSkin >= 0f || s.tBat >= 0f,
            "CPU ${fmtT(s.tCpu)} · GPU ${fmtT(s.tGpu)} · baterai ${fmtT(s.tBat)} · HP ${fmtT(s.tSkin)}", "Tidak ada sensor suhu terbaca")
        sensor("GPU", s.gpu >= 0 || s.gpuMhz > 0, "Beban ${if (s.gpu >= 0) "${s.gpu}%" else "-"} · ${if (s.gpuMhz > 0) "${s.gpuMhz} MHz" else "-"}", "Tidak terbaca (butuh Shizuku/Root)")
        sensor("RAM", s.mem != null || s.ramPct >= 0, "${s.ramText}", "Tidak terbaca")
        sensor("Baterai dan daya", s.batPct >= 0, "${s.batPct}% · daya ${if (s.watt >= 0f) "%.1f W".format(Locale.US, s.watt) else "-"}", "Tidak terbaca")
        return out
    }

    private fun fmtT(v: Float) = if (v >= 0f) "%.0f°C".format(Locale.US, v) else "-"

    private fun mark(l: Int) = when (l) { 0 -> "[OK]  "; 1 -> "[WARN]"; else -> "[FAIL]" }

    fun report(c: Context, checks: List<Check>): String {
        val sb = StringBuilder()
        val ver = runCatching { c.packageManager.getPackageInfo(c.packageName, 0).let { "${it.versionName} (${it.longVersionCode})" } }.getOrDefault("?")
        sb.append("PulseMonitor laporan kesehatan\n")
        sb.append(SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())).append('\n')
        sb.append("Aplikasi $ver · ${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT}) · ${Build.DISPLAY}\n\n")
        sb.append("== PEMERIKSAAN ==\n")
        checks.forEach {
            sb.append("${mark(it.level)} ${it.name}: ${it.detail}\n")
            if (it.extra.isNotBlank()) sb.append("       cuplikan:\n").append(it.extra.prependIndent("       | ")).append('\n')
        }
        sb.append("\n== LOG (terbaru di bawah) ==\n").append(AppLog.dump(200)).append('\n')
        return sb.toString()
    }
}

private val BgH = Color(0xFF101014)
private val CardH = Color(0xFF1D1E24)
private val MutedH = Color(0xFF8E8E99)
private val SubH = Color(0xFFC4C6CE)
private val OkH = Color(0xFF4CC38A)
private val WarnH = Color(0xFFF5B83D)
private val FailH = Color(0xFFE5677A)

private fun levelColor(l: Int) = when (l) { 0 -> OkH; 1 -> WarnH; else -> FailH }

/** Desain B: banner masalah di atas, satu daftar padat (ketuk baris untuk detail), log dengan filter. */
@Composable
fun HealthScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var run by remember { mutableIntStateOf(0) }
    var checks by remember { mutableStateOf<List<Check>?>(null) }
    var logAll by remember { mutableStateOf<List<String>>(emptyList()) }
    var filter by remember { mutableIntStateOf(0) }          // 0 semua, 1 peringatan ke atas, 2 error
    var open by remember { mutableStateOf(setOf<String>()) }  // baris yang sedang dibuka detailnya
    LaunchedEffect(run) {
        checks = null
        val snap = Sampler.state.value
        checks = withContext(Dispatchers.IO) {
            runCatching { HealthCheck.run(ctx, snap) }
                .getOrElse { listOf(Check("Pemeriksaan", 2, "Gagal dijalankan: ${it.javaClass.simpleName} ${it.message}")) }
        }
        logAll = AppLog.dump(120).lines().filter { it.isNotBlank() }
    }
    fun toast(t: String) = Toast.makeText(ctx, t, Toast.LENGTH_SHORT).show()
    val list = checks
    val problems = list.orEmpty().filter { it.level > 0 }.sortedByDescending { it.level }
    val worst = problems.maxOfOrNull { it.level } ?: 0

    Column(Modifier.fillMaxSize().background(BgH).statusBarsPadding().navigationBarsPadding()
        .verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).clip(CircleShape).clickable { onBack() }, contentAlignment = Alignment.Center) {
                Text("←", color = Color.White, fontSize = 26.sp)
            }
            Spacer(Modifier.weight(1f))
            Box(Modifier.clip(CircleShape).background(CardH).clickable { run++ }.padding(horizontal = 16.dp, vertical = 9.dp)) {
                Text("Periksa ulang", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
        }
        Text("Kesehatan & log", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)

        // Banner ringkasan
        if (list == null) Text("Memeriksa…", color = MutedH, fontSize = 13.sp)
        else if (problems.isEmpty()) {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color(0xFF1F3A2E)).padding(horizontal = 14.dp, vertical = 12.dp)) {
                Text("Semua jalan", color = Color(0xFF9FE8C0), fontSize = 14.sp, fontWeight = FontWeight.Medium)
                Text("${list.size} pemeriksaan OK", color = Color(0xFFC6EBD6), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
            }
        } else {
            val bg = if (worst == 2) Color(0xFF3A2A2E) else Color(0xFF3A3322)
            val hi = if (worst == 2) Color(0xFFFFB4C0) else Color(0xFFFFD98A)
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(bg).padding(horizontal = 14.dp, vertical = 12.dp)) {
                Text("${problems.size} hal perlu dicek", color = hi, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                Text(problems.joinToString(" · ") { it.name }, color = Color(0xFFE8D9DB), fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }

        if (list != null) {
            Text("SEMUA PEMERIKSAAN", color = MutedH, fontSize = 12.sp, modifier = Modifier.padding(start = 2.dp, top = 2.dp))
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(CardH).padding(horizontal = 14.dp)) {
                list.sortedByDescending { it.level }.forEachIndexed { i, ck ->
                    val col = levelColor(ck.level)
                    val isOpen = ck.name in open
                    if (i > 0) Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x14FFFFFF)))
                    Column(Modifier.fillMaxWidth().clickable { open = if (isOpen) open - ck.name else open + ck.name }.padding(vertical = 11.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(9.dp).clip(CircleShape).background(col))
                            Text(ck.name, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(start = 10.dp).weight(1f))
                            if (!isOpen) Text(ck.detail, color = if (ck.level == 0) MutedH else col, fontSize = 12.sp, maxLines = 1,
                                overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 150.dp).padding(start = 8.dp))
                        }
                        if (isOpen) {
                            Text(ck.detail, color = SubH, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(top = 6.dp, start = 19.dp))
                            if (ck.extra.isNotBlank()) {
                                Box(Modifier.padding(top = 8.dp, start = 19.dp).fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(BgH)
                                    .horizontalScroll(rememberScrollState()).padding(10.dp)) {
                                    Text(ck.extra, color = MutedH, fontSize = 10.sp, fontFamily = FontFamily.Monospace, softWrap = false)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Log dengan filter
        Text("LOG", color = MutedH, fontSize = 12.sp, modifier = Modifier.padding(start = 2.dp, top = 6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Semua", "Peringatan", "Error").forEachIndexed { i, label ->
                val on = filter == i
                Box(Modifier.clip(CircleShape).background(if (on) Color(0xFF4C8DFF) else CardH).clickable { filter = i }
                    .padding(horizontal = 12.dp, vertical = 5.dp)) {
                    Text(label, color = if (on) Color(0xFF0C0C0E) else Color.White, fontSize = 12.sp)
                }
            }
        }
        val shown = logAll.filter { l ->
            val lv = l.getOrNull(15)
            when (filter) { 1 -> lv == 'W' || lv == 'E'; 2 -> lv == 'E'; else -> true }
        }.takeLast(60)
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(CardH).horizontalScroll(rememberScrollState()).padding(12.dp)) {
            if (shown.isEmpty()) Text("Tidak ada log.", color = MutedH, fontSize = 11.sp)
            else Column {
                shown.forEach { l ->
                    Text(l, color = when (l.getOrNull(15)) { 'E' -> FailH; 'W' -> WarnH; else -> MutedH }, fontSize = 10.sp,
                        lineHeight = 14.sp, fontFamily = FontFamily.Monospace, softWrap = false)
                }
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.weight(1f).clip(CircleShape).background(CardH).clickable(enabled = list != null) {
                val text = HealthCheck.report(ctx, list.orEmpty())
                (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("PulseMonitor", text))
                toast("Laporan disalin")
            }.padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                Text("Salin", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            }
            Box(Modifier.weight(1f).clip(CircleShape).background(Color(0xFF4C8DFF)).clickable(enabled = list != null) {
                val text = HealthCheck.report(ctx, list.orEmpty())
                val i = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, "PulseMonitor laporan kesehatan"); putExtra(Intent.EXTRA_TEXT, text)
                }
                ctx.startActivity(Intent.createChooser(i, "Kirim laporan").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }.padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                Text("Bagikan", color = Color(0xFF0C0C0E), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { AppLog.clear(); logAll = emptyList(); toast("Log dihapus") }.padding(vertical = 8.dp),
            contentAlignment = Alignment.Center) {
            Text("Hapus log", color = MutedH, fontSize = 13.sp)
        }
        Text("Kalau ada fitur yang tidak jalan, tekan Salin atau Bagikan lalu kirim laporannya.", color = MutedH, fontSize = 11.sp, lineHeight = 15.sp)
    }
}
