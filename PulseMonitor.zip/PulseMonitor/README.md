# Pulse Monitor (FPS / CPU / GPU / Suhu)
1. Buka folder ini di Android Studio (Koala+), tunggu Gradle sync, lalu Run di HP Android 10+.
2. Pilih akses: aktifkan Shizuku (lalu tekan "Beri izin Shizuku") atau pakai HP root.
3. Nyalakan "Overlay mengambang" (akan diminta izin tampil di atas aplikasi lain).
Catatan: kode belum dikompilasi/diuji. GPU hanya terbaca di Adreno (kgsl). Tanpa izin INTERNET.

## v0.9.11: Kartu diperluas padat
- Panah di notifikasi kini menampilkan kartu padat (satu kartu, semua info + tombol rekam) yang muat di tinggi kartu ringkas HyperOS; tampilan lengkap besar tetap dipakai saat sistem memperluas notifikasi sendiri.

## v0.9.10: Ikon P + notifikasi diperluas di tempat
- Ikon aplikasi, ikon bertema, ikon status bar, dan lencana notifikasi: gelas kopi diganti huruf P blok abu-abu.
- Panah di kartu notifikasi memperluas isi lengkap di dalam notifikasi (bukan kartu mengambang di luar).

## Perubahan v0.1.1 (stabilisasi)
- Minta izin POST_NOTIFICATIONS saat start (Android 13+), supaya notifikasi overlay muncul.
- Overlay: cek izin tampil-di-atas-aplikasi, tangani addView/removeView gagal, tipe FGS specialUse hanya di API 34+.
- Sampler: hindari crash saat data frame kosong; kegagalan baca FPS tidak lagi menggagalkan CPU/GPU/RAM/suhu.
- Belum ada Gradle wrapper di zip ini: Android Studio akan menawarkan membuatnya saat sync (butuh Gradle 8.7+ untuk AGP 8.5.2).

## v0.2.2: Ikon aplikasi
- Ikon adaptive: latar gelap + garis denyut cyan, plus versi monokrom untuk ikon bertema (Android 13+). Semua berupa vektor XML di res/, tanpa PNG.

## v0.2.1: GPU MediaTek
- Sampler mencoba beberapa jalur GPU berurutan: Adreno (kgsl), MediaTek (GED), Mali lama. Jalur pertama yang terbaca dipakai; jika tidak ada, tampil "-".
- Belum diuji di perangkat MediaTek. Jalur GED bisa berbeda/tertutup di beberapa chipset.

## v0.2.0: Wallpaper
- Kartu "Wallpaper" di layar utama: pilih gambar dari galeri (Photo Picker, tanpa izin storage), ganti, hapus.
- Gambar disalin ke penyimpanan internal aplikasi (maks 1600 px, JPEG) lewat WallpaperStore.kt.
- Slider "Redupkan latar" (20-90%) agar teks tetap terbaca; nilainya tersimpan.

## v0.2.3: Perbaikan suhu (acuan: FrameX)
- Suhu dipisah: baterai, CPU, GPU (sebelumnya satu angka "SUHU" gabungan, GPU tidak pernah dibaca).
- Baterai: dari broadcast BATTERY_CHANGED (tanpa Shizuku/root), cadangan HAL lalu sysfs.
- CPU/GPU: HAL thermal (`dumpsys thermalservice`) dibaca semua sensornya, dikelompokkan lewat nama (cpuss/gpuss/quiet_therm) lalu tipe HAL; cadangan sysfs thermal_zone dan kgsl temp.
- Dibuang: zona sysfs "soc"/"tsens" yang di banyak HP berisi persen baterai atau sensor acak, sehingga angka suhu salah.
- Catatan: belum dikompilasi/diuji di perangkat.

## v0.2.4: Overlay baru
- Tampilan kartu: FPS besar, lalu tabel rata kolom CPU / GPU / RAM / BAT (beban dan suhu), suhu berwarna (hijau, kuning, oranye, merah).
- Bisa digeser: tahan lalu seret overlay ke posisi mana pun; posisi tersimpan.
- Catatan: area overlay kini menangkap sentuhan (perlu supaya bisa digeser), jadi sentuhan tepat di atas kartu tidak tembus ke game.

## v0.2.5: Overlay satu baris
- Overlay jadi pil satu baris: `60 FPS  CPU 16% 63°  GPU 33% 63°  BAT 40°`, suhu tetap berwarna. Tetap bisa digeser.

## v0.2.6: Ikon petir
- Ikon aplikasi diganti jadi petir cyan di atas latar gelap (adaptive + monokrom untuk ikon bertema). Tetap vektor XML.

## v0.3.0: Layar utama baru dan Pengaturan
- Layar utama: kartu FPS dengan grafik 30 detik terakhir, lalu AVG / 1% LOW / FRAMETIME, baris pil CPU / GPU / RAM / Baterai (beban + suhu berwarna), saklar overlay, akses, wallpaper, diagnostik.
- Ikon gerigi di pojok kanan atas membuka Pengaturan: warna aksen, warna teks overlay, warna dan transparansi latar overlay, tombol "Kembalikan warna awal". Tersimpan otomatis.
- Overlay membaca pengaturan warna tiap detik. Belum dikompilasi/diuji di perangkat.

## v0.4.0: Tampilan baru ala WuWa Config
- Layar utama: wallpaper penuh, judul besar "PulseMonitor", chip akses (Shizuku/root) di kanan atas, panel kaca di bawah, dan bilah navigasi 4 tab (Beranda, Statistik, Tampilan, Settings).
- Beranda: status overlay, dua kartu FPS dan Frametime, grafik 30 detik, baris CPU / GPU / RAM / BAT, tombol gradien "Nyalakan/Matikan Overlay".
- Statistik: akses, RAM, suhu, diagnostik. Tampilan: wallpaper dan redup latar. Settings: warna (sama seperti sebelumnya).
- Ikon di navigasi memakai simbol teks (tanpa dependensi icons-extended). Memakai enableEdgeToEdge(). Belum dikompilasi/diuji di perangkat.

## v0.4.1: Layar utama lebih ringkas
- Subjudul "Pilih, lalu nyalakan overlay" dihapus dari Beranda.
- Panel bawah dipadatkan dan diturunkan (padding dan tinggi dikurangi) supaya karakter di wallpaper lebih terlihat.

## v0.4.2: Baris sensor dirapikan
- Suhu di bawah CPU dan GPU dihapus dari Beranda (suhu tetap ada di tab Statistik dan di overlay).
- Baris CPU / GPU / RAM / BAT diberi padding samping dan rata tengah secara vertikal.

## v0.4.3: Status overlay lebih sederhana
- Teks AVG / 1% LOW di bawah "Overlay aktif" dihapus; ikon dan teks status kini rata tengah di barisnya.

## v0.5.0: Rekam FPS dan laporan
- Tab baru "Rekaman" (navigasi jadi 5 tab). Tombol Mulai rekam / Berhenti dan simpan, serta daftar rekaman (nama game, tanggal, AVG FPS, durasi).
- Mulai/berhenti dari dalam game: tombol di notifikasi overlay, atau tahan overlay sekitar 1 detik tanpa menggesernya. Saat merekam, overlay diberi titik merah di depan angka FPS.
- Laporan (ketuk rekaman): ikon dan nama game, kolom Deskripsi (tersimpan otomatis), tanggal + resolusi layar, statistik 2 halaman (geser): MAKS / MIN / RATA-RATA / VARIANS FPS, Relatif kehalusan, 5% Low, suhu maks, daya rata-rata; halaman 2: rata-rata CPU/GPU/RAM, durasi, suhu maks CPU/GPU/BAT.
- Grafik: FPS + Frametime + Suhu, Beban CPU/GPU, RAM, Suhu CPU/GPU/Baterai, Daya (muncul bila terbaca).
- Tombol Bagikan (ringkasan teks), CSV (disimpan ke folder Download tanpa izin storage), Hapus (dua ketukan).
- Data: satu file JSON per rekaman di penyimpanan internal aplikasi (filesDir/records). Sampel kira-kira per detik, bagian awal/akhir tanpa frame dibuang.
- Daya (Watt) = |arus baterai| x tegangan, jadi hanya perkiraan dan paling akurat saat tidak mengisi daya. Beberapa HP tidak melaporkan arus; kolomnya jadi "-".
- Manifest: ditambah QUERY_ALL_PACKAGES agar nama dan ikon game bisa dibaca.
- Belum ada: simpan laporan sebagai gambar. Resolusi yang ditampilkan adalah resolusi layar, bukan resolusi render game.
- Catatan: belum dikompilasi/diuji di perangkat. Rekaman butuh Shizuku/root (sumber data FPS).

## v0.5.1: Rapikan teks dan angka rekaman
- Daftar rekaman: nama dan tanggal di kiri, AVG FPS (besar) dan durasi di kanan, tidak lagi satu baris panjang yang terpotong.
- Statistik laporan: label huruf besar seragam (11sp), angka 22sp, satuan 11sp, jarak antar baris disamakan. Label diperjelas: KEHALUSAN, 5% LOW, SUHU MAKS, DAYA, SUHU CPU/GPU/BAT.

## v0.5.2: FPS diam, akurasi CPU/GPU, FPS turun saat rekam
- FPS dihitung dari selisih frame dibagi waktu nyata dalam jendela ~2,5 detik (sebelumnya 1 detik, ikut melar saat tick lambat). Saat layar diam tanpa frame baru, nilai terakhir ditahan maks 3 detik sebelum jadi 0.
- Saat merekam, paket game dikunci. Fokus sementara ke SystemUI (tarik notifikasi), keyboard, atau PulseMonitor sendiri diabaikan (sticky 20 detik), sehingga FPS tidak jatuh ke aplikasi lain begitu tombol rekam ditekan.
- Beban pemantau dikurangi: fokus dibaca tiap 2 dtk (sebelumnya 2x `dumpsys` tiap detik dan dua kali per tick), HAL thermal tiap 3 dtk. Tick dijadwalkan tetap ~1 dtk, jadi CPU% dan FPS tidak ikut tertarik oleh lama tick.
- GPU Adreno: cadangan `gpubusy` (busy/total) bila `gpu_busy_percentage` tidak ada.
- Catatan: belum dikompilasi/diuji di perangkat.

## v0.5.3: Laporan lebih simpel
- Header ringkas: ikon, nama game, lalu satu baris tanggal · durasi · resolusi. Kolom deskripsi jadi satu baris "Tambah catatan".
- Statistik tidak lagi 2 halaman geser: satu kartu dengan RATA-RATA FPS besar, lalu 2 baris (MAKS, MIN, 5% LOW, HALUS / CPU, GPU, SUHU, DAYA). VARIANS, sampel, dan angka per-sensor dibuang.
- Grafik jadi 3 (FPS, Beban CPU/GPU/RAM, Suhu) + Daya bila terbaca. Frametime dibuang dari grafik FPS karena skalanya (hingga 500 ms) membuat garis FPS tampak datar; frametime tetap ada di CSV.
- Label waktu sumbu X tidak ganda lagi pada rekaman pendek (<10 dtk memakai satu desimal).
- Sampel FPS pertama tiap rekaman dilewati (jendela belum penuh, sebelumnya membuat MIN jadi 2 FPS).

## v0.5.4: Ringkasan laporan tanpa angka besar
- Kartu ringkasan jadi dua kolom daftar kecil (label kiri, nilai kanan, garis tipis): Rata-rata / Maks / Min / 5% low, dan CPU / GPU / Suhu maks / Daya. Angka rata-rata FPS tidak lagi 52sp, hanya sedikit lebih menonjol (warna aksen). "Halus" dibuang.
- Judul grafik dan sudut kartu sedikit dikecilkan. Satuan "FPS" hanya di label "Rata-rata FPS", tidak diulang di tiap baris.

## v0.5.5: Wallpaper di halaman laporan
- Halaman laporan memakai wallpaper yang sama dengan Beranda (dan slider "Redupkan latar", minimal 60% supaya teks terbaca). Tanpa wallpaper tetap latar gelap polos.
- Kartu di laporan jadi semi-transparan (80%) saat ada wallpaper.

## v0.5.6: Animasi navigasi
- Bilah navigasi: pil penanda meluncur (spring) ke tab yang dipilih; ikon dan teks berubah warna halus, ikon terpilih membesar dengan efek memantul.
- Pindah tab: isi panel bergeser searah tab (kanan/kiri) sambil memudar, tinggi panel ikut berubah halus. Subjudul di kepala memudar saat ganti.
- Beranda ke laporan: laporan masuk dari kanan, tombol kembali/panah menggesernya keluar ke kanan.
- Dependensi tambahan: androidx.compose.animation (versi dari BOM).

## v0.6.0: Gaya overlay (Simple / Compact / Normal)
- Pengaturan > "Gaya overlay": pilih Simple (satu baris pil), Compact (kartu kecil: FPS + frametime, CPU, GPU, RAM, baterai + daya, dengan frekuensi), atau Normal (ditambah AVG/LOW, RAM dalam GB, daya, nama paket game). Pratinjau tiap gaya ikut warna dan transparansi overlay. Berlaku langsung dalam ~1 detik, tanpa menyalakan ulang overlay.
- Data baru di Sampler: persen baterai (tanpa Shizuku), frekuensi CPU (tertinggi antar inti) dan GPU (kgsl / devfreq). Bila tidak terbaca, bagian itu dikosongkan.
- Belum ada seperti di contoh: governor (schedutil), per-cluster/per-inti, Touch Hz, lingkaran beban. Belum dikompilasi/diuji di perangkat.

## v0.6.1: GPU MHz dan FPS saat layar tidak disentuh
- GPU MHz: dibaca dari beberapa jalur berurutan (kgsl gpuclk dan devfreq, devfreq Mali, GED MediaTek, Exynos), satuan ditebak per jalur, dan hanya nilai 100..3500 MHz yang diterima. Jalur bus/bandwidth (mis. gpubw) tidak dipakai lagi, karena nilainya bukan MHz GPU. Tab Statistik > Diagnostik menampilkan "GPU clk: jalur=nilai mentah -> hasil".
- FPS: dihitung dari frame yang diserahkan game (totalFrames + droppedFrames) dan bukan hanya frame yang tampil. Saat layar tidak disentuh, panel bisa menurunkan refresh rate sehingga frame game dilewati; itu tidak lagi terbaca sebagai FPS rendah. Waktu sampel memakai titik tengah eksekusi dumpsys agar tidak melenceng. Diagnostik FPS menampilkan "tampil X, diserahkan Y, layar Z Hz" untuk membandingkan.
- Belum dikompilasi/diuji di perangkat.

## v0.6.2: FPS di aplikasi non-game (layar statis)
- Aplikasi biasa (tanpa layer SurfaceView) hanya menggambar saat layar berubah, jadi saat diam terbaca 0-5 FPS. Itu normal, bukan lag. Sekarang bila FPS < 15 pada aplikasi seperti itu, overlay menampilkan refresh rate layar dengan tanda "idle" (mis. "60 FPS idle"). Game dan video (SurfaceView) tidak pernah diganti: angkanya tetap hasil ukur.
- Rekaman memakai FPS terukur apa adanya (fpsRaw), jadi laporan tidak terisi angka pengganti idle.
- Diagnostik FPS menandai "(SurfaceView)" bila layer game terdeteksi.

## v0.7.0: Notifikasi baterai
- Notifikasi overlay kini menampilkan info baterai: judul `PulseMonitor • Discharging` (atau Charging / Full / Not charging), baris 2 `44% • 543 mA (2,0 W) • 38°C`, baris 3 `Active: 4,2%/h • Idle: 19,1%/h` (tampil saat notifikasi diperluas / di layar kunci). Saat merekam, judul diawali `● Merekam FPS`; tombol Mulai/Berhenti rekam tetap ada.
- Active = laju kuras (%/jam) saat layar menyala, Idle = saat layar mati. Dihitung sejak dicabut dari charger, disimpan berkala; tampil "-" sampai ada data minimal 2 menit. Memakai charge counter bila HP melaporkannya (lebih halus dari persen bulat), cadangan persen bulat.
- Arus mA diambil dari BATTERY_PROPERTY_CURRENT_NOW (tanda +/- diabaikan, satuan µA/mA ditebak). Watt = mA x tegangan. Bila HP tidak melaporkan arus, bagian itu dihilangkan.
- Notifikasi disegarkan tiap 3 detik saat layar menyala. File baru: BatteryStats.kt. Belum dikompilasi/diuji di perangkat.

## v0.7.1: Ikon status bar
- Notifikasi memakai ikon petir PulseMonitor sendiri (ic_stat_pulse.xml, vektor) sebagai ikon status bar, menggantikan ikon info bawaan sistem. Warna aksen notifikasi: cyan.
- Catatan: Android hanya memakai bentuk (alpha) ikon status bar lalu mewarnainya sendiri, jadi biasanya tampil putih/monokrom. Beberapa ROM (mis. HyperOS) bisa menampilkan ikon aplikasi berwarna.

## v0.8.0: Panel kontrol dari notifikasi
- Ketuk notifikasi PulseMonitor: muncul kartu mengambang di atas aplikasi/game (tanpa membuka PulseMonitor). Isinya: Gaya overlay (Simple / Compact / Normal, yang aktif diberi aksen, berlaku langsung), tombol Rekam FPS (berubah jadi Berhenti rekam saat merekam; kartu menutup setelah ditekan), tombol Buka app, dan tombol tutup. Ketuk di luar kartu atau ketuk notifikasi lagi untuk menutup.
- Pilihan gaya memakai pengaturan yang sama dengan layar Pengaturan. Butuh izin tampil di atas aplikasi lain (sudah dipakai overlay). Belum dikompilasi/diuji di perangkat.

## v0.8.1: Judul tidak menempel chip Shizuku
- Judul "PulseMonitor" di kepala layar utama dikecilkan 36sp -> 32sp, lalu 29sp dan diberi jarak 14dp dari chip akses (Shizuku / Beri izin), supaya tidak berdempetan di layar sempit.

## v0.8.2: GPU MHz tidak macet
- Frekuensi GPU dibaca 4x per detik (jarak 50 ms) dan diambil yang tertinggi, supaya naik-turunnya terlihat dan tidak menempel di satu angka. Jalur devfreq kgsl sekarang diutamakan, ditambah kgsl clock_mhz dan devfreq *kgsl* sebagai cadangan.
- Diagnostik (Statistik) menampilkan semua nilai mentah tiap jalur dari 4 sampel, untuk melihat jalur mana yang benar-benar bergerak. Belum dikompilasi/diuji di perangkat.

## v0.8.3: Ikon jadi garis denyut (pulse)
- Ikon aplikasi (adaptive + monokrom untuk ikon bertema) dan ikon status bar notifikasi diganti dari petir menjadi garis denyut ala detak jantung. Tetap vektor XML, tanpa PNG.

## v0.8.4: Ikon pulse disempurnakan
- Ikon aplikasi: cincin tipis (transparan) di belakang garis denyut yang kini berbentuk detak jantung lebih jelas (gelombang kecil, lonjakan tinggi, lalu turun), garis lebih tebal. Versi monokrom dan ikon status bar memakai bentuk yang sama (status bar tanpa cincin supaya tetap terbaca di ukuran kecil).

## v0.8.5: Ikon cangkir kopi
- Ikon aplikasi (adaptive + monokrom) dan ikon status bar notifikasi diganti jadi cangkir kopi bergaya garis (uap, cangkir, gagang, tatakan), mengikuti simbol ☕︎. Tetap vektor XML. Berkas ic_stat_pulse.xml tetap bernama sama supaya kode tidak berubah.

## v0.8.6: Ikon lebih kecil, GPU MHz rata-rata berbobot waktu
- Ikon cangkir kopi (aplikasi dan monokrom) dikecilkan ~12% supaya lebih lega di tile ikon. Ikon status bar tidak berubah. Versi aplikasi dinaikkan ke 0.8.6 (sebelumnya masih tertulis 0.6.2).
- GPU MHz: bila devfreq trans_stat tersedia (kgsl / Mali), frekuensi dihitung sebagai rata-rata berbobot waktu selama ~1 detik terakhir (waktu tiap frekuensi dikali frekuensinya), jadi ikut naik-turun mengikuti beban dan tidak menempel di satu angka. Bila tidak ada, dipakai pembacaan sesaat seperti sebelumnya. Diagnostik menampilkan baris "GPU trans_stat" berisi waktu per frekuensi.
- Belum dikompilasi/diuji di perangkat.


## Perbaikan clock CPU/GPU yang macet dan tidak akurat
- Gejala (dari rekaman layar): overlay selalu menampilkan CPU 2600 MHz dan GPU 1430 MHz, sementara aplikasi pembanding menunjukkan GPU naik-turun (598, 1430, 184 MHz).
- GPU: sumber frekuensi yang nilainya tidak berubah selama 8 detik ditandai `[MACET]` di Diagnostik, dan bila ada sumber lain yang bergerak maka sumber itu dipakai. Ditambah sumber MediaTek `/proc/gpufreqv2/gpufreq_status` (baris yang memuat cur/real/now/actual freq).
- GPU: tidak lagi mengambil nilai tertinggi dari 4 sampel dan tidak lagi `maxOf(trans_stat puncak, sesaat)`. Dipakai sampel terbaru, atau rata-rata berbobot waktu bila trans_stat ada. Bias ke atas inilah yang membuat angka menempel di frekuensi tinggi.
- CPU: dibaca per inti dari `scaling_cur_freq` (sama dengan DevCheck), `cpuinfo_cur_freq` hanya cadangan dan ditampilkan di Diagnostik sebagai "(i...)". Diagnostik menampilkan baris baru "CPU clk: inti=MHz ...".
- Hasil Probe GPU (mt6991 / Dimensity 9500s): devfreq `48000000.mali` memberi 26 MHz (governor dummy, tidak mengikuti beban) dan `ged/hal/current_freqency` memberi `53 184363` = 184 MHz, sama dengan aplikasi pembanding. Maka di chip MediaTek, GED `current_freqency` didahulukan dan trans_stat tidak dipakai (trans_stat devfreq Mali dummy dicurigai penyebab angka menempel 1430 MHz).
- Bila GPU masih tidak cocok: buka Statistik > Diagnostik, salin baris "CPU clk" dan "GPU clk", lalu jalankan "Probe GPU dan salin" dan kirim hasilnya.
- Belum dikompilasi/diuji di perangkat.

## Pengaturan warna pindah ke tab Tampilan
- Warna aksen, warna teks overlay, latar overlay + transparansi, warna suhu, dan tombol "Kembalikan warna awal" kini ada di tab Tampilan, di bawah kartu Wallpaper. Tab Settings hanya berisi Gaya overlay. Subjudul tab disesuaikan ("Wallpaper dan warna overlay", "Gaya overlay").

## v0.4.3: Label FPS dan frekuensi GPU
- Overlay: label sekarang di depan angka (`FPS 50`, bukan `50 FPS`).
- Frekuensi GPU: sebelumnya memakai rata-rata berbobot waktu sehingga angka macet di tengah (mis. 598) dan tidak mencapai puncak. Sekarang yang tampil adalah frekuensi tertinggi yang dipakai >=5% jendela (atau sampel sesaat tertinggi), rata-rata tetap ada di diagnostik.
- Diagnostik: baris "GPU batas" menampilkan max_freq / min_freq / thermal_pwrlevel dari kernel, untuk memastikan apakah batas atas dipasang oleh sistem.
- Catatan: belum dikompilasi/diuji di perangkat.

## v0.4.4: Suara saat overlay dinyalakan
- Menekan "Nyalakan Overlay" langsung memutar suara (res/raw/overlay_on.m4a, diambil dari audio video yang dikirim). Memakai kanal notifikasi, jadi ikut volume notifikasi dan mode senyap. Tidak berbunyi saat dimatikan.
- Ganti suara: timpa file overlay_on.m4a (nama harus sama).
- Catatan: belum dikompilasi/diuji di perangkat.

## v0.4.6: Perbaikan overlay tidak mau menyala
- Bug v0.4.5: tombol "Nyalakan Overlay" mengirim intent tanpa action, tapi kode menganggapnya "layanan dihidupkan ulang sistem" dan memakai keadaan terakhir (tersembunyi). Akibatnya setelah overlay pernah disembunyikan (mode latar belakang), menekan tombol tidak memunculkan overlay. Sekarang intent kosong (null) dan intent tanpa action dibedakan.
- Belum dikompilasi/diuji di perangkat.

## v0.4.8: Beban GPU dirata-rata
- Beban GPU sebelumnya satu pembacaan per detik, jadi bisa kena momen GPU nganggur (mis. 0% padahal FPS 60 dan clock 1430 MHz) dan melompat-lompat (7%, 33%, 87%, 94%). Sekarang dibaca 6x dalam ~0,4 detik (jarak 70 ms) lalu dirata-rata.
- Diagnostik (tab Statistik) punya baris baru "GPU beban": jalur yang dipakai, tiap sampel, dan hasil rata-ratanya.
- Frekuensi GPU tidak diubah: sudah terverifikasi sama dengan devfreq dan GED di Dimensity 9500s.
- Belum dikompilasi/diuji di perangkat.

## v0.4.10: Build release
- app/build.gradle.kts: ditambah buildType release (tanpa minify, ditandatangani kunci debug). Jalankan `gradle :app:assembleRelease`; hasil: app/build/outputs/apk/release/app-release.apk.
- Workflow GitHub kini ada di .github/workflows/build.yml (assembleRelease, Gradle 8.9, JDK 17).

## Notifikasi baterai lebih lengkap
- Saat notifikasi diperluas, selain Active/Idle kini tampil: Screen On dan Screen Off (waktu, persen terpakai, mAh dari charge counter), serta Deep sleep dan Awake (pembagian waktu saat layar mati, dari selisih elapsedRealtime dan uptimeMillis). Dihitung sejak dicabut dari charger, sama seperti Active/Idle.
- mAh hanya tampil bila HP melaporkan charge counter.
- Belum dikompilasi/diuji di perangkat.

## Tombol nyalakan/matikan overlay di panel
- Panel yang muncul saat notifikasi diketuk kini punya tombol "Matikan overlay" / "Nyalakan overlay" (di antara Rekam FPS dan Buka app).
- Bila "Tetap aktif di latar belakang" mati (bawaan), mematikan overlay juga menghentikan layanan dan notifikasi hilang. Nyalakan mode itu di Settings agar notifikasi tetap ada dan overlay bisa dinyalakan lagi dari panel.
- Belum dikompilasi/diuji di perangkat.

## Detail baterai di panel
- Panel yang muncul saat notifikasi diketuk kini menampilkan ringkasan baterai yang sama dengan notifikasi yang diperluas (status, arus, Active/Idle, Screen On/Off, Deep sleep/Awake), diperbarui tiap 2 detik. Tidak perlu lagi menarik atau menahan notifikasi.
- Active/Idle tampil "-" sampai ada data minimal 2 menit pada keadaan layar masing-masing.
- Belum dikompilasi/diuji di perangkat.

## RAM di overlay
- Simple: ditambah `RAM xx%` di barisnya. Compact: RAM kini menampilkan terpakai / total (GB) di samping persen. Normal: ditambah baris `SWP` (swap/zram terpakai / total) bila HP punya swap. Layar utama: baris info "Swap" bila ada.
- Pembacaan /proc/meminfo diganti `grep` MemTotal, MemAvailable, SwapTotal, SwapFree.
- Belum dikompilasi/diuji di perangkat.

## Ikon abu-abu tanpa uap
- Ikon aplikasi (launcher, monokrom) dan ikon notifikasi: tiga garis uap di atas cangkir dihapus, cangkir diposisikan ulang ke tengah. Warna ikon launcher dan warna ikon notifikasi diganti dari cyan ke abu-abu (#9AA0A6).
- Belum dikompilasi/diuji di perangkat.

## v0.9.6: Perbaikan force close overlay + header
- Nama tampilan aplikasi: "Pulse Monitor" (launcher, header, notifikasi, laporan).
- OverlayService: startForeground dipanggil paling awal dengan notifikasi sederhana; notifikasi lengkap menyusul. Error di coroutine/notifikasi/overlay ditangkap (tidak lagi force close) dan ditampilkan lewat Toast.
- Header: judul dan chip akses sebaris, subjudul satu baris di bawahnya dengan tinggi tetap.
- Crash apa pun kini disimpan dan ditampilkan di dialog saat aplikasi dibuka lagi (bisa disalin).

## Overlay lebih rapi
- Gaya Compact dan Normal memakai kolom sejajar (label, nilai, suhu, frekuensi rata kanan); ikon menu pindah ke pojok kanan atas.
- Latar overlay bawaan lebih pekat (92%) supaya teks di belakangnya tidak tembus. Slider Transparan tetap bisa diubah (nilai lama direset ke bawaan baru sekali).

## Latensi sentuh (overlay)
- Pengaturan > "Latensi sentuh". Overlay menampilkan baris `LAT` (ms): terakhir, dan rata-rata 20 ketukan di gaya Normal.
- Cara ukur: overlay memakai FLAG_WATCH_OUTSIDE_TOUCH, jadi tiap ketukan (ACTION_DOWN) di luar overlay menghasilkan ACTION_OUTSIDE. Latensi = waktu sekarang - eventTime (cap waktu driver sentuh). Tidak butuh Shizuku/root.
- Batas: hanya ketukan awal tiap sentuhan (bukan geseran), dan tidak termasuk waktu render ke layar (touch-to-photon). Belum dikompilasi/diuji di perangkat.

## Perapian overlay
- Label (CPU, GPU, RAM, BAT, TCH, LAT) redup, nilai terang, di ketiga gaya; sebelumnya Simple memakai warna teks penuh untuk semuanya.
- LAT berwarna menurut latensi: hijau sampai 8 ms, kuning sampai 16, oranye sampai 32, merah di atasnya.
- Kode: satu helper `shape()` menggantikan dua salinan lokal, dan indentasi `showOverlay()` dirapikan. Tidak ada perubahan perilaku.

## v0.9.7: Wallpaper notifikasi + saklar touch di overlay
- Settings > Tampilan > "Wallpaper notifikasi": gambar wallpaper aplikasi (dan tingkat redupnya) juga dipakai sebagai latar badan notifikasi baterai, di versi ringkas dan diperluas. Baris judul "Pulse Monitor" di atasnya digambar Android sehingga tidak ikut bergambar. Gambar dikecilkan (560x240) supaya ringan di RemoteViews.
- Kartu pilih gaya di overlay (ketuk tombol menu) punya bagian "Touch": saklar Touch ms dan Touch Hz, sama dengan pengaturan di Settings.
- Belum dikompilasi/diuji di perangkat.


## v0.9.8: Wallpaper notifikasi sendiri + gambar memenuhi kartu
- Settings > Tampilan > "Wallpaper notifikasi": sekarang bisa memilih gambar khusus notifikasi (Pilih / Ganti / Hapus) dengan slider redup sendiri, terpisah dari wallpaper aplikasi. Tanpa gambar khusus, notifikasi tetap memakai wallpaper aplikasi seperti sebelumnya.
- Gambar notifikasi memenuhi seluruh area kartu: dibuat dalam dua ukuran sesuai bentuknya (ringkas 720x130, diperluas 720x520), bukan satu bitmap lebar yang di-crop paksa. Pudar gelap di empat tepi gambar (penyebab "pita hitam" di dalam kartu) dihapus.
- Catatan: bingkai hitam bulat di luar gambar (terlihat saat notifikasi ditahan lama) digambar oleh sistem/HyperOS dan tidak bisa ditimpa aplikasi. Warna latar kartu tetap diset ke warna rata-rata gambar agar semirip mungkin.
- Belum dikompilasi/diuji di perangkat.

## v0.9.9: Potong gambar (crop)
- Memilih wallpaper aplikasi maupun gambar notifikasi kini membuka layar potong: geser dengan satu jari, cubit atau slider Zoom untuk memperbesar. Bingkai berrasio tetap: kartu notifikasi diperluas (720:520) untuk gambar notifikasi, rasio layar untuk latar aplikasi. Gambar selalu menutup bingkai penuh, jadi hasilnya pas tanpa tepi kosong.
- Crop.kt (CropDialog) baru; WallpaperStore punya decodePreview() dan saveCropped()/saveNotifCropped().
- Belum dikompilasi/diuji di perangkat.

## Hapus tombol rekam di notifikasi ringkas
- Tombol "Rekam"/"Stop" di notifikasi ringkas dihapus. Tampilan penuh (diperluas) tetap punya tombol Mulai/Berhenti rekam.

## Resolusi laporan mengikuti game
- Resolusi di laporan rekaman kini memakai resolusi render game (ukuran buffer layer game di SurfaceFlinger), bukan resolusi layar. Dibaca tiap ~8 detik saat merekam, lalu dipakai nilai yang paling sering muncul. Game 720p tampil 720p. Bila tidak terbaca, kembali memakai resolusi layar. Rekaman lama tidak berubah.

## MAKS / MIN / RATA-RATA FPS berdesimal di laporan
- Laporan rekaman punya baris angka besar MAKS, MIN, dan RATA-RATA FPS dengan satu desimal (mis. 60,2 / 55,6 / 60,1), seperti aplikasi pembanding.
- FPS yang direkam kini menyimpan desimal (dari jendela ~2,5 detik), bukan dibulatkan. Baris "Rata-rata FPS" di kartu ringkasan diganti "Varians FPS" karena rata-ratanya sudah ada di angka besar. Rekaman lama tetap tampil berdesimal .0.

## Info baterai di notifikasi selalu mutakhir
- Notifikasi kini diperbarui seketika saat persen, status (charging/full), atau charger berubah (lewat ACTION_BATTERY_CHANGED), tidak lagi menunggu jadwal 3-30 detik dan tidak macet saat layar mati. Sebelumnya persen di notifikasi bisa tertinggal 1% dari bilah status saat mengisi daya.
- Persen dibulatkan (bukan dipotong) bila skala baterai bukan 100.

## Satuan memori: GB desimal
- Kartu Memori (RAM dan ZRAM/Swap) kini memakai GB desimal (1 GB = 10^9 byte), sama dengan DevCheck. Sebelumnya memakai GiB (1024^3) tapi diberi label "GB", jadi angkanya tampak ~7% lebih kecil (mis. RAM 10,99 vs 11,80 GB; ZRAM 6,00 vs 6,44 GB). Datanya sama, hanya satuannya.

## Perbaikan RAM / ZRAM
- ZRAM kini dihitung dari /proc/swaps (hanya perangkat zram). Swap lain (mis. berkas swap "RAM tambahan" HyperOS) tidak lagi tercampur ke angka ZRAM; bila ada, tampil terpisah sebagai "Swap tambahan". Bila /proc/swaps tak terbaca, kembali memakai SwapTotal/SwapFree.
- Tanpa Shizuku/root, kartu Memori tetap terisi (RAM dan swap dibaca langsung dari /proc, sebelumnya kosong).
- RAM terpakai dijaga tidak negatif / melebihi total bila MemAvailable aneh.

## Kartu Memori: gaya batang ringkas
- Kartu Memori kini memakai batang tebal per baris: "RAM" dan "ZRAM" (serta "Swap tambahan" bila ada) dengan teks terpakai / total GB, batang terisi sesuai pemakaian, dan legenda "Terpakai %" + "Bebas GB". Ukuran RAM di kotak (mis. 12 GB) pindah ke samping judul "Memori".

## Bingkai gelap di pratinjau notifikasi (tahan lama)
- Notifikasi lengkap kini dipasang lewat startForeground (id sama), bukan hanya notify(), supaya pewarnaan kartu dengan warna rata-rata gambar berlaku penuh untuk notifikasi layanan latar depan. Tujuannya: bingkai gelap yang digambar HyperOS ikut berwarna seperti gambar. Tidak dijamin: bila HyperOS tetap menggambar bingkai sendiri di pratinjau tahan-lama, itu batas sistem. Gambar sendiri sudah meluber jauh ke luar area kustom (tapi dipotong sistem di pratinjau itu).

## Foto notifikasi dengan sudut membulat
- Foto latar notifikasi (ringkas dan diperluas) kini bersudut bulat dan pas di area kustom, tanpa luberan ke luar. Bingkai gelap buatan HyperOS yang muncul saat notifikasi ditahan lama jadi tampak seperti bingkai foto yang disengaja. Radius sudut: konstanta CORNER di WallpaperStore.kt (36 px bitmap); luberan: BLEED_DP di OverlayService.kt (0).

## Overlay Simple: TCH/LAT tidak terpotong lagi
- Gaya Simple dulu dipaksa satu baris, jadi saat BAT + TCH (Touch Hz) + LAT ikut aktif, bagian kanan yang melewati lebar layar terpotong (terlihat berhenti di "RAM 6..."). Sekarang Simple boleh turun ke baris berikutnya (maks 3 baris) bila tidak muat; bila muat tetap satu baris. Label dan nilainya diikat (spasi tak terputus) supaya tidak terpisah di pergantian baris.

## Overlay Compact ala monitor game
- Gaya Compact dibuat seperti contoh: kotak gelap bersudut bulat dengan garis tepi abu-abu tipis; label (FPS, CPU, GPU, RAM, BAT, TCH, LAT) berwarna gradasi biru ke pink, nilai putih.
- Urutan baris: FPS + frametime, CPU, GPU (masing-masing dengan bilah beban tipis di bawahnya), RAM, BAT (+ watt), TCH, lalu LAT bila Touch ms aktif. Kolom sejajar: label, nilai, suhu, ekstra (MHz / W).
- Suhu dan frekuensi memakai warna teks overlay (tidak lagi diwarnai hijau/kuning/merah); bilah beban tetap berwarna menurut beban (hijau, kuning, oranye, merah). Teks RAM terpakai/total (GB) dihapus dari Compact, persen tetap ada (Normal masih menampilkannya).
- Ikon menu di kanan dihapus pada gaya Compact; sebagai gantinya ketuk kotak overlay untuk membuka pemilih gaya (tahan ~1 detik tetap mulai/berhenti rekam, geser tetap memindahkan).
- Kode: OverlayService.compact() ditulis ulang, GradSpan (warna teks gradasi) baru. Belum dikompilasi/diuji di perangkat.

## Hapus info baterai dari panel notifikasi
- Panel yang muncul saat notifikasi diketuk tidak lagi menampilkan blok ringkasan baterai (status, arus, Aktif/Diam, Layar Nyala/Mati, Tidur lelap/Terjaga). Isinya kini hanya Gaya overlay, Rekam FPS, dan Matikan/Nyalakan overlay (tombol Buka app juga dihapus).
- Info baterai di notifikasi itu sendiri tidak diubah.
- Belum dikompilasi/diuji di perangkat.
