package com.pulsemonitor

import android.annotation.SuppressLint
import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.widget.Toast
import android.provider.Settings
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.LinearLayout
import android.view.ViewGroup
import kotlinx.coroutines.*

class OverlayService : Service() {
    companion object { const val ACTION_REC = "com.pulsemonitor.REC"; const val ACTION_PANEL = "com.pulsemonitor.PANEL" }
    private var box: TextView? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    override fun onBind(i: Intent?): IBinder? = null

    // Layar menyala/mati: pisahkan laju kuras Active vs Idle, dan segarkan notifikasi
    private var screenRx: BroadcastReceiver? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    /** Notifikasi dengan tombol Mulai/Berhenti rekam, supaya bisa dikendalikan dari dalam game. */
    private fun buildNotif(): Notification {
        val rec = Recorder.active.value
        val pi = PendingIntent.getService(this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_REC),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val tap = PendingIntent.getService(this, 2, Intent(this, OverlayService::class.java).setAction(ACTION_PANEL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val act = Notification.Action.Builder(
            android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_media_play),
            if (rec) "Berhenti rekam" else "Mulai rekam", pi).build()
        val b = BatteryStats.tick()
        val title = (if (rec) "● Merekam FPS" else "PulseMonitor") + (b?.let { " • ${it.status}" } ?: "")
        val l2 = b?.line2 ?: "Overlay aktif"
        val nb = Notification.Builder(this, "ov").setSmallIcon(R.drawable.ic_stat_pulse).setColor(0xFF3DF0FF.toInt())
            .setContentTitle(title).setContentText(l2)
            .setOnlyAlertOnce(true).setShowWhen(false).setContentIntent(tap).addAction(act)
        // Baris ke-3 (Active/Idle) tampil saat notifikasi diperluas / di layar kunci
        if (b != null) nb.setStyle(Notification.BigTextStyle().bigText(l2 + "\n" + b.line3))
        return nb.build()
    }

    private fun refreshNotif() { getSystemService(NotificationManager::class.java).notify(1, buildNotif()) }

    private fun toggleRec() {
        if (Recorder.active.value) {
            scope.launch {
                val r = withContext(Dispatchers.IO) { Recorder.stop(this@OverlayService) }
                Toast.makeText(this@OverlayService, if (r != null) "Rekaman tersimpan" else "Tidak ada data FPS yang terekam", Toast.LENGTH_SHORT).show()
                refreshNotif()
            }
        } else {
            Recorder.start()
            Toast.makeText(this, "Mulai merekam FPS", Toast.LENGTH_SHORT).show()
            refreshNotif()
        }
    }


    // ---------- Panel kontrol (muncul saat notifikasi diketuk) ----------
    private var panel: View? = null
    private var panelJob: Job? = null

    private fun closePanel() {
        panelJob?.cancel(); panelJob = null
        panel?.let { v -> runCatching { getSystemService(WindowManager::class.java).removeView(v) } }
        panel = null
    }

    private fun togglePanel() { if (panel != null) closePanel() else openPanel() }

    /** Kartu mengambang: pilih Gaya overlay (Simple/Compact/Normal) dan Rekam FPS tanpa keluar dari game. */
    private fun openPanel() {
        val wm = getSystemService(WindowManager::class.java)
        val acc = AppSettings.accent
        val base = 0xFF2B2C35.toInt(); val light = 0xFFEDEDF2.toInt()
        fun shape(c: Int, r: Int, stroke: Int? = null) = GradientDrawable().apply {
            setColor(c); cornerRadius = dp(r).toFloat(); if (stroke != null) setStroke(dp(1), stroke)
        }
        fun txt(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
        }
        fun btn(label: String, onClick: () -> Unit) = TextView(this).apply {
            text = label; textSize = 14f; setTextColor(light); gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12)); background = shape(base, 14); setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(6))
            background = shape(0xFF14151C.toInt(), 22, withAlpha(acc, 33))
        }
        // Kepala: judul + status, tombol tutup
        val sub = txt("", 13f, acc)
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(txt("PulseMonitor", 13f, acc, true)); titles.addView(sub)
        head.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(txt("✕", 20f, acc).apply { setPadding(dp(10), dp(4), dp(4), dp(4)); setOnClickListener { closePanel() } })
        root.addView(head)

        // Kiri: gaya overlay
        val left = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(0)); background = shape(0xFF1E1F27.toInt(), 16)
        }
        left.addView(txt("Gaya overlay", 11f, withAlpha(light, 65)).apply { setPadding(dp(6), 0, 0, dp(6)) })
        var paint: () -> Unit = {}
        val styleBtns = AppSettings.STYLES.mapIndexed { idx, name ->
            btn(name) { AppSettings.overlayStyle = idx; AppSettings.save(this); paint() }
        }
        styleBtns.forEach { left.addView(it) }
        paint = {
            styleBtns.forEachIndexed { idx, b ->
                val sel = AppSettings.overlayStyle == idx
                b.background = if (sel) shape(withAlpha(acc, 28), 14, acc) else shape(base, 14)
                b.setTextColor(if (sel) acc else light)
            }
            sub.text = "Gaya: " + AppSettings.STYLES[AppSettings.overlayStyle]
        }
        paint()

        // Kanan: rekam FPS + buka aplikasi
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), 0, 0, 0) }
        val rec = btn("") { togglePanelRec() }.apply { gravity = Gravity.CENTER; background = shape(0xFF1E1F27.toInt(), 14) }
        val open = btn("Buka app") {
            closePanel()
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }.apply { gravity = Gravity.CENTER; background = shape(0xFF1E1F27.toInt(), 14) }
        right.addView(rec); right.addView(open)

        val body = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(10), 0, 0) }
        body.addView(left, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        body.addView(right, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(body)

        val dm = resources.displayMetrics
        val lp = WindowManager.LayoutParams(
            minOf(dm.widthPixels - dp(32), dp(340)), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,   // ketuk di luar kartu = tutup
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        root.setOnTouchListener { _, e -> if (e.actionMasked == MotionEvent.ACTION_OUTSIDE) { closePanel(); true } else false }
        if (runCatching { wm.addView(root, lp) }.isFailure) return
        panel = root
        // Label tombol rekam mengikuti status rekaman
        panelJob = scope.launch {
            Recorder.active.collect { on ->
                rec.text = if (on) "■ Berhenti rekam" else "● Rekam FPS"
                rec.setTextColor(if (on) 0xFFFF5C5C.toInt() else light)
            }
        }
    }

    /** Mulai/berhenti rekam dari panel; kartu ditutup supaya tidak menutupi game. */
    private fun togglePanelRec() { toggleRec(); closePanel() }

    @SuppressLint("ClickableViewAccessibility")
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        BatteryStats.init(this)
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("ov", "Overlay", NotificationManager.IMPORTANCE_LOW))
        if (i?.action == ACTION_REC) toggleRec()
        val notif = buildNotif()
        // Tipe specialUse baru ada di API 34; di bawahnya pakai versi 2 argumen
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, notif)
        // Izin overlay bisa dicabut kapan saja; addView akan crash tanpa pengecekan ini
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (box == null) {
            AppSettings.load(this); Sampler.init(this); Sampler.start()
            val wm = getSystemService(WindowManager::class.java)
            val prefs = getSharedPreferences("overlay", MODE_PRIVATE)

            val bg = GradientDrawable().apply {
                setColor(withAlpha(AppSettings.overlayBg, AppSettings.alpha)); cornerRadius = dp(40).toFloat()
                setStroke(dp(1), withAlpha(AppSettings.accent, 33))
            }
            val v = TextView(this).apply {
                typeface = Typeface.MONOSPACE; textSize = 12f; setTextColor(AppSettings.overlayText)
                setSingleLine(true); setPadding(dp(12), dp(5), dp(12), dp(5)); background = bg
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,       // bisa disentuh (untuk digeser), tidak mencuri fokus
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START; x = prefs.getInt("x", dp(12)); y = prefs.getInt("y", dp(40)) }

            // Geser: tahan lalu seret; posisi disimpan dan dipakai lagi saat overlay dinyalakan berikutnya
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
            // Tahan overlay ~1 detik tanpa menggeser = mulai/berhenti rekam
            val longPress = Runnable { toggleRec(); v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS) }
            v.setOnTouchListener { view: View, e: MotionEvent ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false; view.postDelayed(longPress, 1000) }
                    MotionEvent.ACTION_CANCEL -> view.removeCallbacks(longPress)
                    MotionEvent.ACTION_MOVE -> {
                        if (!moved && (Math.abs(e.rawX - tx) > dp(8) || Math.abs(e.rawY - ty) > dp(8))) { moved = true; view.removeCallbacks(longPress) }
                        if (!moved) return@setOnTouchListener true
                        val dm = resources.displayMetrics
                        lp.x = (sx + (e.rawX - tx).toInt()).coerceIn(0, maxOf(0, dm.widthPixels - view.width))
                        lp.y = (sy + (e.rawY - ty).toInt()).coerceIn(0, maxOf(0, dm.heightPixels - view.height))
                        runCatching { wm.updateViewLayout(view, lp) }
                    }
                    MotionEvent.ACTION_UP -> { view.removeCallbacks(longPress); if (moved) prefs.edit().putInt("x", lp.x).putInt("y", lp.y).apply() }
                }
                true
            }
            val ok = runCatching { wm.addView(v, lp) }.isSuccess
            if (!ok) { stopSelf(); return START_NOT_STICKY }
            box = v
            val rx = object : BroadcastReceiver() {
                override fun onReceive(c: Context, intent: Intent) {
                    BatteryStats.setScreen(intent.action == Intent.ACTION_SCREEN_ON); refreshNotif()
                }
            }
            registerReceiver(rx, IntentFilter().apply { addAction(Intent.ACTION_SCREEN_ON); addAction(Intent.ACTION_SCREEN_OFF) })
            screenRx = rx
            // Segarkan notifikasi tiap 3 detik saat layar menyala; saat mati cukup hitung statistik
            scope.launch {
                while (isActive) {
                    if (BatteryStats.isScreenOn()) refreshNotif() else BatteryStats.tick()
                    delay(3000)
                }
            }
            scope.launch {
                var lastStyle = -1
                Sampler.state.collect { s ->
                    val style = AppSettings.overlayStyle
                    if (style != lastStyle) {   // ganti bentuk: satu baris (pil) atau kartu beberapa baris
                        lastStyle = style
                        v.setSingleLine(style == 0); if (style != 0) v.maxLines = Int.MAX_VALUE
                        bg.cornerRadius = dp(if (style == 0) 40 else 16).toFloat()
                        v.setPadding(dp(12), dp(if (style == 0) 5 else 8), dp(12), dp(if (style == 0) 5 else 8))
                        v.textSize = if (style == 0) 12f else 11.5f
                    }
                    bg.setColor(withAlpha(AppSettings.overlayBg, AppSettings.alpha))
                    bg.setStroke(dp(1), withAlpha(AppSettings.accent, 33))
                    v.setTextColor(AppSettings.overlayText)
                    v.text = line(s)
                }
            }
        }
        if (i?.action == ACTION_PANEL) togglePanel()
        return START_STICKY
    }

    private fun muted() = withAlpha(AppSettings.overlayText, 65)

    private class B(val sb: SpannableStringBuilder = SpannableStringBuilder()) {
        fun put(t: String, color: Int? = null, bold: Boolean = false): B {
            val st = sb.length; sb.append(t)
            if (color != null) sb.setSpan(ForegroundColorSpan(color), st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            if (bold) sb.setSpan(StyleSpan(Typeface.BOLD), st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            return this
        }
        fun temp(t: Float) = if (t >= 0) put("%.0f°".format(t), heat(t)) else put("-")
        fun nl() = put("\n")
    }

    private fun head(b: B, s: Snap, ms: Boolean): B {
        if (Recorder.active.value) b.put("● ", 0xFFFF5C5C.toInt())
        b.put("${s.fps}", null, true).put(" FPS", AppSettings.accent)
        if (s.idle) b.put(" idle", muted())          // layar statis: angka = refresh rate layar
        else if (ms && s.fps > 0) b.put("  %.1f ms".format(1000f / s.fps), muted())
        return b
    }

    private fun mhz(v: Int) = if (v >= 0) "$v MHz" else ""
    private fun watt(w: Float) = if (w >= 0f) "%.1f W".format(w) else ""

    /** Simple: satu baris. 60 FPS  CPU 35% 42°  GPU 45% 41°  BAT 85% 36° */
    private fun simple(s: Snap): CharSequence {
        val b = B(); head(b, s, false)
        b.put("  CPU ${pct(s.cpu)} ").temp(s.tCpu)
        b.put("  GPU ${pct(s.gpu)} ").temp(s.tGpu)
        b.put("  BAT ")
        if (s.batPct >= 0) b.put("${s.batPct}% ").temp(s.tBat) else b.temp(s.tBat)
        return b.sb
    }

    /** Compact: kartu kecil, satu baris per komponen. */
    private fun compact(s: Snap): CharSequence {
        val b = B(); head(b, s, true).nl()
        b.put("CPU ", muted()).put("${pct(s.cpu)}  ").temp(s.tCpu).put("  " + mhz(s.cpuMhz), muted()).nl()
        b.put("GPU ", muted()).put("${pct(s.gpu)}  ").temp(s.tGpu).put("  " + mhz(s.gpuMhz), muted()).nl()
        b.put("RAM ", muted()).put(pct(s.ramPct)).nl()
        b.put("BAT ", muted()).put(if (s.batPct >= 0) "${s.batPct}%  " else "-  ").temp(s.tBat).put("  " + watt(s.watt), muted())
        return b.sb
    }

    /** Normal: paling lengkap, termasuk rata-rata, 1% low, RAM dalam GB, dan nama paket game. */
    private fun normal(s: Snap): CharSequence {
        val b = B(); head(b, s, true).nl()
        b.put("AVG ", muted()).put("${s.avg}").put("   LOW ", muted()).put("${s.low}").nl()
        b.put("CPU ", muted()).put("${pct(s.cpu)}  ").temp(s.tCpu).put("  " + mhz(s.cpuMhz), muted()).nl()
        b.put("GPU ", muted()).put("${pct(s.gpu)}  ").temp(s.tGpu).put("  " + mhz(s.gpuMhz), muted()).nl()
        b.put("RAM ", muted()).put("${pct(s.ramPct)}  ${s.ramText}").nl()
        b.put("BAT ", muted()).put(if (s.batPct >= 0) "${s.batPct}%  " else "-  ").temp(s.tBat).nl()
        b.put("PWR ", muted()).put(if (s.watt >= 0f) watt(s.watt) else "-")
        if (s.pkg.isNotEmpty()) b.nl().put(s.pkg, muted())
        return b.sb
    }

    private fun line(s: Snap): CharSequence = when (AppSettings.overlayStyle) { 1 -> compact(s); 2 -> normal(s); else -> simple(s) }

    override fun onDestroy() {
        closePanel()
        screenRx?.let { runCatching { unregisterReceiver(it) } }; screenRx = null
        scope.cancel(); box?.let { v -> runCatching { getSystemService(WindowManager::class.java).removeView(v) } }; box = null
        super.onDestroy()
    }
}

fun heat(t: Float) = when {
    t < 45f -> 0xFF7CFFB2.toInt()     // aman
    t < 55f -> 0xFFFFD866.toInt()     // hangat
    t < 65f -> 0xFFFF9F43.toInt()     // panas
    else -> 0xFFFF5C5C.toInt()        // sangat panas
}
fun deg(v: Float) = if (v >= 0) "%.0f°".format(v) else "-"
fun pct(v: Int) = if (v >= 0) "$v%" else "-"
