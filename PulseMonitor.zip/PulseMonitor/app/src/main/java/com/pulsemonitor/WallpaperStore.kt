package com.pulsemonitor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import java.io.File

/** Menyimpan wallpaper latar aplikasi. Gambar disalin ke
 *  penyimpanan internal, jadi tidak bergantung pada izin galeri dan tetap ada walau file aslinya dihapus. */
object WallpaperStore {
    private const val MAX_SIDE = 1600   // sisi terpanjang setelah diperkecil, hemat RAM
    private const val PREFS = "pulse"
    private const val KEY_DIM = "dim"

    private fun file(c: Context) = File(c.filesDir, "wallpaper.jpg")

    /** Baca gambar pilihan, diperkecil (maks 1600 px) dan sudah diputar sesuai EXIF. Dipakai layar potong dan penyimpanan. */
    fun decodePreview(c: Context, uri: Uri): Bitmap? = runCatching {
        ImageDecoder.decodeBitmap(ImageDecoder.createSource(c.contentResolver, uri)) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE   // bitmap hardware tidak bisa di-compress
            var sample = 1
            while (maxOf(info.size.width, info.size.height) / sample > MAX_SIDE) sample *= 2
            if (sample > 1) decoder.setTargetSampleSize(sample)
        }
    }.getOrNull()

    private fun writeTo(c: Context, bmp: Bitmap, target: File): Boolean = runCatching {
        val tmp = File(c.filesDir, target.name + ".tmp")
        tmp.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        check(tmp.renameTo(target) || (target.delete() && tmp.renameTo(target)))
    }.isSuccess

    private fun saveTo(c: Context, uri: Uri, target: File): Boolean {
        val bmp = decodePreview(c, uri) ?: return false
        return writeTo(c, bmp, target).also { bmp.recycle() }
    }

    /** Simpan hasil potong (sudah dalam rasio yang diinginkan). */
    fun saveCropped(c: Context, bmp: Bitmap): Boolean = writeTo(c, bmp, file(c))

    // ---------- Wallpaper aplikasi ----------
    fun save(c: Context, uri: Uri): Boolean = saveTo(c, uri, file(c))

    fun load(c: Context): Bitmap? = file(c).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }

    fun clear(c: Context) { file(c).delete() }

    fun dim(c: Context): Float = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getFloat(KEY_DIM, 0.6f)

    fun saveDim(c: Context, v: Float) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putFloat(KEY_DIM, v).apply()
    }

    /** Bersihkan sisa fitur wallpaper notifikasi (gambar dan pengaturan redupnya) dari versi lama. */
    fun purgeNotifLeftovers(c: Context) {
        File(c.filesDir, "notif_wallpaper.jpg").delete()
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove("notif_dim").apply()
    }
}
