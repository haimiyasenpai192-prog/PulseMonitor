package com.pulsemonitor

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Setelah HP menyala / aplikasi diperbarui: bila "Tetap aktif di latar belakang" nyala, hidupkan lagi notifikasinya. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED || i.action == Intent.ACTION_MY_PACKAGE_REPLACED) OverlayService.ensureRunning(c)
        // CPU Tuner: nilai sysfs kembali bawaan tiap boot, jadi tulis ulang profil terakhir bila pengguna menyalakannya (hanya saat boot)
        if (i.action == Intent.ACTION_BOOT_COMPLETED && CpuTuner.bootApply(c)) {
            val pr = goAsync()
            Thread {
                try { Thread.sleep(8000); CpuTuner.applySaved(c) } catch (_: Throwable) {} finally { pr.finish() }
            }.start()
        }
    }
}
