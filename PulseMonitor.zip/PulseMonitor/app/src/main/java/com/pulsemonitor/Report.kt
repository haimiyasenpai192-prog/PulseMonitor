package com.pulsemonitor

import android.content.Context
import android.graphics.Bitmap
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.graphics.graphicsLayer
import kotlin.math.ceil
import kotlin.math.floor

private val Bgr = Color(0xFF101014)
private val CardC = Color(0xFF1D1E24)
private val Muted = Color(0xFF8E8E99)
private val Peri = Color(0xFFD3D7DC)
private val CBlue = Color(0xFF4C8DFF)
private val CGreen = Color(0xFF4CC38A)
private val CAmber = Color(0xFFF5B83D)
private val CPink = Color(0xFFE5677A)
private val COrange = Color(0xFFB07CFF)

/** Warna kartu: semi-transparan bila ada wallpaper, supaya gambar latar tetap terlihat. */
private val LocalCard = compositionLocalOf { CardC }

class Series(val name: String, val color: Color, val v: List<Float>)

fun appIcon(ctx: Context, pkg: String): Bitmap? = runCatching {
    val d = ctx.packageManager.getApplicationIcon(pkg)
    val bmp = Bitmap.createBitmap(192, 192, Bitmap.Config.ARGB_8888)
    d.setBounds(0, 0, 192, 192); d.draw(android.graphics.Canvas(bmp)); bmp
}.getOrNull()

/** Laporan satu rekaman: header, catatan, satu kartu ringkasan, lalu tiga grafik. */
@Composable
fun ReportView(s: Session, onBack: () -> Unit, onShare: () -> Unit, onSave: () -> Unit = {}, onCsv: () -> Unit, onDelete: () -> Unit, onDesc: (String) -> Unit,
               wallpaper: Bitmap? = null, dim: Float = 0.6f) {
    val ctx = LocalContext.current
    val st = remember(s) { s.stats() }
    val icon = remember(s.pkg) { appIcon(ctx, s.pkg) }
    var desc by remember(s.id) { mutableStateOf(s.desc) }
    var confirm by remember { mutableStateOf(false) }
    LaunchedEffect(desc) { if (desc != s.desc) { delay(600); onDesc(desc) } }
    // Catatan yang baru diketik dan langsung ditinggal (<0,6 detik) tetap tersimpan
    val latestDesc by rememberUpdatedState(desc)
    DisposableEffect(s.id) { onDispose { if (latestDesc != s.desc) onDesc(latestDesc) } }
    // "Yakin hapus?" tidak boleh menggantung selamanya
    LaunchedEffect(confirm) { if (confirm) { delay(3000); confirm = false } }

    val card = if (wallpaper != null) CardC.copy(alpha = AppSettings.panelAlpha / 100f) else CardC
    CompositionLocalProvider(LocalCard provides card) {
    Box(Modifier.fillMaxSize().background(Bgr)) {
    if (wallpaper != null) {
        Image(wallpaper.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        // Teks banyak: redam minimal 60% supaya tetap terbaca, mengikuti slider "Redupkan latar" bila lebih gelap
        Box(Modifier.fillMaxSize().background(Bgr.copy(alpha = dim.coerceAtLeast(0.6f))))
    }
    Column(Modifier.fillMaxSize().imePadding().verticalScroll(rememberScrollState())
        .statusBarsPadding().navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.size(44.dp).clip(CircleShape).clickable { onBack() }, contentAlignment = Alignment.Center) {
                Text("←", color = Color.White, fontSize = 26.sp)
            }
            Spacer(Modifier.weight(1f))
            Pill("Bagikan", onShare); Pill("Simpan", onSave); Pill("CSV", onCsv)
            Pill(if (confirm) "Yakin?" else "Hapus", { if (confirm) onDelete() else confirm = true },
                if (confirm) Color(0xFF5A2530) else card)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) Image(icon.asImageBitmap(), null, Modifier.size(56.dp).clip(RoundedCornerShape(13.dp)))
            else Box(Modifier.size(56.dp).background(card, RoundedCornerShape(13.dp)))
            Column(Modifier.padding(start = 14.dp).weight(1f)) {
                Text(s.label, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 2, lineHeight = 26.sp, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                Text("Durasi ${fmtDur(s.dur)}", color = Color(0xFFC4C6CE), fontSize = 12.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.padding(top = 3.dp))
            }
        }
        Box(Modifier.fillMaxWidth().background(card, RoundedCornerShape(18.dp)).padding(horizontal = 16.dp, vertical = 13.dp)) {
            BasicTextField(desc, { desc = it }, textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                cursorBrush = SolidColor(Color.White), modifier = Modifier.fillMaxWidth(),
                decorationBox = { inner -> if (desc.isEmpty()) Text("Tambah catatan", color = Muted, fontSize = 15.sp); inner() })
        }
        // Kartu statistik: tanggal + resolusi di atas, lalu dua halaman (geser kiri-kanan), titik penanda di bawah
        val pages = remember(s) { statPages(s, st) }
        val pager = androidx.compose.foundation.pager.rememberPagerState { pages.size }
        Column(Modifier.fillMaxWidth().background(card, RoundedCornerShape(20.dp)).padding(horizontal = 12.dp, vertical = 14.dp)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(fmtDate(s.id), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                Spacer(Modifier.weight(1f))
                if (s.res.isNotBlank()) Text("Res : ${s.res}", color = Muted, fontSize = 13.sp, maxLines = 1)
            }
            Box(Modifier.fillMaxWidth().padding(top = 10.dp).height(0.5.dp).background(Color(0x22FFFFFF)))
            androidx.compose.foundation.pager.HorizontalPager(pager, Modifier.fillMaxWidth().padding(top = 14.dp), pageSpacing = 16.dp) { pg ->
                // Seberapa jauh halaman ini dari posisi tengah (0 = pas di tengah, 1 = sudah keluar); mengikuti jari saat menggeser
                val off = (((pager.currentPage - pg) + pager.currentPageOffsetFraction).let { if (it < 0f) -it else it }).coerceIn(0f, 1f)
                Box(Modifier.graphicsLayer {
                    alpha = 1f - 0.75f * off
                    val sc = 1f - 0.08f * off
                    scaleX = sc; scaleY = sc
                    translationY = 10.dp.toPx() * off
                }) {
                    if (pg == 0) HeroPage(pages[0], off) else Column(Modifier.fillMaxWidth().heightIn(min = 158.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        pages[pg].chunked(4).forEachIndexed { ri, row ->
                            if (ri > 0) Box(Modifier.fillMaxWidth().height(0.5.dp).background(Color(0x22FFFFFF)))
                            Row(Modifier.fillMaxWidth()) {
                                row.forEachIndexed { ci, (top, v, bottom) -> StatCell(top, v, bottom, Modifier.weight(1f).stagger(off, ri * 4 + ci)) }
                            }
                        }
                    }
                }
            }
            // Titik penanda: yang aktif melebar dan memutih mengikuti geseran; tap titik untuk pindah halaman dengan animasi
            val pageScope = rememberCoroutineScope()
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                repeat(pages.size) { i ->
                    val near = (1f - (((pager.currentPage - i) + pager.currentPageOffsetFraction).let { if (it < 0f) -it else it })).coerceIn(0f, 1f)
                    Box(Modifier.padding(horizontal = 3.dp).height(6.dp).width((6f + 12f * near).dp)
                        .clip(CircleShape)
                        .background(androidx.compose.ui.graphics.lerp(Color(0x55FFFFFF), Color.White, near))
                        .clickable { pageScope.launch { pager.animateScrollToPage(i) } })
                }
            }
        }
        LineChart("Suhu (°C)", s.t, listOf(Series("CPU", CAmber, s.tCpu), Series("GPU", COrange, s.tGpu), Series("Baterai", CGreen, s.tBat), Series("HP", CPink, s.phoneTemp)), fromZero = false)
        LineChart("Beban (%)", s.t, listOf(Series("CPU", CBlue, s.cpu), Series("GPU", CPink, s.gpu), Series("RAM", CGreen, s.ram)))
        LineChart("FPS", s.t, listOf(
            Series("FPS", CBlue, s.fps),
            Series("Frametime", CGreen, s.fps.map { if (it > 0f) 1000f / it else -1f }),
            Series("Suhu", CAmber, s.temp)), fromZero = true)
        if (s.watt.any { it >= 0f }) LineChart("Daya (W)", s.t, listOf(Series("Daya", CPink, s.watt)))
    }
    }
    }
}

@Composable
private fun Pill(text: String, onClick: () -> Unit, bg: Color = Color.Unspecified) {
    val fill = if (bg == Color.Unspecified) LocalCard.current else bg
    Text(text, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(fill).clickable { onClick() }.padding(horizontal = 12.dp, vertical = 9.dp))
}

/** Halaman 1 kartu statistik: rata-rata FPS besar di kiri, Maks/Min/Varians di kanan, empat angka kecil di bawah. */
@Composable
private fun HeroPage(c: List<Triple<String, String, String>>, off: Float = 0f) {
    Column(Modifier.fillMaxWidth().heightIn(min = 158.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1.1f).stagger(off, 0), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Rata-rata", color = Color(0xFFC4C6CE), fontSize = 12.sp, maxLines = 1)
                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.Center) {
                    Text(c[2].second, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                    Text(" FPS", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 5.dp), maxLines = 1)
                }
            }
            Box(Modifier.width(0.5.dp).height(64.dp).background(Color(0x22FFFFFF)))
            Column(Modifier.weight(1f).padding(start = 14.dp)) {
                listOf(0, 1, 3).forEachIndexed { k, i -> Box(Modifier.stagger(off, k + 1)) { StatLine(c[i].first, c[i].second, c[i].third) } }
            }
        }
        Box(Modifier.fillMaxWidth().padding(vertical = 12.dp).height(0.5.dp).background(Color(0x22FFFFFF)))
        Row(Modifier.fillMaxWidth()) {
            listOf(4, 5, 6, 7).forEachIndexed { k, i -> StatCell(c[i].first, c[i].second, c[i].third, Modifier.weight(1f).stagger(off, k + 4)) }
        }
    }
}

@Composable
private fun StatLine(label: String, value: String, unit: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color(0xFFC4C6CE), fontSize = 13.sp, maxLines = 1, softWrap = false, modifier = Modifier.weight(1f))
        Text(value, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
        Text(" $unit", color = Muted, fontSize = 11.sp, maxLines = 1, softWrap = false)
    }
}

/** Animasi bertahap saat geser: tiap sel memudar dan naik sedikit dengan jeda berbeda, jadi isi kartu "mengalir" masuk satu per satu.
 *  off = 0 saat halaman pas di tengah (semua sel penuh), 1 saat sudah keluar; k = urutan sel (makin besar makin telat muncul). */
private fun Modifier.stagger(off: Float, k: Int): Modifier = this.graphicsLayer {
    val p = (1f - off * (1f + 0.25f * k)).coerceIn(0f, 1f)
    alpha = p
    translationY = (1f - p) * 16.dp.toPx()
}

@Composable
private fun StatCell(top: String, value: String, bottom: String, modifier: Modifier = Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(top, color = Color(0xFFC4C6CE), fontSize = 12.sp, maxLines = 1, softWrap = false)
        Text(value, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false,
            modifier = Modifier.padding(top = 3.dp, bottom = 1.dp))
        Text(bottom, color = Muted, fontSize = 11.sp, maxLines = 1, softWrap = false)
    }
}

/** Isi kartu statistik: dua halaman, tiap halaman 8 sel (atas, nilai, bawah). Dipakai layar laporan dan gambar bagikan. */
fun statPages(s: Session, st: Stats): List<List<Triple<String, String, String>>> {
    fun pct(v: Float) = if (v >= 0f) "%.0f".format(v) else "-"
    return listOf(
        listOf(
            Triple("Maks", f1(st.max), "FPS"), Triple("Min", f1(st.min), "FPS"),
            Triple("Rata-rata", f1(st.avg), "FPS"), Triple("Varians", f1(st.sd), "FPS"),
            Triple("Relatif", f1(st.smooth), "Kehalusan"), Triple("5% low", f1(st.low5), "FPS"),
            Triple("MAX", if (st.maxTemp >= 0f) "%.0f".format(st.maxTemp) else "-", "Temperatur"),
            Triple("Daya", if (st.avgWatt >= 0f) f1(st.avgWatt) else "-", "Watt")
        ),
        listOf(
            Triple("CPU", pct(s.cpu.avgValid()), "%"), Triple("GPU", pct(s.gpu.avgValid()), "%"),
            Triple("RAM", pct(s.ram.avgValid()), "%"), Triple("1% low", f1(st.low1), "FPS"),
            Triple("Frame avg", f1(st.ftAvg), "ms"), Triple("Frame maks", f1(st.ftMax), "ms"),
            Triple("Drop", st.drops.toString(), "detik"), Triple("Energi", if (st.energyMwh >= 0f) "%.0f".format(st.energyMwh) else "-", "mWh")
        )
    )
}

/** Grafik garis: grid putus-putus, label sumbu, nilai terakhir tiap seri di kanan, legenda di bawah. Nilai < 0 = putus.
 *  Seri tanpa data sama sekali disembunyikan; grafik tanpa data tidak ditampilkan. fromZero=false: sumbu Y mengikuti rentang data (suhu). */
@Composable
fun LineChart(title: String, t: List<Float>, series: List<Series>, fromZero: Boolean = true) {
    val tm = rememberTextMeasurer()
    val n = t.size
    val shown = series.filter { sr -> sr.v.any { it >= 0f } }
    if (shown.isEmpty() || n < 2) return
    Column(Modifier.fillMaxWidth().background(LocalCard.current, RoundedCornerShape(20.dp)).padding(14.dp)) {
        Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        Canvas(Modifier.fillMaxWidth().padding(top = 12.dp).height(170.dp)) {
            val lbl = TextStyle(color = Muted, fontSize = 11.sp)
            val left = 34.dp.toPx(); val right = 34.dp.toPx(); val bottom = 22.dp.toPx(); val top = 6.dp.toPx()
            val w = size.width - left - right; val h = size.height - top - bottom
            val all = shown.flatMap { it.v }.filter { it >= 0f }
            val rawMax = all.max(); val rawMin = if (fromZero) 0f else all.min()
            val span = (rawMax - rawMin).coerceAtLeast(1f)
            val steps = floatArrayOf(1f, 2f, 5f, 10f, 20f, 25f, 50f, 100f, 200f, 250f, 500f, 1000f)
            val step = steps.firstOrNull { span / it <= 5f } ?: (span / 5f)
            val yMin = if (fromZero) 0f else floor(rawMin / step) * step
            val rows = ceil((rawMax - yMin) / step).toInt().coerceAtLeast(1)
            val yMax = yMin + rows * step
            fun yOf(v: Float) = top + h - ((v - yMin) / (yMax - yMin)) * h
            val tEnd = t.last().coerceAtLeast(1f)
            val dash = PathEffect.dashPathEffect(floatArrayOf(6f, 8f))
            val grid = Color(0x55FFFFFF)
            for (i in 0..rows) {
                val v = yMin + i * step
                val y = yOf(v)
                drawLine(grid, Offset(left, y), Offset(left + w, y), strokeWidth = 1f, pathEffect = dash)
                val text = "%.0f".format(v)
                val sz = tm.measure(text, lbl).size
                drawText(tm, text, Offset(left - 6.dp.toPx() - sz.width, y - sz.height / 2f), lbl)
            }
            // Sumbu waktu: kelipatan bulat (5s, 10s, 30s, 1:00, ...) supaya label sesuai posisinya
            val tSteps = floatArrayOf(1f, 2f, 5f, 10f, 15f, 30f, 60f, 120f, 300f, 600f, 900f, 1800f, 3600f)
            val tStep = tSteps.firstOrNull { tEnd / it <= 6f } ?: 7200f
            var k = 0
            while (k * tStep <= tEnd + 0.001f) {
                val tv = k * tStep
                val x = left + w * (tv / tEnd)
                drawLine(grid, Offset(x, top), Offset(x, top + h), strokeWidth = 1f, pathEffect = dash)
                val text = if (tStep >= 60f || tEnd >= 120f) fmtDur(tv.toInt()) else "${tv.toInt()}s"
                val sz = tm.measure(text, lbl).size
                val tx = (x - sz.width / 2f).coerceIn(0f, size.width - sz.width)
                drawText(tm, text, Offset(tx, top + h + 4.dp.toPx()), lbl)
                k++
            }
            // Garis; titik terakhir selalu ikut walau data diperkecil
            val stride = maxOf(1, n / 500)
            shown.forEach { sr ->
                val p = Path(); var open = false; var i = 0
                val m = minOf(n, sr.v.size)
                while (i < m) {
                    val v = sr.v[i]
                    if (v < 0f) open = false else {
                        val x = left + w * (t[i] / tEnd); val y = yOf(v)
                        if (!open) { p.moveTo(x, y); open = true } else p.lineTo(x, y)
                    }
                    i = if (i >= m - 1) m else minOf(i + stride, m - 1)
                }
                drawPath(p, sr.color, style = Stroke(width = 1.6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            // Nilai terakhir di kanan; label yang berdekatan digeser supaya tidak bertumpuk
            val ends = shown.mapNotNull { sr -> sr.v.lastOrNull { it >= 0f }?.let { sr to it } }
                .map { (sr, lv) -> Triple(sr.color, "%.0f".format(lv), yOf(lv)) }.sortedBy { it.third }
            val ys = FloatArray(ends.size) { ends[it].third }
            val gap = tm.measure("0", TextStyle(fontSize = 12.sp)).size.height.toFloat()
            for (j in 1 until ys.size) if (ys[j] - ys[j - 1] < gap) ys[j] = ys[j - 1] + gap
            ends.forEachIndexed { j, e ->
                val sz = tm.measure(e.second, TextStyle(fontSize = 12.sp)).size
                drawText(tm, e.second, Offset(left + w + 5.dp.toPx(), ys[j] - sz.height / 2f), TextStyle(color = e.first, fontSize = 12.sp))
            }
        }
        if (shown.size > 1) Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            shown.forEach { sr ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).background(sr.color, CircleShape))
                    Text(sr.name, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(start = 6.dp))
                }
            }
        }
    }
}
