package com.pulsemonitor

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Process
import android.os.SystemClock

/**
 * Deteksi aplikasi di depan lewat riwayat penggunaan sistem (UsageStatsManager): dibaca di dalam proses, hitungan milidetik.
 * Sebelumnya hanya `dumpsys window` lewat Shizuku, yang di HyperOS bisa makan 1-3 detik per baca, sehingga nama di notifikasi
 * telat beberapa detik setelah pindah aplikasi. Izin akses penggunaan diberikan otomatis lewat Shizuku/root (appops), tanpa
 * menu pengaturan. Tanpa izin, OverlayService tetap memakai dumpsys seperti biasa.
 */
object Foreground {
    private var lastTry = 0L
    private var lastState = ""

    fun hasAccess(c: Context): Boolean = runCatching {
        val ops = c.getSystemService(AppOpsManager::class.java)
        ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName) == AppOpsManager.MODE_ALLOWED
    }.getOrDefault(false)

    private fun note(state: String) { if (state != lastState) { lastState = state; AppLog.i("AppDepan", state) } }

    /** Pastikan izin ada; bila belum, coba berikan lewat shell (paling sering tiap 30 detik). Panggil dari thread latar. */
    fun ensureAccess(c: Context): Boolean {
        if (hasAccess(c)) { note("jalur cepat (riwayat penggunaan): izin ada"); return true }
        val now = SystemClock.elapsedRealtime()
        if (now - lastTry < 30_000L || Shell.mode() == "-") { note("jalur cepat: izin belum ada, pakai dumpsys"); return false }
        lastTry = now
        runCatching {
            Shell.exec("pm grant ${c.packageName} android.permission.PACKAGE_USAGE_STATS 2>/dev/null; appops set ${c.packageName} GET_USAGE_STATS allow")
        }
        val ok = hasAccess(c)
        note(if (ok) "jalur cepat (riwayat penggunaan): izin diberikan lewat ${Shell.mode()}" else "jalur cepat: izin GAGAL diberikan, pakai dumpsys")
        return ok
    }

    /** Paket yang terakhir dibuka (ACTIVITY_RESUMED) dalam 3 menit terakhir, tanpa jendela sementara. Null bila tidak ada kejadian baru. */
    fun top(c: Context): String? = runCatching {
        val um = c.getSystemService(UsageStatsManager::class.java) ?: return@runCatching null
        val end = System.currentTimeMillis()
        val ev = um.queryEvents(end - 180_000L, end + 2_000L) ?: return@runCatching null
        val e = UsageEvents.Event()
        var pkg: String? = null
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED && !Sampler.isTransientPkg(e.packageName, "")) pkg = e.packageName
        }
        pkg
    }.getOrNull()
}
