package com.pulsemonitor

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val DxBg = Color(0xFF101014)
private val DxCard = Color(0xFF1E1F26)
private val DxTerm = Color(0xFF0A0A0D)
private val DxAccent = Color(0xFF3DF0FF)
private val DxOnAccent = Color(0xFF06262B)
private val DxMuted = Color(0xFF9AA0A8)
private val DxLine = Color(0xFF34353C)
private val DxGreen = Color(0xFF7CFFB2)
private val DxRed = Color(0xFFE5483B)

/** Nama pendek untuk tab profil supaya empat pilihan muat dalam satu baris. */
private fun shortName(p: String) = when (p) { "everything" -> "every"; "everything-profile" -> "every-prof"; "speed-profile" -> "speed-prof"; else -> p }

@Composable
private fun DxSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    Switch(checked = checked, onCheckedChange = onChange, colors = SwitchDefaults.colors(
        checkedTrackColor = DxAccent, checkedThumbColor = DxOnAccent, checkedBorderColor = DxAccent,
        uncheckedTrackColor = DxLine, uncheckedThumbColor = Color(0xFF8E8F96), uncheckedBorderColor = Color(0xFF8E8F96)))
}

/** Halaman DexOpt (desain E): tab profil, log langsung per aplikasi, progres, dan tombol aksi. */
@Composable
fun DexOptScreen(onBack: () -> Unit, onOpenList: () -> Unit) {
    val ctx = LocalContext.current
    BackHandler(onBack = onBack)
    var profile by remember { mutableStateOf(DexOpt.profile(ctx)) }
    var system by remember { mutableStateOf(DexOpt.systemApp(ctx)) }
    var scheduled by remember { mutableStateOf(DexOpt.scheduled(ctx)) }
    val p by DexOpt.progress.collectAsState()
    val log by DexOpt.log.collectAsState()
    val mode = Shell.mode()
    val listState = rememberLazyListState()
    LaunchedEffect(log.size) { if (log.isNotEmpty()) listState.animateScrollToItem(log.size) }

    Column(Modifier.fillMaxSize().background(DxBg).statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("←", color = Color.White, fontSize = 24.sp, modifier = Modifier.clip(CircleShape).clickable { onBack() }.padding(end = 14.dp, top = 4.dp, bottom = 4.dp))
            Text("DexOpt", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            val ok = mode != "-"
            Text(if (ok) mode else "Tanpa akses", color = if (ok) DxGreen else DxRed, fontSize = 12.sp,
                modifier = Modifier.border(BorderStroke(1.dp, if (ok) DxGreen else DxRed), RoundedCornerShape(10.dp)).padding(horizontal = 10.dp, vertical = 4.dp))
        }
        // Tab profil
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(DxCard).padding(3.dp)) {
            DexOpt.PROFILES.forEach { name ->
                val sel = name == profile
                Box(Modifier.weight(1f).clip(RoundedCornerShape(11.dp)).background(if (sel) DxAccent else Color.Transparent)
                    .clickable(enabled = !p.running) { profile = name; DexOpt.setProfile(ctx, name) }.padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
                    Text(shortName(name), color = if (sel) DxOnAccent else Color.White, fontSize = 11.sp, fontWeight = if (sel) FontWeight.Medium else FontWeight.Normal, maxLines = 1)
                }
            }
        }
        Text(profile, color = DxMuted, fontSize = 12.sp, modifier = Modifier.padding(start = 6.dp, top = 6.dp, bottom = 10.dp))

        // Log
        Box(Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(16.dp)).background(DxTerm).padding(12.dp)) {
            if (log.isEmpty() && !p.running) {
                Text(if (mode == "-") "Akses Shizuku/Root belum aktif. Aktifkan dulu di tab Settings." else "Log proses tampil di sini. Tekan Mulai untuk memulai.",
                    color = if (mode == "-") DxRed else DxMuted, fontSize = 13.sp)
            } else LazyColumn(Modifier.fillMaxSize(), state = listState) {
                items(log) { l ->
                    Row {
                        Text(if (l.ok) "OK" else "GAGAL", color = if (l.ok) DxGreen else DxRed, fontFamily = FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.padding(end = 8.dp))
                        Text(l.text, color = DxMuted, fontFamily = FontFamily.Monospace, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                if (p.running && p.current.isNotEmpty()) item { Text("> ${p.current} ...", color = DxAccent, fontFamily = FontFamily.Monospace, fontSize = 12.sp) }
            }
        }

        // Progres
        Row(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(if (p.total > 0) "${if (p.running) p.done + 1 else p.done}/${p.total}" else "-", color = DxMuted, fontSize = 12.sp)
            Text(if (p.message.isNotEmpty() && !p.running) "${p.message} · ${p.failed} gagal" else if (p.failed > 0) "${p.failed} gagal" else p.message, color = DxMuted, fontSize = 12.sp)
        }
        Box(Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)).background(DxLine)) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(if (p.total > 0) (p.done / p.total.toFloat()).coerceIn(0f, 1f) else 0f).background(DxAccent))
        }

        // Saklar singkat
        Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(DxCard).padding(start = 14.dp, end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Aplikasi sistem", color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
                DxSwitch(system) { system = it; DexOpt.setSystemApp(ctx, it) }
            }
            Row(Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(DxCard).padding(start = 14.dp, end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Jadwal 03:00", color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
                DxSwitch(scheduled) { scheduled = it; DexOpt.setScheduled(ctx, it) }
            }
        }
        // Tombol
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.weight(1f).height(48.dp).clip(RoundedCornerShape(14.dp)).background(DxCard).clickable { onOpenList() }, contentAlignment = Alignment.Center) {
                Text("Daftar aplikasi", color = Color.White, fontSize = 14.sp)
            }
            Box(Modifier.weight(1f).height(48.dp).clip(RoundedCornerShape(14.dp)).background(if (p.running) DxRed else DxAccent)
                .clickable { if (p.running) DexOpt.stop() else DexOpt.start(ctx) }, contentAlignment = Alignment.Center) {
                Text(if (p.running) "Stop" else "Mulai DexOpt", color = if (p.running) Color.White else DxOnAccent, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

/** Daftar aplikasi: saklar mati = aplikasi dilewati saat DexOpt. Ada pencarian dan tombol sembunyikan aplikasi sistem. */
@Composable
fun DexOptListScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    BackHandler(onBack = onBack)
    var query by remember { mutableStateOf("") }
    var hideSys by remember { mutableStateOf(DexOpt.hideSystemInList(ctx)) }
    val apps by produceState<List<DexApp>?>(null) { value = withContext(Dispatchers.IO) { DexOpt.listApps(ctx) } }
    val ignored = remember { mutableStateListOf<String>().also { it.addAll(DexOpt.ignored(ctx)) } }
    val shown = apps?.filter { a -> (!hideSys || !a.system) && (query.isBlank() || a.label.contains(query, true) || a.pkg.contains(query, true)) }.orEmpty()

    Column(Modifier.fillMaxSize().background(DxBg).statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("←", color = Color.White, fontSize = 24.sp, modifier = Modifier.clip(CircleShape).clickable { onBack() }.padding(end = 14.dp, top = 4.dp, bottom = 4.dp))
            Text("Daftar aplikasi", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Medium)
        }
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(DxCard).padding(14.dp)) {
            Text("Aplikasi yang dimatikan akan dilewati saat DexOpt", color = Color.White, fontSize = 13.sp)
        }
        if (!DexOpt.hasAccess()) Box(Modifier.padding(top = 8.dp).fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(DxCard).padding(14.dp)) {
            Text("Akses Shizuku/Root belum aktif", color = DxRed, fontSize = 14.sp)
        }
        Column(Modifier.padding(top = 8.dp).fillMaxWidth().weight(1f).clip(RoundedCornerShape(16.dp)).background(DxCard).padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.weight(1f).height(48.dp).clip(RoundedCornerShape(24.dp)).border(BorderStroke(1.dp, DxLine), RoundedCornerShape(24.dp)).padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text("⌕", color = Color.White, fontSize = 20.sp)
                    Box(Modifier.padding(start = 10.dp).weight(1f)) {
                        if (query.isEmpty()) Text("Cari aplikasi...", color = DxMuted, fontSize = 15.sp)
                        BasicTextField(query, { query = it }, singleLine = true, textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                            cursorBrush = SolidColor(DxAccent), modifier = Modifier.fillMaxWidth())
                    }
                }
                Box(Modifier.padding(start = 8.dp).size(48.dp).clip(CircleShape).background(if (hideSys) DxAccent.copy(alpha = 0.22f) else DxBg)
                    .border(BorderStroke(1.dp, DxLine), CircleShape).clickable { hideSys = !hideSys; DexOpt.setHideSystemInList(ctx, hideSys) },
                    contentAlignment = Alignment.Center) { Text(if (hideSys) "◌" else "◉", color = Color.White, fontSize = 20.sp) }
            }
            if (apps == null) Text("Memuat…", color = DxMuted, modifier = Modifier.padding(top = 16.dp))
            LazyColumn(Modifier.fillMaxSize().padding(top = 6.dp)) {
                items(shown, key = { it.pkg }) { a ->
                    val icon by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, a.pkg) {
                        value = withContext(Dispatchers.IO) { DexOpt.icon(ctx, a.pkg)?.asImageBitmap() }
                    }
                    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp, horizontal = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(42.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF2A2B33))) {
                            icon?.let { Image(it, null, Modifier.fillMaxSize()) }
                        }
                        Text(a.label, color = Color.White, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f).padding(horizontal = 14.dp))
                        DxSwitch(a.pkg !in ignored) { on ->
                            if (on) ignored.remove(a.pkg) else if (a.pkg !in ignored) ignored.add(a.pkg)
                            DexOpt.setIgnored(ctx, a.pkg, !on)
                        }
                    }
                }
            }
        }
    }
}
