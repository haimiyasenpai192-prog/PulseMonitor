package com.pulsemonitor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ImageDecoder
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.net.Uri
import java.io.File

/** Menyimpan dua gambar: wallpaper latar aplikasi dan (opsional) wallpaper khusus notifikasi. Gambar disalin ke
 *  penyimpanan internal, jadi tidak bergantung pada izin galeri dan tetap ada walau file aslinya dihapus. */
object WallpaperStore {
    private const val MAX_SIDE = 1600   // sisi terpanjang setelah diperkecil, hemat RAM
    private const val PREFS = "pulse"
    private const val KEY_DIM = "dim"
    private const val KEY_NDIM = "notif_dim"

    private fun file(c: Context) = File(c.filesDir, "wallpaper.jpg")
    private fun notifFile(c: Context) = File(c.filesDir, "notif_wallpaper.jpg")

    /** Baca gambar pilihan, diperkecil (maks 1600 px) dan sudah diputar sesuai EXIF. Dipakai layar potong dan penyimpanan. */
    fun decodePreview(c: Context, uri: Uri): Bitmap? = runCatching {
        ImageDecoder.decodeBitmap(ImageDecoder.createSource(c.contentResolver, uri)) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE   // bitmap hardware tidak bisa di-compress
            var sample = 1
            while (maxOf(info.size.width, info.size.height) / sample > MAX_SIDE) sample *= 2
            if (sample > 1) decoder.setTargetSampleSize(sample)
        }
    }.getOrNull()

    private fun writeTo(c: Context, bmp: Bitmap, target: File): Boolean = runCatching {
        val tmp = File(c.filesDir, target.name + ".tmp")
        tmp.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        check(tmp.renameTo(target) || (target.delete() && tmp.renameTo(target)))
    }.isSuccess

    private fun saveTo(c: Context, uri: Uri, target: File): Boolean {
        val bmp = decodePreview(c, uri) ?: return false
        return writeTo(c, bmp, target).also { bmp.recycle() }
    }

    /** Simpan hasil potong (sudah dalam rasio yang diinginkan). */
    fun saveCropped(c: Context, bmp: Bitmap): Boolean = writeTo(c, bmp, file(c))
    fun saveNotifCropped(c: Context, bmp: Bitmap): Boolean = writeTo(c, bmp, notifFile(c)).also { resetNotifCache() }

    // ---------- Wallpaper aplikasi ----------
    fun save(c: Context, uri: Uri): Boolean = saveTo(c, uri, file(c))

    fun load(c: Context): Bitmap? = file(c).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path) }

    fun clear(c: Context) { file(c).delete(); resetNotifCache() }

    fun dim(c: Context): Float = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getFloat(KEY_DIM, 0.6f)

    fun saveDim(c: Context, v: Float) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putFloat(KEY_DIM, v).apply()
    }

    // ---------- Wallpaper khusus notifikasi ----------
    fun hasNotifOwn(c: Context): Boolean = notifFile(c).exists()

    fun saveNotif(c: Context, uri: Uri): Boolean = saveTo(c, uri, notifFile(c)).also { resetNotifCache() }

    fun clearNotif(c: Context) { notifFile(c).delete(); resetNotifCache() }

    /** Redup khusus gambar notifikasi (dipakai bila gambar notifikasi sendiri dipilih). Bawaan lebih tipis dari latar aplikasi,
     *  supaya gambar tampak jelas dan teks putih tetap terbaca. */
    fun notifDim(c: Context): Float = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getFloat(KEY_NDIM, 0.45f)

    fun saveNotifDim(c: Context, v: Float) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putFloat(KEY_NDIM, v).apply()
    }

    /** Ada gambar yang bisa dipakai untuk notifikasi: gambar notifikasi sendiri, atau (cadangan) wallpaper aplikasi. */
    fun hasNotifSource(c: Context): Boolean = notifFile(c).exists() || file(c).exists()

    // Bitmap latar notifikasi dibuat dalam dua ukuran sesuai bentuk layoutnya, jadi gambar memenuhi seluruh kartu tanpa
    // di-crop paksa dan tanpa pita gelap di tepinya. Hasilnya disimpan di memori selama gambar dan redupnya sama,
    // karena notifikasi disegarkan tiap beberapa detik.
    private const val NW = 720
    private const val NH_SMALL = 208    // kartu ringkas, foto sampai tepi kanan kartu (BLEED_SMALL): ~388dp x ~112dp, rasio ~3,46 : 1
    private const val NH_BIG = 690      // kartu diperluas, foto melebar ke seluruh kotak (lihat BLEED_BIG): ~388dp x ~372dp, rasio ~1,04 : 1
    private const val CORNER = 36f      // radius sudut foto (px bitmap) = radius kartu sistem (~55 px layar) / skala tampil bitmap (~1,53). Foto kini memenuhi kartu, jadi sudutnya mengikuti sudut kartu
    private data class Key(val path: String, val mod: Long, val dim: Float)
    private val notifCache = HashMap<Int, Pair<Key, Bitmap>>()
    private var notifColorCache: Int? = null

    @Synchronized private fun resetNotifCache() { notifCache.clear(); notifColorCache = null }

    @Synchronized
    fun notifBitmap(c: Context, big: Boolean): Bitmap? {
        val own = notifFile(c).takeIf { it.exists() }
        val f = own ?: file(c).takeIf { it.exists() } ?: return null
        val d = (if (own != null) notifDim(c) else dim(c)).coerceIn(0f, 1f)
        val key = Key(f.path, f.lastModified(), d)
        // Tiap bentuk kartu punya bitmap dengan rasio sendiri, supaya gambar tidak ditarik / digepengkan saat tampil
        val slot = if (big) 1 else 0
        notifCache[slot]?.let { if (it.first == key) return it.second }
        val nh = if (big) NH_BIG else NH_SMALL
        // Decode sehemat mungkin: cukup besar untuk menutup NW x nh
        val opt = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, opt)
        var sample = 1
        while (opt.outWidth / (sample * 2) >= NW && opt.outHeight / (sample * 2) >= nh) sample *= 2
        val src = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return null
        val tmp = Bitmap.createBitmap(NW, nh, Bitmap.Config.ARGB_8888)
        val cv = Canvas(tmp)
        val scale = maxOf(NW.toFloat() / src.width, nh.toFloat() / src.height)   // center-crop: gambar menutup seluruh kartu
        val w = src.width * scale; val h = src.height * scale
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        cv.drawBitmap(src, null, RectF((NW - w) / 2f, (nh - h) / 2f, (NW + w) / 2f, (nh + h) / 2f), paint)
        cv.drawColor((d * 255).toInt() shl 24)      // redupkan: hitam transparan, supaya teks putih tetap terbaca
        // Sudut membulat: bingkai gelap buatan sistem (terlihat saat notifikasi ditahan lama) jadi tampak seperti bingkai foto
        val out = Bitmap.createBitmap(NW, nh, Bitmap.Config.ARGB_8888)
        // Semua bentuk kartu (ringkas, padat, diperluas) memakai radius yang sama, konsentris dengan bingkai gelap sistem
        // (radius luar bingkai - tebal bingkai). Pil penuh membuat bingkai menebal di kedua ujung.
        val corner = CORNER
        Canvas(out).drawRoundRect(RectF(0f, 0f, NW.toFloat(), nh.toFloat()), corner, corner,
            Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = BitmapShader(tmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP) })
        tmp.recycle()
        if (big) notifColorCache = averageColor(out)
        src.recycle()
        notifCache[slot] = key to out
        return out
    }

    // Warna rata-rata gambar notifikasi (sudah diredupkan). Dipakai sebagai warna latar kartu yang digambar sistem
    // (tepi di luar area gambar), supaya sedekat mungkin dengan gambar.
    private fun averageColor(b: Bitmap): Int {
        var r = 0L; var g = 0L; var bl = 0L; var n = 0L
        val sx = maxOf(1, b.width / 24); val sy = maxOf(1, b.height / 12)
        var y = 0
        while (y < b.height) {
            var x = 0
            while (x < b.width) {
                val p = b.getPixel(x, y)
                if ((p ushr 24) > 200) { r += (p shr 16) and 0xFF; g += (p shr 8) and 0xFF; bl += p and 0xFF; n++ }
                x += sx
            }
            y += sy
        }
        if (n == 0L) return 0xFF202124.toInt()
        return (0xFF shl 24) or ((r / n).toInt() shl 16) or ((g / n).toInt() shl 8) or (bl / n).toInt()
    }

    /** Warna latar kartu notifikasi dari gambar; null bila tidak ada gambar. */
    @Synchronized
    fun notifColor(c: Context): Int? { notifBitmap(c, true) ?: return null; return notifColorCache }
}
