# PulseMonitor (FPS / CPU / GPU / Suhu)
1. Buka folder ini di Android Studio (Koala+), tunggu Gradle sync, lalu Run di HP Android 10+.
2. Pilih akses: aktifkan Shizuku (lalu tekan "Beri izin Shizuku") atau pakai HP root.
3. Nyalakan "Overlay mengambang" (akan diminta izin tampil di atas aplikasi lain).
Catatan: kode belum dikompilasi/diuji. GPU hanya terbaca di Adreno (kgsl). Tanpa izin INTERNET.

## Perubahan v0.1.1 (stabilisasi)
- Minta izin POST_NOTIFICATIONS saat start (Android 13+), supaya notifikasi overlay muncul.
- Overlay: cek izin tampil-di-atas-aplikasi, tangani addView/removeView gagal, tipe FGS specialUse hanya di API 34+.
- Sampler: hindari crash saat data frame kosong; kegagalan baca FPS tidak lagi menggagalkan CPU/GPU/RAM/suhu.
- Belum ada Gradle wrapper di zip ini: Android Studio akan menawarkan membuatnya saat sync (butuh Gradle 8.7+ untuk AGP 8.5.2).

## v0.2.2: Ikon aplikasi
- Ikon adaptive: latar gelap + garis denyut cyan, plus versi monokrom untuk ikon bertema (Android 13+). Semua berupa vektor XML di res/, tanpa PNG.

## v0.2.1: GPU MediaTek
- Sampler mencoba beberapa jalur GPU berurutan: Adreno (kgsl), MediaTek (GED), Mali lama. Jalur pertama yang terbaca dipakai; jika tidak ada, tampil "-".
- Belum diuji di perangkat MediaTek. Jalur GED bisa berbeda/tertutup di beberapa chipset.

## v0.2.0: Wallpaper
- Kartu "Wallpaper" di layar utama: pilih gambar dari galeri (Photo Picker, tanpa izin storage), ganti, hapus.
- Gambar disalin ke penyimpanan internal aplikasi (maks 1600 px, JPEG) lewat WallpaperStore.kt.
- Slider "Redupkan latar" (20-90%) agar teks tetap terbaca; nilainya tersimpan.

## v0.2.3: Perbaikan suhu (acuan: FrameX)
- Suhu dipisah: baterai, CPU, GPU (sebelumnya satu angka "SUHU" gabungan, GPU tidak pernah dibaca).
- Baterai: dari broadcast BATTERY_CHANGED (tanpa Shizuku/root), cadangan HAL lalu sysfs.
- CPU/GPU: HAL thermal (`dumpsys thermalservice`) dibaca semua sensornya, dikelompokkan lewat nama (cpuss/gpuss/quiet_therm) lalu tipe HAL; cadangan sysfs thermal_zone dan kgsl temp.
- Dibuang: zona sysfs "soc"/"tsens" yang di banyak HP berisi persen baterai atau sensor acak, sehingga angka suhu salah.
- Catatan: belum dikompilasi/diuji di perangkat.

## v0.2.4: Overlay baru
- Tampilan kartu: FPS besar, lalu tabel rata kolom CPU / GPU / RAM / BAT (beban dan suhu), suhu berwarna (hijau, kuning, oranye, merah).
- Bisa digeser: tahan lalu seret overlay ke posisi mana pun; posisi tersimpan.
- Catatan: area overlay kini menangkap sentuhan (perlu supaya bisa digeser), jadi sentuhan tepat di atas kartu tidak tembus ke game.

## v0.2.5: Overlay satu baris
- Overlay jadi pil satu baris: `60 FPS  CPU 16% 63°  GPU 33% 63°  BAT 40°`, suhu tetap berwarna. Tetap bisa digeser.

## v0.2.6: Ikon petir
- Ikon aplikasi diganti jadi petir cyan di atas latar gelap (adaptive + monokrom untuk ikon bertema). Tetap vektor XML.

## v0.3.0: Layar utama baru dan Pengaturan
- Layar utama: kartu FPS dengan grafik 30 detik terakhir, lalu AVG / 1% LOW / FRAMETIME, baris pil CPU / GPU / RAM / Baterai (beban + suhu berwarna), saklar overlay, akses, wallpaper, diagnostik.
- Ikon gerigi di pojok kanan atas membuka Pengaturan: warna aksen, warna teks overlay, warna dan transparansi latar overlay, tombol "Kembalikan warna awal". Tersimpan otomatis.
- Overlay membaca pengaturan warna tiap detik. Belum dikompilasi/diuji di perangkat.

## v0.4.0: Tampilan baru ala WuWa Config
- Layar utama: wallpaper penuh, judul besar "PulseMonitor", chip akses (Shizuku/root) di kanan atas, panel kaca di bawah, dan bilah navigasi 4 tab (Beranda, Statistik, Tampilan, Settings).
- Beranda: status overlay, dua kartu FPS dan Frametime, grafik 30 detik, baris CPU / GPU / RAM / BAT, tombol gradien "Nyalakan/Matikan Overlay".
- Statistik: akses, RAM, suhu, diagnostik. Tampilan: wallpaper dan redup latar. Settings: warna (sama seperti sebelumnya).
- Ikon di navigasi memakai simbol teks (tanpa dependensi icons-extended). Memakai enableEdgeToEdge(). Belum dikompilasi/diuji di perangkat.

## v0.4.1: Layar utama lebih ringkas
- Subjudul "Pilih, lalu nyalakan overlay" dihapus dari Beranda.
- Panel bawah dipadatkan dan diturunkan (padding dan tinggi dikurangi) supaya karakter di wallpaper lebih terlihat.

## v0.4.2: Baris sensor dirapikan
- Suhu di bawah CPU dan GPU dihapus dari Beranda (suhu tetap ada di tab Statistik dan di overlay).
- Baris CPU / GPU / RAM / BAT diberi padding samping dan rata tengah secara vertikal.

## v0.4.3: Status overlay lebih sederhana
- Teks AVG / 1% LOW di bawah "Overlay aktif" dihapus; ikon dan teks status kini rata tengah di barisnya.

## v0.5.0: Rekam FPS dan laporan
- Tab baru "Rekaman" (navigasi jadi 5 tab). Tombol Mulai rekam / Berhenti dan simpan, serta daftar rekaman (nama game, tanggal, AVG FPS, durasi).
- Mulai/berhenti dari dalam game: tombol di notifikasi overlay, atau tahan overlay sekitar 1 detik tanpa menggesernya. Saat merekam, overlay diberi titik merah di depan angka FPS.
- Laporan (ketuk rekaman): ikon dan nama game, kolom Deskripsi (tersimpan otomatis), tanggal + resolusi layar, statistik 2 halaman (geser): MAKS / MIN / RATA-RATA / VARIANS FPS, Relatif kehalusan, 5% Low, suhu maks, daya rata-rata; halaman 2: rata-rata CPU/GPU/RAM, durasi, suhu maks CPU/GPU/BAT.
- Grafik: FPS + Frametime + Suhu, Beban CPU/GPU, RAM, Suhu CPU/GPU/Baterai, Daya (muncul bila terbaca).
- Tombol Bagikan (ringkasan teks), CSV (disimpan ke folder Download tanpa izin storage), Hapus (dua ketukan).
- Data: satu file JSON per rekaman di penyimpanan internal aplikasi (filesDir/records). Sampel kira-kira per detik, bagian awal/akhir tanpa frame dibuang.
- Daya (Watt) = |arus baterai| x tegangan, jadi hanya perkiraan dan paling akurat saat tidak mengisi daya. Beberapa HP tidak melaporkan arus; kolomnya jadi "-".
- Manifest: ditambah QUERY_ALL_PACKAGES agar nama dan ikon game bisa dibaca.
- Belum ada: simpan laporan sebagai gambar. Resolusi yang ditampilkan adalah resolusi layar, bukan resolusi render game.
- Catatan: belum dikompilasi/diuji di perangkat. Rekaman butuh Shizuku/root (sumber data FPS).

## v0.5.1: Rapikan teks dan angka rekaman
- Daftar rekaman: nama dan tanggal di kiri, AVG FPS (besar) dan durasi di kanan, tidak lagi satu baris panjang yang terpotong.
- Statistik laporan: label huruf besar seragam (11sp), angka 22sp, satuan 11sp, jarak antar baris disamakan. Label diperjelas: KEHALUSAN, 5% LOW, SUHU MAKS, DAYA, SUHU CPU/GPU/BAT.

## v0.5.2: FPS diam, akurasi CPU/GPU, FPS turun saat rekam
- FPS dihitung dari selisih frame dibagi waktu nyata dalam jendela ~2,5 detik (sebelumnya 1 detik, ikut melar saat tick lambat). Saat layar diam tanpa frame baru, nilai terakhir ditahan maks 3 detik sebelum jadi 0.
- Saat merekam, paket game dikunci. Fokus sementara ke SystemUI (tarik notifikasi), keyboard, atau PulseMonitor sendiri diabaikan (sticky 20 detik), sehingga FPS tidak jatuh ke aplikasi lain begitu tombol rekam ditekan.
- Beban pemantau dikurangi: fokus dibaca tiap 2 dtk (sebelumnya 2x `dumpsys` tiap detik dan dua kali per tick), HAL thermal tiap 3 dtk. Tick dijadwalkan tetap ~1 dtk, jadi CPU% dan FPS tidak ikut tertarik oleh lama tick.
- GPU Adreno: cadangan `gpubusy` (busy/total) bila `gpu_busy_percentage` tidak ada.
- Catatan: belum dikompilasi/diuji di perangkat.

## v0.5.3: Laporan lebih simpel
- Header ringkas: ikon, nama game, lalu satu baris tanggal · durasi · resolusi. Kolom deskripsi jadi satu baris "Tambah catatan".
- Statistik tidak lagi 2 halaman geser: satu kartu dengan RATA-RATA FPS besar, lalu 2 baris (MAKS, MIN, 5% LOW, HALUS / CPU, GPU, SUHU, DAYA). VARIANS, sampel, dan angka per-sensor dibuang.
- Grafik jadi 3 (FPS, Beban CPU/GPU/RAM, Suhu) + Daya bila terbaca. Frametime dibuang dari grafik FPS karena skalanya (hingga 500 ms) membuat garis FPS tampak datar; frametime tetap ada di CSV.
- Label waktu sumbu X tidak ganda lagi pada rekaman pendek (<10 dtk memakai satu desimal).
- Sampel FPS pertama tiap rekaman dilewati (jendela belum penuh, sebelumnya membuat MIN jadi 2 FPS).

## v0.5.4: Ringkasan laporan tanpa angka besar
- Kartu ringkasan jadi dua kolom daftar kecil (label kiri, nilai kanan, garis tipis): Rata-rata / Maks / Min / 5% low, dan CPU / GPU / Suhu maks / Daya. Angka rata-rata FPS tidak lagi 52sp, hanya sedikit lebih menonjol (warna aksen). "Halus" dibuang.
- Judul grafik dan sudut kartu sedikit dikecilkan. Satuan "FPS" hanya di label "Rata-rata FPS", tidak diulang di tiap baris.

## v0.5.5: Wallpaper di halaman laporan
- Halaman laporan memakai wallpaper yang sama dengan Beranda (dan slider "Redupkan latar", minimal 60% supaya teks terbaca). Tanpa wallpaper tetap latar gelap polos.
- Kartu di laporan jadi semi-transparan (80%) saat ada wallpaper.

## v0.5.6: Animasi navigasi
- Bilah navigasi: pil penanda meluncur (spring) ke tab yang dipilih; ikon dan teks berubah warna halus, ikon terpilih membesar dengan efek memantul.
- Pindah tab: isi panel bergeser searah tab (kanan/kiri) sambil memudar, tinggi panel ikut berubah halus. Subjudul di kepala memudar saat ganti.
- Beranda ke laporan: laporan masuk dari kanan, tombol kembali/panah menggesernya keluar ke kanan.
- Dependensi tambahan: androidx.compose.animation (versi dari BOM).

## v0.6.0: Gaya overlay (Simple / Compact / Normal)
- Pengaturan > "Gaya overlay": pilih Simple (satu baris pil), Compact (kartu kecil: FPS + frametime, CPU, GPU, RAM, baterai + daya, dengan frekuensi), atau Normal (ditambah AVG/LOW, RAM dalam GB, daya, nama paket game). Pratinjau tiap gaya ikut warna dan transparansi overlay. Berlaku langsung dalam ~1 detik, tanpa menyalakan ulang overlay.
- Data baru di Sampler: persen baterai (tanpa Shizuku), frekuensi CPU (tertinggi antar inti) dan GPU (kgsl / devfreq). Bila tidak terbaca, bagian itu dikosongkan.
- Belum ada seperti di contoh: governor (schedutil), per-cluster/per-inti, Touch Hz, lingkaran beban. Belum dikompilasi/diuji di perangkat.
