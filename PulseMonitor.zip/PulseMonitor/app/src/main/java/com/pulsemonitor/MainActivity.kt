@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.pulsemonitor

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.graphics.Bitmap
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.compose.ui.text.style.TextOverflow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import rikka.shizuku.Shizuku

private val Grey = Color(0xFF8E8E99)
private val Bg = Color(0xFF0C0C0E)
// Panel besar di bawah (gaya WuWa Config); transparansinya diatur di tab Tampilan
private val Glass: Color get() = Color(0xFF101116).copy(alpha = AppSettings.panelAlpha / 100f)
// Baris/kartu di dalam panel: tetap solid di nilai bawaan, makin tembus saat slider diturunkan
private val Inner: Color get() = Color(0xFF181A21).copy(alpha = (AppSettings.panelAlpha / AppSettings.DEF_PANEL.toFloat()).coerceAtMost(1f))
// Warna tiap tab navigasi: Beranda biru, Statistik ungu, Tampilan hijau, Settings kuning (Rekam FPS sekarang ada di Beranda)
private val NavColors = listOf(Color(0xFF6FA8FF), Color(0xFFA78BFA), Color(0xFF5BD68E), Color(0xFFE8B84A))
private val RecPink = Color(0xFFF08FB8)
private val Pink = Color(0xFFD58FC4)
private val Blue = Color(0xFF6FA8FF)
private fun acc() = Color(AppSettings.accent)

class MainActivity : ComponentActivity() {
    // Android 13+: tanpa izin ini notifikasi foreground service tidak muncul
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private var wallpaperBmp by mutableStateOf<Bitmap?>(null)
    private var dim by mutableFloatStateOf(0.6f)
    private var cropSrc by mutableStateOf<Bitmap?>(null)        // gambar yang sedang dipotong
    private var overlayOn by mutableStateOf(OverlayService.overlayShown.value)
    private var reportId by mutableStateOf<Long?>(null)
    private var accessDlg by mutableStateOf(false)
    private var styleDlg by mutableStateOf(false)
    private var refreshTick by mutableIntStateOf(0)           // naik tiap tarik-untuk-refresh; dipakai sebagai kunci pembacaan ulang data
    private var refreshing by mutableStateOf(false)

    /** Tarik ke bawah di tab mana pun: baca ulang akses, daftar rekaman, wallpaper, dan info perangkat. */
    private fun doRefresh() {
        if (refreshing) return
        refreshing = true
        Thread {
            runCatching { Access.refresh() }
            runCatching {
                val w = WallpaperStore.load(this); val d = WallpaperStore.dim(this)
                runOnUiThread { wallpaperBmp = w; dim = d }
            }
            Recorder.version.value = Recorder.version.value + 1
            runOnUiThread { refreshTick++ }
            Thread.sleep(700)   // beri waktu spinner terlihat
            runOnUiThread { refreshing = false }
        }.start()
    }

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, r -> Access.onPermissionResult(r == PackageManager.PERMISSION_GRANTED) }
    private val binderListener = Shizuku.OnBinderReceivedListener { Access.refresh() }
    private val deadListener = Shizuku.OnBinderDeadListener { Access.refresh() }

    // Photo Picker: tanpa izin galeri. Di Android 10-12 otomatis jatuh ke pemilih dokumen.
    private val pickImage = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) Thread {
            val bmp = WallpaperStore.decodePreview(this, uri)
            if (bmp != null) cropSrc = bmp
        }.start()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); enableEdgeToEdge()
        AppSettings.load(this); Sampler.init(this)
        Shizuku.addRequestPermissionResultListener(permListener)
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        wallpaperBmp = WallpaperStore.load(this); dim = WallpaperStore.dim(this)
        WallpaperStore.purgeNotifLeftovers(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        showLastCrash()
        setContent {
            val s by Sampler.state.collectAsState()
            // Status tombol mengikuti keadaan layanan yang sebenarnya (tetap benar setelah aplikasi dibuka ulang)
            val shown by OverlayService.overlayShown.collectAsState()
            LaunchedEffect(shown) { overlayOn = shown }
            var tab by remember { mutableIntStateOf(0) }
            BackHandler(enabled = tab != 0) { tab = 0 }
            val rid = reportId
            BackHandler(enabled = rid != null) { reportId = null }
            AnimatedContent(targetState = rid, label = "page", transitionSpec = {
                if (targetState != null)   // buka laporan: masuk dari kanan, halaman lama bergeser sedikit
                    (slideInHorizontally(tween(320)) { it } + fadeIn(tween(320))) togetherWith
                        (slideOutHorizontally(tween(320)) { -it / 4 } + fadeOut(tween(220)))
                else                       // kembali: laporan keluar ke kanan
                    (slideInHorizontally(tween(320)) { -it / 4 } + fadeIn(tween(320))) togetherWith
                        (slideOutHorizontally(tween(320)) { it } + fadeOut(tween(220)))
            }) { id -> if (id != null) ReportScreen(id) else Screen(s, tab) { tab = it } }
        }
    }

    /** Bila sesi sebelumnya berhenti karena crash, tampilkan jejaknya supaya bisa disalin dan dikirim. */
    private fun showLastCrash() {
        val trace = CrashLog.take(this) ?: return
        runCatching {
            android.app.AlertDialog.Builder(this)
                .setTitle("Pulse Monitor berhenti tiba-tiba")
                .setMessage(trace.take(3000))
                .setPositiveButton("Salin") { _, _ ->
                    getSystemService(android.content.ClipboardManager::class.java)
                        .setPrimaryClip(android.content.ClipData.newPlainText("crash", trace))
                    Toast.makeText(this, "Disalin", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Tutup", null).show()
        }
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        super.onDestroy()
    }

    override fun onStart() {
        super.onStart()
        Access.refresh()
        OverlayService.ensureRunning(this)   // mode latar belakang aktif tapi layanan sempat mati -> notifikasi dimunculkan lagi
        Sampler.uiVisible = true; Sampler.start()
    }

    override fun onStop() {
        super.onStop()
        // Aplikasi tidak terlihat: hentikan pembacaan sensor bila tidak ada overlay/rekaman yang memakainya
        Sampler.uiVisible = false
        if (!OverlayService.overlayShown.value && !Recorder.active.value) Sampler.stop()
    }

    private fun toggleOverlay() {
        val turnOn = !OverlayService.overlayShown.value
        if (turnOn && !Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val i = Intent(this, OverlayService::class.java)
        try {
            when {
                turnOn -> { playOverlaySound(); startForegroundService(i) }
                // Mode latar belakang: overlay disembunyikan, layanan (notifikasi) tetap hidup
                AppSettings.bgMode -> startForegroundService(i.setAction(OverlayService.ACTION_HIDE))
                else -> stopService(i)
            }
        } catch (e: Throwable) {
            android.util.Log.e("PulseMonitor", "Gagal memulai layanan overlay", e)
            Toast.makeText(this, "Overlay gagal: ${e.javaClass.simpleName}: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    /** Saklar "Tetap aktif di latar belakang": nyala = layanan hidup tanpa overlay; mati = layanan berhenti bila overlay juga mati. */
    private fun applyBgMode(on: Boolean) {
        val i = Intent(this, OverlayService::class.java)
        try {
            // Nyala: selalu kirim RESTORE, tidak bergantung pada flag "alive". Flag itu bisa basi (layanan baru saja dihentikan dan belum
            // sempat onDestroy, atau notifikasinya sudah disingkirkan sistem/pengguna), sehingga notifikasi tidak muncul sampai saklar
            // dimatikan lalu dinyalakan lagi. RESTORE aman dikirim berulang: overlay tidak diubah, notifikasi dipasang ulang.
            if (on) startForegroundService(i.setAction(OverlayService.ACTION_RESTORE))
            else if (!OverlayService.overlayShown.value) stopService(i)
        } catch (e: Throwable) {
            android.util.Log.e("PulseMonitor", "Gagal mengubah mode latar belakang", e)
            Toast.makeText(this, "Notifikasi gagal: ${e.javaClass.simpleName}: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    /** Suara notifikasi saat overlay dinyalakan (res/raw/overlay_on.m4a). Gagal memutar tidak boleh mengganggu overlay. */
    private fun playOverlaySound() {
        runCatching {
            val attrs = android.media.AudioAttributes.Builder()
                .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            val mp = android.media.MediaPlayer.create(this, R.raw.overlay_on, attrs, android.media.AudioManager.AUDIO_SESSION_ID_GENERATE)
                ?: return
            mp.setOnCompletionListener { it.release() }
            mp.setOnErrorListener { p, _, _ -> p.release(); true }
            mp.setVolume(1f, 1f)
            mp.start()
        }
    }

    @Composable
    fun Screen(s: Snap, tab: Int, setTab: (Int) -> Unit) {
        val titles = listOf("", "Statistik memori, suhu, CPU & RAM", "Wallpaper, warna, dan ukuran overlay", "Akses dan pengaturan")
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1A2038), Bg)))) {
            wallpaperBmp?.let { bmp ->
                Image(bmp.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                // makin gelap ke bawah supaya panel dan teks tetap terbaca
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
                    listOf(Bg.copy(alpha = dim * 0.35f), Bg.copy(alpha = dim)))))
                // Bayangan tipis di atas supaya judul tetap terbaca di wallpaper terang/putih
                Box(Modifier.fillMaxWidth().height(190.dp).background(Brush.verticalGradient(
                    listOf(Color.Black.copy(alpha = 0.6f), Color.Black.copy(alpha = 0.3f), Color.Transparent))))
            }
            // Kepala: judul + chip akses sebaris, subjudul satu baris di bawahnya (tinggi tetap supaya tidak loncat antar tab)
            Column(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 24.dp, vertical = 20.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Pulse Monitor", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold,
                        style = androidx.compose.ui.text.TextStyle(shadow = androidx.compose.ui.graphics.Shadow(Color.Black.copy(alpha = 0.6f), Offset(0f, 2f), 8f)), maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(12.dp))   // jarak judul dan chip akses
                    val ok = s.access != "-"
                    Row(Modifier.clip(RoundedCornerShape(50)).background(Color(0xB3101116))
                        .clickable(enabled = !ok) { Access.refresh(); accessDlg = true }.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(10.dp).background(if (ok) Color(0xFF7CFFB2) else Color(0xFFFF5C5C), CircleShape))
                        Text(if (ok) s.access else "Beri izin", color = if (ok) Color(0xFF7CFFB2) else Color(0xFFFF8A8A),
                            fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, modifier = Modifier.padding(start = 8.dp))
                    }
                }
                Box(Modifier.fillMaxWidth().height(22.dp).padding(top = 2.dp)) {
                    AnimatedContent(targetState = titles[tab], label = "subtitle",
                        transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(120)) }) { t ->
                        if (t.isNotEmpty()) Text(t, color = Color(0xFFE6E6EE), fontSize = 14.sp, style = androidx.compose.ui.text.TextStyle(shadow = androidx.compose.ui.graphics.Shadow(Color.Black.copy(alpha = 0.6f), Offset(0f, 2f), 8f)), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            if (accessDlg) AccessDialog { accessDlg = false }
            cropSrc?.let { src ->
                val dm = resources.displayMetrics
                // Rasio potong mengikuti rasio layar
                val aspect = dm.widthPixels.toFloat() / dm.heightPixels
                CropDialog(src, aspect, "Potong wallpaper aplikasi", onCancel = { cropSrc = null }) { cropped ->
                    cropSrc = null
                    Thread {
                        if (WallpaperStore.saveCropped(this@MainActivity, cropped)) wallpaperBmp = WallpaperStore.load(this@MainActivity)
                    }.start()
                }
            }
            // Panel bawah + navigasi
            Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(Modifier.fillMaxWidth().background(Glass, RoundedCornerShape(28.dp)).padding(8.dp)) {
                    PullToRefreshBox(isRefreshing = refreshing, onRefresh = { doRefresh() }) {
                    AnimatedContent(targetState = tab, label = "tab", transitionSpec = {
                        val dir = if (targetState > initialState) 1 else -1   // geser sesuai arah tab
                        (slideInHorizontally(tween(260)) { it / 4 * dir } + fadeIn(tween(260))) togetherWith
                            (slideOutHorizontally(tween(200)) { -it / 4 * dir } + fadeOut(tween(160))) using SizeTransform(clip = true)
                    }) { t ->
                    when (t) {
                        0 -> Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState())) { HomeTab(s) }
                        1 -> Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(10.dp)) { StatsTab(s) }
                        2 -> Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(10.dp)) { DisplayTab() }
                        else -> Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(10.dp)) { SettingsContent() }
                    }
                    }
                    }
                }
                Box(Modifier.fillMaxWidth().background(Glass, RoundedCornerShape(32.dp)).padding(8.dp)) {
                    BoxWithConstraints(Modifier.fillMaxWidth()) {
                        val w = maxWidth / 4
                        val pill by animateColorAsState(NavColors[tab].copy(alpha = 0.28f), tween(260), label = "navPillCol")
                        val x by animateDpAsState(w * tab, spring(dampingRatio = 0.75f, stiffness = Spring.StiffnessMediumLow), label = "navPill")
                        // pil penanda meluncur ke tab terpilih
                        Box(Modifier.matchParentSize()) {
                            Box(Modifier.offset(x = x).width(w).fillMaxHeight().background(pill, RoundedCornerShape(26.dp)))
                        }
                        Row(Modifier.fillMaxWidth()) {
                            NavItem("⌂", "Beranda", tab == 0, NavColors[0]) { setTab(0) }
                            NavItem("▤", "Statistik", tab == 1, NavColors[1]) { setTab(1) }
                            NavItem("◐", "Tampilan", tab == 2, NavColors[2]) { setTab(2) }
                            NavItem("⚙", "Settings", tab == 3, NavColors[3]) { setTab(3) }
                        }
                    }
                }
            }
        }
    }

    /** Kartu Status CPU (di tab Statistik): frekuensi tiap inti (dua kolom) dan grafik beban CPU di dasar kartu. */
    @Composable
    private fun CpuCard(s: Snap) {
        val green = Color(0xFF9AA0A6)
        var tempDialog by remember { mutableStateOf(false) }
        if (tempDialog) CpuTempDialog(s) { tempDialog = false }
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Inner)) {
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Status CPU", color = Color(0xFFC4C6CE), fontSize = 17.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                Box(Modifier.size(34.dp).clip(CircleShape).background(Color(0x1FFFFFFF)).clickable { tempDialog = true }, contentAlignment = Alignment.Center) {
                    Text("⚙", color = Color.White, fontSize = 18.sp)
                }
            }
            val peak = remember { intArrayOf(0) }
            peak[0] = maxOf(peak[0], s.coreMhz.maxOrNull() ?: 0)
            if (s.coreMhz.isEmpty()) {
                Text("Frekuensi belum terbaca", color = Grey, fontSize = 13.sp, modifier = Modifier.padding(16.dp))
            } else Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                s.coreMhz.withIndex().toList().chunked(4).forEach { group ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        group.forEach { (i, mhz) ->
                            val frac = if (mhz > 0 && peak[0] > 0) (mhz.toFloat() / peak[0]).coerceIn(0.03f, 1f) else 0f
                            val barCol = if (frac >= 0.95f) Color(0xFFE6E8EB) else green
                            Column(Modifier.weight(1f).background(Color(0xFF101116), RoundedCornerShape(12.dp)).padding(horizontal = 8.dp, vertical = 7.dp)) {
                                Text("Inti $i", color = Grey, fontSize = 10.sp, maxLines = 1)
                                Text(if (mhz > 0) "$mhz MHz" else "Offline", color = if (mhz > 0) Color.White else Grey, fontSize = 12.sp, maxLines = 1, softWrap = false)
                                Box(Modifier.padding(top = 4.dp).fillMaxWidth().height(3.dp).background(Color(0xFF2A2D38), RoundedCornerShape(2.dp))) {
                                    Box(Modifier.fillMaxWidth(frac).height(3.dp).background(barCol, RoundedCornerShape(2.dp)))
                                }
                            }
                        }
                        repeat(4 - group.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
            CpuGraph(s.cpuHist, green, Modifier.fillMaxWidth().height(36.dp))
        }
    }

    /** Ketuk angka FPS atau grafik di Beranda: ganti warna aksen ke pilihan berikutnya (sama dengan pilihan di tab Tampilan, overlay ikut berubah). */
    private fun cycleAccent() {
        val a = AppSettings.ACCENTS
        AppSettings.accent = a[(a.indexOf(AppSettings.accent) + 1) % a.size]
        AppSettings.save(this)
    }

    @Composable
    private fun HomeTab(s: Snap) {
        var sensorDlg by remember { mutableStateOf(false) }
        if (sensorDlg) SensorDialog(s) { sensorDlg = false }
        // Dua kartu kecil (Overlay + grafik, lalu Rekam FPS) dengan teks dan jarak diperkecil supaya wallpaper tetap terlihat
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Column(Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(20.dp)).padding(horizontal = 10.dp, vertical = 12.dp)) {
                // Padding 6dp di DALAM area klik (setelah clip) supaya huruf paling kiri tidak terpotong sudut membulat
                // FPS rata kiri, Frametime di kanan (di samping tombol sensor)
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).clickable { cycleAccent() }.padding(horizontal = 6.dp, vertical = 1.dp)) {
                        Text("FPS", color = Grey, fontSize = 11.sp, lineHeight = 14.sp)
                        Text("${s.fps}", color = acc(), fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, lineHeight = 20.sp)
                    }
                    Column(Modifier.padding(horizontal = 6.dp, vertical = 1.dp), horizontalAlignment = Alignment.End) {
                        Text("Frametime", color = Grey, fontSize = 11.sp, lineHeight = 14.sp)
                        Text(if (s.ft > 0f) "%.1f ms".format(s.ft) else "-", color = Color.White, fontSize = 16.sp,
                            fontWeight = FontWeight.Bold, maxLines = 1, lineHeight = 20.sp)
                    }
                    Box(Modifier.padding(start = 4.dp, end = 6.dp).size(28.dp).clip(CircleShape).background(Color(0xFF23252F)).clickable { sensorDlg = true },
                        contentAlignment = Alignment.Center) {
                        Text("⚙", color = Color(0xFFC4C6CE), fontSize = 14.sp)
                    }
                }
                FpsGraph(s.hist, Modifier.padding(top = 6.dp, start = 6.dp, end = 6.dp).fillMaxWidth().height(24.dp).clip(RoundedCornerShape(12.dp)).clickable { cycleAccent() })
                Row(Modifier.fillMaxWidth().padding(top = 4.dp, start = 6.dp, end = 6.dp)) {
                    Text(if (s.idle) "Layar diam  ·  30 detik terakhir" else "30 detik terakhir", color = Grey, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(end = 8.dp))
                    Text("AVG ${if (s.avg > 0) s.avg else "-"}  ·  LOW ${if (s.low > 0) s.low else "-"}", color = Grey, fontSize = 11.sp, maxLines = 1, softWrap = false)
                }
                Box(Modifier.padding(top = 6.dp, start = 6.dp, end = 6.dp).fillMaxWidth().height(1.dp).background(Color(0xFF2A2C36)))
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { toggleOverlay() }.padding(horizontal = 6.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Overlay", color = Color.White, fontSize = 13.sp, lineHeight = 16.sp)
                        Text(if (overlayOn) "Aktif" else "Mati", color = if (overlayOn) acc() else Grey, fontSize = 11.sp, lineHeight = 14.sp)
                    }
                    Box(Modifier.size(width = 38.dp, height = 22.dp).clip(CircleShape).background(if (overlayOn) acc() else Color(0xFF3A3D4A)),
                        contentAlignment = if (overlayOn) Alignment.CenterEnd else Alignment.CenterStart) {
                        Box(Modifier.padding(horizontal = 3.dp).size(16.dp).background(Color.White, CircleShape))
                    }
                }
            }
            RecordControls(s)
        }
    }

    /** Dialog di kartu grafik FPS (tab Beranda): sensor CPU/GPU/RAM/BAT, lalu info baterai, jaringan, RAM, dan penyimpanan. */
    @Composable
    private fun SensorDialog(s: Snap, onDismiss: () -> Unit) {
        val ctx = LocalContext.current
        val ex by produceState(Extras(), refreshTick) {
            while (true) {
                value = withContext(Dispatchers.IO) { DeviceExtras.read(ctx) }
                delay(2000)
            }
        }
        val green = Color(0xFFC4C6CE)
        val bat = ex.bat
        val net = ex.net
        val ram = s.mem?.let { SizeExtra(it.ramUsed, it.ramTotal) } ?: ex.ram
        val sto = ex.storage
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Color.Black,
            shape = RoundedCornerShape(28.dp),
            title = {
                Column {
                    Text("Info perangkat", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 22.sp)
                    Text("Baterai, jaringan, RAM, dan penyimpanan", color = Grey, fontSize = 13.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
                }
            },
            text = {
                Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        InfoTile("Baterai", Modifier.weight(1f).fillMaxHeight()) {
                            val t = if (bat.tempC >= 0f) bat.tempC else s.tBat
                            Text((if (bat.pct >= 0) "${bat.pct}%" else pct(s.batPct)) + if (t >= 0f) "  ${deg(t)}" else "",
                                color = green, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            Text(bat.state, color = Color.White, fontSize = 12.sp, maxLines = 1)
                            Text(bat.remain, color = Grey, fontSize = 12.sp, maxLines = 1)
                        }
                        InfoTile("Jaringan", Modifier.weight(1f).fillMaxHeight(), trailing = { SignalBars(net.sigPct, green) }) {
                            Text(net.type, color = green, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            Text(if (net.mbps > 0) "${net.mbps} Mbps" else "-", color = Color.White, fontSize = 12.sp, maxLines = 1)
                            Text(if (net.sigPct >= 0) "${net.sigPct}%   ${net.dbm} dBm" else "", color = Grey, fontSize = 12.sp, maxLines = 1)
                        }
                    }
                    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        InfoTile("RAM", Modifier.weight(1f).fillMaxHeight()) { DonutInfo(ram) }
                        InfoTile("Penyimpanan", Modifier.weight(1f).fillMaxHeight()) { DonutInfo(sto) }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text("Tutup", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
        )
    }

    @Composable
    private fun InfoTile(title: String, modifier: Modifier, trailing: (@Composable () -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
        Column(modifier.background(Color(0xFF101116), RoundedCornerShape(16.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = Color(0xFF9A9CA6), fontSize = 12.sp, modifier = Modifier.weight(1f))
                trailing?.invoke()
            }
            content()
        }
    }

    /** Ikon sinyal 4 batang; batang yang menyala mengikuti kekuatan sinyal (persen), sisanya redup. */
    @Composable
    private fun SignalBars(pct: Int, color: Color) {
        val lit = when {
            pct >= 80 -> 4
            pct >= 55 -> 3
            pct >= 30 -> 2
            pct >= 1 -> 1
            else -> 0
        }
        Canvas(Modifier.size(width = 20.dp, height = 16.dp)) {
            val n = 4
            val gap = 2.dp.toPx()
            val bw = (size.width - gap * (n - 1)) / n
            val r = androidx.compose.ui.geometry.CornerRadius(1.5.dp.toPx())
            for (i in 0 until n) {
                val h = size.height * (i + 1) / n
                drawRoundRect(
                    color = if (i < lit) color else color.copy(alpha = 0.25f),
                    topLeft = Offset(i * (bw + gap), size.height - h),
                    size = androidx.compose.ui.geometry.Size(bw, h),
                    cornerRadius = r
                )
            }
        }
    }

    /** Lingkaran persen di kiri, angka terpakai dan total di kanan. */
    @Composable
    private fun ColumnScope.DonutInfo(v: SizeExtra) {
        val p = v.pct
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.size(50.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val sw = 6.dp.toPx()
                    val tl = Offset(sw / 2, sw / 2)
                    val sz = androidx.compose.ui.geometry.Size(this.size.width - sw, this.size.height - sw)
                    drawArc(Color(0xFF2A2D38), 0f, 360f, false, topLeft = tl, size = sz, style = Stroke(sw))
                    if (p > 0) drawArc(Color(0xFF9A9CA6), -90f, 360f * p / 100f, false, topLeft = tl, size = sz, style = Stroke(sw, cap = StrokeCap.Round))
                }
                Text(if (p >= 0) "$p%" else "-", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.weight(1f)) {
                Text(if (v.usedGb >= 0f) "%.1f GB".format(v.usedGb) else "-", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(if (v.totalGb > 0f) "dari %.1f GB".format(v.totalGb) else "", color = Grey, fontSize = 11.sp, maxLines = 1)
            }
        }
    }

    private fun toggleRecord(s: Snap) {
        if (Recorder.active.value) {
            Thread {
                val r = Recorder.stop(this)
                runOnUiThread { Toast.makeText(this, if (r != null) "Rekaman tersimpan" else "Tidak ada data FPS yang terekam\n${Recorder.lastFail}", if (r != null) Toast.LENGTH_SHORT else Toast.LENGTH_LONG).show() }
            }.start()
        } else {
            if (s.access == "-") { Toast.makeText(this, "Butuh Shizuku atau root untuk merekam", Toast.LENGTH_SHORT).show(); return }
            Sampler.onRecordStart()
            Recorder.start()
            if (!overlayOn) Toast.makeText(this, "Nyalakan overlay supaya rekaman tetap jalan saat kamu pindah ke game", Toast.LENGTH_LONG).show()
        }
    }

    /** Bagikan laporan sebagai gambar PNG (ringkasan teks ikut sebagai keterangan). Gagal membuat gambar -> kirim teks saja. */
    private fun shareReportImage(s: Session) {
        Toast.makeText(this, "Membuat gambar...", Toast.LENGTH_SHORT).show()
        Thread {
            val uri = runCatching {
                val bmp = ShareImage.render(this, s)
                val dir = java.io.File(cacheDir, "share").apply { mkdirs() }
                dir.listFiles()?.forEach { it.delete() }
                val f = java.io.File(dir, "PulseMonitor_${s.id}.png")
                f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                androidx.core.content.FileProvider.getUriForFile(this, "$packageName.files", f)
            }.getOrNull()
            runOnUiThread {
                if (uri == null) { shareSummary(s); return@runOnUiThread }
                val i = Intent(Intent.ACTION_SEND).apply {
                    type = "image/png"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_TEXT, Recorder.summary(s))
                    clipData = android.content.ClipData.newRawUri("", uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(Intent.createChooser(i, "Bagikan laporan"))
            }
        }.start()
    }

    private fun shareSummary(s: Session) {
        val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, Recorder.summary(s)) }
        startActivity(Intent.createChooser(i, "Bagikan laporan"))
    }

    /** Kartu Rekam FPS kecil di Beranda: titik status, judul + keterangan pendek, ikon riwayat, tombol Mulai / Berhenti. */
    @Composable
    private fun RecordControls(s: Snap, modifier: Modifier = Modifier) {
        val rec by Recorder.active.collectAsState()
        val n by Recorder.count.collectAsState()
        val ver by Recorder.version.collectAsState()
        var list by remember { mutableStateOf<List<Session>>(emptyList()) }
        LaunchedEffect(ver) { list = withContext(Dispatchers.IO) { Recorder.list(this@MainActivity) } }
        var showList by remember { mutableStateOf(false) }
        val recRed = Color(0xFFFF5C5C)
        Row(modifier.fillMaxWidth().background(Inner, RoundedCornerShape(20.dp)).padding(start = 14.dp, end = 8.dp, top = 10.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically) {
            val blink by rememberInfiniteTransition(label = "rec").animateFloat(1f, 0.25f,
                infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "recDot")
            Box(Modifier.size(10.dp).graphicsLayer { alpha = if (rec) blink else 1f }.background(if (rec) recRed else RecPink, CircleShape))
            Column(Modifier.weight(1f).padding(start = 10.dp)) {
                Text(if (rec) "Merekam · ${fmtDur(n)}" else "Rekam FPS", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, lineHeight = 18.sp)
                Text(if (rec) "${s.fps} FPS saat ini" else "Lalu buka game", color = Grey, fontSize = 11.sp, maxLines = 1, lineHeight = 14.sp)
            }
            Box(Modifier.size(34.dp).clip(CircleShape).background(Color(0x1FFFFFFF)).clickable { showList = true }, contentAlignment = Alignment.Center) {
                HistoryIcon(Color.White, Modifier.size(17.dp))
                if (list.isNotEmpty()) Box(Modifier.align(Alignment.TopEnd).padding(top = 1.dp, end = 1.dp).size(14.dp).background(RecPink, CircleShape),
                    contentAlignment = Alignment.Center) {
                    Text(if (list.size > 9) "9+" else "${list.size}", color = Color(0xFF0C0C0E), fontSize = 9.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
            Spacer(Modifier.width(8.dp))
            Box(Modifier.height(34.dp).clip(RoundedCornerShape(17.dp))
                .background(Brush.horizontalGradient(if (rec) listOf(Color(0xFFE5677A), Pink) else listOf(RecPink, Pink)))
                .clickable { toggleRecord(s) }.padding(horizontal = 18.dp), contentAlignment = Alignment.Center) {
                Text(if (rec) "Berhenti" else "Mulai", maxLines = 1, softWrap = false,
                    color = if (rec) Color.White else Color(0xFF0C0C0E), fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
        if (showList) TabDialog("Rekaman", if (list.isEmpty()) "Belum ada rekaman FPS" else "${list.size} rekaman FPS, ketuk untuk lihat laporan", { showList = false }) {
            if (list.isEmpty()) Text("Belum ada rekaman. Tekan Rekam, lalu buka game.", color = Grey, fontSize = 13.sp,
                modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp), textAlign = TextAlign.Center)
            else list.forEach { r -> RecRow(r) { showList = false; reportId = r.id } }
            Text("Rekaman juga bisa dihentikan lewat tombol di notifikasi, atau tahan overlay sekitar 1 detik tanpa menggesernya.",
                color = Grey.copy(alpha = 0.85f), fontSize = 11.sp, lineHeight = 15.sp, modifier = Modifier.padding(top = 8.dp, start = 4.dp, end = 4.dp))
        }
    }

    /** Kartu riwayat: ikon game, nama, tanggal · resolusi, rata-rata FPS, grafik mini FPS, dan chip Min / 5% low. */
    @Composable
    private fun RecRow(r: Session, onClick: () -> Unit) {
        val st = remember(r.id) { r.stats() }
        val ctx = LocalContext.current
        val icon = remember(r.pkg) { appIcon(ctx, r.pkg) }
        val line = acc()
        val whenTxt = remember(r.id) { java.text.SimpleDateFormat("d MMM · HH:mm", java.util.Locale.getDefault()).format(java.util.Date(r.id)) }
        val spark = remember(r.id) {
            val f = r.fps.filter { it > 0f }
            if (f.size <= 60) f else List(60) { i -> f[(i * (f.size - 1)) / 59] }
        }
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Inner).clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (icon != null) Image(icon.asImageBitmap(), null, Modifier.size(44.dp).clip(RoundedCornerShape(11.dp)))
                else Box(Modifier.size(44.dp).background(Color(0xFF262833), RoundedCornerShape(11.dp)), contentAlignment = Alignment.Center) {
                    Text(r.label.take(1).uppercase(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                    Text(r.label, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(whenTxt + (if (r.res.isBlank()) "" else " · ${r.res}"), color = Grey, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Column(Modifier.padding(start = 10.dp), horizontalAlignment = Alignment.End) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(f1(st.avg), color = line, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                        Text(" FPS", color = Grey, fontSize = 11.sp, modifier = Modifier.padding(bottom = 3.dp))
                    }
                    Text(fmtDur(r.dur), color = Grey, fontSize = 12.sp, maxLines = 1)
                }
            }
            if (spark.size >= 2) {
                Canvas(Modifier.fillMaxWidth().height(30.dp)) {
                    var lo = spark.min(); var hi = spark.max()
                    if (hi - lo < 4f) { val m = (hi + lo) / 2f; lo = m - 2f; hi = m + 2f }
                    val path = Path()
                    spark.forEachIndexed { i, v ->
                        val x = size.width * i / (spark.size - 1)
                        val y = size.height * (1f - (v - lo) / (hi - lo))
                        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    drawPath(path, line.copy(alpha = 0.9f), style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Min" to st.min, "5% low" to st.low5, "Maks" to st.max).forEach { (k, v) ->
                    Row(Modifier.background(Color.White.copy(alpha = 0.06f), CircleShape).padding(horizontal = 10.dp, vertical = 4.dp)) {
                        Text("$k ", color = Grey, fontSize = 11.sp)
                        Text("%.0f".format(v), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }

    @Composable
    private fun ReportScreen(id: Long) {
        val sess by produceState<Session?>(null, id, refreshTick) { value = withContext(Dispatchers.IO) { Recorder.load(this@MainActivity, id) } }
        val ss = sess
        if (ss == null) {
            Box(Modifier.fillMaxSize().background(Color(0xFF101014)), contentAlignment = Alignment.Center) { Text("Memuat…", color = Grey) }
            return
        }
        PullToRefreshBox(isRefreshing = refreshing, onRefresh = { doRefresh() }, modifier = Modifier.fillMaxSize()) {
        ReportView(ss, onBack = { reportId = null }, onShare = { shareReportImage(ss) },
            onCsv = {
                Thread {
                    val ok = Recorder.exportCsv(this@MainActivity, ss)
                    runOnUiThread { Toast.makeText(this@MainActivity, if (ok) "CSV tersimpan di folder Download" else "Gagal menyimpan CSV", Toast.LENGTH_SHORT).show() }
                }.start()
            },
            onDelete = { Recorder.delete(this@MainActivity, ss.id); reportId = null },
            onDesc = { t -> Thread { Recorder.saveDesc(this@MainActivity, ss, t) }.start() },
            wallpaper = wallpaperBmp, dim = dim)
        }
    }

    @Composable
    private fun StatsTab(s: Snap) {
        val scope = rememberCoroutineScope()
        var tools by remember { mutableStateOf(false) }
        if (tools) StatsToolsDialog(s) { tools = false }
        DeviceCard()
        if (s.access == "-") Text("Belum ada akses. Pilih Shizuku atau Root di tab Settings.", color = Color(0xFFE0B040), fontSize = 12.sp,
            modifier = Modifier.fillMaxWidth().background(Color(0x1FE0B040), RoundedCornerShape(16.dp)).padding(horizontal = 14.dp, vertical = 10.dp))
        // Geser kiri-kanan: halaman 1 Memori, halaman 2 Status CPU (titik penanda di bawah)
        val pager = androidx.compose.foundation.pager.rememberPagerState { 2 }
        // Tinggi kedua halaman beda (Memori vs Status CPU). Tanpa ini tinggi pager loncat saat geser dan
        // panel (menempel di bawah) ikut naik-turun. Sekarang tinggi diinterpolasi halus mengikuti jari.
        val pageH = remember { androidx.compose.runtime.mutableStateListOf(0, 0) }
        val density = androidx.compose.ui.platform.LocalDensity.current
        val pagerMod = if (pageH[0] > 0 && pageH[1] > 0) {
            val f = (pager.currentPage + pager.currentPageOffsetFraction).coerceIn(0f, 1f)
            val hPx = pageH[0] + (pageH[1] - pageH[0]) * f
            Modifier.fillMaxWidth().height(with(density) { hPx.toDp() })
        } else Modifier.fillMaxWidth()
        androidx.compose.foundation.pager.HorizontalPager(state = pager, pageSpacing = 10.dp, verticalAlignment = Alignment.Top,
            beyondViewportPageCount = 1, modifier = pagerMod) { page ->
            // Animasi geser: halaman yang menjauh sedikit mengecil dan memudar, halaman yang masuk membesar dan menyala
            Box(Modifier.fillMaxWidth().wrapContentHeight(Alignment.Top, unbounded = true)
                .onSizeChanged { if (it.height > 0 && pageH[page] != it.height) pageH[page] = it.height }
                .graphicsLayer {
                val off = ((pager.currentPage - page) + pager.currentPageOffsetFraction).let { if (it < 0f) -it else it }.coerceIn(0f, 1f)
                val k = 1f - off
                transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0.5f, 0f)
                scaleX = 0.95f + 0.05f * k; scaleY = 0.95f + 0.05f * k
                alpha = 0.6f + 0.4f * k
                translationX = size.width * 0.03f * (if (pager.currentPage + pager.currentPageOffsetFraction > page) off else -off)
            }) {
            if (page == 0) {
            // Kartu Memori: judul di kiri, tombol pengaturan (Probe GPU + Diagnostik) di kanan atas
            Column(Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(24.dp)).padding(start = 18.dp, end = 18.dp, top = 16.dp, bottom = 6.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Memori", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    s.mem?.let {
                        Text("${it.marketGb} GB", color = Color(0xFFC4C6CE), fontSize = 12.sp,
                            modifier = Modifier.padding(start = 10.dp).background(Color(0xFF1C1D26), CircleShape).padding(horizontal = 10.dp, vertical = 3.dp))
                    }
                    Spacer(Modifier.weight(1f))
                    Box(Modifier.size(32.dp).clip(CircleShape).background(Color(0xFF1C1D26)).clickable { tools = true }, contentAlignment = Alignment.Center) {
                        Text("⚙", color = Color(0xFFC4C6CE), fontSize = 16.sp)
                    }
                }
                Spacer(Modifier.height(4.dp))
                val m = s.mem
                if (m == null) {
                    MeterRow("RAM", s.ramText, if (s.ramPct >= 0) s.ramPct / 100f else 0f, barLoad(s.ramPct))
                    if (s.swapText.isNotEmpty()) MeterRow("Swap", s.swapText, usedFrac(s.swapText), Color(0xFFA78BFA))
                } else {
                    Column {
                        MemBar("RAM", m.ramTotal, m.ramUsed, m.ramFree, barLoad(s.ramPct))
                        if (m.swapTotal > 0f) MemDivider()
                        if (m.swapTotal > 0f) MemBar(if (m.zram) "ZRAM" else "Swap", m.swapTotal, m.swapUsed, m.swapFree, Color(0xFFA78BFA))
                        if (m.extraTotal > 0f) MemDivider()
                        if (m.extraTotal > 0f) MemBar("Swap tambahan", m.extraTotal, m.extraUsed, (m.extraTotal - m.extraUsed).coerceAtLeast(0f), Color(0xFFA78BFA))
                    }
                }
            }
            } else CpuCard(s)
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 2.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            listOf("Memori", "Status CPU").forEachIndexed { i, _ ->
                val on = pager.currentPage == i
                val dotW by animateDpAsState(if (on) 22.dp else 8.dp, spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMediumLow), label = "dotW")
                val dotC by animateColorAsState(if (on) acc() else Color(0x55FFFFFF), tween(250), label = "dotC")
                Box(Modifier.padding(horizontal = 4.dp).height(8.dp).width(dotW)
                    .background(dotC, CircleShape)
                    .clickable { scope.launch { pager.animateScrollToPage(i) } })
            }
        }
    }

    /** Baca properti sistem lewat getprop (tanpa izin); kosong bila tidak ada. */
    private fun sysProp(key: String): String = try {
        val pr = Runtime.getRuntime().exec(arrayOf("getprop", key))
        pr.inputStream.bufferedReader().use { it.readText() }.trim()
    } catch (e: Exception) { "" }

    private fun androidName(sdk: Int) = when (sdk) {
        36 -> "Baklava"; 35 -> "Vanilla Ice Cream"; 34 -> "Upside Down Cake"; 33 -> "Tiramisu"
        32, 31 -> "Snow Cone"; 30 -> "Red Velvet Cake"; 29 -> "Quince Tart"; else -> ""
    }

    private fun fmtUptime(ms: Long): String {
        val t = ms / 1000
        return "%dj %dm %dd".format(t / 3600, (t % 3600) / 60, t % 60)
    }

    /** Kartu info perangkat: nama HP, chipset, versi Android, waktu aktif dan deep sleep (diperbarui tiap detik). */
    @Composable
    private fun DeviceCard() {
        val info by produceState(listOf("", ""), refreshTick) {
            value = withContext(Dispatchers.IO) {
                val market = sysProp("ro.product.marketname").ifEmpty { sysProp("ro.product.model") }.ifEmpty { Build.MODEL }
                val brand = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
                val name = if (market.startsWith(brand, true)) market else "$brand $market"
                val soc = if (Build.VERSION.SDK_INT >= 31 && Build.SOC_MODEL.isNotEmpty() && Build.SOC_MODEL != "unknown")
                    "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}".trim() else Build.HARDWARE
                listOf(name, soc)
            }
        }
        val up by produceState(0L to 0L) {
            while (true) {
                value = android.os.SystemClock.elapsedRealtime() to android.os.SystemClock.uptimeMillis()
                delay(1000)
            }
        }
        val awake = up.first; val sleep = (up.first - up.second).coerceAtLeast(0L)
        val sleepPct = if (awake > 0) (sleep * 100 / awake).toInt() else 0
        val an = androidName(Build.VERSION.SDK_INT)
        val isPoco = Build.BRAND.equals("poco", true)
        val badgeBg = if (isPoco) Color(0xFFFFD500) else Color(0xFF101116)
        val badgeFg = if (isPoco) Color.Black else Color.White
        val accent = Color(0xFF9AA0A6)
        val accentSoft = Color(0xFFD3D7DC)
        val shape = RoundedCornerShape(24.dp)
        @Composable fun Chip(text: String, tint: Color = Color(0x1FFFFFFF), fg: Color = Color(0xFFE6E8EB)) =
            Text(text, color = fg, fontSize = 11.5.sp, fontWeight = FontWeight.Medium, maxLines = 1,
                modifier = Modifier.background(tint, RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 4.dp))
        @Composable fun Tile(value: String, label: String, valueColor: Color = Color.White, mod: Modifier) =
            Column(mod.background(Color(0x14FFFFFF), RoundedCornerShape(16.dp)).padding(horizontal = 14.dp, vertical = 10.dp)) {
                Text(label, color = Grey, fontSize = 11.sp, maxLines = 1)
                Text(value, color = valueColor, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            }
        Column(
            Modifier.fillMaxWidth()
                .clip(shape)
                .background(Brush.linearGradient(listOf(Color(0xFF3A3D42), Color(0xFF17181B), Color(0xFF0A0B0C))), shape)
                .border(1.dp, Brush.linearGradient(listOf(accent.copy(alpha = 0.6f), Color(0x14FFFFFF))), shape)
                .padding(16.dp)
        ) {
            // Atas: lencana merek + nama HP + chip chipset / versi Android
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(56.dp).background(badgeBg, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
                    Text(Build.BRAND.uppercase(), color = badgeFg, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, maxLines = 1)
                }
                Column(Modifier.padding(start = 14.dp).weight(1f)) {
                    Text(info[0], color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (info[1].isNotEmpty()) Chip(info[1])
                        Chip(if (an.isNotEmpty()) "Android ${Build.VERSION.RELEASE} · $an" else "Android ${Build.VERSION.RELEASE}",
                            accent.copy(alpha = 0.22f), accentSoft)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            // Dua kotak ringkas: waktu aktif dan deep sleep
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Tile(fmtUptime(awake), "Waktu aktif", mod = Modifier.weight(1f))
                Tile(fmtUptime(sleep), "Deep sleep • $sleepPct%", valueColor = accentSoft, mod = Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
            // Bilah tipis: porsi deep sleep dari total waktu aktif
            Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(Color(0x1FFFFFFF))) {
                Box(Modifier.fillMaxWidth((sleepPct / 100f).coerceIn(0.02f, 1f)).fillMaxHeight()
                    .background(Brush.horizontalGradient(listOf(accent, accentSoft)), RoundedCornerShape(3.dp)))
            }
        }
    }

    /** Jalankan probe node GPU di thread terpisah lalu salin hasilnya ke clipboard. */
    private fun runResProbe() {
        Toast.makeText(this, "Membaca layer game...", Toast.LENGTH_SHORT).show()
        Thread {
            val t = runCatching { Sampler.resProbe() }.getOrDefault("")
            runOnUiThread {
                if (t.isBlank()) Toast.makeText(this, "Tidak ada hasil (butuh Shizuku/root)", Toast.LENGTH_SHORT).show()
                else {
                    val cm = getSystemService(android.content.ClipboardManager::class.java)
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("res-probe", t))
                    Toast.makeText(this, "Tersalin (${t.length} karakter). Tempel ke chat.", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun runGpuProbe() {
        Toast.makeText(this, "Membaca node GPU...", Toast.LENGTH_SHORT).show()
        Thread {
            val t = Sampler.gpuProbe()
            runOnUiThread {
                if (t.isBlank()) Toast.makeText(this, "Tidak ada hasil (butuh Shizuku/root)", Toast.LENGTH_SHORT).show()
                else {
                    val cm = getSystemService(android.content.ClipboardManager::class.java)
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("gpu-probe", t))
                    Toast.makeText(this, "Tersalin (${t.length} karakter). Tempel ke chat.", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    /** Dialog di kartu Status CPU: suhu CPU, GPU, dan baterai (dulunya kartu Suhu terpisah). */
    @Composable
    private fun CpuTempDialog(s: Snap, onDismiss: () -> Unit) {
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Color.Black,
            shape = RoundedCornerShape(28.dp),
            title = {
                Column {
                    Text("Suhu", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 22.sp)
                    Text("CPU, GPU, dan Baterai", color = Grey, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    TempMeter("CPU", s.tCpu); TempMeter("GPU", s.tGpu); TempMeter("Baterai", s.tBat)
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text("Tutup", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
        )
    }

    /** Dialog pengaturan di kartu Memori: Probe GPU sekarang bagian dari Diagnostik. */
    @Composable
    private fun StatsToolsDialog(s: Snap, onDismiss: () -> Unit) {
        var diag by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Color.Black,
            shape = RoundedCornerShape(28.dp),
            title = {
                Column {
                    Text("Pengaturan Statistik", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 22.sp)
                    Text("Probe GPU dan Diagnostik", color = Grey, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
                }
            },
            text = {
                Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SettingCard("Diagnostik") {
                        Text("Probe GPU membaca semua node GPU di HP ini dan menyalinnya ke clipboard, untuk mencari sumber frekuensi yang benar.", color = Grey, fontSize = 12.sp)
                        if (s.access != "-") PillButton("Probe GPU dan salin") { runGpuProbe() }
                        else Text("Probe GPU butuh akses Shizuku atau Root (tab Settings).", color = Color(0xFFE0B040), fontSize = 12.sp)
                        Text("Probe resolusi menyalin cuplikan layer game supaya cara bacanya bisa disesuaikan. Buka game dulu dengan overlay menyala.", color = Grey, fontSize = 12.sp)
                        if (s.access != "-") PillButton("Probe resolusi game dan salin") { runResProbe() }
                        if (s.dbg.isNotEmpty()) {
                            PillButton(if (diag) "Sembunyikan" else "Tampilkan", filled = false) { diag = !diag }
                            if (diag) Text(s.dbg, color = Grey, fontSize = 10.5.sp, lineHeight = 15.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text("Tutup", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
        )
    }

    @Composable
    private fun DisplayTab() {
        // 0 = tutup, 2 = warna overlay, 3 = ukuran dan transparan
        var dlg by remember { mutableIntStateOf(0) }
        SettingCard("Wallpaper") {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PillButton(if (wallpaperBmp == null) "Pilih gambar" else "Ganti gambar") {
                    pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
                if (wallpaperBmp != null) PillButton("Hapus", filled = false) { WallpaperStore.clear(this@MainActivity); wallpaperBmp = null }
            }
            if (wallpaperBmp == null) Text("Belum ada gambar. Pilih satu untuk jadi latar aplikasi.", color = Grey, fontSize = 12.sp)
            if (wallpaperBmp != null) {
                SliderLabel("Redupkan latar", "${(dim * 100).toInt()}%")
                AccSlider(dim, 0.2f..0.9f, { dim = it }) { WallpaperStore.saveDim(this@MainActivity, dim) }
            }
        }
        NavCard("Warna overlay", "Aksen, teks, latar, dan suhu", { dlg = 2 }) {
            Box(Modifier.size(22.dp).background(Color(AppSettings.accent), CircleShape).border(1.dp, Color(0x33FFFFFF), CircleShape))
            Spacer(Modifier.width(6.dp))
            Box(Modifier.size(22.dp).background(Color(AppSettings.overlayText), CircleShape).border(1.dp, Color(0x33FFFFFF), CircleShape))
            Spacer(Modifier.width(6.dp))
            Box(Modifier.size(22.dp).background(Color(AppSettings.overlayBg), CircleShape).border(1.dp, Color(0x33FFFFFF), CircleShape))
        }
        NavCard("Ukuran dan transparan", "Overlay dan panel", { dlg = 3 }) {
            Text("${AppSettings.size}%", color = acc(), fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
        if (dlg == 2) TabDialog("Warna overlay", "Perubahan muncul dalam sekitar 1 detik", { dlg = 0 }) { ColorContent() }
        if (dlg == 3) TabDialog("Ukuran dan transparan", "Overlay dan panel", { dlg = 0 }) { SizeContent() }
    }

    /** Dialog umum untuk tab Tampilan: judul, keterangan, isi bisa digulir, tombol Tutup. */
    @Composable
    private fun TabDialog(title: String, sub: String, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Color.Black,
            shape = RoundedCornerShape(28.dp),
            title = {
                Column {
                    Text(title, color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 22.sp)
                    Text(sub, color = Grey, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
                }
            },
            text = { Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) { content() } },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text("Tutup", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
        )
    }

    /** Kartu satu baris yang membuka dialog; isi kecil (pratinjau nilai) tampil di kanan. */
    @Composable
    private fun NavCard(title: String, sub: String, onClick: () -> Unit, trailing: @Composable RowScope.() -> Unit) {
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Inner).clickable { onClick() }.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold)
                Text(sub, color = Grey, fontSize = 12.sp)
            }
            trailing()
            Text("  ›", color = Grey, fontSize = 22.sp)
        }
    }

    @Composable
    private fun SizeContent() {
        val ctx = LocalContext.current
        SettingCard("Ukuran overlay") {
            SliderLabel("Besar kecil", "${AppSettings.size}%")
            AccSlider(AppSettings.size / 100f, 0.6f..2f, { AppSettings.size = ((it * 100).toInt() / 5 * 5).coerceIn(60, 200) }) { AppSettings.save(ctx) }
            PillButton("Ukuran normal", filled = false) { AppSettings.size = AppSettings.DEF_SIZE; AppSettings.save(ctx) }
        }
        SettingCard("Transparan panel") {
            SliderLabel("Seberapa tembus panel dan navigasi", "${AppSettings.panelAlpha}%")
            AccSlider(AppSettings.panelAlpha / 100f, 0.15f..1f, { AppSettings.panelAlpha = (it * 100).toInt().coerceIn(15, 100) }) { AppSettings.save(ctx) }
            PillButton("Kembalikan bawaan", filled = false) { AppSettings.panelAlpha = AppSettings.DEF_PANEL; AppSettings.save(ctx) }
        }
    }

    /** Pratinjau gaya Simple dan Compact: label gradasi biru-ungu-pink, isi dan urutan baris sama dengan overlay aslinya. */
    private fun previewText(idx: Int): AnnotatedString {
        val yel = Color(0xFFFFD866)
        val s0 = Color(0xFF5E9BF5); val s1 = Color(0xFF9A86E8); val s2 = Color(0xFFEE8FBE)
        fun at(f: Float): Color = if (f < 0.5f) androidx.compose.ui.graphics.lerp(s0, s1, f * 2f) else androidx.compose.ui.graphics.lerp(s1, s2, (f - 0.5f) * 2f)
        return buildAnnotatedString {
            fun p(t: String, c: Color = Color.Unspecified, b: Boolean = false) =
                withStyle(SpanStyle(color = c, fontWeight = if (b) FontWeight.Bold else null)) { append(t) }
            fun g(t: String) = t.forEachIndexed { i, ch -> p(ch.toString(), at(if (t.length > 1) i / (t.length - 1f) else 1f)) }
            fun pd(t: String, n: Int) = t.padStart(n)
            fun pe(t: String, n: Int) = t.padEnd(n)
            if (idx == 0) {
                g("FPS"); p(" "); p("60", b = true)
                p("  "); g("CPU"); p(" 35% 42°")
                p("  "); g("GPU"); p(" 45% 41°")
                p("  "); g("RAM"); p(" 62%")
                p("  "); g("BAT"); p(" 85% 36°")
            } else {
                val gap = "  "
                g("FPS"); p(gap + pe("60", 4)); p("16.7ms", yel); p("\n")
                g("CPU"); p(gap + pe("35%", 4) + pe("42°", 4)); p(pd("1800", 4) + "MHz", yel); p("\n")
                g("GPU"); p(gap + pe("45%", 4) + pe("41°", 4)); p(pd("680", 4) + "MHz", yel); p("\n")
                g("BAT"); p(gap + pe("85%", 4) + pe("36°", 4)); p("2.4W", yel); p("\n")
                g("GOV"); p(gap); p("sugov_ext", yel); p("\n")
                g("RAM"); p(gap + "62%")
            }
        }
    }

    /** Label gradasi biru, ungu, pink per huruf: sama dengan label overlay Compact asli. */
    private fun gradLabel(t: String): AnnotatedString {
        val stops = intArrayOf(0xFF5E9BF5.toInt(), 0xFF9A86E8.toInt(), 0xFFEE8FBE.toInt())
        fun ch(c: Int, sh: Int) = c ushr sh and 255
        fun mix(a: Int, b: Int, f: Float): Int {
            fun m(sh: Int) = (ch(a, sh) + (ch(b, sh) - ch(a, sh)) * f).toInt()
            return (0xFF shl 24) or (m(16) shl 16) or (m(8) shl 8) or m(0)
        }
        fun at(f: Float): Int = if (f < 0.5f) mix(stops[0], stops[1], f * 2f) else mix(stops[1], stops[2], (f - 0.5f) * 2f)
        return buildAnnotatedString {
            t.forEachIndexed { i, c ->
                withStyle(SpanStyle(color = Color(at(if (t.length > 1) i / (t.length - 1f) else 1f)))) { append(c.toString()) }
            }
        }
    }

    /** Pratinjau gaya Compact: sama dengan overlay asli (label gradasi, garis beban di bawah CPU/GPU, nilai kuning, governor, RAM). */
    @Composable
    private fun CompactPreview() {
        val tx = Color(AppSettings.overlayText)
        val yel = Color(0xFFFFD866)
        val pv = RoundedCornerShape(10.dp)
        val mono = androidx.compose.ui.text.font.FontFamily.Monospace
        fun pd(t: String, n: Int) = t.padEnd(n)
        @Composable fun Line(label: String, rest: AnnotatedString) {
            Text(buildAnnotatedString { append(gradLabel(label)); append("  "); append(rest) },
                color = tx, fontSize = 10.5.sp, lineHeight = 15.sp, fontFamily = mono, softWrap = false)
        }
        @Composable fun Bar(frac: Float) {
            Box(Modifier.fillMaxWidth(0.5f).padding(top = 1.dp, bottom = 2.dp).height(3.dp).clip(RoundedCornerShape(2.dp)).background(tx.copy(alpha = 0.16f))) {
                Box(Modifier.fillMaxHeight().fillMaxWidth(frac).clip(RoundedCornerShape(2.dp)).background(Color(loadCol((frac * 100).toInt()))))
            }
        }
        fun y(t: String) = buildAnnotatedString { withStyle(SpanStyle(color = yel)) { append(t) } }
        fun plain(t: String) = AnnotatedString(t)
        Column(Modifier.width(IntrinsicSize.Max).clip(pv).background(Color(withAlpha(AppSettings.overlayBg, AppSettings.alpha)))
            .border(1.dp, Color(withAlpha(AppSettings.overlayText, 14)), pv)
            .padding(horizontal = 10.dp, vertical = 7.dp)) {
            Line("FPS", buildAnnotatedString { append(pd("60", 4)); append(y("16.7ms")) })
            Line("CPU", buildAnnotatedString { append(pd("35%", 4)); append(pd("42°", 4)); append(y("1800MHz")) })
            Bar(0.35f)
            Line("GPU", buildAnnotatedString { append(pd("45%", 4)); append(pd("41°", 4)); append(y(" 680MHz")) })
            Bar(0.45f)
            Line("BAT", buildAnnotatedString { append(pd("85%", 4)); append(pd("36°", 4)); append(y("2.4W")) })
            Line("GOV", y("sugov_ext"))
            Line("RAM", plain("62%"))
        }
    }

    /** Pratinjau gaya Normal: baris FPS + tiga bilah horizontal (CPU, GPU, baterai), sama dengan overlay aslinya. */
    @Composable
    private fun RingPreview() {
        val tx = Color(AppSettings.overlayText)
        val yel = Color(0xFFFFD866)
        val pv = RoundedCornerShape(14.dp)
        Column(Modifier.clip(pv).background(Color(withAlpha(AppSettings.overlayBg, AppSettings.alpha)))
            .border(1.dp, Color(withAlpha(AppSettings.overlayText, 14)), pv)
            .padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.width(196.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("FPS", color = tx, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(32.dp))
                Text("60", color = tx, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("16.7ms", color = yel, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            PreviewBar("CPU", 0.35f, Color(loadCol(35)), "3300MHz", tx, yel)
            PreviewBar("GPU", 0.92f, Color(loadCol(92)), "702MHz", tx, yel)
            PreviewBar("BAT", 0.72f, Color(0xFF7CFFB2), "33.1°C", tx, yel)
        }
    }

    @Composable
    private fun PreviewBar(label: String, frac: Float, col: Color, value: String, tx: Color, yel: Color) {
        Row(Modifier.width(196.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = tx, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(32.dp))
            Box(Modifier.width(86.dp).height(6.dp).clip(RoundedCornerShape(3.dp)).background(tx.copy(alpha = 0.16f))) {
                Box(Modifier.fillMaxHeight().fillMaxWidth(frac).clip(RoundedCornerShape(3.dp)).background(col))
            }
            Text(value, color = yel, fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.End, modifier = Modifier.weight(1f))
        }
    }

    @Composable
    private fun StyleOption(idx: Int, title: String, sub: String, inDialog: Boolean = false, onPicked: () -> Unit = {}) {
        val ctx = LocalContext.current
        val sel = AppSettings.overlayStyle == idx
        val ac = acc()
        val border by animateColorAsState(if (sel) ac else Color(0x22FFFFFF), tween(200), label = "styBorder")
        val shape = RoundedCornerShape(20.dp)
        Column(Modifier.fillMaxWidth().clip(shape)
            .background(if (sel) ac.copy(alpha = 0.10f) else Color(0x12FFFFFF))
            .border(if (sel) 2.dp else 1.dp, border, shape)
            .clickable { AppSettings.overlayStyle = idx; AppSettings.save(ctx); onPicked() }.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(sub, color = Grey, fontSize = 12.sp)
                }
                Box(Modifier.size(24.dp).background(if (sel) ac else Color.Transparent, CircleShape)
                    .border(2.dp, if (sel) ac else Grey, CircleShape), contentAlignment = Alignment.Center) {
                    if (sel) Text("✓", color = Color(0xFF101014), fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
            val pv = RoundedCornerShape(if (idx == 0) 20.dp else 14.dp)
            if (idx == 2) RingPreview() else if (idx == 1) CompactPreview()
            else Text(previewText(idx), color = Color(AppSettings.overlayText), fontSize = 10.5.sp, lineHeight = 15.sp,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, softWrap = idx != 0 || inDialog, maxLines = if (idx == 0 && !inDialog) 1 else Int.MAX_VALUE,
                modifier = Modifier.clip(pv).background(Color(withAlpha(AppSettings.overlayBg, AppSettings.alpha)))
                    .border(1.dp, Color(withAlpha(AppSettings.accent, 33)), pv)
                    .padding(horizontal = 12.dp, vertical = if (idx == 0) 6.dp else 9.dp))
        }
    }

    @Composable
    private fun SettingsContent() {
        val ctx = LocalContext.current
        val s by Sampler.state.collectAsState()
        // Setelah memilih metode, status mengikuti Access langsung (bukan menunggu tick Sampler)
        val auto = Access.choice == Access.AUTO
        val connected = if (auto) s.access != "-" else Access.status == 2
        val root = if (auto && connected) s.access == "Root" else Access.isRoot()
        SettingCard("Akses") {
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable { Access.refresh(); accessDlg = true }.padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).background(Color(0xFF0A0A1A), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                    if (root) ShieldIcon(Color(0xFFE49A72), Modifier.size(24.dp)) else PhoneIcon(Color(0xFF8E86F0), Modifier.size(24.dp))
                }
                Column(Modifier.weight(1f).padding(start = 14.dp)) {
                    Text(if (root) "Root" else "Shizuku", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text(when {
                        Access.busy > 0 -> "Memeriksa…"
                        connected -> "Terhubung"
                        Access.status == 1 -> "Ketuk untuk beri izin"
                        root -> "Root tidak tersedia"
                        else -> "Tidak berjalan"
                    }, color = if (connected) Color(0xFF5BD68E) else Color(0xFFE0B040), fontSize = 13.sp)
                }
                Text("›", color = Grey, fontSize = 22.sp)
            }
        }
        // Kartu Pengaturan: tombol gear (sama seperti di kartu Memori) membuka dialog berisi semua pengaturan
        var cfg by remember { mutableStateOf(false) }
        Row(Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(20.dp)).clickable { cfg = true }.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Pengaturan", color = Color.White, fontWeight = FontWeight.Bold)
                Text("Latar belakang, info overlay, dan gaya overlay", color = Grey, fontSize = 12.sp)
            }
            Box(Modifier.size(34.dp).clip(CircleShape).background(Color(0x1FFFFFFF)).clickable { cfg = true }, contentAlignment = Alignment.Center) {
                Text("⚙", color = Color.White, fontSize = 18.sp)
            }
        }
        if (cfg) AppSettingsDialog { cfg = false }
        // Komunitas dan pembuat aplikasi: keduanya membuka Discord
        SettingCard("Komunitas") {
            LinkRow({ GamepadIcon(Color(0xFF8E86F0), Modifier.size(26.dp)) }, "Komunitas Discord", "") {
                openLink("https://discord.gg/EFaCxujTcC")
            }
            SettingDivider()
            LinkRow({ PersonIcon(Color(0xFFE49A72), Modifier.size(26.dp)) }, "Pembuat aplikasi", "lismoyca") {
                openLink("https://discord.com/users/1426827460187656223")
            }
        }
    }

    private fun openLink(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { Toast.makeText(this, "Tidak ada aplikasi untuk membuka tautan", Toast.LENGTH_SHORT).show() }
    }

    /** Dialog pengaturan di tab Settings: Latar belakang, Info tambahan di overlay, dan Gaya overlay. */
    @Composable
    private fun AppSettingsDialog(onDismiss: () -> Unit) {
        val ctx = LocalContext.current
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Color.Black,
            shape = RoundedCornerShape(28.dp),
            title = {
                Column {
                    Text("Pengaturan", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 22.sp)
                    Text("Latar belakang, info overlay, dan gaya overlay", color = Grey, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
                }
            },
            text = {
                Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SettingCard("Latar belakang") {
                        ToggleRow("Tetap aktif di latar belakang", "Notifikasi baterai tetap hidup walau overlay mati",
                            "Notifikasi baterai tetap hidup walau overlay dimatikan. Tanpa overlay dan tanpa pembacaan sensor, jadi ringan di RAM. Matikan saklar ini untuk menghapus notifikasi.",
                            AppSettings.bgMode) { on -> AppSettings.bgMode = on; AppSettings.save(ctx); applyBgMode(on) }
                    }
                    SettingCard("Info tambahan di overlay") {
                        ToggleRow("Touch rate", "Angka Hz saat layar disentuh",
                            "Angka Hz muncul saat layar disentuh, \"-\" saat tidak. Butuh Shizuku atau root.",
                            AppSettings.touchRate) { on -> AppSettings.touchRate = on; AppSettings.save(ctx) }
                        SettingDivider()
                        ToggleRow("Latensi sentuh", "Angka ms tiap layar diketuk",
                            "Angka ms (terakhir dan rata-rata 20 ketukan) muncul tiap layar diketuk. Mengukur waktu dari driver sentuh sampai ke aplikasi, di luar waktu render layar. Tidak butuh Shizuku atau root.",
                            AppSettings.touchLat) { on -> AppSettings.touchLat = on; if (!on) TouchLatency.reset(); AppSettings.save(ctx) }
                        SettingDivider()
                        ToggleRow("Governor CPU", "Nama governor di gaya Compact",
                            "Nama governor CPU (mis. GOV sugov_ext) di gaya Compact; satu baris bila semua cluster sama. Butuh Shizuku atau root.",
                            AppSettings.cpuGov) { on -> AppSettings.cpuGov = on; AppSettings.save(ctx) }
                    }
                    // Satu baris: nama gaya yang aktif tampil di samping, ketuk untuk memilih gaya lain
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Inner).clickable { styleDlg = true }.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Gaya overlay", color = Color.White, fontWeight = FontWeight.Bold)
                            Text("Ketuk untuk memilih bentuk overlay", color = Grey, fontSize = 12.sp)
                        }
                        Text(AppSettings.STYLES[AppSettings.overlayStyle], color = acc(), fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text("  ›", color = Grey, fontSize = 22.sp)
                    }
                    if (styleDlg) StyleDialog { styleDlg = false }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text("Tutup", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
        )
    }

    @Composable
    private fun StyleDialog(onDismiss: () -> Unit) {
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Color.Black,
            shape = RoundedCornerShape(28.dp),
            title = { Text("Gaya overlay", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 24.sp) },
            text = {
                Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Pratinjau mengikuti warna dan transparansi di tab Tampilan.", color = Color(0xFFA9B0B5), fontSize = 13.sp)
                    StyleOption(0, "Simple", "Satu baris: FPS, CPU, GPU, baterai", inDialog = true, onPicked = onDismiss)
                    StyleOption(1, "Compact", "Kartu kecil per komponen, dengan frekuensi", inDialog = true, onPicked = onDismiss)
                    StyleOption(2, "Normal", "Bilah per baris: FPS, CPU, GPU, baterai", inDialog = true, onPicked = onDismiss)
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text("Batal", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
        )
    }

    @Composable
    private fun AccessDialog(onDismiss: () -> Unit) {
        val cur = Access.choice
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Color.Black,
            shape = RoundedCornerShape(28.dp),
            title = { Text("Izinkan Akses", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 24.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Pilih metode yang ingin dipakai untuk akses tingkat tinggi.", color = Color(0xFFA9B0B5))
                    AccessOption("Shizuku", "Tanpa root, jalan lewat Wireless Debugging atau ADB.",
                        Color(0xFF8E86F0), Color(0xFF13111F), cur == Access.SHIZUKU, { PhoneIcon(Color(0xFF8E86F0), Modifier.size(30.dp)) }) {
                        Access.select(Access.SHIZUKU); onDismiss()
                    }
                    AccessOption("Root", "Butuh perangkat yang di-root (Magisk, KernelSU, APatch, dll).",
                        Color(0xFFE49A72), Color(0xFF181412), cur == Access.ROOT, { ShieldIcon(Color(0xFFE49A72), Modifier.size(30.dp)) }) {
                        Access.select(Access.ROOT); onDismiss()
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text("Batal", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
        )
    }

    /** Warna overlay (bagian bawah tab Tampilan). */
    @Composable
    private fun ColorContent() {
        val ctx = LocalContext.current
        var accentDlg by remember { mutableStateOf(false) }
        if (accentDlg) AlertDialog(
            onDismissRequest = { accentDlg = false },
            containerColor = Color.Black,
            shape = RoundedCornerShape(28.dp),
            title = { Text("Warna aksen", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 22.sp) },
            text = { Swatches(AppSettings.ACCENTS, AppSettings.accent) { AppSettings.accent = it; AppSettings.save(ctx) } },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { accentDlg = false }) { Text("Selesai", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
        )
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Inner).clickable { accentDlg = true }.padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text("Warna aksen", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Box(Modifier.size(28.dp).background(Color(AppSettings.accent), CircleShape).border(1.dp, Color(0x33FFFFFF), CircleShape))
        }
        SettingCard("Warna teks overlay") {
            Swatches(AppSettings.TEXTS, AppSettings.overlayText) { AppSettings.overlayText = it; AppSettings.save(ctx) }
        }
        SettingCard("Latar overlay") {
            Swatches(AppSettings.BGS, AppSettings.overlayBg) { AppSettings.overlayBg = it; AppSettings.save(ctx) }
            SliderLabel("Transparan", "${AppSettings.alpha}%")
            AccSlider(AppSettings.alpha / 100f, 0.2f..1f, { AppSettings.alpha = (it * 100).toInt().coerceIn(20, 100) }) { AppSettings.save(ctx) }
        }
        SettingCard("Warna suhu") {
            Text("Berubah sesuai tingkat panas", color = Grey, fontSize = 12.sp)
            HeatLegend(30f, "Aman, di bawah 45°"); HeatLegend(50f, "Hangat, 45-54°")
            HeatLegend(60f, "Panas, 55-64°"); HeatLegend(70f, "Sangat panas, 65°+")
        }
        PillButton("Kembalikan warna awal", filled = false, modifier = Modifier.fillMaxWidth()) { AppSettings.reset(ctx) }
    }
}

@Composable
fun AccessOption(title: String, desc: String, accent: Color, bg: Color, selected: Boolean, icon: @Composable () -> Unit, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(bg)
        .border(if (selected) 2.dp else 1.dp, accent.copy(alpha = if (selected) 0.85f else 0.35f), RoundedCornerShape(20.dp))
        .clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        icon(); Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = accent, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Text(desc, color = Color(0xFFC4CACE), fontSize = 14.sp)
        }
    }
}

/** Ikon riwayat (daftar tiga baris dengan titik), digambar langsung. */
@Composable
fun HistoryIcon(c: Color, m: Modifier) = Canvas(m) {
    val w = size.width; val h = size.height; val sw = w * 0.1f
    listOf(0.22f, 0.5f, 0.78f).forEach { y ->
        drawCircle(c, sw * 0.8f, androidx.compose.ui.geometry.Offset(w * 0.1f, h * y))
        drawLine(c, androidx.compose.ui.geometry.Offset(w * 0.32f, h * y), androidx.compose.ui.geometry.Offset(w * 0.92f, h * y), sw, StrokeCap.Round)
    }
}

/** Ikon ponsel (Shizuku) dan perisai (Root), digambar langsung supaya tidak perlu pustaka ikon tambahan. */
/** Baris tautan: ikon, judul, keterangan di kanan, dan tanda buka-luar. */
@Composable
fun LinkRow(icon: @Composable () -> Unit, title: String, trailing: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { onClick() }.padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(34.dp), contentAlignment = Alignment.Center) { icon() }
        Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f).padding(start = 10.dp))
        if (trailing.isNotEmpty()) Text(trailing, color = Grey, fontSize = 14.sp, modifier = Modifier.padding(end = 8.dp))
        Text("↗", color = Grey, fontSize = 20.sp)
    }
}

/** Ikon gamepad (Discord) dan orang (pembuat), garis tipis digambar langsung. */
@Composable
fun GamepadIcon(c: Color, m: Modifier) = Canvas(m) {
    val w = size.width; val h = size.height; val st = Stroke(width = w * 0.09f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    drawRoundRect(c, androidx.compose.ui.geometry.Offset(w * 0.04f, h * 0.22f), androidx.compose.ui.geometry.Size(w * 0.92f, h * 0.56f),
        androidx.compose.ui.geometry.CornerRadius(w * 0.24f), style = st)
    drawLine(c, androidx.compose.ui.geometry.Offset(w * 0.28f, h * 0.4f), androidx.compose.ui.geometry.Offset(w * 0.28f, h * 0.6f), st.width, StrokeCap.Round)
    drawLine(c, androidx.compose.ui.geometry.Offset(w * 0.18f, h * 0.5f), androidx.compose.ui.geometry.Offset(w * 0.38f, h * 0.5f), st.width, StrokeCap.Round)
    drawCircle(c, w * 0.05f, androidx.compose.ui.geometry.Offset(w * 0.66f, h * 0.46f))
    drawCircle(c, w * 0.05f, androidx.compose.ui.geometry.Offset(w * 0.78f, h * 0.56f))
}

@Composable
fun PersonIcon(c: Color, m: Modifier) = Canvas(m) {
    val w = size.width; val h = size.height; val st = Stroke(width = w * 0.09f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    drawCircle(c, w * 0.2f, androidx.compose.ui.geometry.Offset(w * 0.5f, h * 0.3f), style = st)
    val p = Path().apply { moveTo(w * 0.14f, h * 0.9f); cubicTo(w * 0.14f, h * 0.55f, w * 0.86f, h * 0.55f, w * 0.86f, h * 0.9f); close() }
    drawPath(p, c, style = st)
}

@Composable
fun PhoneIcon(c: Color, m: Modifier) = Canvas(m) {
    val w = size.width * 0.55f; val h = size.height * 0.9f
    drawRoundRect(c, androidx.compose.ui.geometry.Offset((size.width - w) / 2, (size.height - h) / 2),
        androidx.compose.ui.geometry.Size(w, h), androidx.compose.ui.geometry.CornerRadius(size.width * 0.1f))
}

@Composable
fun ShieldIcon(c: Color, m: Modifier) = Canvas(m) {
    val w = size.width; val h = size.height
    val p = Path().apply {
        moveTo(w * 0.5f, h * 0.04f); lineTo(w * 0.92f, h * 0.2f); lineTo(w * 0.92f, h * 0.5f)
        cubicTo(w * 0.92f, h * 0.76f, w * 0.7f, h * 0.92f, w * 0.5f, h * 0.98f)
        cubicTo(w * 0.3f, h * 0.92f, w * 0.08f, h * 0.76f, w * 0.08f, h * 0.5f)
        lineTo(w * 0.08f, h * 0.2f); close()
    }
    drawPath(p, c)
}

@Composable
fun RowScope.NavItem(icon: String, label: String, selected: Boolean, color: Color, onClick: () -> Unit) {
    val col by animateColorAsState(if (selected) color else Grey, tween(220), label = "navCol")
    val sc by animateFloatAsState(if (selected) 1.15f else 1f, spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMedium), label = "navScale")
    Column(Modifier.weight(1f).clip(RoundedCornerShape(26.dp))
        .clickable { onClick() }.padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text(icon, color = col, fontSize = 22.sp, modifier = Modifier.graphicsLayer { scaleX = sc; scaleY = sc })
        Text(label, color = col, fontSize = 11.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

@Composable
fun BigCard(title: String, value: String, sub: String, selected: Boolean, m: Modifier) {
    val shape = RoundedCornerShape(24.dp)
    Column(m.background(Inner, shape)
        .then(if (selected) Modifier.border(1.5.dp, acc().copy(alpha = 0.85f), shape) else Modifier)
        .padding(horizontal = 16.dp, vertical = 10.dp)) {
        Text(title, color = Grey, fontSize = 13.sp)
        Text(value, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
        Text(sub, color = Grey, fontSize = 12.sp, maxLines = 1)
    }
}

/** Warna beban: hijau normal, kuning mulai berat, merah hampir penuh. */
fun loadColor(p: Int): Color = when {
    p < 0 -> Color.White
    p < 60 -> Color.White
    p < 85 -> Color(0xFFFFD866)
    else -> Color(0xFFFF6B6B)
}

@Composable
fun RowScope.MetricDivider() = Box(Modifier.width(1.dp).height(34.dp).background(Color(0x1FFFFFFF)))

@Composable
fun RowScope.Metric(label: String, main: String, sub: String, subTemp: Float, mainTemp: Float = -1f, mainColor: Color? = null) {
    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = Grey, fontSize = 12.sp)
        Text(main, color = mainColor ?: if (mainTemp >= 0) Color(heat(mainTemp)) else Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        if (sub.isNotEmpty()) Text(sub, color = if (subTemp >= 0) Color(heat(subTemp)) else Grey, fontSize = 13.sp, textAlign = TextAlign.Center)
    }
}

@Composable
fun InfoRow(label: String, value: String, t: Float? = null) {
    Row(Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(20.dp)).padding(horizontal = 18.dp, vertical = 14.dp)) {
        Text(label, color = Grey, modifier = Modifier.weight(1f))
        Text(value, color = if (t != null && t >= 0) Color(heat(t)) else Color.White, fontWeight = FontWeight.Bold)
    }
}

/** Baris saklar ringkas: judul + satu baris keterangan; ikon ⓘ membuka penjelasan lengkap di bawahnya. */
@Composable
fun ToggleRow(title: String, short: String, detail: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                Text(short, color = Grey, fontSize = 12.sp)
            }
            Box(Modifier.size(32.dp).clip(CircleShape).clickable { open = !open }, contentAlignment = Alignment.Center) {
                Text(if (open) "▴" else "ⓘ", color = Grey, fontSize = 16.sp)
            }
            Spacer(Modifier.width(4.dp))
            Switch(checked = checked, onCheckedChange = onChange)
        }
        if (open) Text(detail, color = Grey, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp, end = 8.dp))
    }
}

@Composable
fun SettingDivider() = Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x14FFFFFF)))

@Composable
fun SettingCard(title: String, content: @Composable ColumnScope.() -> Unit) = Column(
    Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(20.dp)).padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
) { Text(title, color = Color.White, fontWeight = FontWeight.Bold); content() }

@Composable
fun Swatches(colors: List<Int>, selected: Int, onPick: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        colors.forEach { c ->
            val on = c == selected
            Box(Modifier.size(38.dp).background(Color(c), CircleShape)
                .border(if (on) 2.5.dp else 1.dp, if (on) Color.White else Color(0x33FFFFFF), CircleShape)
                .clickable { onPick(c) }, contentAlignment = Alignment.Center) {
                if (on) Text("✓", color = if (Color(c).luminance() > 0.5f) Color(0xFF101014) else Color.White, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

@Composable
fun SectionTitle(t: String) = Text(t, color = Grey, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 6.dp, top = 4.dp))

@Composable
fun SliderLabel(label: String, value: String) = Row(Modifier.fillMaxWidth()) {
    Text(label, color = Grey, fontSize = 12.sp, modifier = Modifier.weight(1f))
    Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
}

@Composable
fun AccSlider(value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit, onDone: () -> Unit) {
    Slider(value = value, onValueChange = onChange, valueRange = range, onValueChangeFinished = onDone,
        colors = SliderDefaults.colors(thumbColor = acc(), activeTrackColor = acc(), inactiveTrackColor = Color(0x22FFFFFF)))
}

/** Tombol seragam: terisi (aksi utama) atau garis tepi (aksi sekunder). */
@Composable
fun PillButton(text: String, filled: Boolean = true, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(modifier.clip(shape)
        .then(if (filled) Modifier.background(Blue) else Modifier.border(1.dp, Color(0x33FFFFFF), shape))
        .clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 10.dp), contentAlignment = Alignment.Center) {
        Text(text, color = if (filled) Color(0xFF0C0C0E) else Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** Baris ukuran dengan batang: label + nilai di atas, batang tipis di bawah. */
@Composable
fun MeterRow(label: String, value: String, frac: Float, color: Color, valueColor: Color = Color.White) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Grey, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text(value, color = valueColor, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
        Box(Modifier.fillMaxWidth().height(5.dp).background(Color(0x1FFFFFFF), CircleShape)) {
            Box(Modifier.fillMaxWidth(frac.coerceIn(0f, 1f)).fillMaxHeight().background(color, CircleShape))
        }
    }
}

/** Blok memori: nama + total di atas, terpakai + bebas di tengah, batang di bawah. */
/** Garis pemisah tipis antar blok memori. */
@Composable
fun MemDivider() {
    Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF2A2C36)))
}

/** Blok memori minimalis: label + terpakai / total di atas, batang tipis, lalu persen terpakai dan sisa bebas. */
@Composable
fun MemBar(label: String, total: Float, used: Float, free: Float, color: Color) {
    val frac = if (total > 0f) (used / total).coerceIn(0f, 1f) else 0f
    Column(Modifier.padding(vertical = 14.dp)) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text(label, color = Color(0xFFC4C6CE), fontSize = 14.sp, modifier = Modifier.weight(1f))
            Text(buildAnnotatedString {
                withStyle(SpanStyle(color = Color.White, fontWeight = FontWeight.SemiBold)) { append("%.2f".format(used)) }
                append(" / %.2f GB".format(total))
            }, color = Grey, fontSize = 13.sp, maxLines = 1)
        }
        Box(Modifier.padding(top = 10.dp).fillMaxWidth().height(6.dp).clip(CircleShape).background(Color(0x1FFFFFFF))) {
            if (frac > 0f) Box(Modifier.fillMaxWidth(frac).fillMaxHeight().clip(CircleShape).background(color))
        }
        Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("${Math.round(frac * 100)}% terpakai", color = color, fontSize = 12.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            Text("Bebas %.2f GB".format(free), color = Color(0xFFA3A6B2), fontSize = 12.sp)
        }
    }
}

@Composable
fun MemBlock(label: String, total: Float, used: Float, free: Float, color: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f))
            Text("%.2f GB total".format(total), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("%.2f GB digunakan".format(used), color = Grey, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text("%.2f GB Bebas".format(free), color = Grey, fontSize = 12.sp)
        }
        Spacer(Modifier.height(2.dp))
        Box(Modifier.fillMaxWidth().height(8.dp).background(Color(0x1FFFFFFF), CircleShape)) {
            Box(Modifier.fillMaxWidth(if (total > 0f) (used / total).coerceIn(0f, 1f) else 0f).fillMaxHeight().background(color, CircleShape))
        }
    }
}

@Composable
fun TempMeter(label: String, t: Float) {
    if (t < 0f) { MeterRow(label, "-", 0f, Grey); return }
    val word = when { t < 45f -> "Aman"; t < 55f -> "Hangat"; t < 65f -> "Panas"; else -> "Sangat panas" }
    MeterRow(label, "${deg(t)}  $word", (t - 20f) / 70f, Color(heat(t)), Color(heat(t)))
}

/** Warna batang beban: aksen saat normal, kuning mulai berat, merah hampir penuh. */
@Composable
fun barLoad(p: Int): Color = when { p < 60 -> acc(); p < 85 -> Color(0xFFFFD866); else -> Color(0xFFFF6B6B) }

private fun usedFrac(txt: String): Float {
    val n = Regex("[0-9]+[.,]?[0-9]*").findAll(txt).map { it.value.replace(',', '.').toFloatOrNull() ?: 0f }.toList()
    return if (n.size >= 2 && n[1] > 0f) n[0] / n[1] else 0f
}

@Composable
fun HeatLegend(t: Float, label: String) = Row(verticalAlignment = Alignment.CenterVertically) {
    Box(Modifier.size(12.dp).background(Color(heat(t)), CircleShape))
    Text(label, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(start = 10.dp))
}

/** Grafik FPS: garis halus + isi tipis, skala 0..maks (kelipatan 10, minimal 30), garis bantu tipis, titik di nilai terakhir. */
/** Grafik area beban CPU 0..100%, menempel di dasar kartu. */
@Composable
fun CpuGraph(h: List<Int>, col: Color, m: Modifier) {
    Canvas(m) {
        if (h.size < 2) return@Canvas
        val stepX = size.width / (h.size - 1)
        fun py(v: Int) = size.height * (1f - 0.12f - 0.78f * v.coerceIn(0, 100) / 100f)
        val fill = Path(); fill.moveTo(0f, size.height); fill.lineTo(0f, py(h[0]))
        for (i in 1 until h.size) {
            val x0 = (i - 1) * stepX; val y0 = py(h[i - 1]); val x1 = i * stepX; val y1 = py(h[i])
            fill.quadraticBezierTo(x0, y0, (x0 + x1) / 2f, (y0 + y1) / 2f)
            if (i == h.size - 1) fill.lineTo(x1, y1)
        }
        fill.lineTo(size.width, size.height); fill.close()
        drawPath(fill, col.copy(alpha = 0.35f))
    }
}

@Composable
fun FpsGraph(h: List<Int>, m: Modifier) {
    val col = acc()
    Canvas(m) {
        val guide = Color(0x1AFFFFFF)
        for (i in 0..2) { val y = size.height * i / 2f; drawLine(guide, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f) }
        if (h.size < 2) return@Canvas
        val pad = 4.dp.toPx()
        val mx = (kotlin.math.ceil(maxOf(h.maxOrNull() ?: 30, 30) / 10f) * 10f)
        val stepX = size.width / (h.size - 1)
        fun px(i: Int) = i * stepX
        fun py(v: Int) = pad + (size.height - 2 * pad) * (1f - v / mx)
        val line = Path(); val fill = Path()
        line.moveTo(px(0), py(h[0])); fill.moveTo(px(0), size.height); fill.lineTo(px(0), py(h[0]))
        for (i in 1 until h.size) {
            // kurva halus lewat titik tengah antar sampel
            val x0 = px(i - 1); val y0 = py(h[i - 1]); val x1 = px(i); val y1 = py(h[i])
            val mxp = (x0 + x1) / 2f; val myp = (y0 + y1) / 2f
            line.quadraticBezierTo(x0, y0, mxp, myp); fill.quadraticBezierTo(x0, y0, mxp, myp)
            if (i == h.size - 1) { line.lineTo(x1, y1); fill.lineTo(x1, y1) }
        }
        fill.lineTo(size.width, size.height); fill.close()
        drawPath(fill, col.copy(alpha = 0.14f))
        drawPath(line, col, style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawCircle(col, 4.dp.toPx(), Offset(px(h.size - 1), py(h.last())))
    }
}

@Composable
fun Stat(l: String, v: String) = Column { Text(l, color = Grey, fontSize = 11.sp); Text(v, color = Color.White, fontSize = 19.sp) }
