package com.pulsemonitor

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.SystemClock
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import rikka.shizuku.Shizuku

/** Rincian memori dalam GB untuk kartu Statistik; swapTotal = 0 bila HP tidak punya swap. */
data class MemInfo(
    val marketGb: Int = 0, val ramTotal: Float = 0f, val ramUsed: Float = 0f, val ramFree: Float = 0f,
    val swapTotal: Float = 0f, val swapUsed: Float = 0f, val swapFree: Float = 0f, val zram: Boolean = false,
    val extraTotal: Float = 0f, val extraUsed: Float = 0f   // swap non-zram (mis. berkas swap "RAM tambahan") bila zram juga ada
)

/** Hasil baca memori: rincian + teks ringkas untuk tampilan lama. */
class MemRead(val mem: MemInfo, val ramPct: Int, val ramText: String, val swapText: String)

data class Snap(
    val fps: Int = 0, val avg: Int = 0, val low: Int = 0, val ft: Float = 0f,
    val cpu: Int = -1, val gpu: Int = -1, val ramPct: Int = -1, val ramText: String = "-", val swapText: String = "",
    val mem: MemInfo? = null,
    val tCpu: Float = -1f, val tGpu: Float = -1f, val tBat: Float = -1f, val tSkin: Float = -1f,   // tSkin = suhu permukaan HP
    val access: String = "-", val dbg: String = "", val hist: List<Int> = emptyList(),
    val pkg: String = "", val watt: Float = -1f,
    val batPct: Int = -1, val cpuMhz: Int = -1, val gpuMhz: Int = -1,
    val fpsRaw: Int = 0,          // FPS terukur apa adanya (untuk rekaman); fps bisa berisi pengganti saat layar statis
    val fpsRawF: Float = 0f,      // fpsRaw dengan desimal (mis. 60,2) untuk rekaman; 0 bila tidak tersedia
    val idle: Boolean = false,    // true: layar statis, fps berisi refresh rate layar
    val coreMhz: List<Int> = emptyList(),   // frekuensi tiap inti CPU (MHz), -1 = offline / tidak terbaca
    val cpuHist: List<Int> = emptyList(),   // beban CPU 60 detik terakhir (persen)
    val touchHz: Int = -1,                  // touch rate (Hz): -1 = fitur mati, 0 = tidak sedang menyentuh
    val govs: List<Pair<Int, String>> = emptyList(),   // governor CPU per cluster: (inti pertama cluster, nama governor), mis. 0 to "sugov_ext"
    val clusterCpu: List<Pair<Int, Int>> = emptyList(),  // beban CPU per cluster (%): (inti pertama cluster, persen), mis. 0 to 41
    val clMaxMhz: List<Pair<Int, Int>> = emptyList(),    // frekuensi maksimum per cluster (MHz): (inti pertama cluster, MHz), urut dari cluster terkecil
    val appMb: Float = -1f,                 // memori proses game (MB, PSS bila terbaca, kalau tidak RSS); -1 = tidak terbaca
    // Frametime asli dari timestamp frame (--latency), hanya terisi saat merekam. ftN = jumlah frame di sampel ini.
    val ftN: Int = 0, val ftMaxMs: Float = 0f, val jank: Int = 0, val bigJank: Int = 0, val ftTop: List<Float> = emptyList()
)

object Shell {
    // Hanya dipakai saat pengguna belum memilih metode (Access.AUTO)
    private val rootOk: Boolean by lazy {
        runCatching { ProcessBuilder("su", "-c", "id").start().inputStream.bufferedReader().readText().contains("uid=0") }
            .getOrDefault(false)
    }
    fun shizukuReady() = runCatching { Shizuku.pingBinder() && Shizuku.checkSelfPermission() == 0 }.getOrDefault(false)
    /** Mengikuti pilihan di Settings. Belum memilih: Shizuku kalau siap, kalau tidak root. */
    fun mode(): String = when (Access.choice) {
        Access.ROOT -> if (Access.rootState == 2) "Root" else "-"
        Access.SHIZUKU -> if (shizukuReady()) "Shizuku" else "-"
        else -> if (shizukuReady()) "Shizuku" else if (rootOk) "Root" else "-"
    }

    /** Proses shell yang terus berjalan (dibaca baris demi baris oleh pemanggil). Null bila tidak ada akses. */
    fun spawn(cmd: String): Process? = when (mode()) {
        "Shizuku" -> Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        ).apply { isAccessible = true }.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        "Root" -> ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        else -> null
    }

    fun exec(cmd: String): String {
        val p: Process = when (mode()) {
            // newProcess bersifat private di Shizuku 13.x, dipanggil via refleksi
            "Shizuku" -> Shizuku::class.java.getDeclaredMethod(
                "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
            ).apply { isAccessible = true }.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            "Root" -> ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
            else -> return ""
        }
        return runCatching { p.inputStream.bufferedReader().readText() }.getOrDefault("").also { p.destroy() }
    }

    private val inFlight = java.util.concurrent.atomic.AtomicInteger(0)
    /**
     * exec() dengan batas waktu. exec() biasa menunggu tanpa batas; bila dumpsys/Shizuku macet, pemanggil ikut macet selamanya
     * (pemantau aplikasi di depan berhenti diam-diam). Di sini perintah jalan di thread sendiri; lewat batas -> kembalikan "" dan lanjut.
     * Thread yang macet dibiarkan selesai sendiri; bila sudah 4 yang menggantung, perintah baru dilewati supaya tidak menumpuk.
     */
    fun execLimited(cmd: String, ms: Long): String {
        if (inFlight.get() >= 4) { AppLog.w("Shell", "dilewati: sudah 4 perintah menggantung"); return "" }
        inFlight.incrementAndGet()
        var out = ""
        val t = Thread { try { out = exec(cmd) } finally { inFlight.decrementAndGet() } }.apply { isDaemon = true; name = "shell-limited"; start() }
        t.join(ms)
        if (t.isAlive) { AppLog.w("Shell", "melebihi $ms ms, dilewati: ${cmd.take(60)}"); return "" }
        return out
    }
}

object Sampler {
    // Urutan prioritas jalur beban GPU. Tambahkan jalur baru di sini bila ada chipset lain.
    private const val GPU_PATHS = "/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage " +   // Adreno (Qualcomm)
        "/sys/class/kgsl/kgsl-3d0/gpubusy " +                // Adreno cadangan: "busy total" -> persen
        "/sys/kernel/ged/hal/gpu_utilization " +                                       // MediaTek (GED)
        "/sys/module/ged/parameters/gpu_loading " +                                    // MediaTek (GED, varian lain)
        "/proc/mali/utilization " +                                                    // Mali lama
        // Cadangan berprioritas paling rendah; hanya terpakai bila semua jalur di atas tidak terbaca
        "/sys/class/kgsl/kgsl-3d0/devfreq/gpu_load " +                                 // Adreno varian lain
        "/sys/kernel/debug/ged/hal/gpu_utilization " +                                 // MediaTek GED via debugfs
        "/sys/kernel/gpu/gpu_busy"                                                     // varian generik

    // Jalur arus / tegangan baterai (sysfs, satuan standar kernel: arus µA, tegangan µV). battery dulu, lalu bms.
    private const val PWR_PATHS = "/sys/class/power_supply/battery/current_now /sys/class/power_supply/battery/voltage_now " +
        "/sys/class/power_supply/bms/current_now /sys/class/power_supply/bms/voltage_now"

    val state = MutableStateFlow(Snap())
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var job: Job? = null
    private var fastJob: Job? = null
    private var prevTotal = 0L; private var prevIdle = 0L; private var lastCpu = -1
    private val prevCore = HashMap<Int, LongArray>()   // nomor inti -> [total, idle] dari pembacaan /proc/stat sebelumnya
    private val hist = ArrayDeque<Int>()      // FPS terukur (untuk avg / low)
    private val cH = ArrayDeque<Int>()        // beban CPU (untuk grafik Status CPU di tab Statistik)
    private val gHist = ArrayDeque<Int>()     // FPS yang ditampilkan (untuk grafik): sama dengan angka FPS di layar

    /** true selama layar utama aplikasi terlihat; layanan latar belakang tidak boleh mematikan Sampler saat itu. */
    @Volatile var uiVisible = false

    /** Hentikan pembacaan (proses shell tiap detik). Dipanggil saat tidak ada overlay, rekaman, maupun layar utama. */
    fun stop() {
        job?.cancel(); job = null
        fastJob?.cancel(); fastJob = null; fast = null
        fPrevTotal = 0L; fPrevIdle = 0L; fGpuWin.clear(); fLayer = ""; fLayerPkg = ""
        TaskFps.stop()
        prevTotal = 0L; prevIdle = 0L; lastCpu = -1; prevTrans = null; prevCore.clear()
        hist.clear(); gHist.clear(); cH.clear()
    }

    fun start() {
        if (job?.isActive == true) return
        appCtx?.let { TaskFps.start(it) }
        job = scope.launch {
            while (isActive) {
                // Jadwal tetap ~1 detik: lama tick (beberapa proses shell) dikurangkan dari jeda,
                // supaya sampel tidak melambat jadi 2-3 detik dan angka tidak meloncat-loncat.
                val t0 = SystemClock.elapsedRealtime()
                runCatching { tick() }
                delay((1000L - (SystemClock.elapsedRealtime() - t0)).coerceAtLeast(200L))
            }
        }
        // Jalur cepat FPS / CPU / GPU, terpisah dari tick berat di atas
        fastJob = scope.launch {
            while (isActive) {
                val t0 = SystemClock.elapsedRealtime()
                runCatching { fastTick() }
                delay((FAST_MS - (SystemClock.elapsedRealtime() - t0)).coerceAtLeast(80L))
            }
        }
    }

    private fun tick() {
        val mode = Shell.mode()
        if (mode == "-") {
            val mr = runCatching {
                readMem(java.io.File("/proc/meminfo").readText(), runCatching { java.io.File("/proc/swaps").readText() }.getOrDefault(""))
            }.getOrNull()
            state.value = Snap(tBat = batteryTemp(), batPct = batteryPct(), access = "-", dbg = "Suhu baterai: Intent (CPU/GPU butuh Shizuku/root)",
                mem = mr?.mem, ramPct = mr?.ramPct ?: -1, ramText = mr?.ramText ?: "-", swapText = mr?.swapText ?: "")
            return
        }
        // Setelah Sampler.stop() (aplikasi ditutup) pembanding CPU di-reset, jadi tick pertama tidak punya selisih dan beban CPU "-1".
        // Ambil pembanding dulu dan beri jeda singkat supaya selisih pertama sudah bermakna.
        if (prevTotal == 0L) runCatching {
            val blk = Shell.exec("grep '^cpu' /proc/stat")
            val b = blk.trim().lines().firstOrNull().orEmpty().trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
            if (b.size >= 5) {
                prevTotal = b.take(8).sum(); prevIdle = b[3] + b[4]
                prevCore.clear(); prevCore.putAll(coreTimes(blk))
                Thread.sleep(300)
            }
        }
        val out = Shell.exec(
            "grep '^cpu' /proc/stat; echo ==; for n in 1 2 3 4 5 6; do for f in $GPU_PATHS; do [ -r \$f ] && echo \"\$f:\$(cat \$f 2>/dev/null)\"; done; [ \$n -lt 6 ] && sleep 0.07; done; echo ==; " +
            "grep -E '^(MemTotal|MemAvailable|SwapTotal|SwapFree):' /proc/meminfo; echo ==; grep -H . /sys/class/thermal/thermal_zone*/type /sys/class/thermal/thermal_zone*/temp 2>/dev/null; " +
            "echo ==; cat /sys/class/kgsl/kgsl-3d0/temp 2>/dev/null; " +
            "echo ==; for d in /sys/devices/system/cpu/cpu[0-9]*; do [ -r \$d/cpufreq/scaling_cur_freq ] && echo \"\${d##*/}:\$(cat \$d/cpufreq/scaling_cur_freq 2>/dev/null):\$(cat \$d/cpufreq/cpuinfo_cur_freq 2>/dev/null)\"; done; " +
            "echo ==; for n in 1 2 3 4; do for f in /sys/class/kgsl/kgsl-3d0/devfreq/cur_freq /sys/class/kgsl/kgsl-3d0/gpuclk " +
            "/sys/class/kgsl/kgsl-3d0/clock_mhz /sys/class/devfreq/*kgsl*/cur_freq " +
            "/sys/class/devfreq/*mali*/cur_freq /sys/class/devfreq/*.gpu/cur_freq /sys/devices/platform/*mali*/cur_freq " +
            "/sys/kernel/ged/hal/current_freqency /sys/kernel/gpu/gpu_clock; " +
            "do [ -r \$f ] && echo \"\$f:\$(cat \$f 2>/dev/null | tr '\\n' ' ')\"; done; [ \$n -lt 4 ] && sleep 0.05; done; " +
            "[ -r /proc/gpufreqv2/gpufreq_status ] && grep -i -E 'freq' /proc/gpufreqv2/gpufreq_status 2>/dev/null | head -12 | sed 's/^/GPUFREQV2:/'; " +
            "echo ==; for d in /sys/class/kgsl/kgsl-3d0/devfreq /sys/class/devfreq/*kgsl* /sys/class/devfreq/*mali* /sys/class/devfreq/*.gpu; do " +
            "[ -r \$d/trans_stat ] && { echo \"##\$d\"; cat \$d/trans_stat 2>/dev/null; }; done; " +
            "echo ==; for f in /sys/class/kgsl/kgsl-3d0/devfreq/max_freq /sys/class/kgsl/kgsl-3d0/devfreq/min_freq /sys/class/kgsl/kgsl-3d0/max_gpuclk " +
            "/sys/class/kgsl/kgsl-3d0/thermal_pwrlevel /sys/class/kgsl/kgsl-3d0/max_pwrlevel /sys/class/kgsl/kgsl-3d0/devfreq/available_frequencies " +
            "/sys/class/devfreq/*kgsl*/max_freq /sys/class/devfreq/*mali*/max_freq /sys/class/devfreq/*.gpu/max_freq; " +
            "do [ -r \$f ] && echo \"\$f:\$(cat \$f 2>/dev/null | tr '\\n' ' ')\"; done; echo ==; cat /proc/swaps 2>/dev/null; " +
            "echo ==; for p in /sys/devices/system/cpu/cpufreq/policy[0-9]*; do [ -r \$p/scaling_governor ] && echo \"\${p##*/}:\$(cat \$p/scaling_governor 2>/dev/null)\"; done; " +
            "echo ==; for p in /sys/devices/system/cpu/cpufreq/policy[0-9]*; do [ -d \$p ] && echo \"\${p##*/}:\$(cat \$p/cpuinfo_max_freq 2>/dev/null || cat \$p/scaling_max_freq 2>/dev/null)\"; done; " + appMemCmd(curPkg) +
            // Arus + tegangan baterai langsung dari sysfs, 3 pembacaan berjarak 80 ms lalu dirata-rata di powerSysfs()
            "; echo ==; for n in 1 2 3; do for f in $PWR_PATHS; do [ -r \$f ] && echo \"\$f:\$(cat \$f 2>/dev/null)\"; done; [ \$n -lt 3 ] && sleep 0.08; done"
        ).split("==")
        if (out.size < 4) return

        // CPU
        val c = out[0].trim().lines().firstOrNull().orEmpty().trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        var cpu = -1
        if (c.size >= 5) {
            val total = c.take(8).sum(); val idle = c[3] + c[4]
            if (prevTotal > 0 && total > prevTotal) cpu = (100 * ((total - prevTotal) - (idle - prevIdle)) / (total - prevTotal)).toInt()
            prevTotal = total; prevIdle = idle
        }
        if (cpu < 0) cpu = lastCpu else lastCpu = cpu
        fastFresh()?.cpu?.takeIf { it >= 0 }?.let { cpu = it; lastCpu = it }
        val clusterCpu = runCatching { clusterUsage(out[0], out.getOrNull(11) ?: "") }.getOrDefault(emptyList())
        // Beban GPU: Adreno (kgsl) dulu, lalu MediaTek (GED) / Mali. Tiap jalur dibaca 6x dalam ~0,4 detik lalu dirata-rata,
        // karena GED/kgsl melaporkan beban sesaat; satu pembacaan bisa kebetulan kena momen GPU nganggur (0%) walau FPS penuh.
        // Format tiap jalur berbeda (ada yang "45", ada yang "45 30 12"); jalur pertama (urutan prioritas) yang punya sampel dipakai.
        val loadBy = LinkedHashMap<String, MutableList<Int>>()
        for (line in out[1].lines()) {
            val path = line.substringBefore(':')
            val nums = Regex("\\d+").findAll(line.substringAfter(':', "")).mapNotNull { it.value.toLongOrNull() }.toList()
            val v: Int = when {
                nums.isEmpty() -> null
                // gpubusy berisi dua angka "busy total": persen = busy / total
                path.endsWith("gpubusy") -> nums.getOrNull(1)?.takeIf { it > 0 }?.let { (100 * nums[0] / it).toInt().coerceIn(0, 100) }
                else -> nums[0].toInt().takeIf { it in 0..100 }
            } ?: continue
            loadBy.getOrPut(path) { ArrayList() }.add(v)
        }
        val loadPick = loadBy.entries.firstOrNull { it.value.isNotEmpty() }
        val gpuSlow = loadPick?.let { Math.round(it.value.average()).toInt() } ?: -1
        gpuLoadPath = loadPick?.key
        val gpu = fastFresh()?.gpu?.takeIf { it >= 0 } ?: gpuSlow
        gpuLoadDbg = loadPick?.let { "${it.key.substringAfter("/sys/").take(40)}=${it.value.joinToString("/")} -> $gpuSlow%" } ?: "tidak ada jalur terbaca"
        // Frekuensi: CPU = tertinggi dari semua inti (kHz -> MHz); GPU dalam Hz atau kHz tergantung jalur
        val cpuMhzSlow = parseCpuFreq(out.getOrNull(5) ?: "")
        val cpuMhz = fastFresh()?.cpuMhz?.takeIf { it > 0 } ?: cpuMhzSlow
        val gpuInst = parseGpuFreq(out.getOrNull(6) ?: "")
        // Rata-rata berbobot waktu (trans_stat) lebih mewakili naik-turun frekuensi dalam 1 detik; cadangan: nilai sesaat
        // Dipakai frekuensi tertinggi yang benar-benar dipakai GPU (>=5% jendela) atau sampel sesaat tertinggi;
        // rata-rata berbobot membuat angka mentok di tengah dan tidak pernah menyentuh frekuensi puncak.
        gpuLimDbg = (out.getOrNull(8) ?: "").lines().map { it.trim() }.filter { it.isNotEmpty() }
            .joinToString("; ") { it.replace("/sys/class/", "").take(90) }.ifEmpty { "tidak terbaca" }
        val gpuTrans = transAvg(out.getOrNull(7) ?: "")
        // trans_stat (jika ada) = rata-rata berbobot waktu; kalau tidak, nilai sesaat dari sumber yang tidak macet
        // MediaTek: devfreq Mali (governor dummy) tidak diperbarui, trans_stat-nya bisa menempel di satu frekuensi;
        // GED current_freqency adalah sumber yang cocok dengan aplikasi lain, jadi dipakai langsung (tanpa trans_stat).
        val preferInst = gpuPickPath?.let { it.endsWith("current_freqency") || it == "gpufreqv2" } ?: false
        val gpuMhzSlow = (if (!preferInst && gpuTrans > 0) gpuTrans else gpuInst).takeIf { it > 0 } ?: -1
        val gpuMhz = fastFresh()?.gpuMhz?.takeIf { it > 0 } ?: gpuMhzSlow
        // RAM + swap/zram
        val mr = readMem(out[2], out.getOrNull(9) ?: "")
        val ramPct = mr.ramPct; val ramText = mr.ramText; val swapText = mr.swapText; val mem = mr.mem
        // Suhu: HAL thermal (utama) -> sysfs (cadangan); baterai dari Intent BATTERY_CHANGED
        // dumpsys thermalservice berat dan ikut membebani system_server; cukup tiap 3 detik
        val nowMs = SystemClock.elapsedRealtime()
        if (nowMs - halAt >= 3000L) {
            // Pembacaan HAL yang gagal sesaat (dumpsys lambat saat game berat) tidak boleh membuang data lama,
            // kalau tidak suhu pindah ke sysfs yang nilainya bisa beda dan memunculkan lonjakan palsu
            val h = runCatching { thermalHal() }.getOrNull()
            if (h != null) { halCache = h; halOkAt = nowMs } else if (nowMs - halOkAt > 30_000L) halCache = null
            halAt = nowMs
        }
        val hal = halCache
        val sys = parseZones(out[3])
        val kgsl = out.getOrNull(4)?.trim()?.toFloatOrNull()?.let { norm(it) }?.takeIf { it in 5f..120f } ?: -1f
        fun pick(vararg c: Pair<String, Float>): Pair<Float, String> =
            c.firstOrNull { it.second >= 0f }?.let { it.second to it.first } ?: (-1f to "-")
        val tc = pick("HAL" to (hal?.t?.cpu ?: -1f), "HAL-soc" to (hal?.t?.soc ?: -1f), "sysfs" to sys.cpu)
        val tg = pick("HAL" to (hal?.t?.gpu ?: -1f), "sysfs" to sys.gpu, "kgsl" to kgsl)
        val tb = pick("Intent" to batteryTemp(), "HAL" to (hal?.t?.bat ?: -1f), "sysfs" to sys.bat)
        val tsk = pick("HAL" to (hal?.t?.skin ?: -1f), "sysfs" to sys.skin)
        val tempDbg = "CPU ${tc.second}, GPU ${tg.second}, BAT ${tb.second}, skin %.0f° (%s) | HAL: %s".format(
            tsk.first, tsk.second, if (hal != null) "${hal.n} sensor" else "tidak siap/kosong")

        // Saat merekam, kunci paket game supaya fokus yang pindah sebentar (tarik notifikasi,
        // keyboard, toast, overlay) tidak mengalihkan pengukuran ke aplikasi lain.
        if (!Recorder.active.value) pinPkg = null
        else if (pinPkg == null) pinPkg = targetPkg()?.takeIf { !isIgnoredPkg(it, appCtx?.packageName ?: "") }
        if (!Recorder.active.value) { resTick = 0; idleResRead() } else sampleGameRes()

        // f.first < 0 = pengukuran GAGAL sesaat (statistik SurfaceFlinger ter-reset, layer baru, dumpsys lambat, fokus berpindah),
        // bukan 0 FPS sungguhan. Itu yang membuat angka loncat 0 / 60 / 0 saat overlay dipakai.
        val own = appCtx?.packageName ?: ""
        val fSlow = runCatching { fps() }.getOrDefault(-1 to 0)
        // Jalur cepat: FPS dari timestamp frame 1 dtk terakhir, dibaca tiap ~1 dtk. Bila segar dan untuk paket yang sama,
        // dipakai menggantikan hasil jalur lama (timestats jendela 2,5 dtk / TaskFps) yang telat; jalur lama tetap penentu paket & cadangan.
        val fz = fastFresh()?.takeIf { it.fpsRaw >= 0 && it.pkg == curPkg && curPkg.isNotEmpty() }
        val f = if (fz != null) fz.fpsRaw to fSlow.second else fSlow
        val unknown = f.first < 0
        if (f.first > 0) { hist.addLast(f.first); if (hist.size > 30) hist.removeFirst() }
        // Layar diam / adegan statis: game tidak menyerahkan frame baru, jadi selisih frame = 0.
        // Tahan nilai terakhir beberapa detik supaya tidak langsung 0; 0 sungguhan tetap muncul.
        // Gagal ukur ditahan lebih lama (UNKNOWN_HOLD_TICKS), dan tetap ditahan walau paket fokus sesaat berpindah ke
        // SystemUI / PulseMonitor / kosong (jendela overlay atau panel yang disentuh).
        var shown = maxOf(f.first, 0)
        if (f.first > 0) { lastFps = f.first; lastFpsPkg = curPkg; zeroTicks = 0 }
        else {
            val samePkg = lastFpsPkg == curPkg || curPkg.isEmpty() || isIgnoredPkg(curPkg, own)
            val limit = if (unknown) UNKNOWN_HOLD_TICKS else HOLD_TICKS
            // Gagal ukur + paket fokus sempat berganti (game <-> layer lain): tetap tahan sebentar, jangan langsung 0
            val hold = samePkg || (unknown && zeroTicks < HOLD_TICKS)
            if (lastFps > 0 && hold && zeroTicks < limit) { zeroTicks++; shown = lastFps }
            else lastFps = 0
        }
        val rawOut = if (unknown) lastFps else f.first   // untuk rekaman: nilai yang ditahan, bukan angka negatif
        // Aplikasi biasa (tanpa SurfaceView) hanya menggambar saat ada perubahan, jadi layar diam = 0-5 FPS
        // dan itu normal, bukan lag. Tampilkan refresh rate layar (ditandai idle) alih-alih angka kecil itu.
        var idle = false
        if (shown < IDLE_FPS && !surfaceApp && curPkg.isNotEmpty()) {
            val hz = displayHz(); if (hz > 0) { shown = hz; idle = true }
        }
        // Grafik mengikuti angka yang tampil (termasuk tahan nilai terakhir dan refresh rate saat idle), bukan FPS mentah,
        // supaya garisnya tidak jatuh ke bawah saat angkanya tetap 60
        gHist.addLast(shown); if (gHist.size > 30) gHist.removeFirst()
        if (cpu >= 0) { cH.addLast(cpu); if (cH.size > 60) cH.removeFirst() }
        runCatching { fpsLog(f.first, shown) }
        // Daya: sysfs (arus x tegangan terbaru, dirata-rata) dulu; bila tidak terbaca, API BatteryManager (arus sesaat + tegangan broadcast)
        val pw = powerSysfs(out.getOrNull(13) ?: "") ?: batteryWatt().also { powerDbg = if (it >= 0f) "BatteryManager (sysfs tidak terbaca)" else "tidak terbaca" }
        // Frametime asli hanya dibaca saat merekam (satu dumpsys --latency tambahan per detik)
        val frm = if (Recorder.active.value && curPkg.isNotEmpty() && !isIgnoredPkg(curPkg, own)) runCatching { frameStats(curPkg) }.getOrNull()
                  else { ftReset(); null }
        runCatching {
            sensorLog("Beban CPU", cpu >= 0, "dari /proc/stat")
            sensorLog("Frekuensi CPU", cpuMhz > 0, cpuFreqDbg)
            sensorLog("Beban GPU", gpu >= 0, "$gpuLoadDbg | $transDbg")
            sensorLog("Frekuensi GPU", gpuMhz > 0, "$gpuFreqDbg | $gpuLimDbg")
        }
        state.value = Snap(
            fpsRaw = rawOut, idle = idle,
            fpsRawF = if (presentFps > 0f && Math.round(presentFps) == rawOut) presentFps else rawOut.toFloat(),
            fps = shown, avg = if (hist.isEmpty()) 0 else hist.average().toInt(),
            low = if (f.second > 0) f.second else (hist.minOrNull() ?: 0),
            ft = if (shown > 0) 1000f / shown else 0f, cpu = cpu, gpu = gpu,
            ramPct = ramPct, ramText = ramText, swapText = swapText, mem = mem, tCpu = tc.first, tGpu = tg.first, tBat = tb.first, tSkin = tsk.first, access = mode, hist = gHist.toList(),
            dbg = "FPS: $fpsDbg\nSuhu: $tempDbg\nCPU clk: $cpuFreqDbg\nGPU clk: $gpuFreqDbg\nGPU beban: $gpuLoadDbg\nGPU trans_stat: $transDbg\nGPU batas: $gpuLimDbg\nResolusi: $resDbg\nDaya: $powerDbg", pkg = curPkg, watt = pw,
            batPct = batteryPct(), cpuMhz = cpuMhz, gpuMhz = gpuMhz,
            coreMhz = parseCoreFreqs(out.getOrNull(5) ?: ""), cpuHist = cH.toList(),
            govs = parseGovs(out.getOrNull(10) ?: ""), clusterCpu = clusterCpu,
            clMaxMhz = parseClusterMax(out.getOrNull(11) ?: ""),
            appMb = Regex("(\\d+)\\s*kB").find(out.getOrNull(12) ?: "")?.groupValues?.get(1)?.toLongOrNull()?.let { it / 1024f } ?: -1f,
            ftN = frm?.n ?: 0, ftMaxMs = frm?.maxMs ?: 0f, jank = frm?.jank ?: 0, bigJank = frm?.bigJank ?: 0, ftTop = frm?.top ?: emptyList()
        )
        Recorder.onSample(state.value)
    }

    /**
     * Baca RAM dan swap. Satuan GB desimal (1 GB = 10^9 byte, seperti DevCheck); /proc/meminfo dalam kB (1024 byte).
     * RAM terpakai = MemTotal - MemAvailable. ZRAM dihitung dari /proc/swaps (hanya perangkat zram) supaya swap lain
     * (berkas swap "RAM tambahan") tidak ikut tercampur ke angka ZRAM; bila /proc/swaps tak terbaca, pakai SwapTotal/SwapFree.
     */
    private fun readMem(meminfo: String, swaps: String): MemRead {
        val gb = 1024f / 1_000_000_000f
        fun kb(n: String) = Regex("(?m)^$n:\\s+(\\d+)").find(meminfo)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
        val tot = kb("MemTotal"); val av = kb("MemAvailable")
        val ramPct = if (tot > 0) (100 * (tot - av).coerceIn(0L, tot) / tot).toInt() else -1
        var zT = 0L; var zU = 0L; var oT = 0L; var oU = 0L; var any = false
        for (l in swaps.lineSequence()) {
            val f = l.trim().split(Regex("\\s+"))
            if (f.size < 4 || f[0] == "Filename") continue
            val size = f[2].toLongOrNull() ?: continue; val used = f[3].toLongOrNull() ?: continue
            any = true
            if (f[0].contains("zram", ignoreCase = true)) { zT += size; zU += used } else { oT += size; oU += used }
        }
        val zram = zT > 0
        val swT: Long; val swU: Long; val exT: Long; val exU: Long
        if (any) { if (zram) { swT = zT; swU = zU; exT = oT; exU = oU } else { swT = oT; swU = oU; exT = 0; exU = 0 } }
        else { swT = kb("SwapTotal"); swU = (swT - kb("SwapFree")).coerceAtLeast(0L); exT = 0; exU = 0 }
        val ramText = "%.1f / %.0f GB".format((tot - av) * gb, tot * gb)
        val swapText = if (swT > 0) "%.1f / %.1f GB".format(swU * gb, swT * gb) else ""
        // Ukuran RAM "di kotak" = ukuran umum terdekat di atas MemTotal (kernel menyisihkan sebagian)
        val totGb = tot / 1048576f
        val market = listOf(2, 3, 4, 6, 8, 10, 12, 16, 18, 20, 24, 32).firstOrNull { it >= totGb - 0.01f } ?: Math.ceil(totGb.toDouble()).toInt()
        val mem = MemInfo(market, tot * gb, (tot - av).coerceAtLeast(0L) * gb, av * gb, swT * gb, swU * gb, (swT - swU).coerceAtLeast(0L) * gb, zram, exT * gb, exU * gb)
        return MemRead(mem, ramPct, ramText, swapText)
    }

    // ---- Resolusi render game (ukuran buffer layer game di SurfaceFlinger), bukan resolusi layar ----
    @Volatile private var resBusy = false
    private var resTick = 0
    /** Layer milik paket game yang BUKAN layar render game: latar, splash, letterbox, dim. Ukurannya memenuhi layar HP. */
    private val SKIP_LAYER = Regex("""Background for|Splash Screen|Letterbox|Dim Layer|Starting """)
    /** Header layer format Android 14+/16: "Layer [id] nama", boleh berindentasi / diawali "+ " atau "* ". */
    private val LAYER_HDR = Regex("""^\s*(?:[+*]\s+)?Layer \[\d+]""")
    private val SRC_CROP_RE = Regex("""sourceCrop=\[\s*(-?[\d.]+)\s+(-?[\d.]+)\s+(-?[\d.]+)\s+(-?[\d.]+)\s*]""")
    private val BUF_RE = Regex("""activeBuffer=\[\s*(\d+)\s*x\s*(\d+)""")
    private val BUF_RE2 = Regex("""(?i)buffer\w*[ =:\[(]+\s*(\d{3,5})\s*[x\u00d7]\s*(\d{3,5})""")

    /** Resolusi render terakhir yang berhasil dibaca per paket. Dipakai saat rekaman dimulai / berhenti, supaya tidak perlu menunggu. */
    private val resCache = java.util.concurrent.ConcurrentHashMap<String, Pair<Int, Int>>()
    fun cachedRes(pkg: String): Pair<Int, Int>? = resCache[pkg]
    private var resIdleTick = 0

    /** Baca resolusi layer paket ini di thread terpisah (supaya tick tidak melambat); simpan ke cache dan ke rekaman yang sedang jalan. */
    private fun readResAsync(pkg: String) {
        if (pkg.isEmpty() || resBusy) return
        resBusy = true
        scope.launch {
            try {
                val r = parseGameRes(Shell.exec("dumpsys SurfaceFlinger"), pkg)
                if (r != null) { resCache[pkg] = r; Recorder.onRes(r.first, r.second) }
            } catch (_: Throwable) {
            } finally { resBusy = false }
        }
    }

    /** Saat merekam: tiap ~8 detik baca ukuran buffer layer game (2 detik selama belum ada hasil). */
    private fun sampleGameRes() {
        val pkg = pinPkg ?: return
        if (resTick++ % (if (Recorder.hasRes()) 8 else 2) != 0) return
        readResAsync(pkg)
    }

    /**
     * Di luar rekaman: selagi game (layer SurfaceView) ada di depan, baca resolusinya sekali (lalu segarkan tiap ~1 menit),
     * jadi saat tombol rekam ditekan di dalam game, resolusi game sudah diketahui.
     */
    private fun idleResRead() {
        val p = curPkg
        if (p.isEmpty() || !surfaceApp || isIgnoredPkg(p, appCtx?.packageName ?: "")) return
        val every = if (resCache.containsKey(p)) 60 else 10
        if (resIdleTick++ % every == 0) readResAsync(p)
    }

    /** Dipanggil tepat sebelum Recorder.start(): baca ulang fokus dan resolusi game yang sedang di depan, sekarang juga. */
    fun onRecordStartRes() {
        resTick = 0
        val p = lastGame.ifEmpty { curPkg }
        if (p.isNotEmpty() && !isIgnoredPkg(p, appCtx?.packageName ?: "")) readResAsync(p)
    }

    @Volatile private var resDbg = "-"

    /**
     * Diagnostik resolusi: ambil cuplikan dump SurfaceFlinger di sekitar layer game (nama layer + beberapa baris sesudahnya)
     * supaya format dump di HP ini kelihatan dan pembacanya bisa disesuaikan. Panggil dari thread latar.
     */
    fun resProbe(): String {
        val pkg = pinPkg ?: lastGame.ifEmpty { curPkg }
        if (pkg.isEmpty() || isIgnoredPkg(pkg, appCtx?.packageName ?: "")) return "Game belum terdeteksi. Buka game dulu, nyalakan overlay, lalu coba lagi."
        val sb = StringBuilder("Paket: $pkg\nHasil pembacaan: $resDbg\n")
        sb.append("wm size: ").append(Shell.exec("wm size").trim().replace("\n", " | ")).append("\n")
        sb.append("Android: ").append(android.os.Build.VERSION.RELEASE).append(" (SDK ").append(android.os.Build.VERSION.SDK_INT).append(")\n\n")
        val txt = Shell.exec("dumpsys SurfaceFlinger")
        val lines = txt.lines()
        sb.append("Panjang dump: ${txt.length} karakter, ${lines.size} baris\n")
        val hits = lines.indices.filter { lines[it].contains(pkg) }
        sb.append("Baris yang menyebut paket: ${hits.size}\n\n")
        val shown = HashSet<Int>()
        var n = 0
        // SurfaceView lebih dulu, lalu sisanya
        for (i in hits.sortedByDescending { lines[it].contains("SurfaceView") }) {
            if (n >= 5 || sb.length > 9000) break
            if (i in shown) continue
            n++
            sb.append("--- baris $i ---\n")
            for (j in maxOf(0, i - 1)..minOf(i + 14, lines.lastIndex)) { shown.add(j); sb.append(lines[j].trim().take(170)).append('\n') }
            sb.append('\n')
        }
        // Baris yang memuat ukuran buffer di mana pun dalam dump (maks 12)
        val keys = Regex("(?i)activeBuffer|bufferSize|geomBuffer|Source Crop|crop=")
        val extra = lines.filter { keys.containsMatchIn(it) }.take(12)
        if (extra.isNotEmpty()) { sb.append("--- baris ukuran buffer (umum) ---\n"); extra.forEach { sb.append(it.trim().take(170)).append('\n') } }
        return sb.toString()
    }

    /** Cadangan ketiga (format dump baru): geomBufferSize / bufferSize di beberapa baris sesudah nama layer game. */
    private fun snapshotBufferSize(txt: String, pkg: String): Pair<Int, Int>? {
        val rx = Regex("""(?i)(?:geomBufferSize|bufferSize)\D{1,8}(-?\d+)\D+(-?\d+)(?:\D+(-?\d+)\D+(-?\d+))?""")
        val lines = txt.lines()
        var best: Pair<Int, Int>? = null; var bestScore = -1L
        for (i in lines.indices) {
            val l = lines[i]
            if (!l.contains(pkg) || SKIP_LAYER.containsMatchIn(l)) continue
            for (j in i..minOf(i + 15, lines.lastIndex)) {
                val m = rx.find(lines[j]) ?: continue
                val g = m.groupValues
                val w: Int; val h: Int
                if (g[3].isNotEmpty() && g[4].isNotEmpty()) { w = g[3].toInt() - g[1].toInt(); h = g[4].toInt() - g[2].toInt() }
                else { w = g[1].toInt(); h = g[2].toInt() }
                if (w < 100 || h < 100) continue
                val score = (if (l.contains("SurfaceView")) 1L shl 40 else 0L) + w.toLong() * h
                if (score > bestScore) { bestScore = score; best = w to h }
                break
            }
        }
        return best
    }

    /**
     * Cadangan: "sourceCrop=[L T R B]" di blok "Output Layer" (baris nama layer game, angkanya beberapa baris sesudahnya).
     * Ini ukuran buffer yang dirender game (mis. 2336x1080), BUKAN displayFrame (ukuran layar, mis. 1280x2772).
     * Hanya layer SurfaceView game yang dipakai supaya layer UI (VRI) seukuran layar tidak terambil.
     */
    private fun outputSourceCrop(txt: String, pkg: String): Pair<Int, Int>? {
        val lines = txt.lines()
        var best: Pair<Int, Int>? = null; var bestArea = -1L
        for (i in lines.indices) {
            val l = lines[i]
            if (!l.contains(pkg) || !l.contains("SurfaceView") || SKIP_LAYER.containsMatchIn(l)) continue
            for (j in i + 1..minOf(i + 40, lines.lastIndex)) {
                if (j > i + 1 && (LAYER_HDR.containsMatchIn(lines[j]) || lines[j].trimStart().startsWith("- Output Layer"))) break
                val m = SRC_CROP_RE.find(lines[j]) ?: continue
                val w = ((m.groupValues[3].toFloatOrNull() ?: continue) - (m.groupValues[1].toFloatOrNull() ?: continue)).toInt()
                val h = ((m.groupValues[4].toFloatOrNull() ?: continue) - (m.groupValues[2].toFloatOrNull() ?: continue)).toInt()
                if (w < 100 || h < 100) break
                if (w.toLong() * h > bestArea) { bestArea = w.toLong() * h; best = w to h }
                break
            }
        }
        return best
    }

    /**
     * Cadangan bila activeBuffer tidak ada di dump: tabel "HWC layers" memuat Source Crop (L T R B) tiap layer,
     * yaitu bagian buffer yang ditampilkan = ukuran render game. Nama layer di satu baris, angkanya di baris sesudahnya.
     */
    private fun hwcSourceCrop(txt: String, pkg: String): Pair<Int, Int>? {
        val num = Regex("""(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)""")
        val lines = txt.lines()
        var best: Pair<Int, Int>? = null; var bestScore = -1L
        for (i in lines.indices) {
            val l = lines[i]
            if (!l.contains(pkg) || SKIP_LAYER.containsMatchIn(l) || !l.contains("SurfaceView")) continue
            for (j in i..minOf(i + 2, lines.lastIndex)) {
                val m = num.find(lines[j]) ?: continue
                val w = (m.groupValues[3].toFloat() - m.groupValues[1].toFloat()).toInt()
                val h = (m.groupValues[4].toFloat() - m.groupValues[2].toFloat()).toInt()
                if (w < 100 || h < 100) break
                val score = (if (l.contains("SurfaceView")) 1L shl 40 else 0L) + w.toLong() * h
                if (score > bestScore) { bestScore = score; best = w to h }
                break
            }
        }
        return best
    }

    /** Baca resolusi render paket ini sekarang juga (blokir; panggil dari thread latar). Orientasi apa adanya dari buffer. */
    fun readResNow(pkg: String): Pair<Int, Int>? = runCatching {
        if (pkg.isEmpty()) null else parseGameRes(Shell.exec("dumpsys SurfaceFlinger"), pkg, normalize = false)
    }.getOrNull()

    /**
     * Resolusi yang diset game sendiri (game Unreal Engine: GameUserSettings.ini, ResolutionSizeX/Y).
     * Dipakai di laporan supaya yang tampil resolusi game, bukan ukuran layar HP. Butuh Shizuku/root; null bila file tak terbaca.
     */
    fun iniRes(pkg: String): Pair<Int, Int>? = runCatching {
        if (pkg.isEmpty()) return@runCatching null
        val txt = Shell.exec("cat /sdcard/Android/data/$pkg/files/UnrealEngine/Saved/Config/Android/GameUserSettings.ini")
        fun v(k: String) = Regex("(?m)^" + k + "=(\\d+)").find(txt)?.groupValues?.get(1)?.toIntOrNull()
        val w = v("ResolutionSizeX"); val h = v("ResolutionSizeY")
        if (w != null && h != null && w >= 100 && h >= 100) maxOf(w, h) to minOf(w, h) else null
    }.getOrNull()

    /** Ukuran layar asli (termasuk area status/navigasi), bukan displayMetrics yang tanpa bar sistem. */
    fun realScreenRes(): Pair<Int, Int>? = runCatching {
        val pt = android.graphics.Point()
        @Suppress("DEPRECATION")
        appCtx?.getSystemService(DisplayManager::class.java)?.getDisplay(0)?.getRealSize(pt)
        if (pt.x > 0 && pt.y > 0) pt.x to pt.y else null
    }.getOrNull()

    /**
     * Format dump Android 14+/16: tiap layer diawali "Layer [id] nama" dan ukuran buffer-nya ada di baris
     * "geomBufferSize=[L T R B]" sesudahnya (sebelum header Layer berikutnya). Layer SurfaceView game diutamakan.
     * Layer "Background for" (geomBufferSize -1) dan layer tanpa buffer dilewati.
     */
    private fun geomBufferRes(txt: String, pkg: String): Pair<Int, Int>? {
        val rx = Regex("""geomBufferSize=\[\s*(-?\d+)\s+(-?\d+)\s+(-?\d+)\s+(-?\d+)\s*]""")
        var best: Pair<Int, Int>? = null; var bestScore = -1L
        var header: String? = null; var found: Pair<Int, Int>? = null
        fun flush() {
            val h = header ?: return; val f = found ?: return
            if (!h.contains(pkg) || SKIP_LAYER.containsMatchIn(h)) return
            val score = (if (h.contains("SurfaceView")) 1L shl 40 else 0L) + f.first.toLong() * f.second
            if (score > bestScore) { bestScore = score; best = f }
        }
        for (l in txt.lineSequence()) {
            if (LAYER_HDR.containsMatchIn(l)) { flush(); header = l; found = null; continue }
            if (header == null || found != null) continue
            val m = rx.find(l) ?: continue
            val g = m.groupValues
            val w = g[3].toInt() - g[1].toInt(); val h2 = g[4].toInt() - g[2].toInt()
            if (w >= 100 && h2 >= 100) found = w to h2
        }
        flush()
        return best
    }

    /** Cari layer milik paket game (utamakan SurfaceView), ambil ukuran activeBuffer-nya. Null bila tidak terbaca. */
    private fun parseGameRes(txt: String, pkg: String, normalize: Boolean = true): Pair<Int, Int>? {
        if (txt.isEmpty()) return null
        var best: Pair<Int, Int>? = null; var bestScore = -1L
        var header: String? = null; var found: Pair<Int, Int>? = null
        fun flush() {
            val h = header ?: return; val f = found ?: return
            if (!h.contains(pkg) || SKIP_LAYER.containsMatchIn(h)) return
            val score = (if (h.contains("SurfaceView")) 1L shl 40 else 0L) + f.first.toLong() * f.second
            if (score > bestScore) { bestScore = score; best = f }
        }
        for (l in txt.lineSequence()) {
            if (l.startsWith("+ ") || l.startsWith("* ")) { flush(); header = l; found = null; continue }
            if (header == null || found != null) continue
            val m = BUF_RE.find(l) ?: BUF_RE2.find(l) ?: continue
            val w = m.groupValues[1].toIntOrNull() ?: continue; val h2 = m.groupValues[2].toIntOrNull() ?: continue
            if (w >= 100 && h2 >= 100) found = w to h2
        }
        flush()
        var r: Pair<Int, Int>? = best
        var src = "activeBuffer"
        if (r == null) { r = geomBufferRes(txt, pkg); src = "geomBufferSize" }
        if (r == null) { r = outputSourceCrop(txt, pkg); src = "sourceCrop" }
        if (r == null) { r = hwcSourceCrop(txt, pkg); src = "HWC crop" }
        if (r == null) { r = snapshotBufferSize(txt, pkg); src = "bufferSize" }
        if (r == null) {
            val hits = txt.lineSequence().filter { it.contains(pkg) }.toList()
            val sample = hits.take(2).joinToString(" | ") { it.trim().take(90) }
            resDbg = "tidak terbaca ($pkg, ${txt.length} karakter, ${hits.size} baris cocok) $sample"
            return null
        }
        resDbg = "$src ${r.first}x${r.second}"
        if (!normalize) return r
        // Samakan orientasi dengan layar saat ini (buffer kadang dilaporkan terputar)
        val pt = android.graphics.Point()
        @Suppress("DEPRECATION")
        appCtx?.getSystemService(DisplayManager::class.java)?.getDisplay(0)?.getRealSize(pt)
        val hi = maxOf(r.first, r.second); val lo = minOf(r.first, r.second)
        return if (pt.x == 0 && pt.y == 0) r else if (pt.x >= pt.y) hi to lo else lo to hi
    }

    @Volatile private var transDbg = "-"
    private var prevTrans: Map<Long, Long>? = null
    private var prevTransDir = ""

    /**
     * Frekuensi GPU rata-rata selama ~1 detik terakhir dari devfreq trans_stat (waktu tiap frekuensi, ms).
     * Hasil = jumlah(frekuensi x selisih waktu) / jumlah selisih waktu, jadi ikut naik-turun mengikuti beban,
     * tidak menempel di satu angka seperti pembacaan sesaat. -1 bila trans_stat tidak ada / belum ada selisih.
     */
    private fun transAvg(block: String): Int {
        var dir = ""; val cur = LinkedHashMap<Long, Long>()
        val row = Regex("^\\*?\\s*(\\d+):\\s*(.*)$")
        for (raw in block.lines()) {
            val l = raw.trim()
            if (l.startsWith("##")) { if (cur.isNotEmpty()) break; dir = l.drop(2); continue }
            val m = row.find(l) ?: continue
            val f = m.groupValues[1].toLongOrNull() ?: continue
            val t = m.groupValues[2].trim().split(Regex("\\s+")).mapNotNull { it.toLongOrNull() }.lastOrNull() ?: continue
            cur[f] = t
        }
        if (cur.isEmpty()) { transDbg = "tidak ada"; prevTrans = null; return -1 }
        val prev = prevTrans
        prevTrans = cur; val sameDir = prevTransDir == dir; prevTransDir = dir
        if (prev == null || !sameDir) { transDbg = "${dir.substringAfter("/sys/")}: mengukur..."; return -1 }
        var tot = 0L; var sum = 0.0
        val parts = ArrayList<String>()
        val used = ArrayList<Pair<Double, Long>>()
        for ((f, t) in cur) {
            val d = t - (prev[f] ?: t)
            if (d <= 0) continue
            val mhz = when { f >= 10_000_000L -> f / 1e6; f >= 10_000L -> f / 1e3; else -> f.toDouble() }
            tot += d; sum += mhz * d; parts.add("%.0f:%dms".format(mhz, d)); used.add(mhz to d)
        }
        if (tot < 300L) { transDbg = "${dir.substringAfter("/sys/")}: selisih waktu kecil ($tot ms)"; return -1 }
        val avg = Math.round(sum / tot).toInt()
        // Puncak = frekuensi tertinggi yang dipakai minimal 5% dari jendela (min 40 ms), supaya lonjakan sesaat tidak dihitung
        val peak = used.filter { it.second >= maxOf(40L, tot / 20) }.maxOfOrNull { it.first }?.let { Math.round(it).toInt() } ?: avg
        transDbg = "${dir.substringAfter("/sys/")}: ${parts.joinToString(" ")} -> rata2 $avg, puncak $peak MHz"
        return if (peak in 100..3500) peak else -1
    }

    /**
     * Dump semua node GPU yang mungkin ada (Adreno / Mali / MediaTek gpufreq + GED) beserta isinya, untuk mencari
     * node yang benar di HP tertentu. Dijalankan sekali saat tombol "Probe GPU" ditekan, bukan tiap detik.
     */
    fun gpuProbe(): String {
        if (Shell.mode() == "-") return ""
        val cmd = "for d in /proc/gpufreqv2 /proc/gpufreq /sys/kernel/ged/hal /sys/kernel/gpu /sys/class/devfreq /sys/class/kgsl/kgsl-3d0; do " +
            "echo \"## ls \$d\"; ls \$d 2>&1 | head -80; done; " +
            "for f in /proc/gpufreqv2/gpufreq_status /proc/gpufreqv2/gpu_working_opp_table /proc/gpufreq/gpufreq_var_dump " +
            "/sys/kernel/ged/hal/current_freqency /sys/kernel/ged/hal/gpu_utilization /sys/kernel/ged/hal/total_gpu_freq " +
            "/sys/kernel/gpu/gpu_clock /sys/kernel/gpu/gpu_busy /sys/class/devfreq/*/cur_freq /sys/class/devfreq/*/min_freq " +
            "/sys/class/devfreq/*/max_freq /sys/class/devfreq/*/governor /sys/class/kgsl/kgsl-3d0/gpuclk; do " +
            "[ -e \$f ] && { echo \"## \$f\"; cat \$f 2>&1 | head -c 1800; echo; }; done; " +
            "echo \"## getprop\"; getprop ro.board.platform; getprop ro.hardware; getprop ro.product.model"
        return Shell.exec(cmd).take(16000)
    }

    @Volatile private var gpuFreqDbg = "-"
    @Volatile private var gpuLimDbg = "-"
    @Volatile private var gpuLoadDbg = "-"

    /**
     * Baca frekuensi GPU dari beberapa jalur (urutan = prioritas). Tiap jalur dibaca 4x per tick (jarak 50 ms)
     * dan diambil nilai tertingginya, supaya lonjakan frekuensi dalam satu detik ikut terbaca dan angkanya
     * tidak terlihat macet. Satuan ditebak per jalur: Hz (>=10 juta), kHz (>=10 ribu), selain itu MHz.
     * Hanya nilai 100..3500 MHz yang diterima, supaya jalur bus/bandwidth tidak terbaca sebagai MHz.
     */
    private val gpuHist = HashMap<String, ArrayDeque<Int>>()
    @Volatile private var gpuPickPath: String? = null

    private fun parseGpuFreq(block: String): Int {
        val mhzBy = LinkedHashMap<String, MutableList<Int>>()
        val rawBy = LinkedHashMap<String, MutableList<String>>()
        for (l in block.lines()) {
            if (l.indexOf(':') <= 0) continue
            // GPUFREQV2:<baris asli> : ambil angka kHz pada baris yang menyebut cur/current/real freq
            if (l.startsWith("GPUFREQV2:")) {
                val body = l.substring(10)
                if (!Regex("(?i)(cur|real|now|actual)").containsMatchIn(body)) continue
                val kHz = Regex("\\d{5,8}").findAll(body).mapNotNull { it.value.toLongOrNull() }.firstOrNull() ?: continue
                val mhz = (if (kHz >= 10_000_000L) kHz / 1_000_000 else kHz / 1000).toInt()
                mhzBy.getOrPut("gpufreqv2") { ArrayList() }.add(mhz)
                rawBy.getOrPut("gpufreqv2") { ArrayList() }.add(body.trim().take(40))
                continue
            }
            val i = l.lastIndexOf(':')
            val path = l.substring(0, i); val raw = l.substring(i + 1).trim()
            val nums = Regex("\\d+").findAll(raw).mapNotNull { it.value.toLongOrNull() }.toList()
            if (nums.isEmpty()) continue
            // current_freqency (GED MediaTek) berformat "indeks kHz": ambil angka terbesar; lainnya angka pertama
            val v = if (path.endsWith("current_freqency")) nums.max() else nums[0]
            val mhz = when {
                path.endsWith("gpu_clock") || path.endsWith("clock_mhz") -> v
                v >= 10_000_000L -> v / 1_000_000
                v >= 10_000L -> v / 1000
                else -> v
            }.toInt()
            mhzBy.getOrPut(path) { ArrayList() }.add(mhz)
            rawBy.getOrPut(path) { ArrayList() }.add(raw)
        }
        // Nilai tiap sumber pada tick ini = sampel TERAKHIR yang valid (nilai paling baru, bukan puncak).
        val cur = LinkedHashMap<String, Int>()
        for ((path, list) in mhzBy) list.lastOrNull { it in 100..3500 }?.let { cur[path] = it }
        // Deteksi sumber macet: simpan 8 tick terakhir per sumber.
        for ((path, v) in cur) { val h = gpuHist.getOrPut(path) { ArrayDeque() }; h.addLast(v); while (h.size > 8) h.removeFirst() }
        fun stuck(path: String) = gpuHist[path]?.let { it.size >= 8 && it.distinct().size == 1 } ?: false
        fun moving(path: String) = gpuHist[path]?.let { it.size >= 8 && it.distinct().size > 1 } ?: false
        // Prioritas biasa; bila sumber teratas macet padahal ada sumber lain yang bergerak, pakai yang bergerak.
        // MediaTek: GED current_freqency didahulukan, lalu gpufreqv2 (di Dimensity bisa 26 MHz saat GPU tidur), baru sumber lain.
        val ordered = cur.keys.sortedBy { when { it.endsWith("current_freqency") -> 0; it == "gpufreqv2" -> 2; else -> 1 } }
        var pickPath = ordered.firstOrNull()
        if (pickPath != null && stuck(pickPath)) ordered.firstOrNull { moving(it) }?.let { pickPath = it }
        gpuPickPath = pickPath
        val pick = pickPath?.let { cur[it] } ?: -1
        val seen = mhzBy.keys.map { p ->
            val flag = if (stuck(p)) " [MACET]" else if (moving(p)) " [bergerak]" else ""
            "${p.substringAfter("/sys/").take(40)}=${rawBy[p]!!.distinct().joinToString("/")}$flag"
        }
        gpuFreqDbg = if (seen.isEmpty()) "tidak ada jalur terbaca" else seen.joinToString("; ") +
            " -> " + (if (pick >= 0) "$pick MHz (${pickPath!!.substringAfterLast('/')})" else "tidak valid")
        return pick
    }

    @Volatile private var cpuFreqDbg = "-"

    /**
     * Frekuensi CPU: scaling_cur_freq (sama dengan yang dibaca DevCheck dan kebanyakan aplikasi), tertinggi antar inti.
     * cpuinfo_cur_freq hanya dipakai bila scaling_cur_freq tidak terbaca; nilainya ikut ditampilkan di Diagnostik
     * sebagai "(i...)" bila berbeda, karena di MediaTek kedua node ini bisa jauh berbeda.
     */
    private fun parseCpuFreq(block: String): Int {
        var best = -1; val parts = ArrayList<String>()
        for (l in block.lines()) {
            val f = l.trim().split(':'); if (f.size < 2 || !f[0].startsWith("cpu")) continue
            val scaling = f[1].trim().toLongOrNull()?.takeIf { it > 0 }
            val info = f.getOrNull(2)?.trim()?.toLongOrNull()?.takeIf { it > 0 }
            val kHz = scaling ?: info ?: continue
            val mhz = (kHz / 1000).toInt()
            parts.add("${f[0].removePrefix("cpu")}=$mhz" + if (info != null && info != kHz) "(i${info / 1000})" else "")
            if (mhz in 100..5000 && mhz > best) best = mhz
        }
        cpuFreqDbg = if (parts.isEmpty()) "tidak terbaca" else parts.joinToString(" ") + " -> $best MHz"
        return best
    }

    /** Waktu CPU tiap inti dari baris "cpuN ..." di /proc/stat: nomor inti -> [total, idle]. Baris agregat "cpu " dilewati. */
    private fun coreTimes(block: String): Map<Int, LongArray> {
        val m = HashMap<Int, LongArray>()
        for (l in block.lines()) {
            val mt = Regex("^cpu(\\d+)\\s+(.+)$").find(l.trim()) ?: continue
            val idx = mt.groupValues[1].toIntOrNull() ?: continue
            val v = mt.groupValues[2].trim().split(Regex("\\s+")).mapNotNull { it.toLongOrNull() }
            if (v.size >= 5) m[idx] = longArrayOf(v.take(8).sum(), v[3] + v[4])
        }
        return m
    }

    /**
     * Beban CPU tiap cluster (%): selisih waktu sibuk / selisih total semua inti dalam cluster sejak pembacaan sebelumnya.
     * Cluster = policyN di cpufreq (N = inti pertama cluster); inti dimasukkan ke policy terbesar yang <= nomor intinya.
     * Inti yang mati (waktunya tidak bertambah) tidak ikut dihitung. Kosong bila daftar policy tidak terbaca.
     */
    private fun clusterUsage(statBlock: String, policyBlock: String): List<Pair<Int, Int>> {
        val cur = coreTimes(statBlock)
        val starts = Regex("policy(\\d+)").findAll(policyBlock).mapNotNull { it.groupValues[1].toIntOrNull() }.distinct().sorted().toList()
        val dTotal = HashMap<Int, Long>(); val dBusy = HashMap<Int, Long>()
        for ((i, now) in cur) {
            val p = prevCore[i]; prevCore[i] = now
            if (p == null || now[0] <= p[0] || starts.isEmpty()) continue
            val dt = now[0] - p[0]; val busy = dt - (now[1] - p[1])
            val cl = starts.lastOrNull { it <= i } ?: continue
            dTotal[cl] = (dTotal[cl] ?: 0L) + dt; dBusy[cl] = (dBusy[cl] ?: 0L) + busy.coerceIn(0L, dt)
        }
        return starts.mapNotNull { cl ->
            val t = dTotal[cl] ?: return@mapNotNull null
            cl to Math.round(100.0 * (dBusy[cl] ?: 0L) / t).toInt().coerceIn(0, 100)
        }
    }

    /** Governor tiap cluster dari cpufreq/policyN/scaling_governor. N = nomor inti pertama cluster (Cluster0, Cluster4, Cluster7, ...). */
    private fun parseGovs(block: String): List<Pair<Int, String>> =
        block.lines().mapNotNull { l ->
            val m = Regex("^policy(\\d+):(.+)$").find(l.trim()) ?: return@mapNotNull null
            val g = m.groupValues[2].trim().ifEmpty { return@mapNotNull null }
            (m.groupValues[1].toIntOrNull() ?: return@mapNotNull null) to g
        }.sortedBy { it.first }

    /** Frekuensi maksimum tiap cluster dari baris "policyN:kHz" (blok ke-12 keluaran tick). Cluster tanpa nilai terbaca dilewati. */
    private fun parseClusterMax(block: String): List<Pair<Int, Int>> =
        block.lines().mapNotNull { l ->
            val m = Regex("^policy(\\d+):(\\d+)$").find(l.trim()) ?: return@mapNotNull null
            val mhz = (m.groupValues[2].toLongOrNull() ?: return@mapNotNull null) / 1000
            if (mhz <= 0) return@mapNotNull null
            (m.groupValues[1].toIntOrNull() ?: return@mapNotNull null) to mhz.toInt()
        }.sortedBy { it.first }

    /** Perintah shell pembaca memori proses game (bagian ke-13 keluaran tick): PSS dari smaps_rollup, cadangan VmRSS. Nama paket divalidasi dulu. */
    private fun appMemCmd(pkg: String): String =
        if (!Regex("[A-Za-z0-9._]+").matches(pkg)) "echo =="
        else "echo ==; pid=\$(pidof $pkg 2>/dev/null | cut -d' ' -f1); [ -n \"\$pid\" ] && { grep -m1 '^Pss:' /proc/\$pid/smaps_rollup 2>/dev/null || grep -m1 '^VmRSS:' /proc/\$pid/status 2>/dev/null; }"

    /** Frekuensi tiap inti, urut nomor inti; inti yang mati / tidak terbaca = -1. */
    private fun parseCoreFreqs(block: String): List<Int> {
        val m = java.util.TreeMap<Int, Int>()
        for (l in block.lines()) {
            val f = l.trim().split(':'); if (f.size < 2 || !f[0].startsWith("cpu")) continue
            val idx = f[0].removePrefix("cpu").toIntOrNull() ?: continue
            val kHz = f[1].trim().toLongOrNull()?.takeIf { it > 0 } ?: f.getOrNull(2)?.trim()?.toLongOrNull()?.takeIf { it > 0 }
            m[idx] = if (kHz != null) (kHz / 1000).toInt() else -1
        }
        if (m.isEmpty()) return emptyList()
        return (0..m.lastKey()).map { m[it] ?: -1 }
    }

    private var fpsDbg = "-"
    @Volatile private var curPkg = ""
    @Volatile private var pinPkg: String? = null
    private var halCache: Hal? = null; private var halAt = -10_000L; private var halOkAt = -100_000L
    private var lastFps = 0; private var lastFpsPkg = ""; private var zeroTicks = 0
    private val HOLD_TICKS = 3
    private val UNKNOWN_HOLD_TICKS = 6   // gagal ukur: tahan nilai terakhir lebih lama sebelum jatuh ke 0
    private val IDLE_FPS = 15          // di bawah ini pada aplikasi non-game = layar statis, bukan "FPS rendah"
    @Volatile private var surfaceApp = false   // layer SurfaceView = game / video, menggambar terus-menerus

    private fun displayHz(): Int = runCatching {
        appCtx?.getSystemService(DisplayManager::class.java)?.getDisplay(0)?.refreshRate?.let { Math.round(it) }
    }.getOrNull() ?: -1
    // Paket yang bukan target pengukuran: shade notifikasi / SystemUI.
    private val TRANSIENT_PKGS = setOf("com.android.systemui", "android", "com.miui.screenrecorder", "com.miui.securitycenter", "com.miui.gamebooster")
    // Aplikasi live streaming: widget mengambangnya (jumlah penonton, komentar) bisa merebut fokus jendela dari game,
    // padahal yang mau diukur adalah game yang sedang disiarkan. Hanya berlaku untuk PENGUKURAN (FPS/rekam), BUKAN untuk nama di notifikasi.
    private val STREAM_PKGS = setOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.ss.android.ugc.aweme",
        "tv.twitch.android.app", "com.facebook.gamingvideo", "com.streamlabs.goliveandroid", "com.kick.mobile")
    private val SKIP_PKGS = TRANSIENT_PKGS + STREAM_PKGS
    /** Paket yang bukan target: SystemUI, keyboard, perekam layar, sidebar Game Turbo, dan PulseMonitor sendiri. */
    fun isIgnoredPkg(p: String, own: String) = p.isEmpty() || p == own || p in SKIP_PKGS ||
        p.contains("inputmethod") || p.contains("screenrecord") || p.contains("gamebooster") ||
        p.startsWith("com.ss.android.ugc.") || p.contains("tiktok", ignoreCase = true)
    /**
     * Khusus nama aplikasi di notifikasi: hanya jendela sementara (SystemUI, keyboard, perekam layar, Game Turbo) yang dilewati.
     * Aplikasi seperti TikTok/Twitch TETAP dianggap aplikasi di depan; sebelumnya ikut dibuang sehingga notifikasi tertinggal di "POCO Launcher".
     */
    fun isTransientPkg(p: String, own: String) = p.isEmpty() || p == own || p in TRANSIENT_PKGS ||
        p.contains("inputmethod") || p.contains("screenrecord") || p.contains("gamebooster")
    /** Aplikasi terakhir yang benar-benar di depan (bukan SystemUI/keyboard/perekam layar). */
    fun lastGamePkg(): String = lastGame

    private var focusCache = ""; private var focusAt = -10_000L
    /** Dipanggil tepat sebelum Recorder.start(): paksa baca ulang fokus supaya game langsung terkunci, tanpa menunggu cache 2 detik. */
    fun onRecordStart() { focusAt = -10_000L; pinPkg = null; onRecordStartRes() }
    private var lastGame = ""; private var lastGameAt = 0L

    /** Paket yang sedang di depan, untuk nama aplikasi di notifikasi baterai. Tidak menyentuh cache pengukuran FPS. Panggil dari thread latar (menjalankan dumpsys). */
    fun foregroundPkg(): String = focusPkg(forLabel = true).orEmpty()

    private val FOCUS_RX = Regex("u\\d+ ([\\w.]+)/")

    /** Semua paket dari baris keluaran dumpsys (urut kemunculan). Baris "=null" dan jendela tanpa "/" (mis. NotificationShade) dilewati. */
    private fun pkgsIn(out: String, only: String? = null): List<String> =
        out.lines().filter { !it.contains("=null") && (only == null || it.contains(only)) }
            .mapNotNull { FOCUS_RX.find(it)?.groupValues?.get(1) }

    /**
     * Paket di depan. Dulu yang dikembalikan baris PERTAMA yang cocok, walau itu jendela sementara (perekam layar, SystemUI, keyboard,
     * Game Turbo) atau sisa fokus launcher; akibatnya nama di notifikasi baru benar setelah shade ditarik (fokus jadi NotificationShade
     * tanpa "/", lalu baris mFocusedApp terbaca). Sekarang semua kandidat dikumpulkan dan yang pertama BUKAN jendela sementara dipakai.
     * forLabel: mFocusedApp (aplikasinya) didahulukan dari mCurrentFocus (jendelanya), karena jendela fokus bisa melayang/basi.
     * dumpsys activity (berat) hanya dijalankan bila dumpsys window tidak memberi kandidat yang layak.
     */
    /** Ringkasan pembacaan terakhir untuk nama di notifikasi (kandidat jendela/aktivitas dan yang dipilih); dipakai log dan pemeriksaan kesehatan. */
    @Volatile var focusDiag = ""

    private fun focusPkg(forLabel: Boolean = false): String? {
        val own = if (forLabel) "" else (appCtx?.packageName ?: "")
        val win = Shell.execLimited("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp' | head -8", 2500L)
        val cand = if (forLabel) pkgsIn(win, "mFocusedApp") + pkgsIn(win, "mCurrentFocus") else pkgsIn(win)
        val skip: (String) -> Boolean = if (forLabel) { p -> isTransientPkg(p, own) } else { p -> isIgnoredPkg(p, own) }
        cand.firstOrNull { !skip(it) }?.let { if (forLabel) focusDiag = "jendela [${cand.joinToString(",")}] -> $it"; return it }
        val act = pkgsIn(Shell.execLimited("dumpsys activity activities | grep -E 'topResumedActivity|ResumedActivity' | head -4", 2500L))
        act.firstOrNull { !skip(it) }?.let { if (forLabel) focusDiag = "jendela [${cand.joinToString(",")}] aktivitas [${act.joinToString(",")}] -> $it"; return it }
        val r = cand.firstOrNull() ?: act.firstOrNull()
        if (forLabel) focusDiag = "semua sementara/kosong: jendela [${cand.joinToString(",")}] aktivitas [${act.joinToString(",")}] -> ${r ?: "-"}"
        return r
    }

    /** Baris mentah dumpsys window untuk pemeriksaan kesehatan (dipanggil setelah foregroundPkg()). Thread latar. */
    fun fgDiag(): String = focusDiag + "\n" + Shell.execLimited("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp' | head -8", 2500L).trim()

    /**
     * Paket yang diukur. Fokus dibaca tiap 2 detik saja (dumpsys window menahan kunci sistem).
     * Fokus sementara ke SystemUI / keyboard / PulseMonitor sendiri diabaikan selama 20 detik
     * setelah game terakhir di depan; saat merekam, paket dikunci (pinPkg).
     */
    private fun targetPkg(): String? {
        pinPkg?.let { return it }
        val now = SystemClock.elapsedRealtime()
        if (now - focusAt >= 2000L) { focusCache = focusPkg() ?: ""; focusAt = now }
        val p = focusCache
        val transient = isIgnoredPkg(p, appCtx?.packageName ?: "")
        if (!transient) { lastGame = p; lastGameAt = now; return p }
        if (lastGame.isNotEmpty() && now - lastGameAt < 20_000L) return lastGame
        return p.ifEmpty { null }
    }

    private class Ts(val at: Long, val total: Map<String, Long>, val queued: Map<String, Long>)
    private val tsWin = ArrayDeque<Ts>()
    private var tsReady = false
    private var tsEmpty = 0
    @Volatile private var presentFps = 0f
    @Volatile private var queuedFps = 0f

    /**
     * SurfaceFlinger TimeStats per layer: totalFrames (frame yang benar-benar tampil di layar) dan
     * droppedFrames (frame yang diserahkan game tetapi dilewati karena layar sedang lebih lambat).
     * Waktu sampel = titik tengah eksekusi dumpsys, bukan sesudahnya, supaya jeda eksekusi
     * yang berubah-ubah tidak membuat selisih waktu (dan FPS) melenceng.
     */
    private fun timestats(): Ts {
        if (!tsReady) {
            Shell.exec("dumpsys SurfaceFlinger --timestats -clear -enable"); tsReady = true; tsWin.clear()
            tsClearAt = SystemClock.elapsedRealtime()
        }
        val t0 = SystemClock.elapsedRealtime()
        val txt = Shell.exec("dumpsys SurfaceFlinger --timestats -dump")
        val at = (t0 + SystemClock.elapsedRealtime()) / 2
        val total = HashMap<String, Long>(); val queued = HashMap<String, Long>()
        var name: String? = null
        var nLayers = 0
        for (l in txt.lines()) {
            val t = l.trim()
            val v = t.substringAfter('=', "").trim().toLongOrNull()
            when {
                t.startsWith("layerName") -> { name = t.substringAfter('=').trim(); nLayers++ }
                name != null && v != null && t.startsWith("totalFrames") -> { total[name!!] = v; queued[name!!] = (queued[name!!] ?: 0L) + v }
                name != null && v != null && t.startsWith("droppedFrames") -> queued[name!!] = (queued[name!!] ?: 0L) + v
            }
        }
        // Satu dump kosong (dumpsys lambat/timeout saat game berat) jangan langsung me-reset statistik: itu membuang jendela
        // pengukuran dan membuat FPS 0 di tick berikutnya. Aktifkan ulang hanya bila kosong 3 kali berturut-turut.
        if (total.isEmpty()) { if (++tsEmpty >= 3) { tsReady = false; tsEmpty = 0 } } else tsEmpty = 0
        // Tabel TimeStats SurfaceFlinger punya batas ~200 layer (tiap jendela / popup / surface baru menambah satu entri dan tidak
        // pernah dihapus sampai di-clear). Bila penuh, layer game yang dibuat ulang (kembali dari aplikasi lain, ganti scene) TIDAK
        // masuk tabel: layer lama yang tersisa diam, dan FPS terbaca 0 padahal game jalan. Reset sebelum penuh (jeda min. 20 detik).
        if (nLayers >= TS_SOFT_LIMIT && SystemClock.elapsedRealtime() - tsClearAt > 20_000L) {
            AppLog.i("FPS", "tabel timestats $nLayers layer (batas ~200), direset")
            tsReady = false
        }
        return Ts(at, total, queued)
    }

    private val TS_SOFT_LIMIT = 150
    private var tsClearAt = -100_000L

    /**
     * Layer SurfaceFlinger milik [pkg] yang masih hidup, dalam bentuk NAMA layer (dipakai --latency).
     * Android 15/16 mencetak `--list` sebagai "RequestedLayerState{nama#id parentId=... z=...}", bukan nama polos seperti
     * versi lama, sehingga memberi baris utuh ke `--latency` selalu menghasilkan data kosong. Di sini namanya diambil
     * (sampai "#id" terakhir sebelum atribut); format lama (nama polos) tetap didukung.
     */
    private val LAYER_LINE = Regex("^RequestedLayerState\\{(.*?#\\d+)(?=[ }]|$)")
    private fun liveLayers(pkg: String): List<String> =
        Shell.exec("dumpsys SurfaceFlinger --list").lines().mapNotNull { raw ->
            val l = raw.trim()
            if (!l.contains(pkg)) return@mapNotNull null
            val n: String? = if (l.startsWith("RequestedLayerState{")) LAYER_LINE.find(l)?.groupValues?.get(1) else l
            n?.takeIf { !it.startsWith("Background") && !it.startsWith("ActivityRecord{") && !it.startsWith("Task=") }
        }.distinct()

    /** Paket (bukan PulseMonitor/SystemUI/keyboard) dengan frame paling banyak diserahkan dalam jendela terakhir; null bila tidak ada yang aktif. */
    @Volatile private var busiestRate = 0f
    private fun busiestLayerPkg(cur: Ts, own: String, minRate: Float = 5f): String? {
        val base = tsWin.first()
        val dt = (cur.at - base.at) / 1000f
        if (dt < 0.3f) return null
        val rx = Regex("([A-Za-z][A-Za-z0-9_]*(?:\\.[A-Za-z0-9_]+)+)/")
        var best: String? = null; var bestRate = 0f
        for ((k, q1) in cur.queued) {
            val q0 = base.queued[k] ?: continue
            if (q1 < q0) continue
            val pk = rx.find(k)?.groupValues?.get(1) ?: continue
            if (isIgnoredPkg(pk, own)) continue
            var rate = (q1 - q0) / dt
            if (k.contains("SurfaceView[")) rate += 1f   // lapisan game (SurfaceView) menang bila seri dengan UI biasa
            if (rate > bestRate) { bestRate = rate; best = pk }
        }
        busiestRate = bestRate
        return best?.takeIf { bestRate >= minRate }
    }

    /**
     * FPS = frame yang benar-benar tampil di layar per detik (totalFrames) dari layer game, jendela ~2,5 detik.
     * droppedFrames (diserahkan game tapi dilewati layar) TIDAK dihitung, supaya angka sama dengan yang terasa di game.
     * Cadangan bila layer tidak ada: --latency.
     */
    private var pinZero = 0
    /** Info untuk diagnosis: paket yang sedang dikunci dan pesan pembacaan FPS terakhir. */
    fun fpsDiag(): String = "paket terkunci: ${pinPkg ?: "-"} | $fpsDbg | ${TaskFps.diag()}"

    /**
     * Pembungkus: saat merekam dan paket terkunci (pinPkg) terus 0 FPS ~8 detik (mis. terkunci ke paket salah di awal),
     * pindah ke layer non-sistem yang paling aktif supaya rekaman tidak kosong sepanjang sesi.
     */
    private fun fps(): Pair<Int, Int> {
        val r = fps0()
        if (r.first < 0) return r   // gagal ukur sesaat bukan 0 FPS, jangan dihitung untuk pindah paket
        if (!Recorder.active.value || pinPkg == null || r.first > 0) { pinZero = 0; return r }
        if (++pinZero >= 8) {
            pinZero = 0
            val alt = tsWin.lastOrNull()?.let { busiestLayerPkg(it, appCtx?.packageName ?: "") }
            if (alt != null && alt != pinPkg) { pinPkg = alt; resTick = 0 }
        }
        return r
    }

    // ---------- LOG SENSOR (CPU / GPU) ----------
    private val sensBadTicks = HashMap<String, Int>(); private val sensLogged = HashMap<String, Boolean>()

    /** Catat ke log saat sensor tidak terbaca 3 tick berturut-turut (beserta penyebab dari dbg) dan saat terbaca lagi. */
    private fun sensorLog(name: String, good: Boolean, dbg: String) {
        val n = if (good) 0 else (sensBadTicks[name] ?: 0) + 1
        sensBadTicks[name] = n
        val logged = sensLogged[name] == true
        if (n >= 3 && !logged) { sensLogged[name] = true; AppLog.w("Sensor", "$name tidak terbaca | $dbg") }
        else if (good && logged) { sensLogged[name] = false; AppLog.i("Sensor", "$name terbaca lagi") }
    }

    // ---------- AUDIT FPS: catat angka yang tidak masuk akal ----------
    private var auditPrev = -1; private val auditAt = HashMap<String, Long>()

    /**
     * Mencatat ke log (tag FPS-AUDIT) saat pembacaan FPS mencurigakan, beserta data mentahnya, supaya bisa dicocokkan
     * dengan rasa di game (mis. terasa 30 tapi terbaca 120). Dibatasi 1 baris per jenis per 5 detik, hanya saat merekam atau
     * FPS di atas batas layar, supaya log tidak penuh.
     *  - DI ATAS LAYAR  : FPS > refresh rate layar x 1,05 (mustahil tampil lebih dari itu; biasanya layer ganda / jendela pendek)
     *  - DISERAHKAN>>TAMPIL: game menyerahkan jauh lebih banyak frame daripada yang tampil (terasa patah walau angka tinggi)
     *  - JENDELA PENDEK : laju dihitung dari jendela < 1 detik (berisik)
     *  - LONCAT         : berubah > 2x dibanding pembacaan sebelumnya
     */
    /**
     * Frametime ASLI dari timestamp frame (--latency, kolom waktu tampil) 2 detik terakhir: selisih antar frame berurutan.
     * Beda dengan 1000/FPS yang hanya rata-rata: di sini terlihat frame yang tidak rata (mis. 16 / 50 / 16 / 50 ms = terasa 30 FPS
     * walau rata-rata terbaca 60+). Hasil: "rata X ms, p99 Y ms, maks Z ms, N frame" atau "tidak ada data".
     */
    private fun realFrametime(pkg: String): String {
        val live = liveLayers(pkg)
        val layer = live.sortedByDescending { (if (it.contains("SurfaceView")) 2 else 0) + (if (it.contains("BLAST")) 1 else 0) }.firstOrNull()
            ?: return "tidak ada layer"
        val rows = Shell.exec("dumpsys SurfaceFlinger --latency '$layer'").lines().drop(1).map { it.trim().split(Regex("\\s+")) }
        val now = System.nanoTime()
        val ts = rows.mapNotNull { it.getOrNull(1)?.toLongOrNull() }
            .filter { it in 1 until Long.MAX_VALUE / 2 && it <= now && it > now - 2_000_000_000L }.sorted()
        if (ts.size < 3) return "tidak ada data (${ts.size} frame)"
        val d = ts.zipWithNext { a, b -> (b - a) / 1_000_000f }.sorted()
        return "rata %.1f ms, p99 %.1f ms, maks %.1f ms, %d frame".format(d.average(), d[((d.size - 1) * 0.99f).toInt()], d.last(), ts.size)
    }

    private fun fpsAudit(fps: Int, p: Float, q: Float, minD: Float, lyr: List<Triple<String, Float, Float>>, pkg: String) {
        val hz = displayHz()
        val flags = ArrayList<String>()
        if (hz > 0 && fps > hz * 1.05f) flags.add("DI ATAS LAYAR ($fps > $hz Hz)")
        if (q >= 20f && q > p * 1.5f) flags.add("DISERAHKAN>>TAMPIL (%.0f vs %.0f)".format(q, p))
        if (minD < 1.0f) flags.add("JENDELA PENDEK (%.2f dtk)".format(minD))
        if (auditPrev > 0 && fps > 0 && (fps > auditPrev * 2 || fps * 2 < auditPrev)) flags.add("LONCAT ($auditPrev -> $fps)")
        // Frametime tidak masuk akal: lebih cepat dari 1 refresh layar, atau > 100 ms (< 10 FPS) saat game masih menyerahkan frame
        val ftNow = if (fps > 0) 1000f / fps else 0f
        if (hz > 0 && ftNow > 0f && ftNow < 1000f / hz * 0.95f) flags.add("FRAMETIME < 1 REFRESH (%.1f ms, layar %d Hz)".format(ftNow, hz))
        if (ftNow > 100f && q >= 5f) flags.add("FRAMETIME BESAR (%.0f ms padahal diserahkan %.0f/dtk)".format(ftNow, q))
        auditPrev = fps
        if (flags.isEmpty()) return
        if (!Recorder.active.value && flags.none { it.startsWith("DI ATAS") }) return
        val now = SystemClock.elapsedRealtime()
        val key = flags.first().substringBefore(' ')
        if (now - (auditAt[key] ?: -100_000L) < 5000L) return
        auditAt[key] = now
        val top = lyr.sortedByDescending { it.third }.take(3).joinToString("; ") { (k, a, b) ->
            "%s tampil %.0f / serah %.0f".format(k.substringAfter('/').take(40), a, b)
        }
        val ft = "%.1f".format(if (fps > 0) 1000f / fps else 0f)
        val real = runCatching { realFrametime(pkg) }.getOrDefault("gagal ukur")
        AppLog.w("FPS-AUDIT", "${flags.joinToString(", ")} | ft=${ft}ms | ft nyata: $real | $pkg | layer=${lyr.size} | $top | rekam=${Recorder.active.value}")
    }

    // ---------- LOG DIAGNOSIS FPS ----------
    private var badTicks = 0; private var prevBad = false
    private var lastBadLogAt = -100_000L; private var lastOkLogAt = -100_000L; private var lastDeepAt = -100_000L

    /** Catat ke log (dan berkas Download) kapan FPS jatuh ke 0 beserta penyebab yang terbaca, supaya bug-nya bisa ditelusuri dari log. */
    private fun fpsLog(raw: Int, shown: Int) {
        val now = SystemClock.elapsedRealtime()
        val bad = shown <= 0
        if (bad) badTicks++ else badTicks = 0
        val head = "hasil=$raw tampil=$shown paket=${curPkg.ifEmpty { "-" }} fokus=${focusCache.ifEmpty { "-" }} kunci=${pinPkg ?: "-"} rekam=${Recorder.active.value} | $fpsDbg"
        when {
            bad && !prevBad -> { AppLog.w("FPS", "mulai 0: $head"); lastBadLogAt = now }
            !bad && prevBad -> { AppLog.i("FPS", "pulih: $head"); lastOkLogAt = now }
            bad && now - lastBadLogAt >= 5000L -> { AppLog.w("FPS", "masih 0 (${badTicks}x): $head"); lastBadLogAt = now }
            !bad && now - lastOkLogAt >= 60_000L -> { AppLog.i("FPS", "ok: $head"); lastOkLogAt = now }
        }
        prevBad = bad
        if (bad && badTicks >= 5 && now - lastDeepAt >= 60_000L) { lastDeepAt = now; runCatching { fpsDeepDiag() } }
    }

    /** Dipanggil sekali per ~60 detik saat FPS 0 terus: rekam data mentah SurfaceFlinger dan fokus jendela. */
    private fun fpsDeepDiag() {
        val cur = tsWin.lastOrNull(); val base = tsWin.firstOrNull()
        val top = if (cur != null && base != null && cur !== base) {
            val dt = (cur.at - base.at) / 1000f
            cur.queued.mapNotNull { (k, q1) -> base.queued[k]?.let { q0 -> k to (q1 - q0) / dt } }
                .sortedByDescending { it.second }.take(6)
                .joinToString("; ") { "%s=%.0f/dtk".format(it.first.take(60), it.second) }
        } else "belum ada pembanding"
        AppLog.w("FPS", "DIAG jendela=${tsWin.size} sampel, layer=${cur?.total?.size ?: 0}, teraktif: $top | tsReady=$tsReady kosong=$tsEmpty")
        val raw = Shell.exec("dumpsys SurfaceFlinger --timestats -dump")
        val head = raw.lines().filter { it.isNotBlank() }.take(5).joinToString(" / ") { it.trim().take(70) }
        AppLog.w("FPS", "DIAG timestats mentah: ${raw.length} karakter, layerName=${Regex("layerName").findAll(raw).count()}, totalFrames=${Regex("totalFrames").findAll(raw).count()} | $head")
        val list = Shell.exec("dumpsys SurfaceFlinger --list").lines().map { it.trim() }.filter { it.isNotEmpty() }
        val match = list.filter { curPkg.isNotEmpty() && it.contains(curPkg) }.take(4).joinToString(" / ") { it.take(70) }
        AppLog.w("FPS", "DIAG --list: ${list.size} layer; cocok paket '${curPkg}': ${match.ifEmpty { "tidak ada" }}")
        val foc = Shell.exec("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp' | head -4").lines().filter { it.isNotBlank() }
            .joinToString(" / ") { it.trim().take(110) }
        AppLog.w("FPS", "DIAG fokus window: ${foc.ifEmpty { "kosong" }} | Hz layar ${displayHz()} | akses ${Shell.mode()}")
    }

    /**
     * Sumber utama: FPS per-task dari sistem (TaskFps). Jalur lama (timestats) tetap jalan di belakang
     * untuk menentukan paket/layer, dan jadi cadangan bila TaskFps tidak ada / basi / task-nya bukan paket yang diukur.
     */
    private fun fps0(): Pair<Int, Int> {
        val base = fps0Legacy()
        val pkg = curPkg
        TaskFps.track(pkg)
        val t = if (pkg.isEmpty()) null else TaskFps.read(pkg)
        if (t == null) { fpsDbg += " | ${TaskFps.diag()}"; return base }
        // Sistem melapor 0 tapi timestats melihat game menggambar: jangan percaya 0 itu (counter belum siap), pakai jalur lama
        if (t < 0.5f && base.first >= 5) { fpsDbg += " | TaskFps 0, timestats ${base.first} dipakai"; return base }
        presentFps = t; queuedFps = t
        fpsDbg = "TaskFps %.1f | %s".format(t, fpsDbg)
        return Math.round(t) to 0
    }

    private fun fps0Legacy(): Pair<Int, Int> {
        val focus = targetPkg()
        val own = appCtx?.packageName ?: ""
        val cur = timestats()
        // Dump kosong sesaat: pertahankan jendela lama, anggap gagal ukur (bukan 0 FPS)
        if (cur.total.isEmpty() && tsWin.isNotEmpty()) { fpsDbg = "dump timestats kosong, nilai ditahan"; return -1 to 0 }
        tsWin.addLast(cur)
        while (tsWin.size > 1 && cur.at - tsWin.first().at > 2500L) tsWin.removeFirst()
        // Fokus jatuh ke PulseMonitor sendiri / SystemUI (mis. PulseMonitor dibuka sebagai jendela kecil di atas game,
        // atau layar terbelah): game di belakangnya tetap menggambar. Pakai paket dari layer yang paling aktif.
        var found: String? = null
        if (focus == null || isIgnoredPkg(focus, own)) {
            found = busiestLayerPkg(cur, own)
            if (found != null && Recorder.active.value && pinPkg == null) pinPkg = found
        }
        var pkg0: String? = found ?: focus
        // Fokus jendela bisa dipegang aplikasi lain yang tidak menggambar (mis. widget live / overlay pihak ketiga yang
        // belum ada di daftar abaikan) sementara game tetap jalan di belakangnya. Bila paket fokus nyaris tidak
        // menyerahkan frame tapi ada aplikasi lain yang menggambar >= 20 fps, ukur aplikasi itu.
        if (found == null && pkg0 != null) {
            val fp: String = pkg0
            val base0 = tsWin.first(); val dt0 = (cur.at - base0.at) / 1000f
            if (dt0 >= 0.3f) {
                var rate = 0f
                for (k in cur.queued.keys) if (k.contains(fp)) {
                    val q0 = base0.queued[k] ?: continue; val q1 = cur.queued[k] ?: continue
                    if (q1 >= q0) rate = maxOf(rate, (q1 - q0) / dt0)
                }
                if (rate < 5f) { val alt = busiestLayerPkg(cur, own, 20f); if (alt != null && alt != fp) pkg0 = alt }
            }
        }
        // Paket terpilih (fokus / game terakhir) bisa tidak punya layer sama sekali di SurfaceFlinger (mis. widget mengambang,
        // jendela kecil, atau game sudah ditutup). Dulu itu terbaca 0 FPS padahal game lain masih menggambar: pindah ke layer paling aktif.
        var pkgSel: String? = pkg0
        var swNote = ""
        if (pkgSel != null) {
            val p0: String = pkgSel
            if (cur.total.keys.none { it.contains(p0) }) {
                val alt = busiestLayerPkg(cur, own, 5f)
                if (alt != null && alt != p0) { pkgSel = alt; swNote = " | $p0 tanpa layer, pindah ke $alt" }
            }
        }
        val pkg: String? = pkgSel
        curPkg = pkg ?: ""
        if (pkg == null) { fpsDbg = "aplikasi fokus tidak terbaca"; return -1 to 0 }
        val cand = cur.total.keys.filter { it.contains(pkg) }
        val base = tsWin.first()
        val dt = (cur.at - base.at) / 1000f
        var bestQ = 0f; var bestP = 0f
        var valid = false; var reset = false
        var pending = false   // ada layer yang belum punya pembanding (layer baru): lajunya belum diketahui
        val lyr = ArrayList<Triple<String, Float, Float>>()   // untuk log audit: (layer, tampil/dtk, diserahkan/dtk)
        var minD = 99f                                          // jendela terpendek yang dipakai (detik)
        if (dt >= 0.3f) for (k in cand) {
            val p1 = cur.total[k] ?: continue; val q1 = cur.queued[k] ?: continue
            // Pembanding PER LAYER = sampel tertua di jendela yang sudah memuat layer ini. Dulu selalu sampel tertua jendela,
            // sehingga layer baru (loading / ganti scene / surface dibuat ulang) diabaikan ~2,5 detik dan yang terbaca
            // hanya layer lama yang diam = 0 FPS padahal game masih menggambar.
            var b: Ts? = null
            for (w in tsWin) if (w !== cur && w.total.containsKey(k) && w.queued.containsKey(k)) { b = w; break }
            val d = if (b == null) 0f else (cur.at - b.at) / 1000f
            // Jendela terlalu pendek (< 0,8 dtk, mis. tepat setelah timestats di-clear / layer baru) membuat FPS = selisih frame / selisih waktu
            // sangat berisik (satu frame ekstra atau jeda dumpsys 100 ms sudah jadi lonjakan 100+ atau jatuh ke ~0). Anggap "belum tahu", bukan angka.
            if (b == null || d < 0.8f) { pending = true; continue }
            val p0 = b.total[k] ?: continue; val q0 = b.queued[k] ?: continue
            if (p1 >= p0 && q1 >= q0) {
                valid = true; bestP = maxOf(bestP, (p1 - p0) / d); bestQ = maxOf(bestQ, (q1 - q0) / d)
                lyr.add(Triple(k, (p1 - p0) / d, (q1 - q0) / d)); minD = minOf(minD, d)
            }
            else reset = true   // penghitung turun: statistik di-reset (mis. aplikasi lain memanggil --timestats -clear)
        }
        // Mulai jendela baru dari sampel ini supaya tick berikutnya langsung punya pembanding yang benar
        if (reset) { tsWin.clear(); tsWin.addLast(cur) }
        presentFps = bestP; queuedFps = bestQ
        surfaceApp = cand.any { it.contains("SurfaceView[") }
        if (cand.isNotEmpty()) {
            fpsDbg = "$pkg | ${cand.size} layer${if (surfaceApp) " (SurfaceView)" else ""} | tampil %.0f, diserahkan %.0f | layar %d Hz%s".format(
                bestP, bestQ, displayHz(), if (pinPkg != null) " | terkunci" else "") + swNote
            // Layer belum punya pembanding di jendela (layer baru / statistik ter-reset): gagal ukur, bukan 0 FPS
            if (!valid) return -1 to 0
            // 0 dari layer lama yang diam TIDAK boleh dipercaya selama ada layer baru / statistik baru saja di-reset:
            // itu "belum tahu", bukan 0 FPS sungguhan. Ditahan lewat jalur gagal-ukur supaya tidak loncat 60 -> 0.
            if (bestQ < 0.5f && (pending || reset)) { fpsDbg += " | layer baru/reset, ditahan"; return -1 to 0 }
            // Counter timestats sering telat ter-update saat game lag berat (buka menu, ganti scene): terbaca 0 padahal game
            // masih menggambar beberapa frame. Silang-cek dengan timestamp frame asli (--latency) yang dihitung dari SEKARANG ke belakang.
            // Kasus Android 16: layer SurfaceView game menyerahkan frame (diserahkan 30-60) tetapi totalFrames tidak naik
            // (tampil 0) karena frame dihitung sebagai droppedFrames. Itu bukan 0 FPS: ukur lewat --latency, dan bila gagal
            // pakai laju frame yang diserahkan.
            if (bestP < 0.5f && bestQ >= 5f) {
                val live = runCatching { liveLayers(pkg) }.getOrDefault(emptyList())
                val now = runCatching { fpsNow(live) }.getOrDefault(-1f)
                val est = if (now >= 1f) now else bestQ
                fpsDbg += if (now >= 1f) " | tampil 0, latency %.0f".format(now) else " | tampil 0, pakai laju diserahkan %.0f".format(bestQ)
                queuedFps = est; presentFps = est
                return Math.round(est) to 0
            }
            if (bestQ < 0.5f) {
                val live = runCatching { liveLayers(pkg) }.getOrDefault(emptyList())
                // Layer SurfaceView game yang hidup tapi tidak ada di tabel timestats (tabel penuh / layer dibuat ulang):
                // itu bukan 0 FPS. Jadwalkan reset tabel (jeda min. 20 detik) dan ukur langsung lewat --latency.
                val missing = live.any { it.contains("SurfaceView[") && !cur.total.containsKey(it) }
                if (missing && SystemClock.elapsedRealtime() - tsClearAt > 20_000L) {
                    AppLog.i("FPS", "layer game hidup tidak ada di timestats (${cur.total.size} layer), tabel direset")
                    tsReady = false
                }
                val now = runCatching { fpsNow(live) }.getOrDefault(-1f)
                if (now > 0f) { fpsDbg += " | timestats 0, latency %.0f".format(now); queuedFps = now; presentFps = now; return Math.round(now) to 0 }
                if (missing) { fpsDbg += " | layer game belum tercatat timestats, ditahan"; return -1 to 0 }
            }
            // FPS yang dilaporkan = frame yang BENAR-BENAR tampil di layar (bestP), sama dengan yang dirasakan mata.
            // Dulu memakai bestQ (tampil + dropped = frame yang diserahkan game), sehingga game yang dilewati panel
            // (terasa 30) tetap terbaca 60. bestQ hanya dipakai di atas untuk mendeteksi layer aktif / 0 FPS.
            val out = Math.round(minOf(bestP, bestQ))
            runCatching { fpsAudit(out, bestP, bestQ, minD, lyr, pkg) }
            return out to 0
        }
        surfaceApp = false
        val lat = fpsLatency(pkg)
        fpsDbg = "timestats: $pkg tidak ada (${cur.total.size} layer) -> latency: $fpsDbg$swNote"
        return if (lat.first > 0) lat else (-1 to 0)
    }

    // ---------- SUHU ----------
    @Volatile private var appCtx: Context? = null
    fun init(c: Context) { appCtx = c.applicationContext; Access.init(c) }

    private class Temps {
        var cpu = -1f; var gpu = -1f; var bat = -1f; var skin = -1f; var soc = -1f
        fun put(kind: String, v: Float) {
            when (kind) {
                "cpu" -> cpu = maxOf(cpu, v); "gpu" -> gpu = maxOf(gpu, v); "bat" -> bat = maxOf(bat, v)
                "skin" -> skin = maxOf(skin, v); "soc" -> soc = maxOf(soc, v)
            }
        }
    }
    private class Hal(val t: Temps, val n: Int)

    /** Satuan sysfs bisa milli-derajat (42000), desi-derajat (420), atau derajat (42). */
    private fun norm(raw: Float) = when { raw >= 1000f -> raw / 1000f; raw > 150f -> raw / 10f; else -> raw }

    /** Suhu baterai dari broadcast sticky BATTERY_CHANGED (satuan 1/10 °C). Tanpa izin, tanpa Shizuku/root. */
    private fun batteryTemp(): Float {
        BatteryStats.freshTemp().takeIf { it > 0f }?.let { return it }     // file sistem lebih segar dari broadcast
        val i = runCatching { appCtx?.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) }.getOrNull()
            ?: return -1f
        val raw = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        if (raw == Int.MIN_VALUE) return -1f
        // Dipotong ke bawah (39,6 -> 39), bukan dibulatkan, supaya sama dengan DevCheck
        return (raw / 10).toFloat().takeIf { it in 1f..100f } ?: -1f
    }

    /** Persen baterai dari broadcast sticky BATTERY_CHANGED. */
    private fun batteryPct(): Int {
        val i = runCatching { appCtx?.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) }.getOrNull() ?: return -1
        val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1); val sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        return if (l >= 0 && sc > 0) l * 100 / sc else -1
    }

    /** Daya (Watt) = |arus baterai| x tegangan. Satuan arus beda-beda antar HP (µA atau mA), ditebak dari besarnya. -1 bila tidak terbaca. */
    private fun batteryWatt(): Float {
        val ctx = appCtx ?: return -1f
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager ?: return -1f
        val raw = runCatching { bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW) }.getOrDefault(0)
        if (raw == 0 || raw == Int.MIN_VALUE) return -1f
        val mv = runCatching {
            ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
        }.getOrNull() ?: 0
        if (mv <= 0) return -1f
        val a = Math.abs(raw.toLong())
        val amps = if (a > 20_000L) a / 1e6f else a / 1e3f
        return (amps * mv / 1000f).takeIf { it in 0f..60f } ?: -1f
    }

    @Volatile private var powerDbg = "-"
    private var powerSrc = ""

    /**
     * Daya (W) dari sysfs baterai (voltage_now dibaca langsung, bukan dari broadcast yang jarang diperbarui).
     * Arus dan tegangan harus dari direktori yang sama (battery, lalu bms); tiap nilai dirata-rata dari 3 pembacaan.
     * Satuan standar kernel: arus µA, tegangan µV; HP yang melapor mA / mV ditebak dari besarnya. Tanda arus diabaikan.
     * Null bila tidak terbaca / tidak masuk akal, lalu dipakai jalur API.
     */
    private fun powerSysfs(block: String): Float? {
        if (block.isBlank()) return null
        val cur = HashMap<String, MutableList<Long>>(); val vol = HashMap<String, MutableList<Long>>()
        for (l in block.lines()) {
            val v = l.substringAfter(':', "").trim().toLongOrNull() ?: continue
            val p = l.substringBefore(':').trim(); val dir = p.substringBeforeLast('/')
            if (p.endsWith("/current_now")) cur.getOrPut(dir) { ArrayList() }.add(v)
            else if (p.endsWith("/voltage_now")) vol.getOrPut(dir) { ArrayList() }.add(v)
        }
        for (dir in listOf("/sys/class/power_supply/battery", "/sys/class/power_supply/bms")) {
            val c = cur[dir]?.filter { it != 0L && it != Long.MIN_VALUE } ?: continue
            val vv = vol[dir]?.filter { it > 0L } ?: continue
            if (c.isEmpty() || vv.isEmpty()) continue
            val a = c.map { Math.abs(it).toDouble() }.average()
            val volt = vv.average()
            val mA = if (a > 20_000.0) a / 1000.0 else a
            val mV = if (volt > 100_000.0) volt / 1000.0 else volt
            val w = (mA * mV / 1e6).toFloat()
            if (w !in 0f..60f || mV !in 2500.0..5500.0) continue
            powerDbg = "sysfs ${dir.substringAfterLast('/')}: ${c.size} sampel, %.0f mA x %.2f V = %.2f W".format(mA, mV / 1000.0, w)
            if (powerSrc != "sysfs") { powerSrc = "sysfs"; AppLog.i("Daya", "memakai sysfs $dir") }
            return w
        }
        if (powerSrc != "api") { powerSrc = "api"; AppLog.w("Daya", "sysfs arus/tegangan tidak terbaca, pakai BatteryManager") }
        return null
    }

    /** Kelompokkan sensor: nama dulu (gpuss, cpuss, quiet_therm, ...), baru tipe HAL (0 CPU, 1 GPU, 2 BAT, 3 SKIN, 13 SOC). */
    private fun kindOf(type: Int, name: String): String? {
        val n = name.lowercase()
        return when {
            "gpu" in n || "g3d" in n || "mali" in n || "adreno" in n -> "gpu"
            "batt" in n -> "bat"
            "cpu" in n -> "cpu"
            "skin" in n || "quiet" in n -> "skin"
            else -> when (type) { 0 -> "cpu"; 1 -> "gpu"; 2 -> "bat"; 3 -> "skin"; 13 -> "soc"; else -> null }
        }
    }

    private val tempRe = Regex("Temperature\\{([^}]*mValue[^}]*)\\}")
    private val valRe = Regex("mValue\\s*=\\s*(-?[0-9.]+)")
    private val typeRe = Regex("mType\\s*=\\s*(-?\\d+)")
    private val nameRe = Regex("mName\\s*=\\s*([^,}]+)")
    private val halDown = Regex("(?i)hal\\s*ready:\\s*false")

    /** Semua sensor di `dumpsys thermalservice` (seksi "Current temperatures from HAL"). Null bila HAL belum siap/kosong. */
    private fun thermalHal(): Hal? {
        val out = Shell.exec("dumpsys thermalservice")
        if (out.isBlank() || halDown.containsMatchIn(out)) return null
        val i = out.indexOf("Current temperatures from HAL")
        var sec = if (i >= 0) out.substring(i) else out
        val j = sec.indexOf("Cached temperatures"); if (j > 0) sec = sec.substring(0, j)
        val t = Temps(); var n = 0
        for (m in tempRe.findAll(sec)) {
            val body = m.groupValues[1]
            val v = valRe.find(body)?.groupValues?.get(1)?.toFloatOrNull() ?: continue
            if (v !in 1f..150f) continue          // buang sensor tidak valid (NaN/0/-ribuan)
            val ty = typeRe.find(body)?.groupValues?.get(1)?.toIntOrNull() ?: -1
            val nm = nameRe.find(body)?.groupValues?.get(1)?.trim() ?: ""
            kindOf(ty, nm)?.let { t.put(it, v); n++ }
        }
        return if (n > 0) Hal(t, n) else null
    }

    /** Cadangan: /sys/class/thermal/thermal_zone*. Tidak memakai zona "soc" (di banyak HP itu persen baterai, bukan suhu). */
    private fun parseZones(block: String): Temps {
        val zType = HashMap<String, String>(); val zTemp = HashMap<String, Float>()
        for (l in block.lines()) {
            val m = Regex("thermal_zone(\\d+)/(type|temp):(.*)").find(l) ?: continue
            val (z, k, v) = m.destructured
            if (k == "type") zType[z] = v.trim() else v.trim().toFloatOrNull()?.let { zTemp[z] = norm(it) }
        }
        val t = Temps()
        for ((z, ty) in zType) {
            val v = zTemp[z]?.takeIf { it in 5f..120f } ?: continue
            kindOf(-1, ty)?.let { t.put(it, v) }
        }
        return t
    }

    // ---------- JALUR CEPAT ----------
    // Dulu FPS / CPU / GPU baru berubah sekali per tick. Satu tick = rantai proses shell + beberapa sleep (sampel GPU 6x, daya 3x, dst),
    // FPS-nya dari jendela timestats 2,5 dtk atau laporan sistem yang boleh basi 4 dtk, jadi angka di overlay selalu telat 1-3 dtk.
    // Cara baru: FPS = jumlah frame tampil (--latency) dalam 1 dtk terakhir dihitung mundur dari SEKARANG, /proc/stat dibaca sekali per putaran,
    // beban GPU dan frekuensi dibaca sesaat. Loop sendiri tiap 1 dtk, SATU proses shell per putaran, tanpa sleep.
    private const val FAST_MS = 1000L   // 1 dtk: ringan, 1 proses shell per detik
    private class Fast(val at: Long, val pkg: String, val fpsRaw: Int, val cpu: Int, val gpu: Int, val cpuMhz: Int, val gpuMhz: Int)
    @Volatile private var fast: Fast? = null
    @Volatile private var gpuLoadPath: String? = null      // jalur beban GPU yang dipilih tick (jalur pertama yang terbaca)
    private var fLayer = ""; private var fLayerPkg = ""; private var fLayerAt = -100_000L
    private var fPrevTotal = 0L; private var fPrevIdle = 0L
    private val fGpuWin = ArrayDeque<Int>()                // beban GPU sesaat (1 sampel)
    private var fLastFps = 0; private var fLastFpsAt = 0L

    private fun fastFresh(): Fast? = fast?.takeIf { SystemClock.elapsedRealtime() - it.at < 1500L }

    /** Jumlah frame tampil dalam [windowNs] terakhir dihitung mundur dari [nowNs] (kolom 1 = waktu tampil, cadangan kolom 2). -1 = tidak ada data. */
    private fun framesIn(text: String, nowNs: Long, windowNs: Long): Int {
        val rows = text.lines().drop(1).map { it.trim().split(Regex("\\s+")) }
        for (col in intArrayOf(1, 2)) {
            val ts = rows.mapNotNull { it.getOrNull(col)?.toLongOrNull() }.filter { it in 1 until Long.MAX_VALUE / 2 && it <= nowNs }
            if (ts.size < 3) continue
            return ts.count { it > nowNs - windowNs }
        }
        return -1
    }

    private fun gpuRawToMhz(path: String, raw: String): Int {
        val nums = Regex("\\d+").findAll(raw).mapNotNull { it.value.toLongOrNull() }.toList()
        if (nums.isEmpty()) return -1
        val v = if (path.endsWith("current_freqency")) nums.max() else nums[0]
        return when {
            path.endsWith("gpu_clock") || path.endsWith("clock_mhz") -> v
            v >= 10_000_000L -> v / 1_000_000
            v >= 10_000L -> v / 1000
            else -> v
        }.toInt().takeIf { it in 100..3500 } ?: -1
    }

    /** Pilih layer dengan laju frame tertinggi milik [pkg] (SurfaceView / BLAST didahulukan). Dipanggil jarang (tiap ~3 dtk). */
    private fun fastPickLayer(pkg: String) {
        fLayerAt = SystemClock.elapsedRealtime(); fLayerPkg = pkg
        val layers = liveLayers(pkg).sortedByDescending { (if (it.contains("SurfaceView")) 2 else 0) + (if (it.contains("BLAST")) 1 else 0) }.take(3)
        var best = ""; var bestN = -1
        for (l in layers) {
            val t0 = System.nanoTime(); val txt = Shell.exec("dumpsys SurfaceFlinger --latency '$l'"); val t1 = System.nanoTime()
            val n = framesIn(txt, (t0 + t1) / 2, 1_000_000_000L)
            if (n > bestN) { bestN = n; best = l }
        }
        fLayer = best
    }

    private fun fastTick() {
        if (Shell.mode() == "-") { fast = null; return }
        val pkg = curPkg
        val now = SystemClock.elapsedRealtime()
        if (pkg.isEmpty()) { fLayer = ""; fLayerPkg = "" }
        else if (pkg != fLayerPkg || fLayer.isEmpty() || now - fLayerAt > 3000L) fastPickLayer(pkg)
        val layer = fLayer
        val gPath = gpuLoadPath?.takeIf { it.startsWith("/") }
        val fPath = gpuPickPath?.takeIf { it.startsWith("/") }
        val cmd = StringBuilder("head -n1 /proc/stat; echo ==; ")
        if (gPath != null) cmd.append("cat ").append(gPath).append(" 2>/dev/null; ")
        cmd.append("echo ==; ")
        if (fPath != null) cmd.append("cat ").append(fPath).append(" 2>/dev/null | tr '\\n' ' '; ")
        cmd.append("echo ==; for d in /sys/devices/system/cpu/cpu[0-9]*; do [ -r \$d/cpufreq/scaling_cur_freq ] && echo \"\${d##*/}:\$(cat \$d/cpufreq/scaling_cur_freq 2>/dev/null):\"; done")
        if (layer.isNotEmpty()) cmd.append("; echo ==; dumpsys SurfaceFlinger --latency '").append(layer).append("'")
        val t0 = System.nanoTime()
        val out = Shell.exec(cmd.toString()).split("==")
        val t1 = System.nanoTime()
        if (out.size < 4) return
        // CPU: selisih /proc/stat sejak putaran sebelumnya
        var cpu = -1
        val c = out[0].trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        if (c.size >= 5) {
            val total = c.take(8).sum(); val idle = c[3] + c[4]
            if (fPrevTotal > 0 && total > fPrevTotal) cpu = (100 * ((total - fPrevTotal) - (idle - fPrevIdle)) / (total - fPrevTotal)).toInt().coerceIn(0, 100)
            fPrevTotal = total; fPrevIdle = idle
        }
        // GPU: beban sesaat, dirata-rata 3 putaran terakhir
        if (gPath != null) {
            val nums = Regex("\\d+").findAll(out[1]).mapNotNull { it.value.toLongOrNull() }.toList()
            val v: Int? = when {
                nums.isEmpty() -> null
                gPath.endsWith("gpubusy") -> nums.getOrNull(1)?.takeIf { it > 0 }?.let { (100 * nums[0] / it).toInt().coerceIn(0, 100) }
                else -> nums[0].toInt().takeIf { it in 0..100 }
            }
            if (v != null) { fGpuWin.addLast(v); while (fGpuWin.size > 1) fGpuWin.removeFirst() }   // sekali baca
        }
        val gpu = if (fGpuWin.isEmpty()) -1 else Math.round(fGpuWin.average()).toInt()
        val gpuMhz = if (fPath != null) gpuRawToMhz(fPath, out[2]) else -1
        val cpuMhz = out[3].lines().mapNotNull { l ->
            val f = l.trim().split(':'); if (f.size < 2 || !f[0].startsWith("cpu")) null else f[1].trim().toLongOrNull()?.takeIf { it > 0 }?.let { (it / 1000).toInt() }
        }.filter { it in 100..5000 }.maxOrNull() ?: -1
        // FPS: frame tampil dalam 1 dtk terakhir; waktu pembacaan = titik tengah eksekusi dumpsys
        var raw = -1
        if (layer.isNotEmpty() && out.size >= 5) raw = framesIn(out[4], (t0 + t1) / 2, 1_000_000_000L)
        val at = SystemClock.elapsedRealtime()
        fast = Fast(at, pkg, raw, cpu, gpu, cpuMhz, gpuMhz)
        // Publikasikan langsung ke overlay (tick berat hanya sekali per detik); aturan tahan nilai / layar diam sama dengan tick
        var shown = -1; var idle = false
        if (raw >= 0) {
            if (raw > 0) { fLastFps = raw; fLastFpsAt = at }
            shown = if (raw > 0) raw else if (fLastFps > 0 && at - fLastFpsAt < 3000L) fLastFps else 0
            if (shown < IDLE_FPS && !surfaceApp && pkg.isNotEmpty()) { val hz = displayHz(); if (hz > 0) { shown = hz; idle = true } }
        }
        state.update { s ->
            if (s.access == "-") s else s.copy(
                fps = if (shown >= 0) shown else s.fps,
                fpsRaw = if (raw >= 0) raw else s.fpsRaw,
                fpsRawF = if (raw >= 0) raw.toFloat() else s.fpsRawF,
                idle = if (shown >= 0) idle else s.idle,
                ft = if (shown > 0) 1000f / shown else if (shown == 0) 0f else s.ft,
                cpu = if (cpu >= 0) cpu else s.cpu,
                gpu = if (gpu >= 0) gpu else s.gpu,
                cpuMhz = if (cpuMhz > 0) cpuMhz else s.cpuMhz,
                gpuMhz = if (gpuMhz > 0) gpuMhz else s.gpuMhz
            )
        }
    }

    /**
     * FPS 1,5 detik terakhir dari timestamp frame asli (--latency), dihitung mundur dari waktu sekarang (bukan dari frame terakhir),
     * jadi game yang macet tidak dikira masih 60. -1 bila tidak ada data. Hanya dipanggil saat timestats membaca 0.
     */
    private fun fpsNow(live: List<String>): Float {
        val layers = live.sortedByDescending { (if (it.contains("SurfaceView")) 2 else 0) + (if (it.contains("BLAST")) 1 else 0) }
        if (layers.isEmpty()) return -1f
        var best = -1f
        for (layer in layers.take(3)) {
            val rows = Shell.exec("dumpsys SurfaceFlinger --latency '$layer'").lines().drop(1).map { it.trim().split(Regex("\\s+")) }
            val now = System.nanoTime()
            // Kolom 1 = waktu frame tampil, kolom 2 = waktu frame siap. Frame yang dihitung "dropped" oleh timestats
            // sering tidak punya waktu tampil, tetapi waktu siapnya selalu ada: pakai yang menghasilkan laju terbesar.
            for (col in intArrayOf(1, 2)) {
                val ts = rows.mapNotNull { it.getOrNull(col)?.toLongOrNull() }.filter { it in 1 until Long.MAX_VALUE / 2 && it <= now }
                if (ts.size < 2) continue
                best = maxOf(best, ts.count { it > now - 1_500_000_000L } / 1.5f)
            }
        }
        return best
    }

    // ---------- FRAMETIME ASLI (--latency) ----------
    private class Ft(val n: Int, val maxMs: Float, val jank: Int, val bigJank: Int, val top: List<Float>)
    private var ftLayer = ""; private var ftLayerLast = ""; private var ftPkg = ""; private var ftLayerAt = -100_000L
    private var ftLastTs = 0L
    private val ftPrev = ArrayDeque<Float>()   // 3 frametime sebelumnya (untuk Jank), lintas tick
    private fun ftReset() { ftLayer = ""; ftLayerLast = ""; ftPkg = ""; ftLastTs = 0L; ftPrev.clear() }

    /**
     * Frametime tiap frame dari `dumpsys SurfaceFlinger --latency <layer>` (timestamp tampil per frame, buffer ~127 frame),
     * hanya frame BARU sejak tick sebelumnya supaya tidak terhitung dua kali. Menghasilkan jumlah frame, frametime terburuk
     * (12 teratas, untuk menghitung 5% / 1% low sungguhan di akhir rekaman), dan Jank / BigJank (definisi PerfDog):
     * Jank = frametime > 2x rata-rata 3 frame sebelumnya DAN > 83,3 ms; BigJank = > 3x DAN > 125 ms.
     * Selisih > 2 detik dianggap jeda (loading / layar diam), bukan frame lag. Null = belum ada data.
     */
    private fun frameStats(pkg: String): Ft? {
        val now = SystemClock.elapsedRealtime()
        if (pkg != ftPkg) { ftReset(); ftPkg = pkg }
        if (ftLayer.isEmpty() && now - ftLayerAt > 3000L) {
            ftLayerAt = now
            val l = liveLayers(pkg).sortedByDescending { (if (it.contains("SurfaceView")) 2 else 0) + (if (it.contains("BLAST")) 1 else 0) }.firstOrNull() ?: ""
            if (l != ftLayerLast) { ftLastTs = 0L; ftPrev.clear() }
            ftLayer = l; ftLayerLast = l
        }
        if (ftLayer.isEmpty()) return null
        val rows = Shell.exec("dumpsys SurfaceFlinger --latency '$ftLayer'").lines().drop(1).map { it.trim().split(Regex("\\s+")) }
        fun col(c: Int) = rows.mapNotNull { it.getOrNull(c)?.toLongOrNull() }.filter { it in 1 until Long.MAX_VALUE / 2 }.sorted()
        var ts = col(1)
        if (ts.size < 3) ts = col(2)   // kolom 1 (waktu tampil) kosong: pakai waktu frame siap
        if (ts.isEmpty()) { ftLayer = ""; return null }   // layer mati / dibuat ulang: cari lagi
        if (ftLastTs == 0L) { ftLastTs = ts.last(); return null }   // tick pertama: frame lama di buffer tidak dihitung
        val fresh = ts.filter { it > ftLastTs }
        if (fresh.isEmpty()) return Ft(0, 0f, 0, 0, emptyList())
        val seq = ArrayList<Long>(fresh.size + 1); seq.add(ftLastTs); seq.addAll(fresh)
        ftLastTs = fresh.last()
        var jank = 0; var big = 0; var mx = 0f; var n = 0
        val d = ArrayList<Float>()
        for (i in 1 until seq.size) {
            val ms = (seq[i] - seq[i - 1]) / 1e6f
            if (ms <= 0f) continue
            if (ms > 2000f) { ftPrev.clear(); continue }
            n++; d.add(ms); mx = maxOf(mx, ms)
            if (ftPrev.size == 3) {
                val avgPrev = ftPrev.average().toFloat()
                if (ms > 125f && ms > 3f * avgPrev) big++
                else if (ms > 83.33f && ms > 2f * avgPrev) jank++
            }
            ftPrev.addLast(ms); if (ftPrev.size > 3) ftPrev.removeFirst()
        }
        return Ft(n, mx, jank, big, d.sortedDescending().take(12))
    }

    /** FPS dari SurfaceFlinger latency layer aplikasi yang sedang fokus. Return (fps, 1% low). */
    private fun fpsLatency(pkg: String): Pair<Int, Int> {
        val all = liveLayers(pkg)
        if (all.isEmpty()) { fpsDbg = "$pkg: layer tidak ditemukan"; return 0 to 0 }
        val ordered = all.sortedByDescending { (if (it.contains("SurfaceView")) 2 else 0) + (if (it.contains("BLAST")) 1 else 0) }
        for (layer in ordered.take(4)) {
            val rows = Shell.exec("dumpsys SurfaceFlinger --latency '$layer'").lines().drop(1)
                .map { it.trim().split(Regex("\\s+")) }
            for (col in intArrayOf(1, 2)) {
                val ts = rows.mapNotNull { it.getOrNull(col)?.toLongOrNull() }
                    .filter { it in 1 until Long.MAX_VALUE / 2 }.sorted()
                if (ts.size < 3) continue
                val recent = ts.filter { it >= ts.last() - 1_000_000_000L }
                if (recent.size < 2 || recent.last() == recent.first()) continue
                val fps = ((recent.size - 1) * 1e9 / (recent.last() - recent.first())).toInt()
                val deltas = ts.zipWithNext { a, b -> b - a }.filter { it > 0 }.sortedDescending()
                if (deltas.isEmpty()) continue
                val worst = deltas[(deltas.size / 100).coerceAtMost(deltas.size - 1)]
                fpsDbg = "$pkg | ${layer.take(36)} | ${ts.size} frame, kolom $col"
                return fps to (1e9 / worst).toInt()
            }
        }
        fpsDbg = "$pkg: ${ordered.size} layer, data latency kosong"
        return 0 to 0
    }
}
