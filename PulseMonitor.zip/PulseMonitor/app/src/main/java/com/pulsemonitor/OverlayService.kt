package com.pulsemonitor

import android.annotation.SuppressLint
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import kotlinx.coroutines.*

class OverlayService : Service() {
    private var box: TextView? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    override fun onBind(i: Intent?): IBinder? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    @SuppressLint("ClickableViewAccessibility")
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("ov", "Overlay", NotificationManager.IMPORTANCE_LOW))
        val notif = Notification.Builder(this, "ov").setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("PulseMonitor: overlay aktif").build()
        // Tipe specialUse baru ada di API 34; di bawahnya pakai versi 2 argumen
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, notif)
        // Izin overlay bisa dicabut kapan saja; addView akan crash tanpa pengecekan ini
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (box == null) {
            AppSettings.load(this); Sampler.init(this); Sampler.start()
            val wm = getSystemService(WindowManager::class.java)
            val prefs = getSharedPreferences("overlay", MODE_PRIVATE)

            val bg = GradientDrawable().apply {
                setColor(withAlpha(AppSettings.overlayBg, AppSettings.alpha)); cornerRadius = dp(40).toFloat()
                setStroke(dp(1), withAlpha(AppSettings.accent, 33))
            }
            val v = TextView(this).apply {
                typeface = Typeface.MONOSPACE; textSize = 12f; setTextColor(AppSettings.overlayText)
                setSingleLine(true); setPadding(dp(12), dp(5), dp(12), dp(5)); background = bg
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,       // bisa disentuh (untuk digeser), tidak mencuri fokus
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START; x = prefs.getInt("x", dp(12)); y = prefs.getInt("y", dp(40)) }

            // Geser: tahan lalu seret; posisi disimpan dan dipakai lagi saat overlay dinyalakan berikutnya
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
            v.setOnTouchListener { view: View, e: MotionEvent ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                    MotionEvent.ACTION_MOVE -> {
                        val dm = resources.displayMetrics
                        lp.x = (sx + (e.rawX - tx).toInt()).coerceIn(0, maxOf(0, dm.widthPixels - view.width))
                        lp.y = (sy + (e.rawY - ty).toInt()).coerceIn(0, maxOf(0, dm.heightPixels - view.height))
                        runCatching { wm.updateViewLayout(view, lp) }
                    }
                    MotionEvent.ACTION_UP -> prefs.edit().putInt("x", lp.x).putInt("y", lp.y).apply()
                }
                true
            }
            val ok = runCatching { wm.addView(v, lp) }.isSuccess
            if (!ok) { stopSelf(); return START_NOT_STICKY }
            box = v
            scope.launch {
                Sampler.state.collect { s ->
                    bg.setColor(withAlpha(AppSettings.overlayBg, AppSettings.alpha))
                    bg.setStroke(dp(1), withAlpha(AppSettings.accent, 33))
                    v.setTextColor(AppSettings.overlayText)
                    v.text = line(s)
                }
            }
        }
        return START_STICKY
    }

    /** Satu baris: 60 FPS  CPU 16% 63°  GPU 33% 63°  BAT 40°. Suhu berwarna sesuai tingkat panas. */
    private fun line(s: Snap): CharSequence {
        val sb = SpannableStringBuilder()
        fun span(what: Any, from: Int) = sb.setSpan(what, from, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        fun temp(t: Float) {
            val st = sb.length
            sb.append(if (t >= 0) "%.0f°".format(t) else "-")
            if (t >= 0) span(ForegroundColorSpan(heat(t)), st)
        }
        var st = sb.length
        sb.append("${s.fps}"); span(StyleSpan(Typeface.BOLD), st)
        st = sb.length; sb.append(" FPS"); span(ForegroundColorSpan(AppSettings.accent), st)
        sb.append("  CPU ${pct(s.cpu)} "); temp(s.tCpu)
        sb.append("  GPU ${pct(s.gpu)} "); temp(s.tGpu)
        sb.append("  BAT "); temp(s.tBat)
        return sb
    }

    override fun onDestroy() {
        scope.cancel(); box?.let { v -> runCatching { getSystemService(WindowManager::class.java).removeView(v) } }; box = null
        super.onDestroy()
    }
}

fun heat(t: Float) = when {
    t < 45f -> 0xFF7CFFB2.toInt()     // aman
    t < 55f -> 0xFFFFD866.toInt()     // hangat
    t < 65f -> 0xFFFF9F43.toInt()     // panas
    else -> 0xFFFF5C5C.toInt()        // sangat panas
}
fun deg(v: Float) = if (v >= 0) "%.0f°".format(v) else "-"
fun pct(v: Int) = if (v >= 0) "$v%" else "-"
