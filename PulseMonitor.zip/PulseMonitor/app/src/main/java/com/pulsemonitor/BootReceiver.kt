package com.pulsemonitor

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Setelah HP menyala / aplikasi diperbarui: bila "Tetap aktif di latar belakang" nyala, hidupkan lagi notifikasinya. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED || i.action == Intent.ACTION_MY_PACKAGE_REPLACED) OverlayService.ensureRunning(c)
    }
}
