package com.pulsemonitor

import android.content.Context
import android.graphics.Bitmap
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.*
import kotlinx.coroutines.delay
import kotlin.math.ceil

private val Bgr = Color(0xFF101014)
private val CardC = Color(0xFF1D1E24)
private val Muted = Color(0xFF8E8E99)
private val Peri = Color(0xFFA9B4FF)
private val CBlue = Color(0xFF4C8DFF)
private val CGreen = Color(0xFF4CC38A)
private val CAmber = Color(0xFFF5B83D)
private val CPink = Color(0xFFE5677A)
private val COrange = Color(0xFFFF9F43)

class Series(val name: String, val color: Color, val v: List<Float>)

fun appIcon(ctx: Context, pkg: String): Bitmap? = runCatching {
    val d = ctx.packageManager.getApplicationIcon(pkg)
    val bmp = Bitmap.createBitmap(192, 192, Bitmap.Config.ARGB_8888)
    d.setBounds(0, 0, 192, 192); d.draw(android.graphics.Canvas(bmp)); bmp
}.getOrNull()

/** Laporan satu rekaman: header, deskripsi, statistik (2 halaman), lalu grafik. */
@Composable
fun ReportView(s: Session, onBack: () -> Unit, onShare: () -> Unit, onCsv: () -> Unit, onDelete: () -> Unit, onDesc: (String) -> Unit) {
    val ctx = LocalContext.current
    val st = remember(s) { s.stats() }
    val icon = remember(s.pkg) { appIcon(ctx, s.pkg) }
    var desc by remember(s.id) { mutableStateOf(s.desc) }
    var confirm by remember { mutableStateOf(false) }
    LaunchedEffect(desc) { if (desc != s.desc) { delay(600); onDesc(desc) } }

    Column(Modifier.fillMaxSize().background(Bgr).verticalScroll(rememberScrollState())
        .statusBarsPadding().navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("←", color = Color.White, fontSize = 26.sp, modifier = Modifier.clickable { onBack() }.padding(end = 10.dp))
            Spacer(Modifier.weight(1f))
            Pill("Bagikan", onShare); Pill("CSV", onCsv)
            Pill(if (confirm) "Yakin hapus?" else "Hapus", { if (confirm) onDelete() else confirm = true },
                if (confirm) Color(0xFF5A2530) else CardC)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) Image(icon.asImageBitmap(), null, Modifier.size(64.dp).clip(RoundedCornerShape(14.dp)))
            else Box(Modifier.size(64.dp).background(CardC, RoundedCornerShape(14.dp)))
            Text(s.label, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2,
                lineHeight = 32.sp, modifier = Modifier.padding(start = 16.dp).weight(1f))
        }
        Box(Modifier.fillMaxWidth().background(CardC, RoundedCornerShape(24.dp)).padding(horizontal = 20.dp, vertical = 22.dp)) {
            BasicTextField(desc, { desc = it }, textStyle = TextStyle(color = Color.White, fontSize = 18.sp),
                cursorBrush = SolidColor(Color.White), modifier = Modifier.fillMaxWidth(),
                decorationBox = { inner -> if (desc.isEmpty()) Text("Deskripsi", color = Muted, fontSize = 20.sp, fontWeight = FontWeight.Bold); inner() })
        }
        // Statistik, 2 halaman (geser)
        Column(Modifier.fillMaxWidth().background(CardC, RoundedCornerShape(24.dp)).padding(horizontal = 16.dp, vertical = 18.dp)) {
            Row(Modifier.fillMaxWidth()) {
                Text(fmtDate(s.id), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("Res : ${s.res}", color = Muted, fontSize = 14.sp)
            }
            val pager = rememberPagerState(pageCount = { 2 })
            HorizontalPager(pager, Modifier.fillMaxWidth().padding(top = 18.dp)) { page ->
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    if (page == 0) {
                        Row {
                            StatCell("MAKS", f1(st.max), "FPS"); StatCell("MIN", f1(st.min), "FPS")
                            StatCell("RATA-RATA", f1(st.avg), "FPS"); StatCell("VARIANS", f1(st.sd), "FPS")
                        }
                        Row {
                            StatCell("KEHALUSAN", f1(st.smooth), "%"); StatCell("5% LOW", f1(st.low5), "FPS")
                            StatCell("SUHU MAKS", if (st.maxTemp >= 0f) "%.0f".format(st.maxTemp) else "-", "°C")
                            StatCell("DAYA", if (st.avgWatt >= 0f) f1(st.avgWatt) else "-", "Watt")
                        }
                    } else {
                        Row {
                            StatCell("CPU", pctOrDash(s.cpu.avgValid()), "rata-rata"); StatCell("GPU", pctOrDash(s.gpu.avgValid()), "rata-rata")
                            StatCell("RAM", pctOrDash(s.ram.avgValid()), "rata-rata"); StatCell("DURASI", fmtDur(s.dur), "menit")
                        }
                        Row {
                            StatCell("SUHU CPU", degOrDash(s.tCpu.maxValid()), "maks"); StatCell("SUHU GPU", degOrDash(s.tGpu.maxValid()), "maks")
                            StatCell("SUHU BAT", degOrDash(s.tBat.maxValid()), "maks"); StatCell("SAMPEL", "${s.n}", "titik data")
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 14.dp), horizontalArrangement = Arrangement.Center) {
                for (i in 0..1) Box(Modifier.padding(horizontal = 4.dp).size(9.dp).background(if (pager.currentPage == i) Peri else Color(0xFF55555F), CircleShape))
            }
        }
        LineChart("FPS", s.t, listOf(
            Series("FPS", CBlue, s.fps),
            Series("Frametime", CGreen, s.fps.map { if (it > 0f) 1000f / it else -1f }),
            Series("Suhu", CAmber, s.temp)))
        LineChart("Beban CPU / GPU (%)", s.t, listOf(Series("CPU", CBlue, s.cpu), Series("GPU", CPink, s.gpu)))
        LineChart("RAM (%)", s.t, listOf(Series("RAM", CGreen, s.ram)))
        LineChart("Suhu (°C)", s.t, listOf(Series("CPU", CAmber, s.tCpu), Series("GPU", COrange, s.tGpu), Series("Baterai", CGreen, s.tBat)))
        if (s.watt.any { it >= 0f }) LineChart("Daya (Watt)", s.t, listOf(Series("Daya", CPink, s.watt)))
    }
}

private fun pctOrDash(v: Float) = if (v >= 0f) "%.0f%%".format(v) else "-"
private fun degOrDash(v: Float) = if (v >= 0f) "%.0f°".format(v) else "-"

@Composable
private fun Pill(text: String, onClick: () -> Unit, bg: Color = CardC) {
    Text(text, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(bg).clickable { onClick() }.padding(horizontal = 14.dp, vertical = 9.dp))
}

@Composable
private fun RowScope.StatCell(label: String, value: String, unit: String) {
    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = Muted, fontSize = 11.sp, maxLines = 1, letterSpacing = 0.4.sp)
        Text(value, color = Peri, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.padding(vertical = 4.dp))
        Text(unit, color = Muted, fontSize = 11.sp, maxLines = 1)
    }
}

/** Grafik garis: grid putus-putus, label sumbu, nilai terakhir tiap seri di kanan, legenda di bawah. Nilai < 0 = putus. */
@Composable
fun LineChart(title: String, t: List<Float>, series: List<Series>) {
    val tm = rememberTextMeasurer()
    val n = t.size
    Column(Modifier.fillMaxWidth().background(CardC, RoundedCornerShape(24.dp)).padding(16.dp)) {
        Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Medium)
        Canvas(Modifier.fillMaxWidth().padding(top = 12.dp).height(210.dp)) {
            if (n < 2) return@Canvas
            val lbl = TextStyle(color = Muted, fontSize = 11.sp)
            val left = 34.dp.toPx(); val right = 34.dp.toPx(); val bottom = 22.dp.toPx(); val top = 6.dp.toPx()
            val w = size.width - left - right; val h = size.height - top - bottom
            val rawMax = series.flatMap { it.v }.filter { it >= 0f }.maxOrNull() ?: 1f
            val steps = floatArrayOf(1f, 2f, 5f, 10f, 20f, 25f, 50f, 100f, 200f, 250f, 500f, 1000f)
            val step = steps.firstOrNull { rawMax / it <= 5f } ?: (rawMax / 5f)
            val rows = ceil(rawMax / step).toInt().coerceAtLeast(1)
            val ymax = rows * step
            val tEnd = t.last().coerceAtLeast(1f)
            val dash = PathEffect.dashPathEffect(floatArrayOf(6f, 8f))
            val grid = Color(0x55FFFFFF)
            for (i in 0..rows) {
                val y = top + h - (i * step / ymax) * h
                drawLine(grid, Offset(left, y), Offset(left + w, y), strokeWidth = 1f, pathEffect = dash)
                val text = "%.0f".format(i * step)
                val sz = tm.measure(text, lbl).size
                drawText(tm, text, Offset(left - 6.dp.toPx() - sz.width, y - sz.height / 2f), lbl)
            }
            for (i in 0..5) {
                val x = left + w * i / 5f
                drawLine(grid, Offset(x, top), Offset(x, top + h), strokeWidth = 1f, pathEffect = dash)
                val text = if (tEnd >= 120f) fmtDur((tEnd * i / 5f).toInt()) else "${(tEnd * i / 5f).toInt()}s"
                val sz = tm.measure(text, lbl).size
                drawText(tm, text, Offset(x - sz.width / 2f, top + h + 4.dp.toPx()), lbl)
            }
            val stride = maxOf(1, n / 500)
            series.forEach { sr ->
                val p = Path(); var open = false; var i = 0
                while (i < minOf(n, sr.v.size)) {
                    val v = sr.v[i]
                    if (v < 0f) open = false else {
                        val x = left + w * (t[i] / tEnd); val y = top + h - (v / ymax) * h
                        if (!open) { p.moveTo(x, y); open = true } else p.lineTo(x, y)
                    }
                    i += stride
                }
                drawPath(p, sr.color, style = Stroke(width = 1.6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
                sr.v.lastOrNull { it >= 0f }?.let { lv ->
                    val text = "%.0f".format(lv)
                    val sz = tm.measure(text, lbl).size
                    drawText(tm, text, Offset(left + w + 5.dp.toPx(), top + h - (lv / ymax) * h - sz.height / 2f), TextStyle(color = sr.color, fontSize = 12.sp))
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            series.forEach { sr ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).background(sr.color, CircleShape))
                    Text(sr.name, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(start = 6.dp))
                }
            }
        }
    }
}
