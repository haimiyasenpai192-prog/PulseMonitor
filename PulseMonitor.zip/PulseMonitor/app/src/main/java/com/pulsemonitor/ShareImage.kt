package com.pulsemonitor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max

/** Menggambar laporan rekaman menjadi satu gambar PNG (lebar 1080 px) untuk dibagikan. Tidak bergantung pada layar yang sedang tampil. */
object ShareImage {
    private const val W = 1080
    private const val PAD = 48f
    private val BG = Color.parseColor("#101014")
    private val CARD = Color.parseColor("#1D1E24")
    private val MUTED = Color.parseColor("#8E8E99")
    private val SUB = Color.parseColor("#C4C6CE")
    private val GRID = Color.parseColor("#34363F")
    private val BLUE = Color.parseColor("#4C8DFF")
    private val GREEN = Color.parseColor("#4CC38A")
    private val AMBER = Color.parseColor("#F5B83D")
    private val PINK = Color.parseColor("#E5677A")
    private val ORANGE = Color.parseColor("#B07CFF")

    private class Line(val name: String, val color: Int, val v: List<Float>)

    private fun paint(color: Int, size: Float = 0f, bold: Boolean = false, align: Paint.Align = Paint.Align.LEFT) =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color; if (size > 0f) textSize = size; textAlign = align
            typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }

    /** part 0 = ikon + kartu statistik halaman 1 + semua grafik; part 1 = ikon + kartu statistik halaman 2.
     *  Dikirim sebagai dua gambar sekaligus, jadi di chat bisa digeser kiri-kanan seperti halaman di aplikasi. */
    fun render(ctx: Context, s: Session, part: Int = 0): Bitmap {
        val h = layout(null, ctx, s, part)
        val bmp = Bitmap.createBitmap(W, h, Bitmap.Config.ARGB_8888)
        layout(Canvas(bmp), ctx, s, part)
        return bmp
    }

    private fun fit(text: String, p: Paint, width: Float): String =
        TextUtils.ellipsize(text, TextPaint(p), width, TextUtils.TruncateAt.END).toString()

    private fun pct(v: Float) = if (v >= 0f) "%.0f%%".format(v) else "-"

    /** Satu fungsi untuk dua tahap: c == null hanya mengukur tinggi total, c != null menggambar. */
    private fun layout(c: Canvas?, ctx: Context, s: Session, part: Int): Int {
        val st = s.stats()
        c?.drawColor(BG)
        var y = PAD
        val cardP = paint(CARD)

        // ---- Header: ikon, nama, tanggal · durasi · resolusi ----
        val icon = appIcon(ctx, s.pkg)
        val isz = 160f
        if (c != null) {
            val r = RectF(PAD, y, PAD + isz, y + isz)
            if (icon != null) {
                val clip = Path().apply { addRoundRect(r, 36f, 36f, Path.Direction.CW) }
                c.save(); c.clipPath(clip); c.drawBitmap(icon, null, r, Paint(Paint.FILTER_BITMAP_FLAG)); c.restore()
            } else c.drawRoundRect(r, 36f, 36f, cardP)
            val tx = PAD + isz + 36f; val avail = W - PAD - tx
            c.drawText(fit(s.label, paint(Color.WHITE, 64f, true), avail), tx, y + 74f, paint(Color.WHITE, 64f, true))
            c.drawText(fit("Durasi ${fmtDur(s.dur)}", paint(SUB, 34f), avail), tx, y + 128f, paint(SUB, 34f))
        }
        y += isz + 40f

        // ---- Catatan (bila ada) ----
        if (s.desc.isNotBlank()) {
            val tp = TextPaint(paint(Color.WHITE, 36f))
            val sl = StaticLayout.Builder.obtain(s.desc, 0, s.desc.length, tp, (W - 2 * PAD - 64f).toInt()).build()
            val ch = sl.height + 56f
            if (c != null) {
                c.drawRoundRect(RectF(PAD, y, W - PAD, y + ch), 40f, 40f, cardP)
                c.save(); c.translate(PAD + 32f, y + 28f); sl.draw(c); c.restore()
            }
            y += ch + 28f
        }

        // ---- Dua kartu statistik, sama seperti dua halaman di aplikasi: tanggal + resolusi, garis, isi, titik halaman ----
        statPages(s, st).forEachIndexed { pi, page ->
            if (pi != part) return@forEachIndexed
            val gh = 520f
            if (c != null) {
                c.drawRoundRect(RectF(PAD, y, W - PAD, y + gh), 40f, 40f, cardP)
                val cw = (W - 2 * PAD) / 4f
                val left = PAD + 36f; val right = W - PAD - 36f
                val lineP = paint(0x22FFFFFF).apply { strokeWidth = 2f }
                fun cell(i: Int, cx: Float, by: Float) {
                    val (top, v, bottom) = page[i]
                    c.drawText(top, cx, by + 50f, paint(SUB, 28f, align = Paint.Align.CENTER))
                    c.drawText(v, cx, by + 112f, paint(Color.WHITE, 54f, true, Paint.Align.CENTER))
                    c.drawText(bottom, cx, by + 154f, paint(MUTED, 26f, align = Paint.Align.CENTER))
                }
                // Kepala kartu: tanggal di kiri, resolusi di kanan
                c.drawText(fmtDate(s.id), left, y + 62f, paint(Color.WHITE, 34f, true))
                if (s.res.isNotBlank()) c.drawText("Res : ${s.res}", right, y + 62f, paint(MUTED, 32f, align = Paint.Align.RIGHT))
                c.drawLine(left, y + 92f, right, y + 92f, lineP)
                if (pi == 0) {
                    // Halaman 1: rata-rata FPS besar di kiri (rata tengah di kolomnya), Maks / Min / Varians di kanan
                    val split = left + (right - left) * 0.52f
                    val cx = (left + split) / 2f
                    c.drawText("Rata-rata", cx, y + 146f, paint(SUB, 30f, align = Paint.Align.CENTER))
                    val bigP = paint(Color.WHITE, 88f, true); val unitP = paint(MUTED, 30f)
                    val bw = bigP.measureText(page[2].second); val uw = unitP.measureText(" FPS")
                    val sx = cx - (bw + uw) / 2f
                    c.drawText(page[2].second, sx, y + 238f, bigP)
                    c.drawText(" FPS", sx + bw, y + 238f, unitP)
                    c.drawLine(split, y + 114f, split, y + 266f, lineP)
                    listOf(0, 1, 3).forEachIndexed { r, i ->
                        val by = y + 146f + r * 50f
                        val (label, v, unit) = page[i]
                        val unitS = paint(MUTED, 26f, align = Paint.Align.RIGHT)
                        c.drawText(label, split + 36f, by, paint(SUB, 32f))
                        c.drawText(unit, right, by, unitS)
                        c.drawText(v, right - unitS.measureText(unit) - 10f, by, paint(Color.WHITE, 40f, true, Paint.Align.RIGHT))
                    }
                    c.drawLine(left, y + 282f, right, y + 282f, lineP)
                    for (k in 0 until 4) cell(4 + k, PAD + cw * k + cw / 2f, y + 298f)
                } else {
                    // Halaman 2: dua baris empat angka, dipisah garis
                    for (i in 0 until 4) cell(i, PAD + cw * i + cw / 2f, y + 108f)
                    c.drawLine(left, y + 282f, right, y + 282f, lineP)
                    for (i in 4 until 8) cell(i, PAD + cw * (i - 4) + cw / 2f, y + 298f)
                }
                // Titik halaman: yang aktif memanjang dan putih (halaman 1 di kiri, halaman 2 di kanan)
                val dy = y + gh - 32f
                val dim = paint(0x55FFFFFF); val on = paint(Color.WHITE)
                if (pi == 0) {
                    c.drawRoundRect(RectF(W / 2f - 28f, dy - 7f, W / 2f + 12f, dy + 7f), 7f, 7f, on)
                    c.drawCircle(W / 2f + 30f, dy, 7f, dim)
                } else {
                    c.drawCircle(W / 2f - 30f, dy, 7f, dim)
                    c.drawRoundRect(RectF(W / 2f - 12f, dy - 7f, W / 2f + 28f, dy + 7f), 7f, 7f, on)
                }
            }
            y += gh + 28f
        }

        if (part == 1) { y += PAD - 28f; return ceil(y).toInt() }

        // ---- Grafik ----
        val ch = 540f
        val charts = ArrayList<Triple<String, List<Line>, Boolean>>()   // judul, garis, mulai dari nol
        charts.add(Triple("Suhu (°C)", listOf(Line("CPU", AMBER, s.tCpu), Line("GPU", ORANGE, s.tGpu), Line("Baterai", GREEN, s.tBat), Line("HP", PINK, s.phoneTemp)), false))
        charts.add(Triple("Beban (%)", listOf(Line("CPU", BLUE, s.cpu), Line("GPU", PINK, s.gpu), Line("RAM", GREEN, s.ram)), true))
        charts.add(Triple("FPS", listOf(Line("FPS", BLUE, s.fps), Line("Frametime", GREEN, s.fps.map { if (it > 0f) 1000f / it else -1f }), Line("Suhu", AMBER, s.temp)), true))
        if (s.watt.any { it >= 0f }) charts.add(Triple("Daya (W)", listOf(Line("Daya", PINK, s.watt)), true))
        for ((title, lines, zero) in charts) {
            if (c != null) drawChart(c, y, ch, title, s.t, lines, zero, title.startsWith("Beban"))
            y += ch + 28f
        }

        // ---- Penutup ----
        c?.drawText("Pulse Monitor", W / 2f, y + 36f, paint(MUTED, 30f, align = Paint.Align.CENTER))
        y += 36f + PAD
        return ceil(y).toInt()
    }

    private fun drawChart(c: Canvas, top: Float, h: Float, title: String, t: List<Float>, lines: List<Line>, fromZero: Boolean, pct100: Boolean) {
        c.drawRoundRect(RectF(PAD, top, W - PAD, top + h), 40f, 40f, paint(CARD))
        c.drawText(title, PAD + 36f, top + 70f, paint(Color.WHITE, 42f, true))
        // legenda
        if (lines.size > 1) {
            var lx = PAD + 36f
            for (l in lines) {
                c.drawCircle(lx + 10f, top + 118f, 10f, paint(l.color))
                c.drawText(l.name, lx + 32f, top + 130f, paint(SUB, 30f))
                lx += 32f + paint(SUB, 30f).measureText(l.name) + 36f
            }
        }
        val pl = PAD + 36f + 84f; val pr = W - PAD - 40f
        val pt = top + (if (lines.size > 1) 168f else 130f); val pb = top + h - 84f
        // skala Y
        val vals = lines.flatMap { it.v }.filter { it >= 0f }
        var lo: Float; var hi: Float
        if (vals.isEmpty()) { lo = 0f; hi = 1f }
        else if (pct100) { lo = 0f; hi = 100f }
        else {
            val mn = vals.minOrNull() ?: 0f; val mx = vals.maxOrNull() ?: 1f
            lo = if (fromZero) 0f else floor(mn - 1f)
            hi = ceil(mx + 1f)
            if (!fromZero && hi - lo < 4f) { val m = (hi + lo) / 2f; lo = m - 2f; hi = m + 2f }
            if (fromZero && hi <= lo) hi = lo + 1f
        }
        val tmax = max(t.lastOrNull() ?: 1f, 1f)
        val grid = paint(GRID).apply { strokeWidth = 2f; style = Paint.Style.STROKE; pathEffect = DashPathEffect(floatArrayOf(10f, 10f), 0f) }
        val yl = paint(MUTED, 28f, align = Paint.Align.RIGHT)
        for (i in 0..4) {
            val yy = pb - (pb - pt) * i / 4f
            c.drawLine(pl, yy, pr, yy, grid)
            val v = lo + (hi - lo) * i / 4f
            c.drawText(if (hi - lo >= 8f) "%.0f".format(v) else "%.1f".format(v), pl - 12f, yy + 10f, yl)
        }
        // skala X: langkah "bagus" supaya label sekitar 5
        val steps = floatArrayOf(1f, 2f, 5f, 10f, 15f, 30f, 60f, 120f, 300f, 600f, 1200f, 1800f, 3600f)
        val step = steps.firstOrNull { it >= tmax / 5f } ?: 3600f
        val xl = paint(MUTED, 28f, align = Paint.Align.CENTER)
        var tv = 0f
        while (tv <= tmax + 0.001f) {
            val xx = pl + (pr - pl) * tv / tmax
            c.drawLine(xx, pt, xx, pb, grid)
            c.drawText("${tv.toInt()}s", xx, pb + 44f, xl)
            tv += step
        }
        // garis data (nilai < 0 = tidak terbaca, garis putus di situ)
        for (l in lines) {
            val path = Path(); var pen = false
            val n = minOf(l.v.size, t.size)
            for (i in 0 until n) {
                val v = l.v[i]
                if (v < 0f) { pen = false; continue }
                val xx = pl + (pr - pl) * t[i] / tmax
                val yy = pb - (pb - pt) * ((v - lo) / (hi - lo)).coerceIn(0f, 1f)
                if (!pen) { path.moveTo(xx, yy); pen = true } else path.lineTo(xx, yy)
            }
            c.drawPath(path, paint(l.color).apply { style = Paint.Style.STROKE; strokeWidth = 5f; strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND })
        }
    }
}
