# PulseMonitor (FPS / CPU / GPU / Suhu)
1. Buka folder ini di Android Studio (Koala+), tunggu Gradle sync, lalu Run di HP Android 10+.
2. Pilih akses: aktifkan Shizuku (lalu tekan "Beri izin Shizuku") atau pakai HP root.
3. Nyalakan "Overlay mengambang" (akan diminta izin tampil di atas aplikasi lain).
Catatan: kode belum dikompilasi/diuji. GPU hanya terbaca di Adreno (kgsl). Tanpa izin INTERNET.

## Perubahan v0.1.1 (stabilisasi)
- Minta izin POST_NOTIFICATIONS saat start (Android 13+), supaya notifikasi overlay muncul.
- Overlay: cek izin tampil-di-atas-aplikasi, tangani addView/removeView gagal, tipe FGS specialUse hanya di API 34+.
- Sampler: hindari crash saat data frame kosong; kegagalan baca FPS tidak lagi menggagalkan CPU/GPU/RAM/suhu.
- Belum ada Gradle wrapper di zip ini: Android Studio akan menawarkan membuatnya saat sync (butuh Gradle 8.7+ untuk AGP 8.5.2).

## v0.2.2: Ikon aplikasi
- Ikon adaptive: latar gelap + garis denyut cyan, plus versi monokrom untuk ikon bertema (Android 13+). Semua berupa vektor XML di res/, tanpa PNG.

## v0.2.1: GPU MediaTek
- Sampler mencoba beberapa jalur GPU berurutan: Adreno (kgsl), MediaTek (GED), Mali lama. Jalur pertama yang terbaca dipakai; jika tidak ada, tampil "-".
- Belum diuji di perangkat MediaTek. Jalur GED bisa berbeda/tertutup di beberapa chipset.

## v0.2.0: Wallpaper
- Kartu "Wallpaper" di layar utama: pilih gambar dari galeri (Photo Picker, tanpa izin storage), ganti, hapus.
- Gambar disalin ke penyimpanan internal aplikasi (maks 1600 px, JPEG) lewat WallpaperStore.kt.
- Slider "Redupkan latar" (20-90%) agar teks tetap terbaca; nilainya tersimpan.

## v0.2.3: Perbaikan suhu (acuan: FrameX)
- Suhu dipisah: baterai, CPU, GPU (sebelumnya satu angka "SUHU" gabungan, GPU tidak pernah dibaca).
- Baterai: dari broadcast BATTERY_CHANGED (tanpa Shizuku/root), cadangan HAL lalu sysfs.
- CPU/GPU: HAL thermal (`dumpsys thermalservice`) dibaca semua sensornya, dikelompokkan lewat nama (cpuss/gpuss/quiet_therm) lalu tipe HAL; cadangan sysfs thermal_zone dan kgsl temp.
- Dibuang: zona sysfs "soc"/"tsens" yang di banyak HP berisi persen baterai atau sensor acak, sehingga angka suhu salah.
- Catatan: belum dikompilasi/diuji di perangkat.

## v0.2.4: Overlay baru
- Tampilan kartu: FPS besar, lalu tabel rata kolom CPU / GPU / RAM / BAT (beban dan suhu), suhu berwarna (hijau, kuning, oranye, merah).
- Bisa digeser: tahan lalu seret overlay ke posisi mana pun; posisi tersimpan.
- Catatan: area overlay kini menangkap sentuhan (perlu supaya bisa digeser), jadi sentuhan tepat di atas kartu tidak tembus ke game.

## v0.2.5: Overlay satu baris
- Overlay jadi pil satu baris: `60 FPS  CPU 16% 63°  GPU 33% 63°  BAT 40°`, suhu tetap berwarna. Tetap bisa digeser.

## v0.2.6: Ikon petir
- Ikon aplikasi diganti jadi petir cyan di atas latar gelap (adaptive + monokrom untuk ikon bertema). Tetap vektor XML.

## v0.3.0: Layar utama baru dan Pengaturan
- Layar utama: kartu FPS dengan grafik 30 detik terakhir, lalu AVG / 1% LOW / FRAMETIME, baris pil CPU / GPU / RAM / Baterai (beban + suhu berwarna), saklar overlay, akses, wallpaper, diagnostik.
- Ikon gerigi di pojok kanan atas membuka Pengaturan: warna aksen, warna teks overlay, warna dan transparansi latar overlay, tombol "Kembalikan warna awal". Tersimpan otomatis.
- Overlay membaca pengaturan warna tiap detik. Belum dikompilasi/diuji di perangkat.
