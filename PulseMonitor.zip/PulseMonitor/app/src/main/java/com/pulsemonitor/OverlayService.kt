package com.pulsemonitor

import android.annotation.SuppressLint
import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.widget.Toast
import android.provider.Settings
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.LinearLayout
import android.view.ViewGroup
import kotlinx.coroutines.*

private const val FULL_BLEED_TEST = true
private const val BLEED_DP = 0      // luberan gambar ke bingkai sistem: 0 = gambar pas di area kustom (sudut dibulatkan di WallpaperStore)

class OverlayService : Service() {
    companion object {
        const val ACTION_REC = "com.pulsemonitor.REC"; const val ACTION_PANEL = "com.pulsemonitor.PANEL"
        const val ACTION_EXPAND = "com.pulsemonitor.EXPAND"   // panah di kartu notifikasi: buka tampilan lengkap
        const val ACTION_HIDE = "com.pulsemonitor.HIDE"      // sembunyikan overlay, layanan tetap jalan (mode latar belakang)
        const val ACTION_RESTORE = "com.pulsemonitor.RESTORE"   // hidupkan ulang mengikuti keadaan terakhir (setelah swipe dari recents / boot)
        val overlayShown = kotlinx.coroutines.flow.MutableStateFlow(false)   // sumber kebenaran status overlay untuk layar utama
        @Volatile var alive = false

        /** Alarm sekali untuk menghidupkan layanan lagi bila proses dimatikan sistem. Gagal = diabaikan (START_STICKY tetap jadi cadangan). */
        fun scheduleRestore(ctx: Context, delayMs: Long) {
            runCatching {
                val app = ctx.applicationContext
                val pi = PendingIntent.getForegroundService(app, 77,
                    Intent(app, OverlayService::class.java).setAction(ACTION_RESTORE),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                app.getSystemService(AlarmManager::class.java)
                    .setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, android.os.SystemClock.elapsedRealtime() + delayMs, pi)
            }
        }

        /** Dipanggil saat aplikasi dibuka atau perangkat menyala: bila mode latar belakang aktif tapi layanan mati, hidupkan lagi. */
        fun ensureRunning(ctx: Context) {
            runCatching {
                AppSettings.load(ctx)
                if (AppSettings.bgMode && !alive)
                    ctx.applicationContext.startForegroundService(
                        Intent(ctx.applicationContext, OverlayService::class.java).setAction(ACTION_RESTORE))
            }
        }
    }
    private var overlayJob: Job? = null
    private var notifExpanded = false   // panah di kartu notifikasi: true = kartu diperluas di tempat (isi lengkap tampil di dalam notifikasi)
    private var housekeeping = false
    private var box: TextView? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob() + CoroutineExceptionHandler { _, e ->
        android.util.Log.e("PulseMonitor", "Coroutine overlay gagal", e)
    })
    override fun onBind(i: Intent?): IBinder? = null

    // Layar menyala/mati: pisahkan laju kuras Active vs Idle, dan segarkan notifikasi
    private var screenRx: BroadcastReceiver? = null
    private var batteryRx: BroadcastReceiver? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    /** Latar bulat dengan garis tepi opsional; dipakai kartu panel dan pemilih gaya. */
    private fun shape(c: Int, r: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(c); cornerRadius = dp(r).toFloat(); if (stroke != null) setStroke(dp(1), stroke)
    }

    /** Notifikasi dengan tombol Mulai/Berhenti rekam, supaya bisa dikendalikan dari dalam game. */
    private fun buildNotif(): Notification {
        val rec = Recorder.active.value
        val pi = PendingIntent.getService(this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_REC),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val tap = PendingIntent.getService(this, 2, Intent(this, OverlayService::class.java).setAction(ACTION_PANEL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val expandPi = PendingIntent.getService(this, 3, Intent(this, OverlayService::class.java).setAction(ACTION_EXPAND),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val act = Notification.Action.Builder(
            android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_media_play),
            if (rec) "Berhenti rekam" else "Mulai rekam", pi).build()
        val b = runCatching { BatteryStats.tick() }.getOrNull()
        val head = if (rec) "● Merekam FPS" else "Pulse Monitor"
        val fallback = b?.line2 ?: (if (box != null) "Overlay aktif" else "Berjalan di latar belakang")
        val nb = Notification.Builder(this, "ov").setSmallIcon(R.drawable.ic_stat_pulse).setColor(0xFFFFFFFF.toInt())
            .setContentTitle(head).setContentText(fallback)      // cadangan untuk tampilan yang tidak mendukung layout kustom
            .setOnlyAlertOnce(true).setShowWhen(false).setContentIntent(tap).setOngoing(true)
        if (b == null) nb.addAction(act)
        if (b != null) {
            // Ringkas: persen besar + status/suhu + arus/daya. Diperluas: bilah, angka utama, Screen On/Off, laju kuras.
            val pctTxt = if (b.pct >= 0) "${b.pct}%" else "-"
            val statusLine = (if (rec) "● Merekam FPS • " else "") + b.status
            val subLine = listOf(b.current, b.power, b.temp).filter { it != "-" }.joinToString(" • ").ifEmpty { "-" }
            // Dua bitmap sesuai bentuk layout (ringkas = pita lebar, diperluas = hampir persegi) supaya gambar memenuhi kartu
            val wallSmall = if (AppSettings.notifWall) runCatching { WallpaperStore.notifBitmap(this, false) }.getOrNull() else null
            val wall = if (AppSettings.notifWall) runCatching { WallpaperStore.notifBitmap(this, true) }.getOrNull() else null
            // Dengan wallpaper: tombol rekam dipindah ke dalam gambar (area tombol sistem tidak bisa diberi gambar)
            if (wall == null) nb.addAction(act)
            fun android.widget.RemoteViews.paintWall(bmp: Bitmap?, chev: Boolean = true) {
                if (bmp != null) {
                    setImageViewBitmap(R.id.n_bg, bmp); setViewVisibility(R.id.n_bg, View.VISIBLE)
                    // Tanpa header sistem, jadi ikon + nama aplikasi digambar sendiri di atas gambar (mirip tampilan polosan)
                    setViewVisibility(R.id.n_appicon, View.VISIBLE); setViewVisibility(R.id.n_hdr, View.VISIBLE)
                    setViewVisibility(R.id.n_chev, if (chev) View.VISIBLE else View.GONE)
                    setOnClickPendingIntent(R.id.n_chev, expandPi)
                    // Akar layout diperlebar keluar ke area padding yang dipakai ROM (HyperOS), supaya gambar menutup bingkai gelap.
                    // Isi digeser balik lewat padding sebesar luberan itu, jadi posisi teks tidak berubah.
                    val bleed = if (Build.VERSION.SDK_INT >= 31) BLEED_DP else 0
                    if (bleed > 0) for (m in intArrayOf(android.widget.RemoteViews.MARGIN_LEFT, android.widget.RemoteViews.MARGIN_TOP,
                            android.widget.RemoteViews.MARGIN_RIGHT, android.widget.RemoteViews.MARGIN_BOTTOM))
                        setViewLayoutMargin(R.id.n_root, m, -bleed.toFloat(), android.util.TypedValue.COMPLEX_UNIT_DIP)
                    setViewPadding(R.id.n_content, dp(12 + bleed), dp(8 + bleed), dp(12 + bleed), dp(8 + bleed))
                } else { setViewVisibility(R.id.n_bg, View.GONE); setViewVisibility(R.id.n_appicon, View.GONE); setViewVisibility(R.id.n_hdr, View.GONE); setViewVisibility(R.id.n_chev, View.GONE) }
            }
            val small = android.widget.RemoteViews(packageName, R.layout.notif_collapsed).apply {
                paintWall(wallSmall)
                setTextViewText(R.id.n_pct, pctTxt)
                setTextViewText(R.id.n_title, statusLine)
                setTextViewText(R.id.n_sub, subLine)
            }
            // Layout lengkap. Dipakai untuk tampilan diperluas bawaan sistem, dan (saat panah ditekan) juga sebagai isi kartu ringkas,
            // jadi kartu membesar di tempat di dalam panel notifikasi. Panah (naik) hanya tampil bila diperluas lewat panah.
            fun makeBig(withChev: Boolean) = android.widget.RemoteViews(packageName, R.layout.notif_expanded).apply {
                paintWall(wall, withChev)
                setTextViewText(R.id.n_pct, pctTxt)
                setTextViewText(R.id.n_title, (if (rec) "● Merekam FPS • " else "") + b.status)
                setProgressBar(R.id.n_bar, 100, b.pct.coerceAtLeast(0), false)
                setTextViewText(R.id.n_cur, b.current); setTextViewText(R.id.n_pow, b.power); setTextViewText(R.id.n_tmp, b.temp)
                setTextViewText(R.id.n_on, b.screenOn); setTextViewText(R.id.n_on_d, b.screenOnDetail)
                setTextViewText(R.id.n_off, b.screenOff); setTextViewText(R.id.n_off_d, b.screenOffDetail)
                setTextViewText(R.id.n_rate, "Aktif ${b.activeRate}  •  Diam ${b.idleRate}")
                setTextViewText(R.id.n_sleep, "Tidur lelap ${b.deep}  •  Terjaga ${b.awake}")
                if (wall != null) {
                    setViewVisibility(R.id.n_rec, View.VISIBLE)
                    setTextViewText(R.id.n_rec, if (rec) "Berhenti rekam" else "Mulai rekam")
                    setOnClickPendingIntent(R.id.n_rec, pi)
                } else setViewVisibility(R.id.n_rec, View.GONE)
            }
            val expandedInPlace = notifExpanded && wall != null
            val big = makeBig(false)
            // Diperluas lewat panah: HyperOS memotong kartu ringkas di tinggi tertentu, jadi isinya dipadatkan (semua info, satu kartu)
            // supaya muat. Tampilan lengkap besar tetap dipakai saat sistem sendiri memperluas notifikasi (tarik ke bawah).
            fun makeDense() = android.widget.RemoteViews(packageName, R.layout.notif_dense).apply {
                val bmp = wallSmall ?: wall
                if (bmp != null) { setImageViewBitmap(R.id.n_bg, bmp); setViewVisibility(R.id.n_bg, View.VISIBLE) }
                setViewPadding(R.id.n_content, dp(12), dp(7), dp(12), dp(7))
                setTextViewText(R.id.n_pct, pctTxt)
                setTextViewText(R.id.n_title, (if (rec) "● Merekam FPS • " else "") + b.status)
                setProgressBar(R.id.n_bar, 100, b.pct.coerceAtLeast(0), false)
                setTextViewText(R.id.n_cur, b.current); setTextViewText(R.id.n_pow, b.power); setTextViewText(R.id.n_tmp, b.temp)
                setTextViewText(R.id.n_on, b.screenOn); setTextViewText(R.id.n_off, b.screenOff)
                setTextViewText(R.id.n_rate, "Aktif ${b.activeRate} • Diam ${b.idleRate} • Tidur lelap ${b.deep} • Terjaga ${b.awake}")
                setTextViewText(R.id.n_rec, if (rec) "Berhenti rekam" else "Mulai rekam")
                setOnClickPendingIntent(R.id.n_rec, pi)
                setOnClickPendingIntent(R.id.n_chev, expandPi)
            }
            // PERCOBAAN full-bleed: tanpa DecoratedCustomViewStyle, sebagian ROM (MIUI/HyperOS) menampilkan view kustom penuh
            // tanpa header sistem, jadi wallpaper menutupi seluruh kartu. Bila hasilnya jelek/terpotong, ubah FULL_BLEED_TEST jadi false.
            if (!(FULL_BLEED_TEST && wall != null)) nb.setStyle(Notification.DecoratedCustomViewStyle())
            nb.setCustomContentView(if (expandedInPlace) makeDense() else small).setCustomBigContentView(big)
            // Wallpaper "full": warnai seluruh kartu (header + tombol) dengan warna wallpaper, bukan hanya area custom view
            if (wall != null) WallpaperStore.notifColor(this)?.let { nb.setColor(it).setColorized(true) }
        }
        return nb.build()
    }

    /** Notifikasi paling sederhana, tanpa baterai/RemoteViews. Dipakai untuk startForeground supaya tidak pernah gagal. */
    private fun safeNotif(): Notification =
        Notification.Builder(this, "ov").setSmallIcon(R.drawable.ic_stat_pulse)
            .setContentTitle("Pulse Monitor").setContentText("Berjalan di latar belakang")
            .setOnlyAlertOnce(true).setShowWhen(false).setOngoing(true).build()

    /**
     * Pasang notifikasi lengkap sebagai notifikasi layanan latar depan itu sendiri (startForeground ulang dengan id sama),
     * bukan hanya notify() biasa. Pewarnaan kartu (setColorized dengan warna rata-rata gambar) hanya berlaku penuh untuk
     * notifikasi layanan latar depan, jadi ini memberi peluang bingkai gelap buatan sistem ikut berwarna seperti gambar.
     * Gagal = cukup jatuh ke notify() biasa.
     */
    private fun upgradeForeground() {
        val ok = runCatching {
            val n = buildNotif()
            if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
        }.isSuccess
        if (!ok) refreshNotif()
    }

    private fun refreshNotif() {
        runCatching { getSystemService(NotificationManager::class.java).notify(1, buildNotif()) }
            .onFailure { android.util.Log.e("PulseMonitor", "Notifikasi gagal", it) }
    }

    // Panah di kartu notifikasi: ACTION_EXPAND membalik notifExpanded, lalu notifikasi dipasang ulang. Saat diperluas, isi lengkap
    // menggantikan kartu ringkas di dalam panel notifikasi itu sendiri (PendingIntent layanan tidak menutup panel).

    private fun toggleRec() {
        if (Recorder.active.value) {
            scope.launch {
                val r = withContext(Dispatchers.IO) { Recorder.stop(this@OverlayService) }
                Toast.makeText(this@OverlayService, if (r != null) "Rekaman tersimpan" else "Tidak ada data FPS yang terekam\n${Recorder.lastFail}", if (r != null) Toast.LENGTH_SHORT else Toast.LENGTH_LONG).show()
                refreshNotif(); updateSampler()
            }
        } else {
            Sampler.init(this); Sampler.start()
            Sampler.onRecordStart()
            Recorder.start()
            // Tutup panel notifikasi supaya game kembali di depan dan tidak ikut menurunkan FPS
            scope.launch(Dispatchers.IO) { runCatching { Shell.exec("cmd statusbar collapse") } }
            Toast.makeText(this, "Mulai merekam FPS", Toast.LENGTH_SHORT).show()
            refreshNotif()
        }
    }


    // ---------- Panel kontrol (muncul saat notifikasi diketuk) ----------
    private var panel: View? = null
    private var panelJob: Job? = null
    private var boxLp: WindowManager.LayoutParams? = null
    private var panelClosedAt = 0L

    private fun closePanel() {
        if (panel != null) panelClosedAt = android.os.SystemClock.elapsedRealtime()
        panelJob?.cancel(); panelJob = null
        panel?.let { v -> runCatching { getSystemService(WindowManager::class.java).removeView(v) } }
        panel = null
    }

    private fun togglePanel() { if (panel != null) closePanel() else openPanel() }

    /** Kartu kecil di bawah overlay (atau di atasnya bila mepet bawah layar): pilih gaya overlay dengan satu ketukan. */
    private fun toggleStylePicker() {
        if (panel != null) { closePanel(); return }
        val wm = getSystemService(WindowManager::class.java)
        val acc = AppSettings.accent
        val base = 0xFF2B2C35.toInt(); val light = 0xFFEDEDF2.toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(10), dp(10), dp(4)); minimumWidth = dp(170)
            background = shape(0xFF14151C.toInt(), 18, withAlpha(acc, 33))
        }
        root.addView(TextView(this).apply {
            text = "Gaya overlay"; textSize = 12f; setTextColor(acc); typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(4), 0, 0, dp(8))
        })
        AppSettings.STYLES.forEachIndexed { idx, name ->
            val sel = AppSettings.overlayStyle == idx
            root.addView(TextView(this).apply {
                text = name; textSize = 14f; setTextColor(if (sel) acc else light); gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(10), dp(14), dp(10))
                background = if (sel) shape(withAlpha(acc, 28), 12, acc) else shape(base, 12)
                setOnClickListener { AppSettings.overlayStyle = idx; AppSettings.save(this@OverlayService); closePanel() }
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(6) }
            })
        }
        // Saklar cepat touch: ketuk untuk nyala/mati tanpa keluar dari game
        fun toggleRow(label: String, get: () -> Boolean, set: (Boolean) -> Unit) {
            val tv = TextView(this).apply {
                textSize = 14f; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(10), dp(14), dp(10))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(6) }
            }
            fun paintRow() {
                val on = get()
                tv.text = label + (if (on) "  ·  ON" else "  ·  OFF")
                tv.setTextColor(if (on) acc else light)
                tv.background = if (on) shape(withAlpha(acc, 28), 12, acc) else shape(base, 12)
            }
            tv.setOnClickListener { set(!get()); AppSettings.save(this@OverlayService); paintRow() }
            paintRow(); root.addView(tv)
        }
        root.addView(TextView(this).apply {
            text = "Touch"; textSize = 12f; setTextColor(acc); typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(4), dp(6), 0, dp(8))
        })
        toggleRow("Touch ms", { AppSettings.touchLat }) { on -> AppSettings.touchLat = on; if (!on) TouchLatency.reset() }
        toggleRow("Touch Hz", { AppSettings.touchRate }) { on -> AppSettings.touchRate = on }
        val dm = resources.displayMetrics
        val l = boxLp
        val estH = dp(176 + 130)
        var px = (l?.x ?: dp(12)).coerceIn(0, maxOf(0, dm.widthPixels - dp(170)))
        var py = (l?.y ?: dp(40)) + (box?.height ?: dp(30)) + dp(6)
        if (py + estH > dm.heightPixels) py = maxOf(0, (l?.y ?: dp(40)) - estH - dp(6))
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = px; y = py }
        root.setOnTouchListener { _, e -> if (e.actionMasked == MotionEvent.ACTION_OUTSIDE) { closePanel(); true } else false }
        if (runCatching { wm.addView(root, lp) }.isFailure) return
        panel = root
    }

    /** Kartu mengambang: pilih Gaya overlay (Simple/Compact/Normal) dan Rekam FPS tanpa keluar dari game. */
    private fun openPanel() {
        val wm = getSystemService(WindowManager::class.java)
        val acc = AppSettings.accent
        val base = 0xFF2B2C35.toInt(); val light = 0xFFEDEDF2.toInt()
        fun txt(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
        }
        fun btn(label: String, onClick: () -> Unit) = TextView(this).apply {
            text = label; textSize = 14f; setTextColor(light); gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12)); background = shape(base, 14); setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(6))
            background = shape(0xFF14151C.toInt(), 22, withAlpha(acc, 33))
        }
        // Kepala: judul + status, tombol tutup
        val sub = txt("", 13f, acc)
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(txt("Pulse Monitor", 13f, acc, true)); titles.addView(sub)
        head.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(txt("✕", 20f, acc).apply { setPadding(dp(10), dp(4), dp(4), dp(4)); setOnClickListener { closePanel() } })
        root.addView(head)

        // Ringkasan baterai langsung di panel (satu ketukan di notifikasi), diperbarui tiap 2 detik selama panel terbuka
        val batt = txt("", 11.5f, light).apply {
            typeface = Typeface.MONOSPACE; setPadding(dp(12), dp(8), dp(12), dp(8)); background = shape(0xFF1E1F27.toInt(), 14)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) }
        }
        fun battText() { BatteryStats.tick()?.let { b -> batt.text = "${b.status}\n${b.line2}\n${b.line3}\n${b.line4}" } }
        battText()
        root.addView(batt)

        // Kiri: gaya overlay
        val left = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(0)); background = shape(0xFF1E1F27.toInt(), 16)
        }
        left.addView(txt("Gaya overlay", 11f, withAlpha(light, 65)).apply { setPadding(dp(6), 0, 0, dp(6)) })
        var paint: () -> Unit = {}
        val styleBtns = AppSettings.STYLES.mapIndexed { idx, name ->
            btn(name) { AppSettings.overlayStyle = idx; AppSettings.save(this); paint() }
        }
        styleBtns.forEach { left.addView(it) }
        paint = {
            styleBtns.forEachIndexed { idx, b ->
                val sel = AppSettings.overlayStyle == idx
                b.background = if (sel) shape(withAlpha(acc, 28), 14, acc) else shape(base, 14)
                b.setTextColor(if (sel) acc else light)
            }
            sub.text = "Gaya: " + AppSettings.STYLES[AppSettings.overlayStyle]
        }
        paint()

        // Kanan: rekam FPS + buka aplikasi
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), 0, 0, 0) }
        val rec = btn("") { togglePanelRec() }.apply { gravity = Gravity.CENTER; background = shape(0xFF1E1F27.toInt(), 14) }
        val open = btn("Buka app") {
            closePanel()
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }.apply { gravity = Gravity.CENTER; background = shape(0xFF1E1F27.toInt(), 14) }
        // Nyalakan / matikan overlay tanpa membuka aplikasi
        val on = box != null
        val ovBtn = btn(if (on) "Matikan overlay" else "Nyalakan overlay") { closePanel(); setOverlay(!on) }
            .apply { gravity = Gravity.CENTER; background = shape(0xFF1E1F27.toInt(), 14); setTextColor(if (on) 0xFFFF5C5C.toInt() else acc) }
        right.addView(rec); right.addView(ovBtn); right.addView(open)

        val body = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(10), 0, 0) }
        body.addView(left, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        body.addView(right, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(body)

        val dm = resources.displayMetrics
        val lp = WindowManager.LayoutParams(
            minOf(dm.widthPixels - dp(32), dp(340)), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,   // ketuk di luar kartu = tutup
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        root.setOnTouchListener { _, e -> if (e.actionMasked == MotionEvent.ACTION_OUTSIDE) { closePanel(); true } else false }
        if (runCatching { wm.addView(root, lp) }.isFailure) return
        panel = root
        // Label tombol rekam mengikuti status rekaman
        panelJob = scope.launch {
            launch { while (isActive) { delay(2000); battText() } }
            Recorder.active.collect { on ->
                rec.text = if (on) "■ Berhenti rekam" else "● Rekam FPS"
                rec.setTextColor(if (on) 0xFFFF5C5C.toInt() else light)
            }
        }
    }

    /**
     * Nyalakan/matikan overlay dari panel. Mati + mode latar belakang nonaktif = layanan berhenti dan notifikasi hilang
     * (sama seperti tombol di layar utama); dengan mode latar belakang, notifikasi tetap ada sehingga bisa dinyalakan lagi.
     */
    private fun setOverlay(on: Boolean) {
        val prefs = getSharedPreferences("overlay", MODE_PRIVATE)
        if (on) {
            if (box == null && (!Settings.canDrawOverlays(this) || !showOverlay())) {
                Toast.makeText(this, "Izin tampil di atas aplikasi lain belum diberikan", Toast.LENGTH_SHORT).show()
                return
            }
        } else hideOverlay()
        prefs.edit().putBoolean("shown", box != null).apply()
        overlayShown.value = box != null
        if (box == null && !AppSettings.bgMode) { stopSelf(); return }
        updateSampler(); refreshNotif()
    }

    /** Mulai/berhenti rekam dari panel; kartu ditutup supaya tidak menutupi game. */
    private fun togglePanelRec() { toggleRec(); closePanel() }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        alive = true
        // 1) Channel + startForeground SEGERA dengan notifikasi sederhana (batas waktu sistem ~10 detik, dan tidak boleh melempar error)
        runCatching {
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(NotificationChannel("ov", "Overlay", NotificationManager.IMPORTANCE_LOW))
        }
        val first = safeNotif()
        val fgOk = runCatching {
            // Tipe specialUse baru ada di API 34; di bawahnya pakai versi 2 argumen
            if (Build.VERSION.SDK_INT >= 34) startForeground(1, first, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            else startForeground(1, first)
        }.onFailure { android.util.Log.e("PulseMonitor", "startForeground gagal", it) }.isSuccess
        if (!fgOk) { overlayShown.value = false; stopSelf(); return START_NOT_STICKY }

        // 2) Sisanya dibungkus: error apa pun hanya mematikan layanan dengan pesan, bukan force close
        return try {
            BatteryStats.init(this); AppSettings.load(this); Sampler.init(this)
            if (i?.action == ACTION_REC) toggleRec()
            if (i?.action == ACTION_EXPAND) notifExpanded = !notifExpanded   // harus sebelum upgradeForeground() di bawah
            val prefs = getSharedPreferences("overlay", MODE_PRIVATE)
            // Intent kosong = layanan dihidupkan ulang sistem: ikuti keadaan terakhir. REC/PANEL tidak mengubah keadaan overlay.
            // Penting: intent biasa dari tombol "Nyalakan Overlay" punya action null, jadi "intent kosong" dicek lewat i == null
            val act = i?.action
            val wantOverlay = when {
                act == ACTION_RESTORE -> prefs.getBoolean("shown", false)
                i == null -> prefs.getBoolean("shown", true)
                act == ACTION_HIDE -> false
                act == ACTION_REC || act == ACTION_PANEL || act == ACTION_EXPAND -> if (housekeeping) box != null else prefs.getBoolean("shown", true)
                else -> true
            }
            if (wantOverlay && box == null) {
                // Izin overlay bisa dicabut kapan saja; addView akan crash tanpa pengecekan ini
                if (!Settings.canDrawOverlays(this) || !showOverlay()) { overlayShown.value = false; stopSelf(); return START_NOT_STICKY }
            } else if (!wantOverlay && box != null) hideOverlay()
            // Tanpa overlay dan tanpa mode latar belakang, tidak ada alasan layanan tetap hidup (notifikasi ikut hilang)
            if (box == null && !AppSettings.bgMode) { overlayShown.value = false; stopSelf(); return START_NOT_STICKY }
            prefs.edit().putBoolean("shown", box != null).apply()
            overlayShown.value = box != null
            startHousekeeping()
            updateSampler()
            upgradeForeground()     // ganti notifikasi sederhana dengan versi lengkap (bila gagal, yang sederhana tetap tampil)
            if (i?.action == ACTION_PANEL) togglePanel()
            START_STICKY
        } catch (e: Throwable) {
            android.util.Log.e("PulseMonitor", "Overlay gagal dinyalakan", e)
            runCatching { Toast.makeText(this, "Overlay gagal: ${e.javaClass.simpleName}: ${e.message}", Toast.LENGTH_LONG).show() }
            runCatching { hideOverlay() }
            overlayShown.value = false; stopSelf(); START_NOT_STICKY
        }
    }

    /** Sampler (proses shell tiap detik) hanya jalan bila ada yang memakainya: overlay, rekaman, atau layar utama. */
    private fun updateSampler() {
        if (box != null || Recorder.active.value) { Sampler.init(this); Sampler.start() }
        else if (!Sampler.uiVisible) Sampler.stop()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun showOverlay(): Boolean {
        val wm = getSystemService(WindowManager::class.java)
        val prefs = getSharedPreferences("overlay", MODE_PRIVATE)
        val bg = GradientDrawable().apply {
            setColor(withAlpha(AppSettings.overlayBg, AppSettings.alpha)); cornerRadius = dp(40).toFloat()
            setStroke(dp(1), withAlpha(AppSettings.accent, 33))
        }
        val v = TextView(this).apply {
            typeface = Typeface.MONOSPACE; textSize = 12f; setTextColor(AppSettings.overlayText)
            setSingleLine(true); setPadding(dp(12), dp(5), dp(12), dp(5)); background = bg
        }
        // Tombol menu di ujung kanan overlay: ketuk = pilih gaya overlay
        val menuIcon = MenuIcon(withAlpha(AppSettings.overlayText, 70))
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,   // bisa disentuh (digeser), tidak mencuri fokus; ketukan di luar dipakai ukur latensi sentuh
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = prefs.getInt("x", dp(12)); y = prefs.getInt("y", dp(40)) }
        boxLp = lp

        // Geser: tahan lalu seret; posisi disimpan dan dipakai lagi saat overlay dinyalakan berikutnya
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false; var downOnBtn = false; var longFired = false
        // Tahan overlay ~1 detik tanpa menggeser = mulai/berhenti rekam
        val longPress = Runnable { longFired = true; toggleRec(); v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS) }
        v.setOnTouchListener { view: View, e: MotionEvent ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false; longFired = false
                    // Gaya Compact (1) tanpa ikon menu: seluruh kotak yang diketuk membuka pemilih gaya
                    downOnBtn = AppSettings.overlayStyle != 1 && e.x >= view.width - view.paddingRight - menuIcon.bounds.width() - dp(14)
                    if (!downOnBtn) view.postDelayed(longPress, 1000)
                }
                MotionEvent.ACTION_CANCEL -> view.removeCallbacks(longPress)
                // Ketukan di luar overlay (mis. di game): selang cap waktu driver -> sampai di sini = latensi sentuh
                MotionEvent.ACTION_OUTSIDE -> if (AppSettings.touchLat) TouchLatency.record(android.os.SystemClock.uptimeMillis() - e.eventTime)
                MotionEvent.ACTION_MOVE -> {
                    if (!moved && (Math.abs(e.rawX - tx) > dp(8) || Math.abs(e.rawY - ty) > dp(8))) { moved = true; view.removeCallbacks(longPress) }
                    if (!moved) return@setOnTouchListener true
                    val dm = resources.displayMetrics
                    lp.x = (sx + (e.rawX - tx).toInt()).coerceIn(0, maxOf(0, dm.widthPixels - view.width))
                    lp.y = (sy + (e.rawY - ty).toInt()).coerceIn(0, maxOf(0, dm.heightPixels - view.height))
                    runCatching { wm.updateViewLayout(view, lp) }
                }
                MotionEvent.ACTION_UP -> {
                    view.removeCallbacks(longPress)
                    if (moved) prefs.edit().putInt("x", lp.x).putInt("y", lp.y).apply()
                    // Kartu yang baru saja tertutup oleh ketukan di luar jangan langsung dibuka lagi
                    else if (!longFired && (downOnBtn || AppSettings.overlayStyle == 1) && android.os.SystemClock.elapsedRealtime() - panelClosedAt > 350) toggleStylePicker()
                }
            }
            true
        }
        if (!runCatching { wm.addView(v, lp) }.onFailure { android.util.Log.e("PulseMonitor", "addView overlay gagal", it) }.isSuccess) return false
        box = v
        overlayJob = scope.launch {
            var lastStyle = -1; var lastSize = -1; var lastLines = -1
            kotlinx.coroutines.flow.combine(Sampler.state, TouchMonitor.hz, TouchLatency.state) { a, h, _ ->    // TouchLatency hanya pemicu render ulang
                a.copy(touchHz = if (AppSettings.touchRate) h else -1)
            }.collect { s -> runCatching {
                if (AppSettings.touchRate) TouchMonitor.start() else TouchMonitor.stop()
                val style = AppSettings.overlayStyle; val size = AppSettings.size
                val text = line(s); val lines = text.count { it == '\n' } + 1
                if (style != lastStyle || size != lastSize || lines != lastLines) {   // ganti bentuk, ukuran, atau jumlah baris
                    lastStyle = style; lastSize = size; lastLines = lines
                    val k = size / 100f
                    fun sp(v: Float) = (v * resources.displayMetrics.density * k).toInt()
                    // Simple: satu baris bila muat; bila terlalu panjang untuk lebar layar (BAT/TCH/LAT ikut aktif) turun ke baris berikutnya, tidak lagi terpotong
                    v.setSingleLine(false); v.maxLines = if (style == 0) 3 else Int.MAX_VALUE; v.setHorizontallyScrolling(false)
                    val tight = style == 1   // Compact: kotak kecil tanpa ikon menu (ketuk kotak = pemilih gaya)
                    bg.cornerRadius = sp(if (style == 0) 40f else if (tight) 8f else 9f).toFloat()
                    if (tight) v.setPadding(sp(6f), sp(3f), sp(6f), sp(3f))
                    else v.setPadding(sp(if (style == 0) 12f else 7f), sp(if (style == 0) 5f else 2f), sp(if (style == 0) 12f else 6f), sp(if (style == 0) 5f else 2f))
                    v.setLineSpacing(0f, if (style == 2) 0.9f else 1f)   // Normal: antar baris sedikit dirapatkan
                    v.textSize = (if (style == 0) 12f else if (tight) 11f else 11.5f) * k
                    if (tight) v.setCompoundDrawables(null, null, null, null)
                    else {
                        val ic = sp(14f); menuIcon.iconPx = ic; menuIcon.setBounds(0, 0, ic, maxOf(ic, v.lineHeight * lines)); v.compoundDrawablePadding = sp(5f)
                        v.setCompoundDrawables(null, null, menuIcon, null)
                    }
                }
                menuIcon.color = withAlpha(AppSettings.overlayText, 70); menuIcon.invalidateSelf()
                bg.setColor(withAlpha(AppSettings.overlayBg, AppSettings.alpha))
                // Compact: garis tepi abu-abu netral tipis (seperti di foto); gaya lain tetap memakai warna aksen
                bg.setStroke(dp(1), if (style == 1) withAlpha(AppSettings.overlayText, 14) else withAlpha(AppSettings.accent, 45))
                v.setTextColor(AppSettings.overlayText)
                v.text = text
            }.onFailure { android.util.Log.e("PulseMonitor", "Render overlay gagal", it) } }
        }
        return true
    }

    private fun hideOverlay() {
        overlayJob?.cancel(); overlayJob = null; TouchMonitor.stop(); TouchLatency.reset()
        box?.let { v -> runCatching { getSystemService(WindowManager::class.java).removeView(v) } }
        box = null; boxLp = null
    }

    /** Penerima layar menyala/mati + penyegar notifikasi. Sekali per hidup layanan; jarang saat overlay tersembunyi supaya hemat. */
    private fun startHousekeeping() {
        if (housekeeping) return
        housekeeping = true
        val rx = object : BroadcastReceiver() {
            override fun onReceive(c: Context, intent: Intent) {
                runCatching { BatteryStats.setScreen(intent.action == Intent.ACTION_SCREEN_ON) }; refreshNotif()
            }
        }
        registerReceiver(rx, IntentFilter().apply { addAction(Intent.ACTION_SCREEN_ON); addAction(Intent.ACTION_SCREEN_OFF) })
        screenRx = rx
        // Persen/status/charger berubah: perbarui notifikasi seketika (tanpa menunggu jadwal 3-30 detik), supaya angkanya
        // sama dengan bilah status. Perubahan kecil (arus, tegangan, suhu) dibatasi 2,5 detik saat layar nyala.
        val brx = object : BroadcastReceiver() {
            private var lastKey = ""; private var lastAt = 0L
            override fun onReceive(c: Context, intent: Intent) {
                val key = "${intent.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1)}|" +
                    "${intent.getIntExtra(android.os.BatteryManager.EXTRA_STATUS, 0)}|${intent.getIntExtra(android.os.BatteryManager.EXTRA_PLUGGED, 0)}"
                val now = android.os.SystemClock.elapsedRealtime()
                if (key != lastKey || (BatteryStats.isScreenOn() && now - lastAt > 2500L)) { lastKey = key; lastAt = now; refreshNotif() }
            }
        }
        registerReceiver(brx, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        batteryRx = brx
        scope.launch {
            while (isActive) {
                val on = BatteryStats.isScreenOn()
                if (on) refreshNotif() else runCatching { BatteryStats.tick() }
                // overlay tampil: 3 dtk; tersembunyi: 5 dtk (layar nyala) / 30 dtk (layar mati)
                delay(if (box != null) 3000L else if (on) 5000L else 30_000L)
            }
        }
    }

    private fun muted() = withAlpha(AppSettings.overlayText, 65)
    private val YEL = 0xFFFFD866.toInt()   // frametime, MHz, watt (semua gaya)

    private class B(val sb: SpannableStringBuilder = SpannableStringBuilder()) {
        fun put(t: String, color: Int? = null, bold: Boolean = false): B {
            val st = sb.length; sb.append(t)
            if (color != null) sb.setSpan(ForegroundColorSpan(color), st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            if (bold) sb.setSpan(StyleSpan(Typeface.BOLD), st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            return this
        }
        fun temp(t: Float) = if (t >= 0) put("%.0f°".format(t)) else put("-")
        fun nl() = put("\n")
    }

    // Kolom monospace sejajar: LABEL(4) NILAI(5) 2sp SUHU(4) 2sp EKSTRA(8)
    private fun B.tcol(t: Float): B = if (t >= 0) put("%.0f°".format(t).padEnd(4)) else put("-".padEnd(4))
    private fun B.lab(t: String): B = glab(t).put("\u00A0")
    /** Label gradasi biru -> pink (dominan pink), dihitung per huruf supaya benar di posisi mana pun (awal atau tengah baris). */
    private fun B.glab(t: String): B {
        val from = 0xFF8FA6F5.toInt(); val to = 0xFFFF6FB1.toInt()
        fun mix(a: Int, b: Int, f: Float) = ((a ushr 16 and 255) + ((b ushr 16 and 255) - (a ushr 16 and 255)) * f).toInt() shl 16 or
            (((a ushr 8 and 255) + ((b ushr 8 and 255) - (a ushr 8 and 255)) * f).toInt() shl 8) or
            ((a and 255) + ((b and 255) - (a and 255)) * f).toInt() or (0xFF shl 24)
        t.forEachIndexed { i, ch -> put(ch.toString(), mix(from, to, if (t.length > 1) i / (t.length - 1f) else 1f)) }
        return this
    }
    private fun B.v(t: String): B = put(t.padStart(5))

    private fun head(b: B, s: Snap, ms: Boolean, aligned: Boolean = false): B {
        if (!aligned && Recorder.active.value) b.put("● ", 0xFFFF5C5C.toInt())
        b.glab("FPS").put("\u00A0")
        if (aligned) b.put("${s.fps}".padStart(5), null, true) else b.put("${s.fps}", null, true)
        if (s.idle) b.put(if (aligned) "  idle" else " idle", YEL)          // layar statis: angka = refresh rate layar
        else if (ms && s.fps > 0) b.put("  %.1f ms".format(1000f / s.fps), YEL)
        if (aligned && Recorder.active.value) b.put("  ●", 0xFFFF5C5C.toInt())   // Normal: titik rekam di ujung kanan, kolom tetap lurus
        return b
    }

    private fun latNow() = if (AppSettings.touchLat) TouchLatency.state.value else null

    /** Latensi sentuh: hijau rapat, kuning sedang, oranye lambat, merah buruk. */
    private fun latColor(ms: Int) = when {
        ms <= 8 -> 0xFF7CFFB2.toInt(); ms <= 16 -> 0xFFFFD866.toInt(); ms <= 32 -> 0xFFFF9F43.toInt(); else -> 0xFFFF5C5C.toInt()
    }


    private fun mhz(v: Int) = if (v >= 0) "$v MHz" else ""
    private fun watt(w: Float) = if (w >= 0f) "%.1f W".format(w) else ""

    /** Simple: satu baris, label redup + nilai terang. FPS 60  CPU 35% 42°  GPU 45% 41°  RAM 62%  BAT 85% 36°  LAT 8ms */
    private fun simple(s: Snap): CharSequence {
        val b = B(); head(b, s, false)
        b.put("  ").lab("CPU").put(pct(s.cpu) + "\u00A0").temp(s.tCpu)
        b.put("  ").lab("GPU").put(pct(s.gpu) + "\u00A0").temp(s.tGpu)
        b.put("  ").lab("RAM").put(pct(s.ramPct))
        b.put("  ").lab("BAT")
        if (s.batPct >= 0) b.put("${s.batPct}%\u00A0").temp(s.tBat) else b.temp(s.tBat)
        if (s.touchHz >= 0) b.put("  ").lab("TCH").put(if (s.touchHz > 0) "${s.touchHz}" else "-")
        if (AppSettings.touchLat) {
            b.put("  ").lab("LAT")
            val l = latNow()
            if (l != null) b.put("${l.last}", latColor(l.last)).put("ms", muted()) else b.put("-")
        }
        return b.sb
    }

    /**
     * Compact: kotak kecil ala monitor game. Label berwarna (gradasi biru ke pink), nilai putih, kolom sejajar:
     *   LABEL(3) 2sp NILAI(4) 2sp SUHU(4) 2sp EKSTRA(MHz / W / ms)
     *   FPS  60    16.7ms
     *   CPU  35%   42°   2840 MHz    + bilah beban tipis di bawahnya
     *   GPU  45%   41°    680 MHz    + bilah beban tipis di bawahnya
     *   RAM  62%
     *   BAT  85%   36°   2.4W
     *   TCH  0 Hz                    (hanya bila Touch Hz aktif; LAT juga, bila Touch ms aktif)
     */
    private fun compact(s: Snap): CharSequence {
        val b = B(); val gap = "  "
        // FPS + frametime (sejajar kolom suhu); titik merah di ujung kanan saat merekam
        b.glab("FPS").put(gap).put("${s.fps}".padEnd(4)).put(gap)
        if (s.idle) b.put("idle", YEL) else if (s.fps > 0) b.put("%.1fms".format(1000f / s.fps), YEL)
        if (Recorder.active.value) b.put(gap).put("●", 0xFFFF5C5C.toInt())
        b.nl()
        // CPU dan GPU: baris + garis tipis beban (bar) di bawahnya
        val k = AppSettings.size / 100f
        val barPx = maxOf(2, (dp(5) * k / 2f).toInt()); val padPx = maxOf(1, (dp(1) * k).toInt())
        fun row(name: String, p: Int, t: Float, f: Int) {
            val st = b.sb.length
            b.glab(name).put(gap).put(pct(p).padEnd(4)).put(gap).put(deg(t).padEnd(4))
            if (f >= 0) b.put(gap).put("$f".padStart(4) + " MHz", YEL)
            b.nl()
            if (p >= 0) b.sb.setSpan(BarSpan(p, loadCol(p), withAlpha(AppSettings.overlayText, 16), barPx, padPx), st, b.sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        row("CPU", s.cpu, s.tCpu, s.cpuMhz)
        row("GPU", s.gpu, s.tGpu, s.gpuMhz)
        b.glab("RAM").put(gap).put(pct(s.ramPct)).nl()
        b.glab("BAT").put(gap).put(pct(s.batPct).padEnd(4)).put(gap).put(deg(s.tBat).padEnd(4))
        if (s.watt >= 0f) b.put(gap).put("%.1fW".format(s.watt), YEL)
        if (s.touchHz >= 0) b.nl().glab("TCH").put(gap).put("${s.touchHz} Hz")
        if (AppSettings.touchLat) {
            b.nl().glab("LAT").put(gap)
            val l = latNow()
            if (l != null) b.put("${l.last}", latColor(l.last)).put(" ms") else b.put("-")
        }
        return b.sb
    }

    /**
     * Normal: paling lengkap, grid tetap (monospace):
     *   KOL 1  LABEL(3) + spasi
     *   KOL 2  NILAI rata kanan (5)
     *   KOL 3  teks rata kiri (idle / LOW / suhu / RAM / satuan), mulai di kolom yang sama di semua baris
     *   KOL 4  MHz rata kanan (8)
     * Satuan (W, Hz, ms) dipindah ke KOL 3 supaya angkanya tetap sejajar dengan baris lain.
     */
    private fun normal(s: Snap): CharSequence {
        val b = B(); val gap = "  "
        head(b, s, true, true).nl()
        b.lab("AVG").v("${s.avg}").put(gap).glab("LOW").put(" ${s.low}").nl()
        // CPU dan GPU: baris + garis tipis beban di bawahnya (sama seperti gaya Compact)
        val k = AppSettings.size / 100f
        val barPx = maxOf(2, (dp(5) * k / 2f).toInt()); val padPx = maxOf(1, (dp(1) * k).toInt())
        fun loadRow(name: String, p: Int, t: Float, f: Int) {
            val st = b.sb.length
            b.lab(name).v(pct(p)).put(gap).tcol(t).put(gap + mhz(f).padStart(8), YEL).nl()
            if (p >= 0) b.sb.setSpan(BarSpan(p, loadCol(p), withAlpha(AppSettings.overlayText, 16), barPx, padPx), st, b.sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        loadRow("CPU", s.cpu, s.tCpu, s.cpuMhz)
        loadRow("GPU", s.gpu, s.tGpu, s.gpuMhz)
        // RAM & SWP: garis miring dibuat sejajar
        val ramP = s.ramText.split(" / ", limit = 2); val swpP = s.swapText.split(" / ", limit = 2)
        val lw = maxOf(ramP[0].length, if (s.swapText.isNotEmpty()) swpP[0].length else 0)
        // total (mis. "12 GB", "6,4 GB") berwarna kuning
        fun mem(p: List<String>, raw: String) {
            if (p.size == 2) { b.put(gap + p[0].padStart(lw) + " / "); b.put(p[1], YEL) } else b.put(gap + raw)
        }
        b.lab("RAM").v(pct(s.ramPct)); mem(ramP, s.ramText); b.nl()
        if (s.swapText.isNotEmpty()) { b.lab("SWP").v(""); mem(swpP, s.swapText); b.nl() }
        b.lab("BAT").v(if (s.batPct >= 0) "${s.batPct}%" else "-").put(gap).tcol(s.tBat).nl()
        b.lab("PWR")
        if (s.watt >= 0f) b.put("%.1f".format(s.watt).padStart(5), YEL).put(gap + "W", YEL) else b.v("-")
        if (s.touchHz >= 0) {
            b.nl().lab("TCH")
            if (s.touchHz > 0) b.v("${s.touchHz}").put(gap + "Hz", YEL) else b.v("-")
        }
        if (AppSettings.touchLat) {
            b.nl().lab("LAT")
            val l = latNow()
            if (l != null) b.put("${l.last}".padStart(5), latColor(l.last)).put(gap + "ms", muted()).put("  avg ${l.avg}", muted())
            else b.v("-")
        }
        if (s.pkg.isNotEmpty()) b.nl().put(s.pkg, muted())
        return b.sb
    }

    private fun line(s: Snap): CharSequence = when (AppSettings.overlayStyle) { 1 -> compact(s); 2 -> normal(s); else -> simple(s) }

    /**
     * Aplikasi di-swipe dari recents. Sebagian ROM (MIUI/HyperOS, dll.) mematikan proses sekaligus layanannya dan
     * START_STICKY saja tidak selalu menghidupkannya lagi, jadi jadwalkan alarm untuk memulihkan layanan + notifikasi.
     */
    override fun onTaskRemoved(rootIntent: Intent?) {
        AppSettings.load(this)
        if (AppSettings.bgMode || box != null) scheduleRestore(this, 1500L)
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        closePanel()
        screenRx?.let { runCatching { unregisterReceiver(it) } }; screenRx = null
        batteryRx?.let { runCatching { unregisterReceiver(it) } }; batteryRx = null
        TouchMonitor.stop()
        scope.cancel(); box?.let { v -> runCatching { getSystemService(WindowManager::class.java).removeView(v) } }; box = null
        overlayShown.value = false; alive = false; housekeeping = false
        if (!Sampler.uiVisible && !Recorder.active.value) Sampler.stop()
        super.onDestroy()
    }
}

fun heat(t: Float) = when {
    t < 45f -> 0xFF7CFFB2.toInt()     // aman
    t < 55f -> 0xFFFFD866.toInt()     // hangat
    t < 65f -> 0xFFFF9F43.toInt()     // panas
    else -> 0xFFFF5C5C.toInt()        // sangat panas
}
fun deg(v: Float) = if (v >= 0) "%.0f°".format(v) else "-"
fun pct(v: Int) = if (v >= 0) "$v%" else "-"

/** Warna beban: hijau rendah, kuning sedang, oranye tinggi, merah sangat tinggi. */
fun loadCol(p: Int) = when {
    p < 50 -> 0xFF7CFFB2.toInt(); p < 75 -> 0xFFFFD866.toInt(); p < 90 -> 0xFFFF9F43.toInt(); else -> 0xFFFF5C5C.toInt()
}

/** Garis tipis di bawah satu baris teks (overlay Compact): tinggi baris ditambah sedikit, lalu garis latar + garis isi sesuai persen. */
private class BarSpan(val pct: Int, val color: Int, val track: Int, val barPx: Int, val padPx: Int) :
    android.text.style.LineHeightSpan, android.text.style.LineBackgroundSpan {
    override fun chooseHeight(text: CharSequence, start: Int, end: Int, spanstartv: Int, lineHeight: Int, fm: android.graphics.Paint.FontMetricsInt) {
        fm.descent += barPx + padPx; fm.bottom += barPx + padPx
    }
    override fun drawBackground(c: android.graphics.Canvas, p: android.graphics.Paint, left: Int, right: Int, top: Int, baseline: Int, bottom: Int,
                                text: CharSequence, start: Int, end: Int, lnum: Int) {
        val q = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        val r = barPx / 2f; val y0 = (bottom - barPx).toFloat(); val y1 = bottom.toFloat()
        q.color = track; c.drawRoundRect(left.toFloat(), y0, right.toFloat(), y1, r, r, q)
        q.color = color; c.drawRoundRect(left.toFloat(), y0, left + (right - left) * pct.coerceIn(0, 100) / 100f, y1, r, r, q)
    }
}

/** Warna teks gradasi horizontal selebar label (dipakai label overlay Compact). */
private class GradSpan(val label: String, val from: Int, val to: Int) : android.text.style.CharacterStyle() {
    override fun updateDrawState(tp: android.text.TextPaint) {
        tp.shader = android.graphics.LinearGradient(0f, 0f, tp.measureText(label), 0f, from, to, android.graphics.Shader.TileMode.CLAMP)
    }
}

/** Ikon menu tiga garis, digambar manual supaya mengikuti warna teks overlay. */
private class MenuIcon(var color: Int, var iconPx: Int = 0) : android.graphics.drawable.Drawable() {
    private val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        style = android.graphics.Paint.Style.STROKE; strokeCap = android.graphics.Paint.Cap.ROUND
    }
    override fun draw(c: android.graphics.Canvas) {
        val b = bounds; val w = b.width().toFloat(); val h = if (iconPx > 0) iconPx else b.height()
        p.color = color; p.strokeWidth = maxOf(2f, w / 8f)
        val x0 = b.left + w * 0.12f; val x1 = b.right - w * 0.12f
        for (i in 0..2) { val y = b.top + h * (0.22f + 0.28f * i); c.drawLine(x0, y, x1, y, p) }
    }
    override fun setAlpha(alpha: Int) { p.alpha = alpha }
    override fun setColorFilter(cf: android.graphics.ColorFilter?) { p.colorFilter = cf }
    @Suppress("DEPRECATION") override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
