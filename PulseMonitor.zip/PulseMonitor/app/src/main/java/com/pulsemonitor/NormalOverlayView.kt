package com.pulsemonitor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.max

/**
 * Overlay gaya "Normal": FPS besar di kiri, CPU dan GPU berbentuk cincin (label + persen di dalam,
 * MHz di bawah cincin), lalu garis tipis dan baris RAM / BAT. Baris tambahan (GOV, TCH, LAT) di bawahnya bila aktif.
 *
 *   FPS      ( CPU )   ( GPU )
 *   60       ( 35% )   ( 45% )
 *            2840MHz   680MHz
 *   ─────────────────────────
 *   RAM 62%   BAT 85% 36° 2.4W
 */
class NormalOverlayView(ctx: Context) : View(ctx) {
    var snap = Snap()
    var rec = false
    /** Baris tambahan di bawah RAM/BAT. Tiap baris = daftar (label, nilai), mis. GOV sugov_ext atau TCH 120Hz + LAT 8ms. */
    var extraRows: List<List<Pair<String, String>>> = emptyList()
    var scale = 1f
    var bgColor = 0xEE101014.toInt()
    var strokeColor = 0x22FFFFFF
    var textColor = 0xFFFFFFFF.toInt()

    private val d = ctx.resources.displayMetrics.density
    private fun u(v: Float) = v * d * scale
    private val YEL = 0xFFFFD866.toInt()
    private val RED = 0xFFFF5C5C.toInt()
    private val GRN = 0xFF7CFFB2.toInt()
    private val BLUE = 0xFF5E9BF5.toInt()
    private val PURPLE = 0xFF9A86E8.toInt()
    private val PINK = 0xFFEE8FBE.toInt()

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val mono = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.MONOSPACE; textAlign = Paint.Align.LEFT }
    private val monoBold = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD); textAlign = Paint.Align.LEFT }
    private val bigP = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.LEFT }
    private val pctP = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER }
    private val rect = RectF()

    private class Seg(val t: String, val color: Int, val grad: Boolean = false)

    // ---- ukuran (dp, dikali skala) ----
    private fun padX() = u(14f)
    private fun padY() = u(10f)
    private fun ringD() = u(58f)
    private fun ringGap() = u(14f)
    private fun leftGap() = u(16f)
    private fun mhzH() = u(18f)
    private fun rowH() = u(17f)
    private fun divGap() = u(8f)
    private fun divTh() = max(1f, d / 2f)
    private fun textSz() = u(11.5f)

    // ---- warna ----
    private fun batColor(v: Int) = when { v <= 15 -> RED; v <= 30 -> 0xFFFF9F43.toInt(); else -> GRN }
    private fun tempColor(t: Float) = when { t >= 45f -> RED; t >= 40f -> YEL; else -> GRN }
    private fun lerp(a: Int, b: Int, t: Float): Int {
        fun ch(s: Int) = ((a shr s and 0xFF) + ((b shr s and 0xFF) - (a shr s and 0xFF)) * t).toInt()
        return (0xFF shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
    }
    /** Gradasi label: biru -> ungu -> pink menurut posisi huruf (3 huruf = tepat biru, ungu, pink). */
    private fun gradColor(i: Int, n: Int): Int {
        if (n <= 1) return BLUE
        val t = i / (n - 1f)
        return if (t <= 0.5f) lerp(BLUE, PURPLE, t * 2f) else lerp(PURPLE, PINK, (t - 0.5f) * 2f)
    }

    // ---- teks ----
    private fun mhzText(v: Int) = if (v >= 0) "${v}MHz" else "-"

    private fun bottomRow(): List<Seg> {
        val s = snap
        val l = mutableListOf(Seg("RAM", textColor), Seg(" " + pct(s.ramPct), textColor), Seg("   ", textColor))
        l += Seg("BAT", textColor)
        if (s.tBat >= 0f) l += Seg(" " + deg(s.tBat), tempColor(s.tBat))
        if (s.watt >= 0f) l += Seg(" " + String.format(Locale.US, "%.1fW", s.watt), YEL)
        return l
    }

    private fun extraSegs(row: List<Pair<String, String>>): List<Seg> {
        val l = mutableListOf<Seg>()
        row.forEachIndexed { i, (lab, v) ->
            if (i > 0) l += Seg("   ", textColor)
            l += Seg(lab, textColor); l += Seg(" $v", YEL)
        }
        return l
    }

    private fun rows(): List<List<Seg>> = listOf(bottomRow()) + extraRows.map { extraSegs(it) }

    private fun segsWidth(segs: List<Seg>): Float { mono.textSize = textSz(); return segs.sumOf { mono.measureText(it.t).toDouble() }.toFloat() }

    private fun baseFor(cy: Float, paint: Paint) = cy - (paint.ascent() + paint.descent()) / 2f

    private fun leftW(): Float {
        mono.textSize = textSz(); bigP.textSize = u(26f)
        return max(u(32f), max(mono.measureText("FPS") + if (rec) u(10f) else 0f, bigP.measureText("${snap.fps}")))
    }
    private fun colW(mhz: Int): Float { mono.textSize = textSz(); return max(ringD(), mono.measureText(mhzText(mhz))) }
    private fun topH() = ringD() + u(2f) + mhzH()

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val topW = leftW() + leftGap() + colW(snap.cpuMhz) + ringGap() + colW(snap.gpuMhz)
        val rowsW = rows().maxOf { segsWidth(it) }
        val w = padX() * 2 + max(topW, rowsW)
        val h = padY() * 2 + topH() + divGap() * 2 + divTh() + rowH() * rows().size
        setMeasuredDimension(ceil(w).toInt(), ceil(h).toInt())
    }

    private fun drawSegs(c: Canvas, segs: List<Seg>, x0: Float, by: Float) {
        mono.textSize = textSz(); var x = x0
        for (sg in segs) {
            if (sg.grad) {
                sg.t.forEachIndexed { i, ch -> mono.color = gradColor(i, sg.t.length); c.drawText(ch.toString(), x, by, mono); x += mono.measureText(ch.toString()) }
            } else { mono.color = sg.color; c.drawText(sg.t, x, by, mono); x += mono.measureText(sg.t) }
        }
    }

    private fun drawRing(c: Canvas, cx: Float, cy: Float, label: String, pctV: Int) {
        val r = u(23f); val sw = u(4.5f)
        p.style = Paint.Style.STROKE; p.strokeWidth = sw; p.strokeCap = Paint.Cap.BUTT
        p.color = withAlpha(textColor, 16); c.drawCircle(cx, cy, r, p)
        if (pctV > 0) {
            p.color = loadCol(pctV); p.strokeCap = Paint.Cap.ROUND
            rect.set(cx - r, cy - r, cx + r, cy + r)
            c.drawArc(rect, -90f, 360f * pctV.coerceIn(0, 100) / 100f, false, p)
        }
        p.strokeCap = Paint.Cap.BUTT
        // label kecil berwarna di atas, persen di bawah
        monoBold.textSize = u(9.5f)
        val lw = monoBold.measureText(label); var x = cx - lw / 2f
        monoBold.color = textColor; c.drawText(label, x, cy - u(3f), monoBold)
        pctP.textSize = u(12.5f); pctP.color = textColor
        c.drawText(pct(pctV), cx, cy + u(10f), pctP)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val rad = u(12f)
        p.style = Paint.Style.FILL; p.color = bgColor
        rect.set(0f, 0f, w, h); c.drawRoundRect(rect, rad, rad, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = d; p.color = strokeColor
        rect.set(d / 2, d / 2, w - d / 2, h - d / 2); c.drawRoundRect(rect, rad, rad, p)

        val x0 = padX(); val top = padY()
        val lw = leftW()
        val tH = topH()

        // Blok kiri: label FPS + angka besar. Dipusatkan terhadap tinggi cincin.
        mono.textSize = textSz(); bigP.textSize = u(26f)
        val leftH = u(18f) + u(30f)
        val lt = top + max(0f, (ringD() - leftH) / 2f)   // sejajar dengan cincin CPU/GPU (tanpa baris MHz)
        var cy = lt + u(9f)
        // Label FPS dipusatkan di atas angka FPS (tidak mepet kiri)
        val fpsLabW = mono.measureText("FPS")
        var lx = x0 + max(0f, (bigP.measureText("${snap.fps}") - fpsLabW) / 2f)
        mono.color = textColor; c.drawText("FPS", lx, baseFor(cy, mono), mono); lx += fpsLabW
        if (rec) { p.style = Paint.Style.FILL; p.color = RED; c.drawCircle(lx + u(6f), cy, u(3f), p) }
        bigP.color = textColor
        c.drawText("${snap.fps}", x0, baseFor(lt + u(18f) + u(15f), bigP), bigP)

        // Dua cincin: CPU lalu GPU, MHz di bawah masing-masing
        val cw1 = colW(snap.cpuMhz); val cw2 = colW(snap.gpuMhz)
        val x1 = x0 + lw + leftGap(); val x2 = x1 + cw1 + ringGap()
        val rcy = top + ringD() / 2f
        val mcy = top + ringD() + u(2f) + mhzH() / 2f
        drawRing(c, x1 + cw1 / 2f, rcy, "CPU", snap.cpu)
        drawRing(c, x2 + cw2 / 2f, rcy, "GPU", snap.gpu)
        mono.color = YEL; mono.textAlign = Paint.Align.CENTER
        c.drawText(mhzText(snap.cpuMhz), x1 + cw1 / 2f, baseFor(mcy, mono), mono)
        c.drawText(mhzText(snap.gpuMhz), x2 + cw2 / 2f, baseFor(mcy, mono), mono)
        mono.textAlign = Paint.Align.LEFT

        // Garis pemisah tipis
        val dy = top + tH + divGap()
        p.style = Paint.Style.FILL; p.color = withAlpha(textColor, 14)
        c.drawRect(x0, dy, w - padX(), dy + divTh(), p)

        // RAM / BAT lalu baris tambahan
        var ry = dy + divTh() + divGap()
        for (r in rows()) { drawSegs(c, r, x0, baseFor(ry + rowH() / 2f, mono)); ry += rowH() }
    }
}
