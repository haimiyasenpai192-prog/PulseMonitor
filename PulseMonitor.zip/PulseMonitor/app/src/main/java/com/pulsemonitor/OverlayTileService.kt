package com.pulsemonitor

import android.app.PendingIntent
import android.content.Intent
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.Toast
import kotlinx.coroutines.*

/**
 * Ubin Quick Settings untuk menyalakan/mematikan overlay tanpa membuka aplikasi.
 * Logikanya sama dengan tombol di layar utama (MainActivity.toggleOverlay): nyala = start layanan,
 * mati = ACTION_HIDE bila "Tetap aktif di latar belakang" nyala, selain itu layanan dihentikan.
 * Status ubin mengikuti OverlayService.overlayShown selama panel terbuka, jadi ikut berubah bila
 * overlay dinyalakan/dimatikan dari tempat lain (layar utama, kartu panel di overlay).
 */
class OverlayTileService : TileService() {
    private var scope: CoroutineScope? = null

    override fun onStartListening() {
        super.onStartListening()
        render(OverlayService.overlayShown.value)
        scope?.cancel()
        scope = CoroutineScope(Dispatchers.Main + SupervisorJob()).also { s ->
            s.launch { OverlayService.overlayShown.collect { render(it) } }
        }
    }

    override fun onStopListening() {
        scope?.cancel(); scope = null
        super.onStopListening()
    }

    override fun onClick() {
        super.onClick()
        // Layar terkunci: minta buka kunci dulu, baru overlay diubah
        if (isLocked) unlockAndRun { toggle() } else toggle()
    }

    private fun toggle() {
        AppSettings.load(this)   // proses bisa baru dibuat untuk ubin ini; bgMode harus sudah terbaca
        val turnOn = !OverlayService.overlayShown.value
        if (turnOn && !Settings.canDrawOverlays(this)) {
            // Belum ada izin tampil di atas aplikasi lain: buka halaman izinnya, panel ditutup
            val perm = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runCatching { openAndCollapse(perm) }
                .onFailure { android.util.Log.e("PulseMonitor", "Gagal membuka halaman izin overlay", it) }
            return
        }
        val i = Intent(this, OverlayService::class.java)
        try {
            when {
                turnOn -> startForegroundService(i)
                AppSettings.bgMode -> startForegroundService(i.setAction(OverlayService.ACTION_HIDE))
                else -> stopService(i)
            }
        } catch (e: Throwable) {
            android.util.Log.e("PulseMonitor", "Ubin overlay gagal", e)
            Toast.makeText(this, "Overlay gagal: ${e.javaClass.simpleName}: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    /** API 34+ memakai PendingIntent; versi Intent sudah usang di sana tetapi masih dibutuhkan untuk API 29-33. */
    @Suppress("DEPRECATION")
    private fun openAndCollapse(intent: Intent) {
        if (Build.VERSION.SDK_INT >= 34)
            startActivityAndCollapse(PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE))
        else startActivityAndCollapse(intent)
    }

    private fun render(on: Boolean) {
        val t = qsTile ?: return
        t.state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = "Pulse Overlay"
        t.subtitle = if (on) "Aktif" else "Mati"      // API 29+, minSdk proyek ini 29
        t.icon = Icon.createWithResource(this, R.drawable.ic_stat_pulse)
        t.updateTile()
    }
}
