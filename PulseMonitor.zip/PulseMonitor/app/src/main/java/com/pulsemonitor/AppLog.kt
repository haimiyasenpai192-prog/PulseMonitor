package com.pulsemonitor

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Log ringan aplikasi: disimpan di memori dan di berkas, ditampilkan serta dibagikan dari layar Kesehatan & log. */
object AppLog {
    private const val MAX_LINES = 400
    private const val MAX_FILE = 120_000L
    private val lines = ArrayDeque<String>()
    private var file: File? = null
    private var appCtx: Context? = null
    private val exportPool = Executors.newSingleThreadScheduledExecutor { r -> Thread(r, "applog-export").apply { isDaemon = true } }
    private val exportPending = AtomicBoolean(false)
    @Volatile private var exportUri: android.net.Uri? = null
    private const val EXPORT_DIR = "PulseMonitor"   // subfolder di dalam Download

    /** Bagian "PEMERIKSAAN" dari laporan kesehatan terakhir; ikut ditulis ke berkas log di Download bila ada. */
    @Volatile var checksText: String? = null
    private val ID = Locale("id", "ID")
    // Tiap baris log: hari, tanggal, jam (mis. "Kam 19/11 18:24:05")
    private val fmt = SimpleDateFormat("EEE dd/MM HH:mm:ss", ID)
    // Cap waktu ekspor di kepala berkas (mis. "Kamis, 19 November 2026 · 18:24:05")
    private fun stamp() = SimpleDateFormat("EEEE, dd MMMM yyyy · HH:mm:ss", ID).format(Date())

    @Synchronized fun init(c: Context) {
        if (file != null) return
        appCtx = c.applicationContext
        val f = File(c.applicationContext.filesDir, "applog.txt")
        file = f
        runCatching { f.readLines().takeLast(MAX_LINES).forEach { lines.addLast(it) } }
    }

    @Synchronized private fun add(level: String, tag: String, msg: String) {
        val l = "${fmt.format(Date())} $level/$tag ${msg.replace('\n', ' ')}".take(600)
        lines.addLast(l)
        while (lines.size > MAX_LINES) lines.removeFirst()
        val f = file ?: return
        runCatching {
            if (f.length() > MAX_FILE) f.writeText(lines.joinToString("\n") + "\n") else f.appendText(l + "\n")
        }
        exportAsync()
    }

    /** Jejak crash disimpan permanen (tidak ikut dihapus saat dialog crash ditutup) supaya tetap ada di berkas Download. */
    fun keepCrash(c: Context, trace: String) {
        runCatching { File(c.applicationContext.filesDir, "crash_keep.txt").writeText(trace) }
    }

    /** Tulis ulang berkas log di folder Download, digabung dan ditunda ~2 detik supaya tidak menulis tiap baris. */
    fun exportAsync() {
        if (appCtx == null || !exportPending.compareAndSet(false, true)) return
        runCatching { exportPool.schedule({ exportNow() }, 2, TimeUnit.SECONDS) }.onFailure { exportPending.set(false) }
    }

    /** Segera tulis Download/PulseMonitor/Pulse Monitor log.txt (dipakai juga saat crash). Satu berkas, selalu ditimpa. */
    fun exportNow(): Boolean {
        exportPending.set(false)
        val c = appCtx ?: return false
        return runCatching {
            val text = buildString {
                append("Pulse Monitor log\n").append(stamp()).append("\n\n")
                val head = checksText
                // dua baris pertama laporan (judul + waktu) sudah diganti kepala di atas
                if (head != null) append(head.lines().drop(2).joinToString("\n").trimStart('\n')).append('\n')
                else {
                    val ver = runCatching { c.packageManager.getPackageInfo(c.packageName, 0).let { "${it.versionName} (${it.longVersionCode})" } }.getOrDefault("?")
                    append("Aplikasi $ver · ${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT}) · ${Build.DISPLAY}\n")
                }
                append("\n== LOG (terbaru di bawah) ==\n").append(dump(MAX_LINES)).append('\n')
                val crash = runCatching { File(c.filesDir, "crash_keep.txt").readText() }.getOrNull()
                if (!crash.isNullOrBlank()) append("\n== CRASH TERAKHIR ==\n").append(crash).append('\n')
            }
            val cr = c.contentResolver
            val coll = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            var fresh = false
            val uri = exportUri ?: run {
                // Satu berkas saja: Download/PulseMonitor/Pulse Monitor log.txt, selalu ditimpa. Hari, tanggal, dan jam ada di baris kedua isinya.
                // Android 11+: aplikasi hanya melihat berkas yang DIA buat sendiri, jadi berkas dari install lama harus dihapus manual.
                val plainName = "Pulse Monitor log.txt"
                var plainId: Long? = null
                val others = ArrayList<Long>()
                cr.query(coll, arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME),
                    "(${MediaStore.Downloads.DISPLAY_NAME} LIKE ? OR ${MediaStore.Downloads.DISPLAY_NAME} LIKE ?) AND ${MediaStore.Downloads.RELATIVE_PATH} LIKE ?",
                    arrayOf("PulseMonitor_log%", "Pulse Monitor log%", Environment.DIRECTORY_DOWNLOADS + "/" + EXPORT_DIR + "%"),
                    "${MediaStore.Downloads._ID} DESC")?.use {
                    while (it.moveToNext()) {
                        val id = it.getLong(0)
                        if (plainId == null && it.getString(1) == plainName) plainId = id else others.add(id)
                    }
                }
                for (o in others) runCatching { cr.delete(ContentUris.withAppendedId(coll, o), null, null) }
                plainId?.let { ContentUris.withAppendedId(coll, it) } ?: run {
                    fresh = true
                    cr.insert(coll, ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, plainName)
                        put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/" + EXPORT_DIR)
                    })!!
                }
            }
            exportUri = uri
            try {
                cr.openOutputStream(uri, "wt")!!.use { it.write(text.toByteArray()) }
            } catch (t: Throwable) {
                // Gagal tulis: jangan tinggalkan berkas kosong; bila berkas dihapus pengguna, buat baru pada ekspor berikutnya.
                exportUri = null
                if (fresh) runCatching { cr.delete(uri, null, null) }
                throw t
            }
            true
        }.getOrElse { false }
    }

    fun i(tag: String, msg: String) = add("I", tag, msg)
    fun w(tag: String, msg: String) = add("W", tag, msg)
    fun e(tag: String, msg: String, t: Throwable? = null) =
        add("E", tag, if (t == null) msg else "$msg: ${t.javaClass.simpleName} ${t.message}")

    @Synchronized fun dump(n: Int = 200): String = lines.toList().takeLast(n).joinToString("\n")

    @Synchronized fun clear() {
        lines.clear()
        runCatching { file?.writeText("") }
        runCatching { appCtx?.let { File(it.filesDir, "crash_keep.txt").delete() } }
        exportAsync()
    }
}
