package com.pulsemonitor

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Pengaturan warna. State Compose, jadi layar utama langsung berubah; overlay membacanya tiap detik. */
object AppSettings {
    val ACCENTS = listOf(0xFF3DF0FF.toInt(), 0xFF7CFFB2.toInt(), 0xFFA78BFA.toInt(), 0xFFFF9F43.toInt(), 0xFFFF6FB1.toInt())
    val TEXTS = listOf(0xFFFFFFFF.toInt(), 0xFF3DF0FF.toInt(), 0xFFFFD866.toInt(), 0xFF7CFFB2.toInt())
    val BGS = listOf(0xFF101014.toInt(), 0xFF1B1230.toInt(), 0xFF0B2A2E.toInt(), 0xFF1A2A52.toInt())
    private const val DEF_ALPHA = 92

    var accent by mutableIntStateOf(ACCENTS[0])
    var overlayText by mutableIntStateOf(TEXTS[0])
    var overlayBg by mutableIntStateOf(BGS[0])
    val STYLES = listOf("Simple", "Compact", "Normal")
    var overlayStyle by mutableIntStateOf(0)       // 0 Simple (satu baris), 1 Compact, 2 Normal
    var alpha by mutableIntStateOf(DEF_ALPHA)      // transparansi latar overlay, 20..100 persen
    const val DEF_PANEL = 92
    var panelAlpha by mutableIntStateOf(DEF_PANEL)  // transparansi panel dan navigasi di layar utama, 15..100 persen
    const val DEF_SIZE = 100
    var size by mutableIntStateOf(DEF_SIZE)         // ukuran overlay, 60..200 persen
    var bgMode by mutableStateOf(false)            // true: notifikasi tetap hidup di latar belakang walau overlay dimatikan
    var touchRate by mutableStateOf(false)         // true: overlay menampilkan touch rate (Hz) saat layar disentuh
    var touchLat by mutableStateOf(false)          // true: overlay menampilkan latensi sentuh (ms) tiap layar diketuk
    var cpuGov by mutableStateOf(true)             // true: overlay Compact menampilkan governor CPU tiap cluster
    var notifWall by mutableStateOf(false)         // true: wallpaper aplikasi dipakai juga sebagai latar notifikasi baterai
    @Volatile private var loaded = false

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun load(c: Context) {
        if (loaded) return
        val p = prefs(c)
        accent = p.getInt("accent", ACCENTS[0]); overlayText = p.getInt("text", TEXTS[0])
        overlayBg = p.getInt("bg", BGS[0]); alpha = p.getInt("alpha2", DEF_ALPHA).coerceIn(20, 100)
        overlayStyle = p.getInt("style", 0).coerceIn(0, STYLES.size - 1)
        bgMode = p.getBoolean("bgmode", false); touchRate = p.getBoolean("touchrate", false); touchLat = p.getBoolean("touchlat", false); notifWall = p.getBoolean("notifwall", false); cpuGov = p.getBoolean("cpugov", true)
        panelAlpha = p.getInt("panel", DEF_PANEL).coerceIn(15, 100)
        size = p.getInt("size", DEF_SIZE).coerceIn(60, 200)
        loaded = true
    }

    fun save(c: Context) {
        prefs(c).edit().putInt("accent", accent).putInt("text", overlayText).putInt("bg", overlayBg).putInt("alpha2", alpha).putInt("style", overlayStyle).putBoolean("bgmode", bgMode).putBoolean("touchrate", touchRate).putBoolean("touchlat", touchLat).putBoolean("notifwall", notifWall).putBoolean("cpugov", cpuGov).putInt("panel", panelAlpha).putInt("size", size).apply()
    }

    fun reset(c: Context) {
        accent = ACCENTS[0]; overlayText = TEXTS[0]; overlayBg = BGS[0]; alpha = DEF_ALPHA
        save(c)
    }
}

/** Warna RGB + transparansi dalam persen (0..100) jadi ARGB. */
fun withAlpha(rgb: Int, pct: Int): Int = (rgb and 0xFFFFFF) or ((pct.coerceIn(0, 100) * 255 / 100) shl 24)
