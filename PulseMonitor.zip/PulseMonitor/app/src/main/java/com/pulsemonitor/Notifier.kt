package com.pulsemonitor

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer

/**
 * Notifikasi + suara saat metode akses dipilih. Suara diputar lewat MediaPlayer yang dipegang di sini
 * (bukan di Composable), jadi tidak terpotong saat layar berubah atau aplikasi pindah ke latar.
 */
object Notifier {
    private const val CH_OK = "access_selected"
    private const val CH_FAIL = "access_failed"
    private const val ID_ACCESS = 21
    private var player: MediaPlayer? = null

    fun accessSelected(ctx: Context, method: String) {
        val app = ctx.applicationContext
        playSound(app, R.raw.notif_access)
        show(app, CH_OK, "Metode akses dipilih", silent = true, title = "Akses $method dipilih",
            text = "Metode akses diganti ke $method.", icon = R.drawable.ic_stat_pulse)
    }

    /** Gagal / ditolak: memakai suara notifikasi bawaan HP (lewat channel, bukan suara custom). */
    fun accessFailed(ctx: Context, method: String, reason: String) {
        val app = ctx.applicationContext
        show(app, CH_FAIL, "Akses gagal", silent = false, title = "Akses $method gagal",
            text = reason, icon = android.R.drawable.stat_notify_error)
    }

    private fun show(app: Context, channel: String, channelName: String, silent: Boolean, title: String, text: String, icon: Int) {
        try {
            val nm = app.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(channel, channelName, NotificationManager.IMPORTANCE_DEFAULT).apply {
                    if (silent) { setSound(null, null); enableVibration(false) }
                })
            val open = PendingIntent.getActivity(
                app, 1,
                Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = Notification.Builder(app, channel)
                .setSmallIcon(icon)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
            nm.notify(ID_ACCESS, n)
        } catch (_: Throwable) {}
    }

    /** MediaPlayer.create menyiapkan berkas suara secara sinkron; di thread utama itu bikin klik terasa telat, jadi dijalankan di thread lain. */
    private fun playSound(app: Context, res: Int) { Thread { playSoundNow(app, res) }.start() }

    @Synchronized
    private fun playSoundNow(app: Context, res: Int) {
        try {
            if (player?.isPlaying == true) return
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val mp = MediaPlayer.create(app, res, attrs, AudioManager.AUDIO_SESSION_ID_GENERATE) ?: return
            mp.setOnCompletionListener { m -> release(m) }
            mp.setOnErrorListener { m, _, _ -> release(m); true }
            player = mp
            mp.start()
        } catch (_: Throwable) {
            player = null
        }
    }

    @Synchronized
    private fun release(m: MediaPlayer) {
        try { m.release() } catch (_: Throwable) {}
        if (player === m) player = null
    }
}
