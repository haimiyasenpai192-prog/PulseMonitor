package com.pulsemonitor

import android.content.Context

/**
 * Penjaga notifikasi di luar proses aplikasi (butuh Shizuku/root).
 *
 * Masalah: "Hapus semua" di recents HyperOS mematikan proses dengan gaya force-stop. Alarm dan START_STICKY milik aplikasi ikut hilang,
 * jadi notifikasi mode "Pulse Latar" tidak pernah kembali. Hanya proses di luar aplikasi yang bisa menghidupkannya lagi.
 *
 * Cara kerja: skrip kecil (jalan sebagai shell, lepas dari aplikasi) dinyalakan saat mode latar belakang nyala. Tiap ~3 detik skrip
 * memeriksa proses/layanan PulseMonitor; kalau mati, ia memulai OverlayService lagi (RESTORE). Skrip berhenti sendiri bila berkas bendera
 * dihapus (mode latar belakang dimatikan) atau aplikasi sudah di-uninstall. Tanpa Shizuku/root fitur ini tidak aktif.
 * Skrip menulis log sendiri (pulsemonitor_watch.log); isinya ikut tampil di Kesehatan & log lewat pemeriksaan "Penjaga latar belakang".
 */
object Watchdog {
    private const val DIR = "/data/local/tmp"
    private const val SCRIPT = "$DIR/pulsemonitor_watch.sh"
    private const val FLAG = "$DIR/pulsemonitor_watch.on"
    private const val PIDF = "$DIR/pulsemonitor_watch.pid"
    private const val LOG = "$DIR/pulsemonitor_watch.log"
    private const val FGFLAG = "$DIR/pulsemonitor_watch.fg"
    private const val VER = "pulsemonitor-watch v3"

    @Volatile private var kept = false
    /** Minta sistem tidak membatasi aplikasi di latar belakang (daftar putih Doze, appops, bucket aktif). Sekali per proses; hasil dicatat di log. */
    private fun keepAlive(pkg: String) {
        if (kept) return
        kept = true
        val o = Shell.exec(listOf(
            "cmd deviceidle whitelist +$pkg 2>&1",
            "appops set $pkg RUN_IN_BACKGROUND allow 2>&1",
            "appops set $pkg RUN_ANY_IN_BACKGROUND allow 2>&1",
            "am set-standby-bucket $pkg active 2>&1"
        ).joinToString("\n")).trim().replace("\n", " | ")
        AppLog.i("Penjaga", "izin latar belakang (Doze/appops/bucket): ${o.ifEmpty { "selesai tanpa keluaran" }.take(200)}")
    }

    class Status(val flag: Boolean, val alive: Boolean, val log: String)

    private fun script(pkg: String): String = listOf(
        "#!/system/bin/sh",
        "# $VER",
        "PKG=$pkg",
        "FLAG=$FLAG",
        "FGFLAG=$FGFLAG",
        "PIDF=$PIDF",
        "LOG=$LOG",
        "log() { echo \"\$(date '+%m-%d %H:%M:%S') \$1\" >> \$LOG; }",
        "echo \$\$ > \$PIDF",
        "log \"skrip mulai pid=\$\$\"",
        "n=0; lastfg=\"\"",
        "while [ -f \"\$FLAG\" ] && [ \"\$(cat \$PIDF 2>/dev/null)\" = \"\$\$\" ]; do",
        "  n=\$((n+1))",
        "  alive=0; why=\"\"",
        "  if [ -n \"\$(pidof \$PKG)\" ]; then",
        "    alive=1",
        "    if [ \$((n % 5)) -eq 0 ] && ! dumpsys activity services \$PKG 2>/dev/null | grep -q '\\.OverlayService'; then alive=0; why=\"proses ada, layanan mati\"; fi",
        "  else why=\"proses mati\"; fi",
        "  if [ \$alive -eq 0 ] && [ -f \"\$FLAG\" ]; then",
        "    log \"\$why -> mulai layanan\"; lastfg=\"\"",
        "    am start-foreground-service -n \$PKG/.OverlayService -a com.pulsemonitor.RESTORE >/dev/null 2>&1 || log \"am gagal rc=\$?\"",
        "    sleep 3",
        "  fi",
        // Pemantau aplikasi di depan di luar proses: HyperOS membekukan proses aplikasi yang di latar belakang (timer di dalam proses diam
        // sampai 37 detik), tapi skrip ini (uid shell) tidak ikut dibekukan. Tiap ada perubahan, layanan "dibangunkan" lewat intent FG.
        "  if [ -f \"\$FGFLAG\" ] && [ \$alive -eq 1 ]; then",
        "    o=\$(timeout 3 dumpsys window 2>/dev/null | grep -E 'mCurrentFocus|mFocusedApp' | head -8)",
        "    c=\",\"",
        "    for q in \$(echo \"\$o\" | grep mFocusedApp | sed -n 's/.* u[0-9][0-9]* \\([A-Za-z0-9_.]*\\)\\/.*/\\1/p') \$(echo \"\$o\" | grep mCurrentFocus | sed -n 's/.* u[0-9][0-9]* \\([A-Za-z0-9_.]*\\)\\/.*/\\1/p'); do",
        "      case \"\$c\" in *\",\$q,\"*) ;; *) c=\"\$c\$q,\";; esac",
        "    done",
        "    if [ \"\$c\" != \",\" ] && [ \"\$c\" != \"\$lastfg\" ]; then",
        "      lastfg=\"\$c\"",
        "      am start-foreground-service -n \$PKG/.OverlayService -a com.pulsemonitor.FG --es pkgs \"\${c#,}\" >/dev/null 2>&1 || log \"ping gagal rc=\$?\"",
        "    fi",
        "  fi",
        "  if [ \$((n % 20)) -eq 0 ]; then",
        "    pm path \$PKG >/dev/null 2>&1 || { log \"aplikasi tidak ada, berhenti\"; rm -f \"\$FLAG\"; exit 0; }",
        "    [ \$(( \$(wc -c < \$LOG 2>/dev/null) + 0 )) -gt 20000 ] && { tail -n 40 \$LOG > \$LOG.t; mv \$LOG.t \$LOG; }",
        "  fi",
        "  if [ -f \"\$FGFLAG\" ]; then sleep 1; else sleep 3; fi",
        "done",
        "log \"skrip berhenti (bendera dihapus atau digantikan)\""
    ).joinToString("\n")

    private fun startCmd(pkg: String, fg: Boolean): String = listOf(
        "mkdir -p $DIR",
        if (fg) "touch $FGFLAG" else "rm -f $FGFLAG",
        "if [ -f $PIDF ] && kill -0 \$(cat $PIDF) 2>/dev/null && grep -q '$VER' $SCRIPT 2>/dev/null; then touch $FLAG; echo sudah-jalan; exit 0; fi",
        "[ -f $PIDF ] && kill \$(cat $PIDF) 2>/dev/null",
        "cat > $SCRIPT <<'PMEOF'",
        script(pkg),
        "PMEOF",
        "chmod 755 $SCRIPT",
        "touch $FLAG",
        "rm -f $PIDF",
        "command -v setsid >/dev/null 2>&1 && S=setsid || S=",
        "(\$S nohup sh $SCRIPT </dev/null >/dev/null 2>&1 &)",
        "echo dimulai",
        "exit 0"
    ).joinToString("\n")

    /** on = nyalakan/pastikan penjaga jalan; off = hentikan (berhenti sendiri dalam 3-6 detik). Aman dipanggil berulang dari thread mana pun. */
    fun sync(ctx: Context, on: Boolean, fg: Boolean = AppSettings.notifApp) {
        val pkg = ctx.applicationContext.packageName
        Thread {
            runCatching {
                val mode = Shell.mode()
                if (mode == "-") { if (on) AppLog.w("Penjaga", "tidak dinyalakan: tidak ada akses Shizuku/root"); return@runCatching }
                if (on) keepAlive(pkg)
                if (on) AppLog.i("Penjaga", "nyalakan ($mode, pantau aplikasi=${if (fg) "ya" else "tidak"}): ${Shell.exec(startCmd(pkg, fg)).trim().ifEmpty { "tanpa keluaran" }}")
                else { Shell.exec("rm -f $FLAG $FGFLAG"); AppLog.i("Penjaga", "dimatikan ($mode)") }
            }.onFailure { AppLog.e("Penjaga", "gagal", it) }
        }.apply { name = "pulse-watchdog"; isDaemon = true }.start()
    }

    /** Keadaan penjaga + ekor log skripnya. Menjalankan shell, jadi panggil dari thread latar. */
    fun status(): Status {
        val out = Shell.exec(listOf(
            "[ -f $FLAG ] && echo flag=1 || echo flag=0",
            "p=\$(cat $PIDF 2>/dev/null); kill -0 \$p 2>/dev/null && echo alive=1 || echo alive=0",
            "echo ==",
            "tail -n 25 $LOG 2>/dev/null"
        ).joinToString("\n"))
        val lines = out.lines()
        val cut = lines.indexOf("==")
        val head = if (cut >= 0) lines.take(cut) else lines
        val tail = if (cut >= 0) lines.drop(cut + 1).filter { it.isNotBlank() } else emptyList()
        return Status("flag=1" in head, "alive=1" in head, tail.joinToString("\n").ifEmpty { "(log skrip kosong)" })
    }
}
