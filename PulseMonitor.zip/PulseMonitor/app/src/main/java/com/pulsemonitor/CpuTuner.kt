package com.pulsemonitor

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.roundToInt

/** Satu cluster CPU (satu folder cpufreq/policyN). Frekuensi dalam kHz, sesuai sysfs. */
data class CpuCluster(
    val policy: Int, val cpus: List<Int>, val freqs: List<Int>, val govs: List<String>,
    val gov: String, val min: Int, val max: Int, val hwMin: Int, val hwMax: Int
) {
    /** Daftar frekuensi yang boleh dipilih. Kernel tanpa scaling_available_frequencies: dibuat per 100 MHz dari batas keras. */
    fun steps(): List<Int> {
        if (freqs.isNotEmpty()) return freqs
        val lo = hwMin; val hi = hwMax
        if (lo <= 0 || hi <= lo) return listOf(maxOf(lo, hi, max, min).coerceAtLeast(0))
        val l = (lo..hi step 100000).toMutableList()
        if (l.last() != hi) l.add(hi)
        return l
    }
    fun cpuRange(): String = if (cpus.size <= 1) "CPU${cpus.firstOrNull() ?: policy}" else "CPU${cpus.first()}-${cpus.last()}"
}

data class CpuSnap(val clusters: List<CpuCluster>, val offline: Set<Int>, val hot: Set<Int>)

/** Pengaturan yang akan ditulis untuk satu cluster. */
data class CpuCfg(val policy: Int, val gov: String, val min: Int, val max: Int)

/**
 * Atur CPU lewat sysfs (cpufreq + hotplug). KHUSUS ROOT: Shizuku berjalan sebagai shell dan tidak boleh menulis
 * scaling_* / online, jadi semua perintah di sini memakai su langsung dan tidak lewat Shell.exec.
 */
object CpuTuner {
    private const val BASE = "/sys/devices/system/cpu"
    private val SAFE = Regex("[A-Za-z0-9_.\\-]+")

    /** true bila pengguna memilih Root di Settings dan su sudah diizinkan. */
    fun available(): Boolean = Access.choice == Access.ROOT && Access.rootState == 2

    private fun su(cmd: String): String = try {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor(); out
    } catch (e: Throwable) { "ERR:${e.message}" }

    fun read(): CpuSnap? {
        val sh = "for p in $BASE/cpufreq/policy[0-9]*; do [ -d \$p ] || continue; " +
            "echo \"P|\${p##*/}|\$(cat \$p/related_cpus 2>/dev/null)|\$(cat \$p/scaling_available_frequencies 2>/dev/null)" +
            "|\$(cat \$p/scaling_available_governors 2>/dev/null)|\$(cat \$p/scaling_governor 2>/dev/null)" +
            "|\$(cat \$p/scaling_min_freq 2>/dev/null)|\$(cat \$p/scaling_max_freq 2>/dev/null)" +
            "|\$(cat \$p/cpuinfo_min_freq 2>/dev/null)|\$(cat \$p/cpuinfo_max_freq 2>/dev/null)\"; done; " +
            "for c in $BASE/cpu[0-9]*; do [ -f \$c/online ] && echo \"C|\${c##*/}|\$(cat \$c/online)\"; done"
        val out = su(sh)
        if (out.startsWith("ERR:")) return null
        val cl = ArrayList<CpuCluster>(); val off = HashSet<Int>(); val hot = HashSet<Int>()
        for (line in out.lines()) {
            val f = line.trim().split("|")
            if (f.size >= 10 && f[0] == "P") {
                val pol = f[1].removePrefix("policy").toIntOrNull()
                val max = f[7].trim().toIntOrNull() ?: 0
                if (pol == null || max <= 0) continue
                val ws = Regex("[ ,]+")
                val cpus = f[2].trim().split(ws).mapNotNull { it.toIntOrNull() }.sorted().ifEmpty { listOf(pol) }
                val freqs = f[3].trim().split(ws).mapNotNull { it.toIntOrNull() }.filter { it > 0 }.distinct().sorted()
                val govs = f[4].trim().split(ws).filter { it.isNotEmpty() && SAFE.matches(it) }
                val min = f[6].trim().toIntOrNull() ?: 0
                val hwMin = f[8].trim().toIntOrNull() ?: min
                val hwMax = f[9].trim().toIntOrNull() ?: max
                cl.add(CpuCluster(pol, cpus, freqs, govs, f[5].trim(), min, max, hwMin, hwMax))
            } else if (f.size >= 3 && f[0] == "C") {
                val n = f[1].removePrefix("cpu").toIntOrNull() ?: continue
                hot.add(n); if (f[2].trim() == "0") off.add(n)
            }
        }
        if (cl.isEmpty()) return null
        return CpuSnap(cl.sortedBy { it.policy }, off, hot)
    }

    /** Nama cluster berdasarkan urutan kekuatan (frekuensi maks tertinggi = paling kuat). */
    fun label(s: CpuSnap, c: CpuCluster): String {
        val order = s.clusters.sortedBy { it.hwMax }
        val i = order.indexOfFirst { it.policy == c.policy }
        return when {
            order.size == 1 -> "CPU"
            i == 0 -> "Little"
            i == order.lastIndex -> if (order.size >= 3) "Prime" else "Big"
            else -> "Big"
        }
    }

    /** Tulis pengaturan, lalu baca ulang dan laporkan apakah kernel menerimanya. */
    fun apply(cfg: List<CpuCfg>, offline: Set<Int>): String {
        val before = read() ?: return "Gagal membaca CPU. Pastikan izin root diberikan."
        val sb = StringBuilder()
        // 1) hidupkan dulu inti yang diminta online (policy inti mati tidak bisa ditulis)
        for (n in before.hot) if (n !in offline) sb.append("echo 1 > $BASE/cpu$n/online 2>/dev/null; ")
        // 2) governor dan batas frekuensi per cluster
        for (c in cfg) {
            val cl = before.clusters.firstOrNull { it.policy == c.policy } ?: continue
            if (!SAFE.matches(c.gov)) continue
            val st = cl.steps()
            val hi = c.max.coerceIn(st.first(), st.last())
            val lo = c.min.coerceIn(st.first(), hi)
            val p = "$BASE/cpufreq/policy${c.policy}"
            sb.append("chmod 644 $p/scaling_governor $p/scaling_min_freq $p/scaling_max_freq 2>/dev/null; ")
            sb.append("echo ${c.gov} > $p/scaling_governor 2>/dev/null; ")
            // urutan ini selalu sah: turunkan min dulu, atur max, lalu naikkan min
            sb.append("echo ${minOf(cl.hwMin, st.first())} > $p/scaling_min_freq 2>/dev/null; ")
            sb.append("echo $hi > $p/scaling_max_freq 2>/dev/null; ")
            sb.append("echo $lo > $p/scaling_min_freq 2>/dev/null; ")
        }
        // 3) matikan inti yang diminta (cpu0 tidak pernah dimatikan)
        for (n in offline) if (n != 0 && n in before.hot) sb.append("echo 0 > $BASE/cpu$n/online 2>/dev/null; ")
        su(sb.toString())

        val after = read() ?: return "Diterapkan, tapi gagal membaca ulang."
        val lines = ArrayList<String>()
        for (c in cfg) {
            val cl = after.clusters.firstOrNull { it.policy == c.policy } ?: continue
            val ok = cl.gov == c.gov && cl.max == c.max && cl.min == c.min
            lines.add("${cl.cpuRange()}: ${cl.gov} ${cl.min / 1000}–${cl.max / 1000} MHz " + if (ok) "✓" else "(disesuaikan kernel)")
        }
        val offBad = offline.filter { it != 0 && it in after.hot && it !in after.offline }
        if (offBad.isNotEmpty()) lines.add("Inti ${offBad.joinToString(", ")} tetap menyala (ditahan sistem)")
        return lines.joinToString("\n").ifEmpty { "Tidak ada yang diterapkan." }
    }

    // ---- Penyimpanan profil ----
    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences("cputune", Context.MODE_PRIVATE)

    fun bootApply(c: Context): Boolean = prefs(c).getBoolean("boot", false)
    fun setBootApply(c: Context, v: Boolean) { prefs(c).edit().putBoolean("boot", v).apply() }

    private fun encode(cfg: List<CpuCfg>, off: Set<Int>) =
        cfg.joinToString(";") { "${it.policy},${it.gov},${it.min},${it.max}" } + "#" + off.sorted().joinToString(",")

    private fun decode(s: String?): Pair<List<CpuCfg>, Set<Int>>? {
        if (s.isNullOrBlank() || !s.contains("#")) return null
        val cfg = s.substringBefore("#").split(";").mapNotNull {
            val f = it.split(",")
            if (f.size != 4 || !SAFE.matches(f[1])) null
            else {
                val p = f[0].toIntOrNull(); val lo = f[2].toIntOrNull(); val hi = f[3].toIntOrNull()
                if (p == null || lo == null || hi == null) null else CpuCfg(p, f[1], lo, hi)
            }
        }
        val off = s.substringAfter("#").split(",").mapNotNull { it.toIntOrNull() }.toSet()
        return if (cfg.isEmpty()) null else cfg to off
    }

    fun saveProfile(c: Context, cfg: List<CpuCfg>, off: Set<Int>) { prefs(c).edit().putString("profile", encode(cfg, off)).apply() }

    /** Simpan keadaan kernel saat pertama kali layar dibuka, sebagai acuan tombol "Kembalikan awal". */
    fun saveDefaultOnce(c: Context, s: CpuSnap) {
        val p = prefs(c)
        if (p.contains("default")) return
        p.edit().putString("default", encode(s.clusters.map { CpuCfg(it.policy, it.gov, it.min, it.max) }, s.offline)).apply()
    }

    fun loadDefault(c: Context) = decode(prefs(c).getString("default", null))

    /** Dipanggil BootReceiver bila "Terapkan saat boot" nyala. Melewati bila profil kosong atau su tidak ada. */
    fun applySaved(c: Context) {
        val (cfg, off) = decode(prefs(c).getString("profile", null)) ?: return
        runCatching { apply(cfg, off) }
    }

    // ---- Preset ----
    /** kind 1 = Hemat (batas atas ~60%), 2 = Performa (batas bawah ~50%, governor performance bila ada). */
    fun preset(s: CpuSnap, kind: Int): List<CpuCfg> = s.clusters.map { c ->
        val st = c.steps()
        when (kind) {
            1 -> CpuCfg(c.policy, c.gov, st.first(), st[((st.size - 1) * 0.6f).roundToInt()])
            else -> CpuCfg(c.policy, if ("performance" in c.govs) "performance" else c.gov, st[((st.size - 1) * 0.5f).roundToInt()], st.last())
        }
    }
}

// ===================== UI =====================

private data class Ed(val policy: Int, val gov: String, val minI: Int, val maxI: Int)

private fun nearest(st: List<Int>, v: Int): Int = st.indices.minByOrNull { abs(st[it] - v) } ?: 0

@Composable
private fun CChip(text: String, on: Boolean, enabled: Boolean = true, onClick: () -> Unit) {
    val a = Color(AppSettings.accent)
    val shape = RoundedCornerShape(50)
    Box(Modifier.clip(shape).background(if (on) a.copy(alpha = 0.25f) else Color(0x14FFFFFF))
        .border(1.dp, if (on) a else Color(0x22FFFFFF), shape)
        .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 12.dp, vertical = 7.dp)) {
        Text(text, color = if (!enabled) Color(0xFF8E8E99) else if (on) a else Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun FreqSlider(label: String, steps: List<Int>, idx: Int, onChange: (Int) -> Unit) {
    val a = Color(AppSettings.accent)
    val i = idx.coerceIn(0, steps.lastIndex)
    SliderLabel(label, "${steps[i] / 1000} MHz")
    if (steps.size >= 2) {
        Slider(value = i.toFloat(), onValueChange = { onChange(it.roundToInt()) }, valueRange = 0f..steps.lastIndex.toFloat(),
            steps = (steps.size - 2).coerceAtLeast(0),
            colors = SliderDefaults.colors(thumbColor = a, activeTrackColor = a, inactiveTrackColor = Color(0x22FFFFFF)))
    }
}

/** Isi tab Performa: disisipkan di panel kaca (sudah bisa di-scroll oleh pemanggil). */
@Composable
fun CpuTunerTab() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val root = CpuTuner.available()
    var snap by remember { mutableStateOf<CpuSnap?>(null) }
    var loading by remember { mutableStateOf(root) }
    var busy by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf("") }
    var bootOn by remember { mutableStateOf(CpuTuner.bootApply(ctx)) }
    val ed = remember { mutableStateListOf<Ed>() }
    var off by remember { mutableStateOf(setOf<Int>()) }

    fun fill(s: CpuSnap, cfg: List<CpuCfg>?, offline: Set<Int>?) {
        ed.clear()
        s.clusters.forEach { c ->
            val w = cfg?.firstOrNull { it.policy == c.policy }
            val st = c.steps()
            ed.add(Ed(c.policy, w?.gov ?: c.gov, nearest(st, w?.min ?: c.min), nearest(st, w?.max ?: c.max)))
        }
        off = offline ?: s.offline
    }

    fun cfgNow(): List<CpuCfg> {
        val s = snap ?: return emptyList()
        return ed.mapNotNull { e ->
            val c = s.clusters.firstOrNull { it.policy == e.policy } ?: return@mapNotNull null
            val st = c.steps()
            CpuCfg(e.policy, e.gov, st[e.minI.coerceIn(0, st.lastIndex)], st[e.maxI.coerceIn(0, st.lastIndex)])
        }
    }

    fun doApply(cfg: List<CpuCfg>, offline: Set<Int>) {
        if (busy) return
        busy = true; result = "Menerapkan…"
        scope.launch {
            val r = withContext(Dispatchers.IO) {
                val msg = CpuTuner.apply(cfg, offline)
                CpuTuner.saveProfile(ctx, cfg, offline)
                msg to CpuTuner.read()
            }
            result = r.first
            r.second?.let { snap = it; fill(it, null, null) }   // tampilkan keadaan kernel sebenarnya
            busy = false
        }
    }

    LaunchedEffect(root) {
        if (!root) return@LaunchedEffect
        loading = true
        val s = withContext(Dispatchers.IO) { CpuTuner.read()?.also { CpuTuner.saveDefaultOnce(ctx, it) } }
        snap = s
        if (s != null) fill(s, null, null)
        loading = false
    }

    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        val s = snap
        if (!root) {
            SettingCard("Butuh akses Root") {
                Text("Mengubah governor dan frekuensi CPU hanya bisa dengan root. Shizuku tidak cukup karena berjalan sebagai shell.",
                    color = Color(0xFF8E8E99), fontSize = 13.sp)
                Text("Buka tab Settings > Izinkan Akses, pilih Root, lalu izinkan di Magisk/KernelSU/APatch.",
                    color = Color(0xFF8E8E99), fontSize = 13.sp)
            }
            return@Column
        }
        if (loading) { Text("Membaca CPU…", color = Color(0xFF8E8E99), modifier = Modifier.padding(16.dp)); return@Column }
        if (s == null) {
            SettingCard("CPU tidak terbaca") {
                Text("Folder $BASE_PATH/cpufreq tidak ditemukan atau su menolak. Coba tarik-ulang dengan membuka layar ini lagi.",
                    color = Color(0xFF8E8E99), fontSize = 13.sp)
            }
            return@Column
        }

        Text("Peringatan: frekuensi min tinggi atau inti dimatikan bisa bikin HP panas, boros, atau tersendat. " +
            "Nilai kembali ke bawaan setelah restart, kecuali \"Terapkan saat boot\" dinyalakan.",
            color = Color(0xFFE8B84A), fontSize = 12.sp, modifier = Modifier.padding(horizontal = 6.dp))

        SettingCard("Preset") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PillButton("Hemat", false, Modifier.weight(1f)) { val c = CpuTuner.preset(s, 1); fill(s, c, s.offline); doApply(c, s.offline) }
                PillButton("Performa", false, Modifier.weight(1f)) { val c = CpuTuner.preset(s, 2); fill(s, c, s.offline); doApply(c, s.offline) }
                PillButton("Awal", false, Modifier.weight(1f)) {
                    val d = CpuTuner.loadDefault(ctx)
                    if (d != null) { fill(s, d.first, d.second); doApply(d.first, d.second) }
                }
            }
            Text("\"Awal\" = keadaan CPU saat layar ini pertama kali dibuka.", color = Color(0xFF8E8E99), fontSize = 11.sp)
        }

        s.clusters.forEachIndexed { k, c ->
            val e = ed.getOrNull(k) ?: return@forEachIndexed
            val st = c.steps()
            SettingCard("${CpuTuner.label(s, c)} · ${c.cpuRange()}") {
                Text("Saat ini: ${c.gov}, ${c.min / 1000}–${c.max / 1000} MHz", color = Color(0xFF8E8E99), fontSize = 12.sp)
                if (c.govs.isNotEmpty()) {
                    Text("Governor", color = Color(0xFF8E8E99), fontSize = 12.sp)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        c.govs.forEach { g -> CChip(g, g == e.gov) { ed[k] = e.copy(gov = g) } }
                    }
                }
                FreqSlider("Frekuensi minimum", st, e.minI) { i -> ed[k] = e.copy(minI = i, maxI = maxOf(e.maxI, i)) }
                FreqSlider("Frekuensi maksimum", st, e.maxI) { i -> ed[k] = e.copy(maxI = i, minI = minOf(e.minI, i)) }
                if (c.cpus.any { it in s.hot || it == 0 }) {
                    Text("Inti (ketuk untuk nyala/mati)", color = Color(0xFF8E8E99), fontSize = 12.sp)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        c.cpus.forEach { n ->
                            val canToggle = n != 0 && n in s.hot
                            CChip("CPU$n", n !in off, canToggle) { off = if (n in off) off - n else off + n }
                        }
                    }
                }
            }
        }

        SettingCard("Terapkan") {
            ToggleRow("Terapkan saat boot", "Pakai pengaturan ini otomatis setelah HP menyala",
                "Setelah HP selesai menyala, aplikasi menunggu sekitar 8 detik lalu menulis ulang pengaturan terakhir yang kamu terapkan. " +
                    "Bila HP jadi aneh, buka layar ini lalu tekan Awal, atau matikan saklar ini dan restart.", bootOn) {
                bootOn = it; CpuTuner.setBootApply(ctx, it)
            }
            SettingDivider()
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PillButton("Terapkan", true, Modifier.weight(1f)) { doApply(cfgNow(), off) }
                PillButton("Baca ulang", false, Modifier.weight(1f)) {
                    scope.launch {
                        val n = withContext(Dispatchers.IO) { CpuTuner.read() }
                        if (n != null) { snap = n; fill(n, null, null); result = "" }
                    }
                }
            }
            if (result.isNotEmpty()) Text(result, color = Color.White, fontSize = 12.sp)
        }
        Spacer(Modifier.size(8.dp))
    }
}

private const val BASE_PATH = "/sys/devices/system/cpu"
