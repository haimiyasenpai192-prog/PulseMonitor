package com.pulsemonitor

import android.annotation.SuppressLint
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.widget.Toast
import android.provider.Settings
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import kotlinx.coroutines.*

class OverlayService : Service() {
    companion object { const val ACTION_REC = "com.pulsemonitor.REC" }
    private var box: TextView? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    override fun onBind(i: Intent?): IBinder? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    /** Notifikasi dengan tombol Mulai/Berhenti rekam, supaya bisa dikendalikan dari dalam game. */
    private fun buildNotif(): Notification {
        val rec = Recorder.active.value
        val pi = PendingIntent.getService(this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_REC),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val act = Notification.Action.Builder(
            android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_media_play),
            if (rec) "Berhenti rekam" else "Mulai rekam", pi).build()
        return Notification.Builder(this, "ov").setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle(if (rec) "PulseMonitor: merekam FPS" else "PulseMonitor: overlay aktif")
            .addAction(act).build()
    }

    private fun refreshNotif() { getSystemService(NotificationManager::class.java).notify(1, buildNotif()) }

    private fun toggleRec() {
        if (Recorder.active.value) {
            scope.launch {
                val r = withContext(Dispatchers.IO) { Recorder.stop(this@OverlayService) }
                Toast.makeText(this@OverlayService, if (r != null) "Rekaman tersimpan" else "Tidak ada data FPS yang terekam", Toast.LENGTH_SHORT).show()
                refreshNotif()
            }
        } else {
            Recorder.start()
            Toast.makeText(this, "Mulai merekam FPS", Toast.LENGTH_SHORT).show()
            refreshNotif()
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("ov", "Overlay", NotificationManager.IMPORTANCE_LOW))
        if (i?.action == ACTION_REC) toggleRec()
        val notif = buildNotif()
        // Tipe specialUse baru ada di API 34; di bawahnya pakai versi 2 argumen
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, notif)
        // Izin overlay bisa dicabut kapan saja; addView akan crash tanpa pengecekan ini
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (box == null) {
            AppSettings.load(this); Sampler.init(this); Sampler.start()
            val wm = getSystemService(WindowManager::class.java)
            val prefs = getSharedPreferences("overlay", MODE_PRIVATE)

            val bg = GradientDrawable().apply {
                setColor(withAlpha(AppSettings.overlayBg, AppSettings.alpha)); cornerRadius = dp(40).toFloat()
                setStroke(dp(1), withAlpha(AppSettings.accent, 33))
            }
            val v = TextView(this).apply {
                typeface = Typeface.MONOSPACE; textSize = 12f; setTextColor(AppSettings.overlayText)
                setSingleLine(true); setPadding(dp(12), dp(5), dp(12), dp(5)); background = bg
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,       // bisa disentuh (untuk digeser), tidak mencuri fokus
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START; x = prefs.getInt("x", dp(12)); y = prefs.getInt("y", dp(40)) }

            // Geser: tahan lalu seret; posisi disimpan dan dipakai lagi saat overlay dinyalakan berikutnya
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
            // Tahan overlay ~1 detik tanpa menggeser = mulai/berhenti rekam
            val longPress = Runnable { toggleRec(); v.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS) }
            v.setOnTouchListener { view: View, e: MotionEvent ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false; view.postDelayed(longPress, 1000) }
                    MotionEvent.ACTION_CANCEL -> view.removeCallbacks(longPress)
                    MotionEvent.ACTION_MOVE -> {
                        if (!moved && (Math.abs(e.rawX - tx) > dp(8) || Math.abs(e.rawY - ty) > dp(8))) { moved = true; view.removeCallbacks(longPress) }
                        if (!moved) return@setOnTouchListener true
                        val dm = resources.displayMetrics
                        lp.x = (sx + (e.rawX - tx).toInt()).coerceIn(0, maxOf(0, dm.widthPixels - view.width))
                        lp.y = (sy + (e.rawY - ty).toInt()).coerceIn(0, maxOf(0, dm.heightPixels - view.height))
                        runCatching { wm.updateViewLayout(view, lp) }
                    }
                    MotionEvent.ACTION_UP -> { view.removeCallbacks(longPress); if (moved) prefs.edit().putInt("x", lp.x).putInt("y", lp.y).apply() }
                }
                true
            }
            val ok = runCatching { wm.addView(v, lp) }.isSuccess
            if (!ok) { stopSelf(); return START_NOT_STICKY }
            box = v
            scope.launch {
                var lastStyle = -1
                Sampler.state.collect { s ->
                    val style = AppSettings.overlayStyle
                    if (style != lastStyle) {   // ganti bentuk: satu baris (pil) atau kartu beberapa baris
                        lastStyle = style
                        v.setSingleLine(style == 0); if (style != 0) v.maxLines = Int.MAX_VALUE
                        bg.cornerRadius = dp(if (style == 0) 40 else 16).toFloat()
                        v.setPadding(dp(12), dp(if (style == 0) 5 else 8), dp(12), dp(if (style == 0) 5 else 8))
                        v.textSize = if (style == 0) 12f else 11.5f
                    }
                    bg.setColor(withAlpha(AppSettings.overlayBg, AppSettings.alpha))
                    bg.setStroke(dp(1), withAlpha(AppSettings.accent, 33))
                    v.setTextColor(AppSettings.overlayText)
                    v.text = line(s)
                }
            }
        }
        return START_STICKY
    }

    private fun muted() = withAlpha(AppSettings.overlayText, 65)

    private class B(val sb: SpannableStringBuilder = SpannableStringBuilder()) {
        fun put(t: String, color: Int? = null, bold: Boolean = false): B {
            val st = sb.length; sb.append(t)
            if (color != null) sb.setSpan(ForegroundColorSpan(color), st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            if (bold) sb.setSpan(StyleSpan(Typeface.BOLD), st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            return this
        }
        fun temp(t: Float) = if (t >= 0) put("%.0f°".format(t), heat(t)) else put("-")
        fun nl() = put("\n")
    }

    private fun head(b: B, s: Snap, ms: Boolean): B {
        if (Recorder.active.value) b.put("● ", 0xFFFF5C5C.toInt())
        b.put("${s.fps}", null, true).put(" FPS", AppSettings.accent)
        if (s.idle) b.put(" idle", muted())          // layar statis: angka = refresh rate layar
        else if (ms && s.fps > 0) b.put("  %.1f ms".format(1000f / s.fps), muted())
        return b
    }

    private fun mhz(v: Int) = if (v >= 0) "$v MHz" else ""
    private fun watt(w: Float) = if (w >= 0f) "%.1f W".format(w) else ""

    /** Simple: satu baris. 60 FPS  CPU 35% 42°  GPU 45% 41°  BAT 85% 36° */
    private fun simple(s: Snap): CharSequence {
        val b = B(); head(b, s, false)
        b.put("  CPU ${pct(s.cpu)} ").temp(s.tCpu)
        b.put("  GPU ${pct(s.gpu)} ").temp(s.tGpu)
        b.put("  BAT ")
        if (s.batPct >= 0) b.put("${s.batPct}% ").temp(s.tBat) else b.temp(s.tBat)
        return b.sb
    }

    /** Compact: kartu kecil, satu baris per komponen. */
    private fun compact(s: Snap): CharSequence {
        val b = B(); head(b, s, true).nl()
        b.put("CPU ", muted()).put("${pct(s.cpu)}  ").temp(s.tCpu).put("  " + mhz(s.cpuMhz), muted()).nl()
        b.put("GPU ", muted()).put("${pct(s.gpu)}  ").temp(s.tGpu).put("  " + mhz(s.gpuMhz), muted()).nl()
        b.put("RAM ", muted()).put(pct(s.ramPct)).nl()
        b.put("BAT ", muted()).put(if (s.batPct >= 0) "${s.batPct}%  " else "-  ").temp(s.tBat).put("  " + watt(s.watt), muted())
        return b.sb
    }

    /** Normal: paling lengkap, termasuk rata-rata, 1% low, RAM dalam GB, dan nama paket game. */
    private fun normal(s: Snap): CharSequence {
        val b = B(); head(b, s, true).nl()
        b.put("AVG ", muted()).put("${s.avg}").put("   LOW ", muted()).put("${s.low}").nl()
        b.put("CPU ", muted()).put("${pct(s.cpu)}  ").temp(s.tCpu).put("  " + mhz(s.cpuMhz), muted()).nl()
        b.put("GPU ", muted()).put("${pct(s.gpu)}  ").temp(s.tGpu).put("  " + mhz(s.gpuMhz), muted()).nl()
        b.put("RAM ", muted()).put("${pct(s.ramPct)}  ${s.ramText}").nl()
        b.put("BAT ", muted()).put(if (s.batPct >= 0) "${s.batPct}%  " else "-  ").temp(s.tBat).nl()
        b.put("PWR ", muted()).put(if (s.watt >= 0f) watt(s.watt) else "-")
        if (s.pkg.isNotEmpty()) b.nl().put(s.pkg, muted())
        return b.sb
    }

    private fun line(s: Snap): CharSequence = when (AppSettings.overlayStyle) { 1 -> compact(s); 2 -> normal(s); else -> simple(s) }

    override fun onDestroy() {
        scope.cancel(); box?.let { v -> runCatching { getSystemService(WindowManager::class.java).removeView(v) } }; box = null
        super.onDestroy()
    }
}

fun heat(t: Float) = when {
    t < 45f -> 0xFF7CFFB2.toInt()     // aman
    t < 55f -> 0xFFFFD866.toInt()     // hangat
    t < 65f -> 0xFFFF9F43.toInt()     // panas
    else -> 0xFFFF5C5C.toInt()        // sangat panas
}
fun deg(v: Float) = if (v >= 0) "%.0f°".format(v) else "-"
fun pct(v: Int) = if (v >= 0) "$v%" else "-"
