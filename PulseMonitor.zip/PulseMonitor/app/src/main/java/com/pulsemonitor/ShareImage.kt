package com.pulsemonitor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max

/** Menggambar laporan rekaman menjadi satu gambar PNG (lebar 1080 px) untuk dibagikan. Tidak bergantung pada layar yang sedang tampil. */
object ShareImage {
    private const val W = 1080
    private const val PAD = 48f
    private val BG = Color.parseColor("#101014")
    private val CARD = Color.parseColor("#1D1E24")
    private val MUTED = Color.parseColor("#8E8E99")
    private val SUB = Color.parseColor("#C4C6CE")
    private val GRID = Color.parseColor("#34363F")
    private val BLUE = Color.parseColor("#4C8DFF")
    private val GREEN = Color.parseColor("#4CC38A")
    private val AMBER = Color.parseColor("#F5B83D")
    private val PINK = Color.parseColor("#E5677A")
    private val ORANGE = Color.parseColor("#FF9F43")

    private class Line(val name: String, val color: Int, val v: List<Float>)

    private fun paint(color: Int, size: Float = 0f, bold: Boolean = false, align: Paint.Align = Paint.Align.LEFT) =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color; if (size > 0f) textSize = size; textAlign = align
            typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }

    fun render(ctx: Context, s: Session): Bitmap {
        val h = layout(null, ctx, s)
        val bmp = Bitmap.createBitmap(W, h, Bitmap.Config.ARGB_8888)
        layout(Canvas(bmp), ctx, s)
        return bmp
    }

    private fun fit(text: String, p: Paint, width: Float): String =
        TextUtils.ellipsize(text, TextPaint(p), width, TextUtils.TruncateAt.END).toString()

    private fun pct(v: Float) = if (v >= 0f) "%.0f%%".format(v) else "-"

    /** Satu fungsi untuk dua tahap: c == null hanya mengukur tinggi total, c != null menggambar. */
    private fun layout(c: Canvas?, ctx: Context, s: Session): Int {
        val st = s.stats()
        c?.drawColor(BG)
        var y = PAD
        val cardP = paint(CARD)

        // ---- Header: ikon, nama, tanggal · durasi · resolusi ----
        val icon = appIcon(ctx, s.pkg)
        val isz = 160f
        if (c != null) {
            val r = RectF(PAD, y, PAD + isz, y + isz)
            if (icon != null) {
                val clip = Path().apply { addRoundRect(r, 36f, 36f, Path.Direction.CW) }
                c.save(); c.clipPath(clip); c.drawBitmap(icon, null, r, Paint(Paint.FILTER_BITMAP_FLAG)); c.restore()
            } else c.drawRoundRect(r, 36f, 36f, cardP)
            val tx = PAD + isz + 36f; val avail = W - PAD - tx
            c.drawText(fit(s.label, paint(Color.WHITE, 64f, true), avail), tx, y + 74f, paint(Color.WHITE, 64f, true))
            c.drawText(fit("${fmtDate(s.id)}  ·  ${fmtDur(s.dur)}${s.resPart}", paint(SUB, 34f), avail), tx, y + 128f, paint(SUB, 34f))
        }
        y += isz + 40f

        // ---- Catatan (bila ada) ----
        if (s.desc.isNotBlank()) {
            val tp = TextPaint(paint(Color.WHITE, 36f))
            val sl = StaticLayout.Builder.obtain(s.desc, 0, s.desc.length, tp, (W - 2 * PAD - 64f).toInt()).build()
            val ch = sl.height + 56f
            if (c != null) {
                c.drawRoundRect(RectF(PAD, y, W - PAD, y + ch), 40f, 40f, cardP)
                c.save(); c.translate(PAD + 32f, y + 28f); sl.draw(c); c.restore()
            }
            y += ch + 28f
        }

        // ---- MAKS / MIN / RATA-RATA ----
        val bh = 210f
        if (c != null) {
            c.drawRoundRect(RectF(PAD, y, W - PAD, y + bh), 40f, 40f, cardP)
            val cw = (W - 2 * PAD) / 3f
            val items = listOf("MAKS" to st.max, "MIN" to st.min, "RATA-RATA" to st.avg)
            items.forEachIndexed { i, (lab, v) ->
                val cx = PAD + cw * i + cw / 2f
                c.drawText(lab, cx, y + 60f, paint(MUTED, 30f, align = Paint.Align.CENTER))
                c.drawText(f1(v), cx, y + 140f, paint(Color.WHITE, 78f, true, Paint.Align.CENTER))
                c.drawText("FPS", cx, y + 186f, paint(MUTED, 30f, align = Paint.Align.CENTER))
            }
        }
        y += bh + 28f

        // ---- Ringkasan dua kolom ----
        val rowH = 88f; val sh = rowH * 3 + 32f
        if (c != null) {
            c.drawRoundRect(RectF(PAD, y, W - PAD, y + sh), 40f, 40f, cardP)
            val colW = (W - 2 * PAD - 64f - 40f) / 2f
            val left = listOf(
                Triple("Varians FPS", f1(st.sd), ""),
                Triple("5% low", "%.0f".format(st.low5), ""),
                Triple("Daya", if (st.avgWatt >= 0f) f1(st.avgWatt) else "-", "W"))
            val right = listOf(
                Triple("CPU", pct(s.cpu.avgValid()), ""),
                Triple("GPU", pct(s.gpu.avgValid()), ""),
                Triple("Suhu HP", if (st.maxTemp >= 0f) "%.0f".format(st.maxTemp) else "-", "°C"))
            val line = paint(GRID).apply { strokeWidth = 2f }
            listOf(left to (PAD + 32f), right to (PAD + 32f + colW + 40f)).forEach { (rows, x0) ->
                rows.forEachIndexed { i, (lab, v, unit) ->
                    val base = y + 16f + rowH * i + 58f
                    c.drawText(lab, x0, base, paint(SUB, 34f))
                    val unitW = if (unit.isEmpty()) 0f else paint(MUTED, 28f).measureText(unit) + 8f
                    c.drawText(v, x0 + colW - unitW, base, paint(Color.WHITE, 44f, true, Paint.Align.RIGHT))
                    if (unit.isNotEmpty()) c.drawText(unit, x0 + colW, base, paint(MUTED, 28f, align = Paint.Align.RIGHT))
                    if (i < 2) c.drawLine(x0, y + 16f + rowH * (i + 1), x0 + colW, y + 16f + rowH * (i + 1), line)
                }
            }
        }
        y += sh + 28f

        // ---- Grafik ----
        val ch = 540f
        val charts = ArrayList<Triple<String, List<Line>, Boolean>>()   // judul, garis, mulai dari nol
        charts.add(Triple("FPS", listOf(Line("FPS", BLUE, s.fps)), false))
        charts.add(Triple("Beban (%)", listOf(Line("CPU", BLUE, s.cpu), Line("GPU", PINK, s.gpu), Line("RAM", GREEN, s.ram)), true))
        charts.add(Triple("Suhu (°C)", listOf(Line("CPU", AMBER, s.tCpu), Line("GPU", ORANGE, s.tGpu), Line("Baterai", GREEN, s.tBat), Line("HP", PINK, s.phoneTemp)), false))
        if (s.watt.any { it >= 0f }) charts.add(Triple("Daya (W)", listOf(Line("Daya", PINK, s.watt)), true))
        for ((title, lines, zero) in charts) {
            if (c != null) drawChart(c, y, ch, title, s.t, lines, zero, title.startsWith("Beban"))
            y += ch + 28f
        }

        // ---- Penutup ----
        c?.drawText("Pulse Monitor", W / 2f, y + 36f, paint(MUTED, 30f, align = Paint.Align.CENTER))
        y += 36f + PAD
        return ceil(y).toInt()
    }

    private fun drawChart(c: Canvas, top: Float, h: Float, title: String, t: List<Float>, lines: List<Line>, fromZero: Boolean, pct100: Boolean) {
        c.drawRoundRect(RectF(PAD, top, W - PAD, top + h), 40f, 40f, paint(CARD))
        c.drawText(title, PAD + 36f, top + 70f, paint(Color.WHITE, 42f, true))
        // legenda
        if (lines.size > 1) {
            var lx = PAD + 36f
            for (l in lines) {
                c.drawCircle(lx + 10f, top + 118f, 10f, paint(l.color))
                c.drawText(l.name, lx + 32f, top + 130f, paint(SUB, 30f))
                lx += 32f + paint(SUB, 30f).measureText(l.name) + 36f
            }
        }
        val pl = PAD + 36f + 84f; val pr = W - PAD - 40f
        val pt = top + (if (lines.size > 1) 168f else 130f); val pb = top + h - 84f
        // skala Y
        val vals = lines.flatMap { it.v }.filter { it >= 0f }
        var lo: Float; var hi: Float
        if (vals.isEmpty()) { lo = 0f; hi = 1f }
        else if (pct100) { lo = 0f; hi = 100f }
        else {
            val mn = vals.minOrNull() ?: 0f; val mx = vals.maxOrNull() ?: 1f
            lo = if (fromZero) 0f else floor(mn - 1f)
            hi = ceil(mx + 1f)
            if (!fromZero && hi - lo < 4f) { val m = (hi + lo) / 2f; lo = m - 2f; hi = m + 2f }
            if (fromZero && hi <= lo) hi = lo + 1f
        }
        val tmax = max(t.lastOrNull() ?: 1f, 1f)
        val grid = paint(GRID).apply { strokeWidth = 2f; style = Paint.Style.STROKE; pathEffect = DashPathEffect(floatArrayOf(10f, 10f), 0f) }
        val yl = paint(MUTED, 28f, align = Paint.Align.RIGHT)
        for (i in 0..4) {
            val yy = pb - (pb - pt) * i / 4f
            c.drawLine(pl, yy, pr, yy, grid)
            val v = lo + (hi - lo) * i / 4f
            c.drawText(if (hi - lo >= 8f) "%.0f".format(v) else "%.1f".format(v), pl - 12f, yy + 10f, yl)
        }
        // skala X: langkah "bagus" supaya label sekitar 5
        val steps = floatArrayOf(1f, 2f, 5f, 10f, 15f, 30f, 60f, 120f, 300f, 600f, 1200f, 1800f, 3600f)
        val step = steps.firstOrNull { it >= tmax / 5f } ?: 3600f
        val xl = paint(MUTED, 28f, align = Paint.Align.CENTER)
        var tv = 0f
        while (tv <= tmax + 0.001f) {
            val xx = pl + (pr - pl) * tv / tmax
            c.drawLine(xx, pt, xx, pb, grid)
            c.drawText("${tv.toInt()}s", xx, pb + 44f, xl)
            tv += step
        }
        // garis data (nilai < 0 = tidak terbaca, garis putus di situ)
        for (l in lines) {
            val path = Path(); var pen = false
            val n = minOf(l.v.size, t.size)
            for (i in 0 until n) {
                val v = l.v[i]
                if (v < 0f) { pen = false; continue }
                val xx = pl + (pr - pl) * t[i] / tmax
                val yy = pb - (pb - pt) * ((v - lo) / (hi - lo)).coerceIn(0f, 1f)
                if (!pen) { path.moveTo(xx, yy); pen = true } else path.lineTo(xx, yy)
            }
            c.drawPath(path, paint(l.color).apply { style = Paint.Style.STROKE; strokeWidth = 5f; strokeJoin = Paint.Join.ROUND; strokeCap = Paint.Cap.ROUND })
        }
    }
}
