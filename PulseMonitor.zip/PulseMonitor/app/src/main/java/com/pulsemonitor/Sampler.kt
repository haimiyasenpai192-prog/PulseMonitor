package com.pulsemonitor

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import rikka.shizuku.Shizuku

data class Snap(
    val fps: Int = 0, val avg: Int = 0, val low: Int = 0, val ft: Float = 0f,
    val cpu: Int = -1, val gpu: Int = -1, val ramPct: Int = -1, val ramText: String = "-",
    val tCpu: Float = -1f, val tGpu: Float = -1f, val tBat: Float = -1f,
    val access: String = "-", val dbg: String = ""
)

object Shell {
    private val rootOk: Boolean by lazy {
        runCatching { ProcessBuilder("su", "-c", "id").start().inputStream.bufferedReader().readText().contains("uid=0") }
            .getOrDefault(false)
    }
    fun shizukuReady() = runCatching { Shizuku.pingBinder() && Shizuku.checkSelfPermission() == 0 }.getOrDefault(false)
    fun mode(): String = if (shizukuReady()) "Shizuku" else if (rootOk) "Root" else "-"

    fun exec(cmd: String): String {
        val p: Process = when (mode()) {
            // newProcess bersifat private di Shizuku 13.x, dipanggil via refleksi
            "Shizuku" -> Shizuku::class.java.getDeclaredMethod(
                "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
            ).apply { isAccessible = true }.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            "Root" -> ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
            else -> return ""
        }
        return runCatching { p.inputStream.bufferedReader().readText() }.getOrDefault("").also { p.destroy() }
    }
}

object Sampler {
    // Urutan prioritas jalur beban GPU. Tambahkan jalur baru di sini bila ada chipset lain.
    private const val GPU_PATHS = "/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage " +   // Adreno (Qualcomm)
        "/sys/kernel/ged/hal/gpu_utilization " +                                       // MediaTek (GED)
        "/sys/module/ged/parameters/gpu_loading " +                                    // MediaTek (GED, varian lain)
        "/proc/mali/utilization"                                                       // Mali lama

    val state = MutableStateFlow(Snap())
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var job: Job? = null
    private var prevTotal = 0L; private var prevIdle = 0L
    private val hist = ArrayDeque<Int>()

    fun start() {
        if (job?.isActive == true) return
        job = scope.launch {
            while (isActive) {
                runCatching { tick() }
                delay(1000)
            }
        }
    }

    private fun tick() {
        val mode = Shell.mode()
        if (mode == "-") {
            state.value = Snap(tBat = batteryTemp(), access = "-", dbg = "Suhu baterai: Intent (CPU/GPU butuh Shizuku/root)")
            return
        }
        val out = Shell.exec(
            "head -1 /proc/stat; echo ==; for f in $GPU_PATHS; do [ -r \$f ] && echo \"\$f:\$(cat \$f 2>/dev/null)\"; done; echo ==; " +
            "head -3 /proc/meminfo; echo ==; grep -H . /sys/class/thermal/thermal_zone*/type /sys/class/thermal/thermal_zone*/temp 2>/dev/null; " +
            "echo ==; cat /sys/class/kgsl/kgsl-3d0/temp 2>/dev/null"
        ).split("==")
        if (out.size < 4) return

        // CPU
        val c = out[0].trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        var cpu = -1
        if (c.size >= 5) {
            val total = c.take(8).sum(); val idle = c[3] + c[4]
            if (prevTotal > 0 && total > prevTotal) cpu = (100 * ((total - prevTotal) - (idle - prevIdle)) / (total - prevTotal)).toInt()
            prevTotal = total; prevIdle = idle
        }
        // GPU: Adreno (kgsl) dulu, lalu MediaTek (GED) / Mali. Ambil angka pertama 0..100 dari jalur
        // pertama yang terbaca; format tiap jalur berbeda (ada yang "45", ada yang "45 30 12").
        val gpu = out[1].lines().firstNotNullOfOrNull { line ->
            Regex("\\d+").find(line.substringAfter(':', ""))?.value?.toIntOrNull()?.takeIf { it in 0..100 }
        } ?: -1
        // RAM
        fun kb(n: String) = Regex("$n:\\s+(\\d+)").find(out[2])?.groupValues?.get(1)?.toLongOrNull() ?: 0L
        val tot = kb("MemTotal"); val av = kb("MemAvailable")
        val ramPct = if (tot > 0) (100 * (tot - av) / tot).toInt() else -1
        val ramText = "%.1f / %.0f GB".format((tot - av) / 1048576f, tot / 1048576f)
        // Suhu: HAL thermal (utama) -> sysfs (cadangan); baterai dari Intent BATTERY_CHANGED
        val hal = runCatching { thermalHal() }.getOrNull()
        val sys = parseZones(out[3])
        val kgsl = out.getOrNull(4)?.trim()?.toFloatOrNull()?.let { norm(it) }?.takeIf { it in 5f..120f } ?: -1f
        fun pick(vararg c: Pair<String, Float>): Pair<Float, String> =
            c.firstOrNull { it.second >= 0f }?.let { it.second to it.first } ?: (-1f to "-")
        val tc = pick("HAL" to (hal?.t?.cpu ?: -1f), "HAL-soc" to (hal?.t?.soc ?: -1f), "sysfs" to sys.cpu)
        val tg = pick("HAL" to (hal?.t?.gpu ?: -1f), "sysfs" to sys.gpu, "kgsl" to kgsl)
        val tb = pick("Intent" to batteryTemp(), "HAL" to (hal?.t?.bat ?: -1f), "sysfs" to sys.bat)
        val tsk = pick("HAL" to (hal?.t?.skin ?: -1f), "sysfs" to sys.skin)
        val tempDbg = "CPU ${tc.second}, GPU ${tg.second}, BAT ${tb.second}, skin %.0f° (%s) | HAL: %s".format(
            tsk.first, tsk.second, if (hal != null) "${hal.n} sensor" else "tidak siap/kosong")

        val f = runCatching { fps() }.getOrDefault(0 to 0)
        if (f.first > 0) { hist.addLast(f.first); if (hist.size > 30) hist.removeFirst() }
        state.value = Snap(
            fps = f.first, avg = if (hist.isEmpty()) 0 else hist.average().toInt(),
            low = if (f.second > 0) f.second else (hist.minOrNull() ?: 0),
            ft = if (f.first > 0) 1000f / f.first else 0f, cpu = cpu, gpu = gpu,
            ramPct = ramPct, ramText = ramText, tCpu = tc.first, tGpu = tg.first, tBat = tb.first, access = mode,
            dbg = "FPS: $fpsDbg\nSuhu: $tempDbg"
        )
    }

    private var fpsDbg = "-"

    private fun focusPkg(): String? {
        val outs = listOf(
            Shell.exec("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp' | head -6"),
            Shell.exec("dumpsys activity activities | grep -E 'topResumedActivity|ResumedActivity' | head -4")
        )
        for (o in outs) for (l in o.lines()) {
            if (l.contains("=null")) continue
            Regex("u\\d+ ([\\w.]+)/").find(l)?.let { return it.groupValues[1] }
        }
        return null
    }

    private var tsPrev = HashMap<String, Long>()
    private var tsPrevAt = 0L
    private var tsReady = false

    /** SurfaceFlinger TimeStats: layer -> total frame yang sudah dipresentasikan. */
    private fun timestats(): Map<String, Long> {
        if (!tsReady) { Shell.exec("dumpsys SurfaceFlinger --timestats -clear -enable"); tsReady = true }
        val res = HashMap<String, Long>()
        var name: String? = null
        for (l in Shell.exec("dumpsys SurfaceFlinger --timestats -dump").lines()) {
            val t = l.trim()
            if (t.startsWith("layerName")) name = t.substringAfter('=').trim()
            else if (name != null && t.startsWith("totalFrames")) {
                res[name!!] = t.substringAfter('=').trim().toLongOrNull() ?: 0L; name = null
            }
        }
        if (res.isEmpty()) tsReady = false   // statistik belum aktif/ter-reset: aktifkan lagi di tick berikutnya
        return res
    }

    /** FPS = selisih totalFrames layer aplikasi fokus per detik. Cadangan: --latency. */
    private fun fps(): Pair<Int, Int> {
        val pkg = focusPkg()
        if (pkg == null) { fpsDbg = "aplikasi fokus tidak terbaca"; return 0 to 0 }
        val stats = timestats()
        val now = System.currentTimeMillis()
        val dt = (now - tsPrevAt) / 1000f
        val cand = stats.filter { it.key.contains(pkg) }
        var best = 0f
        for ((k, v) in cand) {
            val prev = tsPrev[k] ?: continue
            if (dt > 0.3f && v >= prev) best = maxOf(best, (v - prev) / dt)
        }
        tsPrev = HashMap(stats); tsPrevAt = now
        if (cand.isNotEmpty()) {
            fpsDbg = "$pkg | timestats ${cand.size} layer, ${stats.size} total"
            return best.toInt() to 0
        }
        val lat = fpsLatency()
        fpsDbg = "timestats: $pkg tidak ada (${stats.size} layer) -> latency: $fpsDbg"
        return lat
    }

    // ---------- SUHU ----------
    @Volatile private var appCtx: Context? = null
    fun init(c: Context) { appCtx = c.applicationContext }

    private class Temps {
        var cpu = -1f; var gpu = -1f; var bat = -1f; var skin = -1f; var soc = -1f
        fun put(kind: String, v: Float) {
            when (kind) {
                "cpu" -> cpu = maxOf(cpu, v); "gpu" -> gpu = maxOf(gpu, v); "bat" -> bat = maxOf(bat, v)
                "skin" -> skin = maxOf(skin, v); "soc" -> soc = maxOf(soc, v)
            }
        }
    }
    private class Hal(val t: Temps, val n: Int)

    /** Satuan sysfs bisa milli-derajat (42000), desi-derajat (420), atau derajat (42). */
    private fun norm(raw: Float) = when { raw >= 1000f -> raw / 1000f; raw > 150f -> raw / 10f; else -> raw }

    /** Suhu baterai dari broadcast sticky BATTERY_CHANGED (satuan 1/10 °C). Tanpa izin, tanpa Shizuku/root. */
    private fun batteryTemp(): Float {
        val i = runCatching { appCtx?.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) }.getOrNull()
            ?: return -1f
        val raw = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        if (raw == Int.MIN_VALUE) return -1f
        return (raw / 10f).takeIf { it in 1f..100f } ?: -1f
    }

    /** Kelompokkan sensor: nama dulu (gpuss, cpuss, quiet_therm, ...), baru tipe HAL (0 CPU, 1 GPU, 2 BAT, 3 SKIN, 13 SOC). */
    private fun kindOf(type: Int, name: String): String? {
        val n = name.lowercase()
        return when {
            "gpu" in n || "g3d" in n || "mali" in n || "adreno" in n -> "gpu"
            "batt" in n -> "bat"
            "cpu" in n -> "cpu"
            "skin" in n || "quiet" in n -> "skin"
            else -> when (type) { 0 -> "cpu"; 1 -> "gpu"; 2 -> "bat"; 3 -> "skin"; 13 -> "soc"; else -> null }
        }
    }

    private val tempRe = Regex("Temperature\\{([^}]*mValue[^}]*)\\}")
    private val valRe = Regex("mValue\\s*=\\s*(-?[0-9.]+)")
    private val typeRe = Regex("mType\\s*=\\s*(-?\\d+)")
    private val nameRe = Regex("mName\\s*=\\s*([^,}]+)")
    private val halDown = Regex("(?i)hal\\s*ready:\\s*false")

    /** Semua sensor di `dumpsys thermalservice` (seksi "Current temperatures from HAL"). Null bila HAL belum siap/kosong. */
    private fun thermalHal(): Hal? {
        val out = Shell.exec("dumpsys thermalservice")
        if (out.isBlank() || halDown.containsMatchIn(out)) return null
        val i = out.indexOf("Current temperatures from HAL")
        var sec = if (i >= 0) out.substring(i) else out
        val j = sec.indexOf("Cached temperatures"); if (j > 0) sec = sec.substring(0, j)
        val t = Temps(); var n = 0
        for (m in tempRe.findAll(sec)) {
            val body = m.groupValues[1]
            val v = valRe.find(body)?.groupValues?.get(1)?.toFloatOrNull() ?: continue
            if (v !in 1f..150f) continue          // buang sensor tidak valid (NaN/0/-ribuan)
            val ty = typeRe.find(body)?.groupValues?.get(1)?.toIntOrNull() ?: -1
            val nm = nameRe.find(body)?.groupValues?.get(1)?.trim() ?: ""
            kindOf(ty, nm)?.let { t.put(it, v); n++ }
        }
        return if (n > 0) Hal(t, n) else null
    }

    /** Cadangan: /sys/class/thermal/thermal_zone*. Tidak memakai zona "soc" (di banyak HP itu persen baterai, bukan suhu). */
    private fun parseZones(block: String): Temps {
        val zType = HashMap<String, String>(); val zTemp = HashMap<String, Float>()
        for (l in block.lines()) {
            val m = Regex("thermal_zone(\\d+)/(type|temp):(.*)").find(l) ?: continue
            val (z, k, v) = m.destructured
            if (k == "type") zType[z] = v.trim() else v.trim().toFloatOrNull()?.let { zTemp[z] = norm(it) }
        }
        val t = Temps()
        for ((z, ty) in zType) {
            val v = zTemp[z]?.takeIf { it in 5f..120f } ?: continue
            kindOf(-1, ty)?.let { t.put(it, v) }
        }
        return t
    }

    /** FPS dari SurfaceFlinger latency layer aplikasi yang sedang fokus. Return (fps, 1% low). */
    private fun fpsLatency(): Pair<Int, Int> {
        val pkg = focusPkg()
        if (pkg == null) { fpsDbg = "aplikasi fokus tidak terbaca"; return 0 to 0 }
        val all = Shell.exec("dumpsys SurfaceFlinger --list").lines().map { it.trim() }
            .filter { it.contains(pkg) && !it.startsWith("Background") }
        if (all.isEmpty()) { fpsDbg = "$pkg: layer tidak ditemukan"; return 0 to 0 }
        val ordered = all.sortedByDescending { (if (it.contains("SurfaceView")) 2 else 0) + (if (it.contains("BLAST")) 1 else 0) }
        for (layer in ordered.take(4)) {
            val rows = Shell.exec("dumpsys SurfaceFlinger --latency '$layer'").lines().drop(1)
                .map { it.trim().split(Regex("\\s+")) }
            for (col in intArrayOf(1, 2)) {
                val ts = rows.mapNotNull { it.getOrNull(col)?.toLongOrNull() }
                    .filter { it in 1 until Long.MAX_VALUE / 2 }.sorted()
                if (ts.size < 3) continue
                val recent = ts.filter { it >= ts.last() - 1_000_000_000L }
                if (recent.size < 2 || recent.last() == recent.first()) continue
                val fps = ((recent.size - 1) * 1e9 / (recent.last() - recent.first())).toInt()
                val deltas = ts.zipWithNext { a, b -> b - a }.filter { it > 0 }.sortedDescending()
                if (deltas.isEmpty()) continue
                val worst = deltas[(deltas.size / 100).coerceAtMost(deltas.size - 1)]
                fpsDbg = "$pkg | ${layer.take(36)} | ${ts.size} frame, kolom $col"
                return fps to (1e9 / worst).toInt()
            }
        }
        fpsDbg = "$pkg: ${ordered.size} layer, data latency kosong"
        return 0 to 0
    }
}
