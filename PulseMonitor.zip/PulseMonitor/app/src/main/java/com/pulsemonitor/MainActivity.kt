package com.pulsemonitor

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.graphics.Bitmap
import android.os.Build
import android.provider.Settings
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import rikka.shizuku.Shizuku

private val Cyan = Color(0xFF3DF0FF); private val Grey = Color(0xFF8E8E99)
private val Card = Color(0xE0131316); private val Bg = Color(0xFF0C0C0E)

class MainActivity : ComponentActivity() {
    // Android 13+: tanpa izin ini notifikasi foreground service tidak muncul
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private var wallpaperBmp by mutableStateOf<Bitmap?>(null)
    private var dim by mutableFloatStateOf(0.6f)

    // Photo Picker: tanpa izin galeri. Di Android 10-12 otomatis jatuh ke pemilih dokumen.
    private val pickImage = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) Thread {
            if (WallpaperStore.save(this, uri)) wallpaperBmp = WallpaperStore.load(this)
        }.start()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); Sampler.start()
        wallpaperBmp = WallpaperStore.load(this); dim = WallpaperStore.dim(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent { val s by Sampler.state.collectAsState(); Screen(s) }
    }

    @Composable
    fun Screen(s: Snap) {
        var on by remember { mutableStateOf(false) }
        Box(Modifier.fillMaxSize().background(Bg)) {
        wallpaperBmp?.let { bmp ->
            Image(bmp.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(Bg.copy(alpha = dim)))   // peredam agar teks tetap terbaca
        }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp).statusBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("PULSEMONITOR", color = Cyan, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
            Row(verticalAlignment = Alignment.Bottom) {
                Text("${s.fps}", color = Color.White, fontSize = 112.sp, fontWeight = FontWeight.SemiBold)
                Text(" FPS", color = Cyan, modifier = Modifier.padding(bottom = 24.dp))
            }
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                Stat("AVG", "${s.avg}"); Stat("1% LOW", "${s.low}"); Stat("FRAMETIME", "%.1f ms".format(s.ft))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Tile("CPU", pct(s.cpu), Modifier.weight(1f)); Tile("GPU", pct(s.gpu), Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Tile("RAM", pct(s.ramPct), Modifier.weight(1f))
                Tile("SUHU", if (s.temp >= 0) "%.0f°C".format(s.temp) else "-", Modifier.weight(1f))
            }
            Column(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(20.dp)).padding(16.dp)) {
                Text("Akses: ${if (s.access == "-") "belum ada" else s.access}", color = Color.White, fontWeight = FontWeight.Bold)
                if (s.access == "-") {
                    Text("Jalankan Shizuku lalu beri izin, atau gunakan perangkat root.", color = Grey, fontSize = 12.sp)
                    Button(onClick = { runCatching { if (Shizuku.pingBinder()) Shizuku.requestPermission(1) } }) { Text("Beri izin Shizuku") }
                }
            }
            Column(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(20.dp)).padding(16.dp)) {
                Text("Wallpaper", color = Color.White, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = {
                        pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }) { Text(if (wallpaperBmp == null) "Pilih gambar" else "Ganti gambar") }
                    if (wallpaperBmp != null) OutlinedButton(onClick = { WallpaperStore.clear(this@MainActivity); wallpaperBmp = null }) {
                        Text("Hapus")
                    }
                }
                if (wallpaperBmp != null) {
                    Text("Redupkan latar", color = Grey, fontSize = 12.sp)
                    Slider(value = dim, onValueChange = { dim = it },
                        onValueChangeFinished = { WallpaperStore.saveDim(this@MainActivity, dim) },
                        valueRange = 0.2f..0.9f)
                }
            }
            if (s.dbg.isNotEmpty()) Column(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(20.dp)).padding(16.dp)) {
                Text("Diagnostik", color = Color.White, fontWeight = FontWeight.Bold)
                Text(s.dbg, color = Grey, fontSize = 11.sp)
            }
            Row(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(20.dp)).padding(16.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text("Overlay mengambang", color = Color.White, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                Switch(checked = on, onCheckedChange = {
                    if (it && !Settings.canDrawOverlays(this@MainActivity)) {
                        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                    } else {
                        on = it
                        val i = Intent(this@MainActivity, OverlayService::class.java)
                        if (it) startForegroundService(i) else stopService(i)
                    }
                })
            }
        }
        }
    }
}

@Composable
fun Stat(l: String, v: String) = Column { Text(l, color = Grey, fontSize = 11.sp); Text(v, color = Color.White, fontSize = 19.sp) }

@Composable
fun Tile(l: String, v: String, m: Modifier) = Column(m.background(Card, RoundedCornerShape(22.dp)).padding(16.dp)) {
    Text(l, color = Grey, fontSize = 12.sp); Text(v, color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.SemiBold)
}
