package com.pulsemonitor

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.graphics.Bitmap
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.compose.ui.text.style.TextOverflow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import rikka.shizuku.Shizuku

private val Grey = Color(0xFF8E8E99)
private val Bg = Color(0xFF0C0C0E)
// Panel besar di bawah (gaya WuWa Config); transparansinya diatur di tab Tampilan
private val Glass: Color get() = Color(0xFF101116).copy(alpha = AppSettings.panelAlpha / 100f)
// Baris/kartu di dalam panel: tetap solid di nilai bawaan, makin tembus saat slider diturunkan
private val Inner: Color get() = Color(0xFF181A21).copy(alpha = (AppSettings.panelAlpha / AppSettings.DEF_PANEL.toFloat()).coerceAtMost(1f))
// Warna tiap tab navigasi: Beranda biru, Statistik ungu, Rekaman pink, Tampilan hijau, Settings kuning
private val NavColors = listOf(Color(0xFF6FA8FF), Color(0xFFA78BFA), Color(0xFFF08FB8), Color(0xFF5BD68E), Color(0xFFE8B84A))
private val Pink = Color(0xFFD58FC4)
private val Blue = Color(0xFF6FA8FF)
private fun acc() = Color(AppSettings.accent)

class MainActivity : ComponentActivity() {
    // Android 13+: tanpa izin ini notifikasi foreground service tidak muncul
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private var wallpaperBmp by mutableStateOf<Bitmap?>(null)
    private var dim by mutableFloatStateOf(0.6f)
    private var cropSrc by mutableStateOf<Bitmap?>(null)        // gambar yang sedang dipotong
    private var cropForNotif by mutableStateOf(false)           // true: untuk notifikasi, false: untuk latar aplikasi
    private var notifOwn by mutableStateOf(false)             // ada gambar khusus notifikasi
    private var notifDim by mutableFloatStateOf(0.45f)
    private var overlayOn by mutableStateOf(OverlayService.overlayShown.value)
    private var reportId by mutableStateOf<Long?>(null)
    private var accessDlg by mutableStateOf(false)
    private var styleDlg by mutableStateOf(false)

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, r -> Access.onPermissionResult(r == PackageManager.PERMISSION_GRANTED) }
    private val binderListener = Shizuku.OnBinderReceivedListener { Access.refresh() }
    private val deadListener = Shizuku.OnBinderDeadListener { Access.refresh() }

    // Photo Picker: tanpa izin galeri. Di Android 10-12 otomatis jatuh ke pemilih dokumen.
    private val pickImage = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) Thread {
            val bmp = WallpaperStore.decodePreview(this, uri)
            if (bmp != null) { cropForNotif = false; cropSrc = bmp }
        }.start()
    }

    // Gambar khusus notifikasi (terpisah dari wallpaper aplikasi)
    private val pickNotifImage = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) Thread {
            val bmp = WallpaperStore.decodePreview(this, uri)
            if (bmp != null) { cropForNotif = true; cropSrc = bmp }
        }.start()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); enableEdgeToEdge()
        AppSettings.load(this); Sampler.init(this)
        Shizuku.addRequestPermissionResultListener(permListener)
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        wallpaperBmp = WallpaperStore.load(this); dim = WallpaperStore.dim(this)
        notifOwn = WallpaperStore.hasNotifOwn(this); notifDim = WallpaperStore.notifDim(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        showLastCrash()
        setContent {
            val s by Sampler.state.collectAsState()
            // Status tombol mengikuti keadaan layanan yang sebenarnya (tetap benar setelah aplikasi dibuka ulang)
            val shown by OverlayService.overlayShown.collectAsState()
            LaunchedEffect(shown) { overlayOn = shown }
            var tab by remember { mutableIntStateOf(0) }
            BackHandler(enabled = tab != 0) { tab = 0 }
            val rid = reportId
            BackHandler(enabled = rid != null) { reportId = null }
            AnimatedContent(targetState = rid, label = "page", transitionSpec = {
                if (targetState != null)   // buka laporan: masuk dari kanan, halaman lama bergeser sedikit
                    (slideInHorizontally(tween(320)) { it } + fadeIn(tween(320))) togetherWith
                        (slideOutHorizontally(tween(320)) { -it / 4 } + fadeOut(tween(220)))
                else                       // kembali: laporan keluar ke kanan
                    (slideInHorizontally(tween(320)) { -it / 4 } + fadeIn(tween(320))) togetherWith
                        (slideOutHorizontally(tween(320)) { it } + fadeOut(tween(220)))
            }) { id -> if (id != null) ReportScreen(id) else Screen(s, tab) { tab = it } }
        }
    }

    /** Bila sesi sebelumnya berhenti karena crash, tampilkan jejaknya supaya bisa disalin dan dikirim. */
    private fun showLastCrash() {
        val trace = CrashLog.take(this) ?: return
        runCatching {
            android.app.AlertDialog.Builder(this)
                .setTitle("Pulse Monitor berhenti tiba-tiba")
                .setMessage(trace.take(3000))
                .setPositiveButton("Salin") { _, _ ->
                    getSystemService(android.content.ClipboardManager::class.java)
                        .setPrimaryClip(android.content.ClipData.newPlainText("crash", trace))
                    Toast.makeText(this, "Disalin", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Tutup", null).show()
        }
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        super.onDestroy()
    }

    override fun onStart() {
        super.onStart()
        Access.refresh()
        OverlayService.ensureRunning(this)   // mode latar belakang aktif tapi layanan sempat mati -> notifikasi dimunculkan lagi
        Sampler.uiVisible = true; Sampler.start()
    }

    override fun onStop() {
        super.onStop()
        // Aplikasi tidak terlihat: hentikan pembacaan sensor bila tidak ada overlay/rekaman yang memakainya
        Sampler.uiVisible = false
        if (!OverlayService.overlayShown.value && !Recorder.active.value) Sampler.stop()
    }

    private fun toggleOverlay() {
        val turnOn = !OverlayService.overlayShown.value
        if (turnOn && !Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val i = Intent(this, OverlayService::class.java)
        try {
            when {
                turnOn -> { playOverlaySound(); startForegroundService(i) }
                // Mode latar belakang: overlay disembunyikan, layanan (notifikasi) tetap hidup
                AppSettings.bgMode -> startForegroundService(i.setAction(OverlayService.ACTION_HIDE))
                else -> stopService(i)
            }
        } catch (e: Throwable) {
            android.util.Log.e("PulseMonitor", "Gagal memulai layanan overlay", e)
            Toast.makeText(this, "Overlay gagal: ${e.javaClass.simpleName}: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    /** Saklar "Tetap aktif di latar belakang": nyala = layanan hidup tanpa overlay; mati = layanan berhenti bila overlay juga mati. */
    private fun applyBgMode(on: Boolean) {
        val i = Intent(this, OverlayService::class.java)
        if (on) { if (!OverlayService.alive) startForegroundService(i.setAction(OverlayService.ACTION_HIDE)) }
        else if (!OverlayService.overlayShown.value) stopService(i)
    }

    /** Suara notifikasi saat overlay dinyalakan (res/raw/overlay_on.m4a). Gagal memutar tidak boleh mengganggu overlay. */
    private fun playOverlaySound() {
        runCatching {
            val attrs = android.media.AudioAttributes.Builder()
                .setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            val mp = android.media.MediaPlayer.create(this, R.raw.overlay_on, attrs, android.media.AudioManager.AUDIO_SESSION_ID_GENERATE)
                ?: return
            mp.setOnCompletionListener { it.release() }
            mp.setOnErrorListener { p, _, _ -> p.release(); true }
            mp.start()
        }
    }

    @Composable
    fun Screen(s: Snap, tab: Int, setTab: (Int) -> Unit) {
        val titles = listOf("", "Statistik memori, suhu, CPU & RAM", "Rekam FPS dan lihat laporan", "Wallpaper dan warna overlay", "Gaya overlay")
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1A2038), Bg)))) {
            wallpaperBmp?.let { bmp ->
                Image(bmp.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                // makin gelap ke bawah supaya panel dan teks tetap terbaca
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
                    listOf(Bg.copy(alpha = dim * 0.35f), Bg.copy(alpha = dim)))))
                // Bayangan tipis di atas supaya judul tetap terbaca di wallpaper terang/putih
                Box(Modifier.fillMaxWidth().height(190.dp).background(Brush.verticalGradient(
                    listOf(Color.Black.copy(alpha = 0.6f), Color.Black.copy(alpha = 0.3f), Color.Transparent))))
            }
            // Kepala: judul + chip akses sebaris, subjudul satu baris di bawahnya (tinggi tetap supaya tidak loncat antar tab)
            Column(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 24.dp, vertical = 20.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Pulse Monitor", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold,
                        style = androidx.compose.ui.text.TextStyle(shadow = androidx.compose.ui.graphics.Shadow(Color.Black.copy(alpha = 0.6f), Offset(0f, 2f), 8f)), maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(12.dp))   // jarak judul dan chip akses
                    val ok = s.access != "-"
                    Row(Modifier.clip(RoundedCornerShape(50)).background(Color(0xB3101116))
                        .clickable(enabled = !ok) { Access.refresh(); accessDlg = true }.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(10.dp).background(if (ok) Color(0xFF7CFFB2) else Color(0xFFFF5C5C), CircleShape))
                        Text(if (ok) s.access else "Beri izin", color = if (ok) Color(0xFF7CFFB2) else Color(0xFFFF8A8A),
                            fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, modifier = Modifier.padding(start = 8.dp))
                    }
                }
                Box(Modifier.fillMaxWidth().height(22.dp).padding(top = 2.dp)) {
                    AnimatedContent(targetState = titles[tab], label = "subtitle",
                        transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(120)) }) { t ->
                        if (t.isNotEmpty()) Text(t, color = Color(0xFFE6E6EE), fontSize = 14.sp, style = androidx.compose.ui.text.TextStyle(shadow = androidx.compose.ui.graphics.Shadow(Color.Black.copy(alpha = 0.6f), Offset(0f, 2f), 8f)), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            if (accessDlg) AccessDialog { accessDlg = false }
            cropSrc?.let { src ->
                val dm = resources.displayMetrics
                // Notifikasi: rasio kartu diperluas (720x520). Latar aplikasi: rasio layar.
                val aspect = if (cropForNotif) 720f / 520f else dm.widthPixels.toFloat() / dm.heightPixels
                CropDialog(src, aspect, if (cropForNotif) "Potong gambar notifikasi" else "Potong wallpaper aplikasi",
                    onCancel = { cropSrc = null }) { cropped ->
                    cropSrc = null
                    Thread {
                        if (cropForNotif) {
                            if (WallpaperStore.saveNotifCropped(this@MainActivity, cropped)) {
                                notifOwn = true; AppSettings.notifWall = true; AppSettings.save(this@MainActivity)
                            }
                        } else if (WallpaperStore.saveCropped(this@MainActivity, cropped)) wallpaperBmp = WallpaperStore.load(this@MainActivity)
                    }.start()
                }
            }
            // Panel bawah + navigasi
            Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(Modifier.fillMaxWidth().background(Glass, RoundedCornerShape(32.dp)).padding(10.dp)) {
                    AnimatedContent(targetState = tab, label = "tab", transitionSpec = {
                        val dir = if (targetState > initialState) 1 else -1   // geser sesuai arah tab
                        (slideInHorizontally(tween(260)) { it / 4 * dir } + fadeIn(tween(260))) togetherWith
                            (slideOutHorizontally(tween(200)) { -it / 4 * dir } + fadeOut(tween(160))) using SizeTransform(clip = true)
                    }) { t ->
                    when (t) {
                        0 -> HomeTab(s)
                        1 -> Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(10.dp)) { StatsTab(s) }
                        2 -> Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(10.dp)) { RecordTab(s) }
                        3 -> Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(10.dp)) { DisplayTab(); ColorContent() }
                        else -> Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(10.dp)) { SettingsContent() }
                    }
                    }
                }
                Box(Modifier.fillMaxWidth().background(Glass, RoundedCornerShape(32.dp)).padding(8.dp)) {
                    BoxWithConstraints(Modifier.fillMaxWidth()) {
                        val w = maxWidth / 5
                        val pill by animateColorAsState(NavColors[tab].copy(alpha = 0.28f), tween(260), label = "navPillCol")
                        val x by animateDpAsState(w * tab, spring(dampingRatio = 0.75f, stiffness = Spring.StiffnessMediumLow), label = "navPill")
                        // pil penanda meluncur ke tab terpilih
                        Box(Modifier.matchParentSize()) {
                            Box(Modifier.offset(x = x).width(w).fillMaxHeight().background(pill, RoundedCornerShape(26.dp)))
                        }
                        Row(Modifier.fillMaxWidth()) {
                            NavItem("⌂", "Beranda", tab == 0, NavColors[0]) { setTab(0) }
                            NavItem("▤", "Statistik", tab == 1, NavColors[1]) { setTab(1) }
                            NavItem("●", "Rekaman", tab == 2, NavColors[2]) { setTab(2) }
                            NavItem("◐", "Tampilan", tab == 3, NavColors[3]) { setTab(3) }
                            NavItem("⚙", "Settings", tab == 4, NavColors[4]) { setTab(4) }
                        }
                    }
                }
            }
        }
    }

    /** Kartu Status CPU (di tab Statistik): frekuensi tiap inti (dua kolom) dan grafik beban CPU di dasar kartu. */
    @Composable
    private fun CpuCard(s: Snap) {
        val green = Color(0xFF9AA0A6)
        var tempDialog by remember { mutableStateOf(false) }
        if (tempDialog) CpuTempDialog(s) { tempDialog = false }
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Inner)) {
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Status CPU", color = Color(0xFFC4C6CE), fontSize = 17.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                Text(pct(s.cpu), color = loadColor(s.cpu), fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(end = 10.dp))
                Box(Modifier.size(34.dp).clip(CircleShape).background(Color(0x1FFFFFFF)).clickable { tempDialog = true }, contentAlignment = Alignment.Center) {
                    Text("⚙", color = Color.White, fontSize = 18.sp)
                }
            }
            val peak = remember { intArrayOf(0) }
            peak[0] = maxOf(peak[0], s.coreMhz.maxOrNull() ?: 0)
            if (s.coreMhz.isEmpty()) {
                Text("Frekuensi belum terbaca", color = Grey, fontSize = 13.sp, modifier = Modifier.padding(16.dp))
            } else Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                s.coreMhz.withIndex().toList().chunked(4).forEach { group ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        group.forEach { (i, mhz) ->
                            val frac = if (mhz > 0 && peak[0] > 0) (mhz.toFloat() / peak[0]).coerceIn(0.03f, 1f) else 0f
                            val barCol = if (frac >= 0.95f) Color(0xFFE6E8EB) else green
                            Column(Modifier.weight(1f).background(Color(0xFF101116), RoundedCornerShape(12.dp)).padding(horizontal = 8.dp, vertical = 7.dp)) {
                                Text("Inti $i", color = Grey, fontSize = 10.sp, maxLines = 1)
                                Text(if (mhz > 0) "$mhz MHz" else "Offline", color = if (mhz > 0) Color.White else Grey, fontSize = 12.sp, maxLines = 1, softWrap = false)
                                Box(Modifier.padding(top = 4.dp).fillMaxWidth().height(3.dp).background(Color(0xFF2A2D38), RoundedCornerShape(2.dp))) {
                                    Box(Modifier.fillMaxWidth(frac).height(3.dp).background(barCol, RoundedCornerShape(2.dp)))
                                }
                            }
                        }
                        repeat(4 - group.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
            CpuGraph(s.cpuHist, green, Modifier.fillMaxWidth().height(36.dp))
        }
    }

    /** Ketuk angka FPS atau grafik di Beranda: ganti warna aksen ke pilihan berikutnya (sama dengan pilihan di tab Tampilan, overlay ikut berubah). */
    private fun cycleAccent() {
        val a = AppSettings.ACCENTS
        AppSettings.accent = a[(a.indexOf(AppSettings.accent) + 1) % a.size]
        AppSettings.save(this)
    }

    @Composable
    private fun HomeTab(s: Snap) {
        var sensorDlg by remember { mutableStateOf(false) }
        if (sensorDlg) SensorDialog(s) { sensorDlg = false }
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // Satu kartu ringkas: status, FPS + frametime, grafik
            Column(Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(24.dp)).padding(horizontal = 16.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)) {
                // Status overlay (satu baris) + tombol sensor
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val sc = if (overlayOn) Color(0xFF5FD38D) else Grey
                    Box(Modifier.size(8.dp).background(sc, CircleShape))
                    Text(if (overlayOn) "Overlay aktif" else "Overlay mati", color = sc, fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 8.dp).weight(1f))
                    Box(Modifier.size(26.dp).clip(CircleShape).background(Color(0x1FFFFFFF)).clickable { sensorDlg = true }, contentAlignment = Alignment.Center) {
                        Text("⚙", color = Color.White, fontSize = 15.sp)
                    }
                }
                // FPS dan frametime berdampingan, tanpa kartu terpisah
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).clickable { cycleAccent() }) {
                        Text("FPS", color = Grey, fontSize = 13.sp)
                        Text("${s.fps}", color = acc(), fontSize = 36.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                        Text(if (s.idle) "Layar diam" else "Frame per detik", color = Grey, fontSize = 12.sp, maxLines = 1)
                    }
                    Box(Modifier.width(1.dp).height(44.dp).background(Color(0x1FFFFFFF)))
                    Column(Modifier.weight(1f).padding(start = 18.dp)) {
                        Text("Frametime", color = Grey, fontSize = 13.sp)
                        Text(if (s.ft > 0f) "%.1f ms".format(s.ft) else "-", color = Color.White, fontSize = 24.sp,
                            fontWeight = FontWeight.Bold, maxLines = 1)
                        Text("Makin kecil makin halus", color = Grey, fontSize = 12.sp, maxLines = 1)
                    }
                }
                FpsGraph(s.hist, Modifier.fillMaxWidth().height(36.dp).clip(RoundedCornerShape(8.dp)).clickable { cycleAccent() })
                Row(Modifier.fillMaxWidth()) {
                    Text("30 detik terakhir", color = Grey, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    Text("AVG ${if (s.avg > 0) s.avg else "-"}  ·  LOW ${if (s.low > 0) s.low else "-"}", color = Grey, fontSize = 12.sp)
                }
            }
            // Tombol utama + petunjuk singkat
            Box(Modifier.fillMaxWidth().height(46.dp).clip(RoundedCornerShape(23.dp))
                .background(Brush.horizontalGradient(if (overlayOn) listOf(Color(0xFFE5677A), Pink) else listOf(Color(0xFFA3A9B0), Color(0xFFD3D7DC))))
                .clickable { toggleOverlay() }, contentAlignment = Alignment.Center) {
                Text(if (overlayOn) "Matikan Overlay" else "Nyalakan Overlay", color = if (overlayOn) Color.White else Color(0xFF0C0C0E),
                    fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
    }

    /** Dialog di kartu grafik FPS (tab Beranda): sensor CPU/GPU/RAM/BAT, lalu info baterai, jaringan, RAM, dan penyimpanan. */
    @Composable
    private fun SensorDialog(s: Snap, onDismiss: () -> Unit) {
        val ctx = LocalContext.current
        val ex by produceState(Extras()) {
            while (true) {
                value = withContext(Dispatchers.IO) { DeviceExtras.read(ctx) }
                delay(2000)
            }
        }
        val green = Color(0xFFC4C6CE)
        val bat = ex.bat
        val net = ex.net
        val ram = s.mem?.let { SizeExtra(it.ramUsed, it.ramTotal) } ?: ex.ram
        val sto = ex.storage
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Color.Black,
            shape = RoundedCornerShape(28.dp),
            title = {
                Column {
                    Text("Info perangkat", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 22.sp)
                    Text("Baterai, jaringan, RAM, dan penyimpanan", color = Grey, fontSize = 13.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
                }
            },
            text = {
                Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        InfoTile("Baterai", Modifier.weight(1f).fillMaxHeight()) {
                            val t = if (bat.tempC >= 0f) bat.tempC else s.tBat
                            Text((if (bat.pct >= 0) "${bat.pct}%" else pct(s.batPct)) + if (t >= 0f) "  ${deg(t)}" else "",
                                color = green, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            Text(bat.state, color = Color.White, fontSize = 12.sp, maxLines = 1)
                            Text(bat.remain, color = Grey, fontSize = 12.sp, maxLines = 1)
                        }
                        InfoTile("Jaringan", Modifier.weight(1f).fillMaxHeight(), trailing = { SignalBars(net.sigPct, green) }) {
                            Text(net.type, color = green, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            Text(if (net.mbps > 0) "${net.mbps} Mbps" else "-", color = Color.White, fontSize = 12.sp, maxLines = 1)
                            Text(if (net.sigPct >= 0) "${net.sigPct}%   ${net.dbm} dBm" else "", color = Grey, fontSize = 12.sp, maxLines = 1)
                        }
                    }
                    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        InfoTile("RAM", Modifier.weight(1f).fillMaxHeight()) { DonutInfo(ram) }
                        InfoTile("Penyimpanan", Modifier.weight(1f).fillMaxHeight()) { DonutInfo(sto) }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text("Tutup", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
        )
    }

    @Composable
    private fun InfoTile(title: String, modifier: Modifier, trailing: (@Composable () -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
        Column(modifier.background(Color(0xFF101116), RoundedCornerShape(16.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = Color(0xFF9A9CA6), fontSize = 12.sp, modifier = Modifier.weight(1f))
                trailing?.invoke()
            }
            content()
        }
    }

    /** Ikon sinyal 4 batang; batang yang menyala mengikuti kekuatan sinyal (persen), sisanya redup. */
    @Composable
    private fun SignalBars(pct: Int, color: Color) {
        val lit = when {
            pct >= 80 -> 4
            pct >= 55 -> 3
            pct >= 30 -> 2
            pct >= 1 -> 1
            else -> 0
        }
        Canvas(Modifier.size(width = 20.dp, height = 16.dp)) {
            val n = 4
            val gap = 2.dp.toPx()
            val bw = (size.width - gap * (n - 1)) / n
            val r = androidx.compose.ui.geometry.CornerRadius(1.5.dp.toPx())
            for (i in 0 until n) {
                val h = size.height * (i + 1) / n
                drawRoundRect(
                    color = if (i < lit) color else color.copy(alpha = 0.25f),
                    topLeft = Offset(i * (bw + gap), size.height - h),
                    size = androidx.compose.ui.geometry.Size(bw, h),
                    cornerRadius = r
                )
            }
        }
    }

    /** Lingkaran persen di kiri, angka terpakai dan total di kanan. */
    @Composable
    private fun ColumnScope.DonutInfo(v: SizeExtra) {
        val p = v.pct
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.size(50.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val sw = 6.dp.toPx()
                    val tl = Offset(sw / 2, sw / 2)
                    val sz = androidx.compose.ui.geometry.Size(this.size.width - sw, this.size.height - sw)
                    drawArc(Color(0xFF2A2D38), 0f, 360f, false, topLeft = tl, size = sz, style = Stroke(sw))
                    if (p > 0) drawArc(Color(0xFF9A9CA6), -90f, 360f * p / 100f, false, topLeft = tl, size = sz, style = Stroke(sw, cap = StrokeCap.Round))
                }
                Text(if (p >= 0) "$p%" else "-", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.weight(1f)) {
                Text(if (v.usedGb >= 0f) "%.1f GB".format(v.usedGb) else "-", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(if (v.totalGb > 0f) "dari %.1f GB".format(v.totalGb) else "", color = Grey, fontSize = 11.sp, maxLines = 1)
            }
        }
    }

    private fun toggleRecord(s: Snap) {
        if (Recorder.active.value) {
            Thread {
                val r = Recorder.stop(this)
                runOnUiThread { Toast.makeText(this, if (r != null) "Rekaman tersimpan" else "Tidak ada data FPS yang terekam", Toast.LENGTH_SHORT).show() }
            }.start()
        } else {
            if (s.access == "-") { Toast.makeText(this, "Butuh Shizuku atau root untuk merekam", Toast.LENGTH_SHORT).show(); return }
            Sampler.onRecordStart()
            Recorder.start()
            if (!overlayOn) Toast.makeText(this, "Nyalakan overlay supaya rekaman tetap jalan saat kamu pindah ke game", Toast.LENGTH_LONG).show()
        }
    }

    private fun shareSummary(s: Session) {
        val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, Recorder.summary(s)) }
        startActivity(Intent.createChooser(i, "Bagikan laporan"))
    }

    @Composable
    private fun RecordTab(s: Snap) {
        val rec by Recorder.active.collectAsState()
        val n by Recorder.count.collectAsState()
        val ver by Recorder.version.collectAsState()
        var list by remember { mutableStateOf<List<Session>>(emptyList()) }
        LaunchedEffect(ver) { list = withContext(Dispatchers.IO) { Recorder.list(this@MainActivity) } }
        Column(Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(24.dp)).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (rec) {
                    val blink by rememberInfiniteTransition(label = "rec").animateFloat(1f, 0.25f,
                        infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "recDot")
                    Box(Modifier.padding(end = 12.dp).size(12.dp).graphicsLayer { alpha = blink }.background(Color(0xFFFF5C5C), CircleShape))
                }
                Column(Modifier.weight(1f)) {
                    Text(if (rec) "Merekam" else "Rekam FPS", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text(if (rec) "${s.fps} FPS saat ini" else "Tekan Mulai, lalu buka game.", color = Grey, fontSize = 12.sp)
                }
                if (rec) Text(fmtDur(n), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            }
            if (!rec) Text("Berhenti lewat tombol di notifikasi, atau tahan overlay sekitar 1 detik tanpa menggesernya.", color = Grey, fontSize = 12.sp)
            Box(Modifier.fillMaxWidth().height(46.dp).clip(RoundedCornerShape(23.dp))
                .background(Brush.horizontalGradient(if (rec) listOf(Color(0xFFE5677A), Pink) else listOf(Color(0xFFA3A9B0), Color(0xFFD3D7DC))))
                .clickable { toggleRecord(s) }, contentAlignment = Alignment.Center) {
                Text(if (rec) "Berhenti dan simpan" else "Mulai rekam", color = if (rec) Color.White else Color(0xFF0C0C0E), fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
        if (list.isEmpty()) {
            Column(Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(24.dp)).padding(horizontal = 16.dp, vertical = 22.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Belum ada rekaman", color = Color.White, fontWeight = FontWeight.Bold)
                Text("Hasil rekaman muncul di sini, lengkap dengan grafik dan laporan.", color = Grey, fontSize = 12.sp, textAlign = TextAlign.Center)
            }
        } else {
            SectionTitle("Riwayat · ${list.size}")
            list.forEach { r -> RecRow(r) { reportId = r.id } }
        }
    }

    @Composable
    private fun RecRow(r: Session, onClick: () -> Unit) {
        val st = remember(r.id) { r.stats() }
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Inner).clickable { onClick() }.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(r.label, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(fmtDate(r.id), color = Grey, fontSize = 12.sp, maxLines = 1)
            }
            Column(Modifier.padding(start = 12.dp), horizontalAlignment = Alignment.End) {
                Text(f1(st.avg), color = acc(), fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text("FPS  ·  ${fmtDur(r.dur)}", color = Grey, fontSize = 12.sp, maxLines = 1)
            }
            Text("›", color = Grey, fontSize = 22.sp, modifier = Modifier.padding(start = 10.dp))
        }
    }

    @Composable
    private fun ReportScreen(id: Long) {
        val sess by produceState<Session?>(null, id) { value = withContext(Dispatchers.IO) { Recorder.load(this@MainActivity, id) } }
        val ss = sess
        if (ss == null) {
            Box(Modifier.fillMaxSize().background(Color(0xFF101014)), contentAlignment = Alignment.Center) { Text("Memuat…", color = Grey) }
            return
        }
        ReportView(ss, onBack = { reportId = null }, onShare = { shareSummary(ss) },
            onCsv = {
                Thread {
                    val ok = Recorder.exportCsv(this, ss)
                    runOnUiThread { Toast.makeText(this, if (ok) "CSV tersimpan di folder Download" else "Gagal menyimpan CSV", Toast.LENGTH_SHORT).show() }
                }.start()
            },
            onDelete = { Recorder.delete(this, ss.id); reportId = null },
            onDesc = { t -> Thread { Recorder.saveDesc(this, ss, t) }.start() },
            wallpaper = wallpaperBmp, dim = dim)
    }

    @Composable
    private fun StatsTab(s: Snap) {
        var tools by remember { mutableStateOf(false) }
        if (tools) StatsToolsDialog(s) { tools = false }
        DeviceCard()
        if (s.access == "-") Text("Belum ada akses. Pilih Shizuku atau Root di tab Settings.", color = Color(0xFFE0B040), fontSize = 12.sp,
            modifier = Modifier.fillMaxWidth().background(Color(0x1FE0B040), RoundedCornerShape(16.dp)).padding(horizontal = 14.dp, vertical = 10.dp))
        // Kartu Memori: judul di kiri, tombol pengaturan (Probe GPU + Diagnostik) di kanan atas
        Column(Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(20.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Memori", color = Color.White, fontWeight = FontWeight.Bold)
                s.mem?.let { Text("${it.marketGb} GB", color = Grey, fontSize = 12.sp, modifier = Modifier.padding(start = 8.dp)) }
                Spacer(Modifier.weight(1f))
                Box(Modifier.size(34.dp).clip(CircleShape).background(Color(0x1FFFFFFF)).clickable { tools = true }, contentAlignment = Alignment.Center) {
                    Text("⚙", color = Color.White, fontSize = 18.sp)
                }
            }
            val m = s.mem
            if (m == null) {
                MeterRow("RAM", s.ramText, if (s.ramPct >= 0) s.ramPct / 100f else 0f, barLoad(s.ramPct))
                if (s.swapText.isNotEmpty()) MeterRow("Swap", s.swapText, usedFrac(s.swapText), Color(0xFFA78BFA))
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    MemBar("RAM", m.ramTotal, m.ramUsed, m.ramFree, barLoad(s.ramPct))
                    if (m.swapTotal > 0f) MemBar(if (m.zram) "ZRAM" else "Swap", m.swapTotal, m.swapUsed, m.swapFree, Color(0xFFA78BFA))
                    if (m.extraTotal > 0f) MemBar("Swap tambahan", m.extraTotal, m.extraUsed, (m.extraTotal - m.extraUsed).coerceAtLeast(0f), Color(0xFFA78BFA))
                }
            }
        }
        CpuCard(s)
    }

    /** Baca properti sistem lewat getprop (tanpa izin); kosong bila tidak ada. */
    private fun sysProp(key: String): String = try {
        val pr = Runtime.getRuntime().exec(arrayOf("getprop", key))
        pr.inputStream.bufferedReader().use { it.readText() }.trim()
    } catch (e: Exception) { "" }

    private fun androidName(sdk: Int) = when (sdk) {
        36 -> "Baklava"; 35 -> "Vanilla Ice Cream"; 34 -> "Upside Down Cake"; 33 -> "Tiramisu"
        32, 31 -> "Snow Cone"; 30 -> "Red Velvet Cake"; 29 -> "Quince Tart"; else -> ""
    }

    private fun fmtUptime(ms: Long): String {
        val t = ms / 1000
        return "%dj %dm %dd".format(t / 3600, (t % 3600) / 60, t % 60)
    }

    /** Kartu info perangkat: nama HP, chipset, versi Android, waktu aktif dan deep sleep (diperbarui tiap detik). */
    @Composable
    private fun DeviceCard() {
        val info by produceState(listOf("", "")) {
            value = withContext(Dispatchers.IO) {
                val market = sysProp("ro.product.marketname").ifEmpty { sysProp("ro.product.model") }.ifEmpty { Build.MODEL }
                val brand = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
                val name = if (market.startsWith(brand, true)) market else "$brand $market"
                val soc = if (Build.VERSION.SDK_INT >= 31 && Build.SOC_MODEL.isNotEmpty() && Build.SOC_MODEL != "unknown")
                    "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}".trim() else Build.HARDWARE
                listOf(name, soc)
            }
        }
        val up by produceState(0L to 0L) {
            while (true) {
                value = android.os.SystemClock.elapsedRealtime() to android.os.SystemClock.uptimeMillis()
                delay(1000)
            }
        }
        val awake = up.first; val sleep = (up.first - up.second).coerceAtLeast(0L)
        val sleepPct = if (awake > 0) (sleep * 100 / awake).toInt() else 0
        val an = androidName(Build.VERSION.SDK_INT)
        val isPoco = Build.BRAND.equals("poco", true)
        val badgeBg = if (isPoco) Color(0xFFFFD500) else Color(0xFF101116)
        val badgeFg = if (isPoco) Color.Black else Color.White
        val accent = Color(0xFF9AA0A6)
        val accentSoft = Color(0xFFD3D7DC)
        val shape = RoundedCornerShape(24.dp)
        @Composable fun Chip(text: String, tint: Color = Color(0x1FFFFFFF), fg: Color = Color(0xFFE6E8EB)) =
            Text(text, color = fg, fontSize = 11.5.sp, fontWeight = FontWeight.Medium, maxLines = 1,
                modifier = Modifier.background(tint, RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 4.dp))
        @Composable fun Tile(value: String, label: String, valueColor: Color = Color.White, mod: Modifier) =
            Column(mod.background(Color(0x14FFFFFF), RoundedCornerShape(16.dp)).padding(horizontal = 14.dp, vertical = 10.dp)) {
                Text(label, color = Grey, fontSize = 11.sp, maxLines = 1)
                Text(value, color = valueColor, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            }
        Column(
            Modifier.fillMaxWidth()
                .clip(shape)
                .background(Brush.linearGradient(listOf(Color(0xFF3A3D42), Color(0xFF17181B), Color(0xFF0A0B0C))), shape)
                .border(1.dp, Brush.linearGradient(listOf(accent.copy(alpha = 0.6f), Color(0x14FFFFFF))), shape)
                .padding(16.dp)
        ) {
            // Atas: lencana merek + nama HP + chip chipset / versi Android
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(56.dp).background(badgeBg, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
                    Text(Build.BRAND.uppercase(), color = badgeFg, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, maxLines = 1)
                }
                Column(Modifier.padding(start = 14.dp).weight(1f)) {
                    Text(info[0], color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (info[1].isNotEmpty()) Chip(info[1])
                        Chip(if (an.isNotEmpty()) "Android ${Build.VERSION.RELEASE} · $an" else "Android ${Build.VERSION.RELEASE}",
                            accent.copy(alpha = 0.22f), accentSoft)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            // Dua kotak ringkas: waktu aktif dan deep sleep
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Tile(fmtUptime(awake), "Waktu aktif", mod = Modifier.weight(1f))
                Tile(fmtUptime(sleep), "Deep sleep • $sleepPct%", valueColor = accentSoft, mod = Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
            // Bilah tipis: porsi deep sleep dari total waktu aktif
            Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(Color(0x1FFFFFFF))) {
                Box(Modifier.fillMaxWidth((sleepPct / 100f).coerceIn(0.02f, 1f)).fillMaxHeight()
                    .background(Brush.horizontalGradient(listOf(accent, accentSoft)), RoundedCornerShape(3.dp)))
            }
        }
    }

    /** Jalankan probe node GPU di thread terpisah lalu salin hasilnya ke clipboard. */
    private fun runGpuProbe() {
        Toast.makeText(this, "Membaca node GPU...", Toast.LENGTH_SHORT).show()
        Thread {
            val t = Sampler.gpuProbe()
            runOnUiThread {
                if (t.isBlank()) Toast.makeText(this, "Tidak ada hasil (butuh Shizuku/root)", Toast.LENGTH_SHORT).show()
                else {
                    val cm = getSystemService(android.content.ClipboardManager::class.java)
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("gpu-probe", t))
                    Toast.makeText(this, "Tersalin (${t.length} karakter). Tempel ke chat.", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    /** Dialog di kartu Status CPU: suhu CPU, GPU, dan baterai (dulunya kartu Suhu terpisah). */
    @Composable
    private fun CpuTempDialog(s: Snap, onDismiss: () -> Unit) {
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Color.Black,
            shape = RoundedCornerShape(28.dp),
            title = {
                Column {
                    Text("Suhu", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 22.sp)
                    Text("CPU, GPU, dan Baterai", color = Grey, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    TempMeter("CPU", s.tCpu); TempMeter("GPU", s.tGpu); TempMeter("Baterai", s.tBat)
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text("Tutup", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
        )
    }

    /** Dialog pengaturan di kartu Memori: Probe GPU sekarang bagian dari Diagnostik. */
    @Composable
    private fun StatsToolsDialog(s: Snap, onDismiss: () -> Unit) {
        var diag by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Color.Black,
            shape = RoundedCornerShape(28.dp),
            title = {
                Column {
                    Text("Pengaturan Statistik", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 22.sp)
                    Text("Probe GPU dan Diagnostik", color = Grey, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
                }
            },
            text = {
                Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SettingCard("Diagnostik") {
                        Text("Probe GPU membaca semua node GPU di HP ini dan menyalinnya ke clipboard, untuk mencari sumber frekuensi yang benar.", color = Grey, fontSize = 12.sp)
                        if (s.access != "-") PillButton("Probe GPU dan salin") { runGpuProbe() }
                        else Text("Probe GPU butuh akses Shizuku atau Root (tab Settings).", color = Color(0xFFE0B040), fontSize = 12.sp)
                        if (s.dbg.isNotEmpty()) {
                            PillButton(if (diag) "Sembunyikan" else "Tampilkan", filled = false) { diag = !diag }
                            if (diag) Text(s.dbg, color = Grey, fontSize = 10.5.sp, lineHeight = 15.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text("Tutup", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
        )
    }

    @Composable
    private fun DisplayTab() {
        val ctx = LocalContext.current
        SectionTitle("Tampilan aplikasi")
        SettingCard("Wallpaper") {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PillButton(if (wallpaperBmp == null) "Pilih gambar" else "Ganti gambar") {
                    pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
                if (wallpaperBmp != null) PillButton("Hapus", filled = false) { WallpaperStore.clear(this@MainActivity); wallpaperBmp = null }
            }
            if (wallpaperBmp != null) {
                SliderLabel("Redupkan latar", "${(dim * 100).toInt()}%")
                AccSlider(dim, 0.2f..0.9f, { dim = it }) { WallpaperStore.saveDim(this@MainActivity, dim) }
            } else Text("Belum ada gambar. Pilih satu untuk jadi latar aplikasi.", color = Grey, fontSize = 12.sp)
        }
        SettingCard("Wallpaper notifikasi") {
            val canUse = notifOwn || wallpaperBmp != null
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Pakai gambar di notifikasi baterai", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    Text(when {
                        notifOwn -> "Memakai gambar khusus notifikasi (terpisah dari wallpaper aplikasi). Tampil di notifikasi berikutnya."
                        wallpaperBmp != null -> "Belum ada gambar khusus, jadi memakai wallpaper aplikasi. Pilih gambar sendiri di bawah bila mau beda."
                        else -> "Pilih gambar khusus notifikasi di bawah."
                    }, color = Grey, fontSize = 12.sp)
                }
                Spacer(Modifier.width(12.dp))
                Switch(checked = AppSettings.notifWall && canUse, enabled = canUse,
                    onCheckedChange = { on -> AppSettings.notifWall = on; AppSettings.save(ctx) })
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PillButton(if (notifOwn) "Ganti gambar" else "Pilih gambar") {
                    pickNotifImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
                if (notifOwn) PillButton("Hapus", filled = false) {
                    WallpaperStore.clearNotif(this@MainActivity); notifOwn = false
                }
            }
            if (notifOwn) {
                SliderLabel("Redupkan gambar notifikasi", "${(notifDim * 100).toInt()}%")
                AccSlider(notifDim, 0f..0.9f, { notifDim = it }) { WallpaperStore.saveNotifDim(this@MainActivity, notifDim) }
            }
        }
        SettingCard("Transparan panel") {
            SliderLabel("Seberapa tembus panel dan navigasi", "${AppSettings.panelAlpha}%")
            AccSlider(AppSettings.panelAlpha / 100f, 0.15f..1f, { AppSettings.panelAlpha = (it * 100).toInt().coerceIn(15, 100) }) { AppSettings.save(ctx) }
            PillButton("Kembalikan bawaan", filled = false) { AppSettings.panelAlpha = AppSettings.DEF_PANEL; AppSettings.save(ctx) }
        }
        SectionTitle("Overlay")
    }

    /** Pratinjau gaya overlay: warna dan latar mengikuti pengaturan, label redup dan suhu berwarna seperti overlay aslinya. */
    private fun previewText(idx: Int): AnnotatedString {
        val ac = Color(AppSettings.accent); val tx = Color(AppSettings.overlayText); val mu = tx.copy(alpha = 0.65f)
        fun heatC(t: Float) = Color(heat(t))
        return buildAnnotatedString {
            fun p(t: String, c: Color = Color.Unspecified, b: Boolean = false) =
                withStyle(SpanStyle(color = c, fontWeight = if (b) FontWeight.Bold else null)) { append(t) }
            fun pd(t: String, n: Int) = t.padStart(n)
            p("FPS ", ac); if (idx == 0) p("60", b = true) else p(pd("60", 5), b = true)
            when (idx) {
                0 -> { p("  CPU 35% "); p("42°", heatC(42f)); p("  GPU 45% "); p("41°", heatC(41f)); p("  BAT 85%") }
                else -> {
                    p("  16.7 ms", mu); p("\n")
                    if (idx == 2) { p("AVG ", mu); p(pd("58", 5)); p("  "); p("LOW ", mu); p("45"); p("\n") }
                    p("CPU ", mu); p(pd("35%", 5)); p("  "); p(pd("42°", 4), heatC(42f)); p("  " + pd("1800 MHz", 8), mu); p("\n")
                    p("GPU ", mu); p(pd("45%", 5)); p("  "); p(pd("41°", 4), heatC(41f)); p("  " + pd("680 MHz", 8), mu); p("\n")
                    if (idx == 1) { p("RAM ", mu); p(pd("62%", 5)); p("  7.1 / 11 GB", mu); p("\n") }
                    else { p("RAM ", mu); p(pd("62%", 5)); p("  7.1 / 11 GB"); p("\n") }
                    p("BAT ", mu); p(pd("85%", 5)); p("  "); p(pd("36°", 4), heatC(36f))
                    if (idx == 1) p("  " + pd("2.4 W", 8), mu)
                    else { p("\n"); p("PWR ", mu); p(pd("2.4 W", 5)) }
                }
            }
        }
    }

    @Composable
    private fun StyleOption(idx: Int, title: String, sub: String, inDialog: Boolean = false, onPicked: () -> Unit = {}) {
        val ctx = LocalContext.current
        val sel = AppSettings.overlayStyle == idx
        val ac = acc()
        val border by animateColorAsState(if (sel) ac else Color(0x22FFFFFF), tween(200), label = "styBorder")
        val shape = RoundedCornerShape(20.dp)
        Column(Modifier.fillMaxWidth().clip(shape)
            .background(if (sel) ac.copy(alpha = 0.10f) else Color(0x12FFFFFF))
            .border(if (sel) 2.dp else 1.dp, border, shape)
            .clickable { AppSettings.overlayStyle = idx; AppSettings.save(ctx); onPicked() }.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(sub, color = Grey, fontSize = 12.sp)
                }
                Box(Modifier.size(24.dp).background(if (sel) ac else Color.Transparent, CircleShape)
                    .border(2.dp, if (sel) ac else Grey, CircleShape), contentAlignment = Alignment.Center) {
                    if (sel) Text("✓", color = Color(0xFF101014), fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
            val pv = RoundedCornerShape(if (idx == 0) 20.dp else 14.dp)
            Text(previewText(idx), color = Color(AppSettings.overlayText), fontSize = 10.5.sp, lineHeight = 15.sp,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, softWrap = idx != 0 || inDialog, maxLines = if (idx == 0 && !inDialog) 1 else Int.MAX_VALUE,
                modifier = Modifier.clip(pv).background(Color(withAlpha(AppSettings.overlayBg, AppSettings.alpha)))
                    .border(1.dp, Color(withAlpha(AppSettings.accent, 33)), pv)
                    .padding(horizontal = 12.dp, vertical = if (idx == 0) 6.dp else 9.dp))
        }
    }

    @Composable
    private fun SettingsContent() {
        val ctx = LocalContext.current
        val s by Sampler.state.collectAsState()
        // Setelah memilih metode, status mengikuti Access langsung (bukan menunggu tick Sampler)
        val auto = Access.choice == Access.AUTO
        val connected = if (auto) s.access != "-" else Access.status == 2
        val root = if (auto && connected) s.access == "Root" else Access.isRoot()
        SettingCard("Akses") {
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable { Access.refresh(); accessDlg = true }.padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).background(Color(0xFF0A0A1A), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                    if (root) ShieldIcon(Color(0xFFE49A72), Modifier.size(24.dp)) else PhoneIcon(Color(0xFF8E86F0), Modifier.size(24.dp))
                }
                Column(Modifier.weight(1f).padding(start = 14.dp)) {
                    Text(if (root) "Root" else "Shizuku", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text(when {
                        Access.busy > 0 -> "Memeriksa…"
                        connected -> "Terhubung"
                        Access.status == 1 -> "Ketuk untuk beri izin"
                        root -> "Root tidak tersedia"
                        else -> "Tidak berjalan"
                    }, color = if (connected) Color(0xFF5BD68E) else Color(0xFFE0B040), fontSize = 13.sp)
                }
                Text("›", color = Grey, fontSize = 22.sp)
            }
        }
        SettingCard("Latar belakang") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Tetap aktif di latar belakang", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    Text("Notifikasi baterai tetap hidup walau overlay dimatikan. Tanpa overlay dan tanpa pembacaan sensor, jadi ringan di RAM. Matikan saklar ini untuk menghapus notifikasi.",
                        color = Grey, fontSize = 12.sp)
                }
                Spacer(Modifier.width(12.dp))
                Switch(checked = AppSettings.bgMode, onCheckedChange = { on -> AppSettings.bgMode = on; AppSettings.save(ctx); applyBgMode(on) })
            }
        }
        SettingCard("Touch rate") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Tampilkan touch rate di overlay", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    Text("Angka Hz muncul saat layar disentuh, \"-\" saat tidak. Butuh Shizuku atau root.", color = Grey, fontSize = 12.sp)
                }
                Spacer(Modifier.width(12.dp))
                Switch(checked = AppSettings.touchRate, onCheckedChange = { on -> AppSettings.touchRate = on; AppSettings.save(ctx) })
            }
        }
        SettingCard("Latensi sentuh") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Tampilkan latensi sentuh di overlay", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    Text("Angka ms (terakhir dan rata-rata 20 ketukan) muncul tiap layar diketuk. Mengukur waktu dari driver sentuh sampai ke aplikasi, di luar waktu render layar. Tidak butuh Shizuku atau root.", color = Grey, fontSize = 12.sp)
                }
                Spacer(Modifier.width(12.dp))
                Switch(checked = AppSettings.touchLat, onCheckedChange = { on -> AppSettings.touchLat = on; if (!on) TouchLatency.reset(); AppSettings.save(ctx) })
            }
        }
        // Satu baris: nama gaya yang aktif tampil di samping, ketuk untuk memilih gaya lain
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Inner).clickable { styleDlg = true }.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Gaya overlay", color = Color.White, fontWeight = FontWeight.Bold)
                Text("Ketuk untuk memilih bentuk overlay", color = Grey, fontSize = 12.sp)
            }
            Text(AppSettings.STYLES[AppSettings.overlayStyle], color = acc(), fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text("  ›", color = Grey, fontSize = 22.sp)
        }
        if (styleDlg) StyleDialog { styleDlg = false }
    }

    @Composable
    private fun StyleDialog(onDismiss: () -> Unit) {
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Color.Black,
            shape = RoundedCornerShape(28.dp),
            title = { Text("Gaya overlay", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 24.sp) },
            text = {
                Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Pratinjau mengikuti warna dan transparansi di tab Tampilan.", color = Color(0xFFA9B0B5), fontSize = 13.sp)
                    StyleOption(0, "Simple", "Satu baris: FPS, CPU, GPU, baterai", inDialog = true, onPicked = onDismiss)
                    StyleOption(1, "Compact", "Kartu kecil per komponen, dengan frekuensi", inDialog = true, onPicked = onDismiss)
                    StyleOption(2, "Normal", "Paling lengkap: rata-rata, low, RAM, daya, game", inDialog = true, onPicked = onDismiss)
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text("Batal", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
        )
    }

    @Composable
    private fun AccessDialog(onDismiss: () -> Unit) {
        val cur = Access.choice
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Color.Black,
            shape = RoundedCornerShape(28.dp),
            title = { Text("Izinkan Akses", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 24.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Pilih metode yang ingin dipakai untuk akses tingkat tinggi.", color = Color(0xFFA9B0B5))
                    AccessOption("Shizuku", "Tanpa root, jalan lewat Wireless Debugging atau ADB.",
                        Color(0xFF8E86F0), Color(0xFF13111F), cur == Access.SHIZUKU, { PhoneIcon(Color(0xFF8E86F0), Modifier.size(30.dp)) }) {
                        Access.select(Access.SHIZUKU); onDismiss()
                    }
                    AccessOption("Root", "Butuh perangkat yang di-root (Magisk, KernelSU, APatch, dll).",
                        Color(0xFFE49A72), Color(0xFF181412), cur == Access.ROOT, { ShieldIcon(Color(0xFFE49A72), Modifier.size(30.dp)) }) {
                        Access.select(Access.ROOT); onDismiss()
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text("Batal", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
        )
    }

    /** Warna overlay (bagian bawah tab Tampilan). */
    @Composable
    private fun ColorContent() {
        val ctx = LocalContext.current
        SettingCard("Ukuran overlay") {
            SliderLabel("Besar kecil", "${AppSettings.size}%")
            AccSlider(AppSettings.size / 100f, 0.6f..2f, { AppSettings.size = ((it * 100).toInt() / 5 * 5).coerceIn(60, 200) }) { AppSettings.save(ctx) }
            PillButton("Ukuran normal", filled = false) { AppSettings.size = AppSettings.DEF_SIZE; AppSettings.save(ctx) }
        }
        var accentDlg by remember { mutableStateOf(false) }
        if (accentDlg) AlertDialog(
            onDismissRequest = { accentDlg = false },
            containerColor = Color.Black,
            shape = RoundedCornerShape(28.dp),
            title = { Text("Warna aksen", color = Color(0xFFEDEFF1), fontWeight = FontWeight.SemiBold, fontSize = 22.sp) },
            text = { Swatches(AppSettings.ACCENTS, AppSettings.accent) { AppSettings.accent = it; AppSettings.save(ctx) } },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { accentDlg = false }) { Text("Selesai", color = Color(0xFF8E86F0), fontWeight = FontWeight.Medium, fontSize = 17.sp) } }
        )
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Inner).clickable { accentDlg = true }.padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text("Warna aksen", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Box(Modifier.size(28.dp).background(Color(AppSettings.accent), CircleShape).border(1.dp, Color(0x33FFFFFF), CircleShape))
        }
        SettingCard("Warna teks overlay") {
            Swatches(AppSettings.TEXTS, AppSettings.overlayText) { AppSettings.overlayText = it; AppSettings.save(ctx) }
        }
        SettingCard("Latar overlay") {
            Swatches(AppSettings.BGS, AppSettings.overlayBg) { AppSettings.overlayBg = it; AppSettings.save(ctx) }
            SliderLabel("Transparan", "${AppSettings.alpha}%")
            AccSlider(AppSettings.alpha / 100f, 0.2f..1f, { AppSettings.alpha = (it * 100).toInt().coerceIn(20, 100) }) { AppSettings.save(ctx) }
        }
        SettingCard("Warna suhu") {
            Text("Berubah sesuai tingkat panas", color = Grey, fontSize = 12.sp)
            HeatLegend(30f, "Aman, di bawah 45°"); HeatLegend(50f, "Hangat, 45-54°")
            HeatLegend(60f, "Panas, 55-64°"); HeatLegend(70f, "Sangat panas, 65°+")
        }
        Text("Perubahan warna overlay muncul dalam sekitar 1 detik.", color = Grey, fontSize = 12.sp)
        PillButton("Kembalikan warna awal", filled = false, modifier = Modifier.fillMaxWidth()) { AppSettings.reset(ctx) }
    }
}

@Composable
fun AccessOption(title: String, desc: String, accent: Color, bg: Color, selected: Boolean, icon: @Composable () -> Unit, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(bg)
        .border(if (selected) 2.dp else 1.dp, accent.copy(alpha = if (selected) 0.85f else 0.35f), RoundedCornerShape(20.dp))
        .clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        icon(); Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = accent, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Text(desc, color = Color(0xFFC4CACE), fontSize = 14.sp)
        }
    }
}

/** Ikon ponsel (Shizuku) dan perisai (Root), digambar langsung supaya tidak perlu pustaka ikon tambahan. */
@Composable
fun PhoneIcon(c: Color, m: Modifier) = Canvas(m) {
    val w = size.width * 0.55f; val h = size.height * 0.9f
    drawRoundRect(c, androidx.compose.ui.geometry.Offset((size.width - w) / 2, (size.height - h) / 2),
        androidx.compose.ui.geometry.Size(w, h), androidx.compose.ui.geometry.CornerRadius(size.width * 0.1f))
}

@Composable
fun ShieldIcon(c: Color, m: Modifier) = Canvas(m) {
    val w = size.width; val h = size.height
    val p = Path().apply {
        moveTo(w * 0.5f, h * 0.04f); lineTo(w * 0.92f, h * 0.2f); lineTo(w * 0.92f, h * 0.5f)
        cubicTo(w * 0.92f, h * 0.76f, w * 0.7f, h * 0.92f, w * 0.5f, h * 0.98f)
        cubicTo(w * 0.3f, h * 0.92f, w * 0.08f, h * 0.76f, w * 0.08f, h * 0.5f)
        lineTo(w * 0.08f, h * 0.2f); close()
    }
    drawPath(p, c)
}

@Composable
fun RowScope.NavItem(icon: String, label: String, selected: Boolean, color: Color, onClick: () -> Unit) {
    val col by animateColorAsState(if (selected) color else Grey, tween(220), label = "navCol")
    val sc by animateFloatAsState(if (selected) 1.15f else 1f, spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMedium), label = "navScale")
    Column(Modifier.weight(1f).clip(RoundedCornerShape(26.dp))
        .clickable { onClick() }.padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text(icon, color = col, fontSize = 22.sp, modifier = Modifier.graphicsLayer { scaleX = sc; scaleY = sc })
        Text(label, color = col, fontSize = 11.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

@Composable
fun BigCard(title: String, value: String, sub: String, selected: Boolean, m: Modifier) {
    val shape = RoundedCornerShape(24.dp)
    Column(m.background(Inner, shape)
        .then(if (selected) Modifier.border(1.5.dp, acc().copy(alpha = 0.85f), shape) else Modifier)
        .padding(horizontal = 16.dp, vertical = 10.dp)) {
        Text(title, color = Grey, fontSize = 13.sp)
        Text(value, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
        Text(sub, color = Grey, fontSize = 12.sp, maxLines = 1)
    }
}

/** Warna beban: hijau normal, kuning mulai berat, merah hampir penuh. */
fun loadColor(p: Int): Color = when {
    p < 0 -> Color.White
    p < 60 -> Color.White
    p < 85 -> Color(0xFFFFD866)
    else -> Color(0xFFFF6B6B)
}

@Composable
fun RowScope.MetricDivider() = Box(Modifier.width(1.dp).height(34.dp).background(Color(0x1FFFFFFF)))

@Composable
fun RowScope.Metric(label: String, main: String, sub: String, subTemp: Float, mainTemp: Float = -1f, mainColor: Color? = null) {
    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = Grey, fontSize = 12.sp)
        Text(main, color = mainColor ?: if (mainTemp >= 0) Color(heat(mainTemp)) else Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        if (sub.isNotEmpty()) Text(sub, color = if (subTemp >= 0) Color(heat(subTemp)) else Grey, fontSize = 13.sp, textAlign = TextAlign.Center)
    }
}

@Composable
fun InfoRow(label: String, value: String, t: Float? = null) {
    Row(Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(20.dp)).padding(horizontal = 18.dp, vertical = 14.dp)) {
        Text(label, color = Grey, modifier = Modifier.weight(1f))
        Text(value, color = if (t != null && t >= 0) Color(heat(t)) else Color.White, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SettingCard(title: String, content: @Composable ColumnScope.() -> Unit) = Column(
    Modifier.fillMaxWidth().background(Inner, RoundedCornerShape(20.dp)).padding(16.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
) { Text(title, color = Color.White, fontWeight = FontWeight.Bold); content() }

@Composable
fun Swatches(colors: List<Int>, selected: Int, onPick: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        colors.forEach { c ->
            val on = c == selected
            Box(Modifier.size(38.dp).background(Color(c), CircleShape)
                .border(if (on) 2.5.dp else 1.dp, if (on) Color.White else Color(0x33FFFFFF), CircleShape)
                .clickable { onPick(c) }, contentAlignment = Alignment.Center) {
                if (on) Text("✓", color = if (Color(c).luminance() > 0.5f) Color(0xFF101014) else Color.White, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

@Composable
fun SectionTitle(t: String) = Text(t, color = Grey, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 6.dp, top = 4.dp))

@Composable
fun SliderLabel(label: String, value: String) = Row(Modifier.fillMaxWidth()) {
    Text(label, color = Grey, fontSize = 12.sp, modifier = Modifier.weight(1f))
    Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
}

@Composable
fun AccSlider(value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit, onDone: () -> Unit) {
    Slider(value = value, onValueChange = onChange, valueRange = range, onValueChangeFinished = onDone,
        colors = SliderDefaults.colors(thumbColor = acc(), activeTrackColor = acc(), inactiveTrackColor = Color(0x22FFFFFF)))
}

/** Tombol seragam: terisi (aksi utama) atau garis tepi (aksi sekunder). */
@Composable
fun PillButton(text: String, filled: Boolean = true, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(modifier.clip(shape)
        .then(if (filled) Modifier.background(Blue) else Modifier.border(1.dp, Color(0x33FFFFFF), shape))
        .clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 10.dp), contentAlignment = Alignment.Center) {
        Text(text, color = if (filled) Color(0xFF0C0C0E) else Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** Baris ukuran dengan batang: label + nilai di atas, batang tipis di bawah. */
@Composable
fun MeterRow(label: String, value: String, frac: Float, color: Color, valueColor: Color = Color.White) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Grey, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text(value, color = valueColor, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
        Box(Modifier.fillMaxWidth().height(5.dp).background(Color(0x1FFFFFFF), CircleShape)) {
            Box(Modifier.fillMaxWidth(frac.coerceIn(0f, 1f)).fillMaxHeight().background(color, CircleShape))
        }
    }
}

/** Blok memori: nama + total di atas, terpakai + bebas di tengah, batang di bawah. */
/** Batang ringkas: label + "terpakai / total GB", batang tebal terisi sesuai pemakaian, legenda Terpakai % dan Bebas GB. */
@Composable
fun MemBar(label: String, total: Float, used: Float, free: Float, color: Color) {
    val frac = if (total > 0f) (used / total).coerceIn(0f, 1f) else 0f
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text(buildAnnotatedString {
                withStyle(SpanStyle(color = Color.White, fontWeight = FontWeight.Medium)) { append("%.2f".format(used)) }
                append(" / %.2f GB".format(total))
            }, color = Grey, fontSize = 13.sp)
        }
        Box(Modifier.padding(top = 6.dp).fillMaxWidth().height(14.dp).clip(RoundedCornerShape(7.dp)).background(Color(0x2EFFFFFF))) {
            if (frac > 0f) Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(color))
        }
        Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).background(color, CircleShape))
                Text("Terpakai ${Math.round(frac * 100)}%", color = Grey, fontSize = 11.sp, modifier = Modifier.padding(start = 5.dp))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).background(Color(0x2EFFFFFF), CircleShape))
                Text("Bebas %.2f GB".format(free), color = Grey, fontSize = 11.sp, modifier = Modifier.padding(start = 5.dp))
            }
        }
    }
}

@Composable
fun MemBlock(label: String, total: Float, used: Float, free: Float, color: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f))
            Text("%.2f GB total".format(total), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("%.2f GB digunakan".format(used), color = Grey, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text("%.2f GB Bebas".format(free), color = Grey, fontSize = 12.sp)
        }
        Spacer(Modifier.height(2.dp))
        Box(Modifier.fillMaxWidth().height(8.dp).background(Color(0x1FFFFFFF), CircleShape)) {
            Box(Modifier.fillMaxWidth(if (total > 0f) (used / total).coerceIn(0f, 1f) else 0f).fillMaxHeight().background(color, CircleShape))
        }
    }
}

@Composable
fun TempMeter(label: String, t: Float) {
    if (t < 0f) { MeterRow(label, "-", 0f, Grey); return }
    val word = when { t < 45f -> "Aman"; t < 55f -> "Hangat"; t < 65f -> "Panas"; else -> "Sangat panas" }
    MeterRow(label, "${deg(t)}  $word", (t - 20f) / 70f, Color(heat(t)), Color(heat(t)))
}

/** Warna batang beban: aksen saat normal, kuning mulai berat, merah hampir penuh. */
@Composable
fun barLoad(p: Int): Color = when { p < 60 -> acc(); p < 85 -> Color(0xFFFFD866); else -> Color(0xFFFF6B6B) }

private fun usedFrac(txt: String): Float {
    val n = Regex("[0-9]+[.,]?[0-9]*").findAll(txt).map { it.value.replace(',', '.').toFloatOrNull() ?: 0f }.toList()
    return if (n.size >= 2 && n[1] > 0f) n[0] / n[1] else 0f
}

@Composable
fun HeatLegend(t: Float, label: String) = Row(verticalAlignment = Alignment.CenterVertically) {
    Box(Modifier.size(12.dp).background(Color(heat(t)), CircleShape))
    Text(label, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(start = 10.dp))
}

/** Grafik FPS: garis halus + isi tipis, skala 0..maks (kelipatan 10, minimal 30), garis bantu tipis, titik di nilai terakhir. */
/** Grafik area beban CPU 0..100%, menempel di dasar kartu. */
@Composable
fun CpuGraph(h: List<Int>, col: Color, m: Modifier) {
    Canvas(m) {
        if (h.size < 2) return@Canvas
        val stepX = size.width / (h.size - 1)
        fun py(v: Int) = size.height * (1f - 0.12f - 0.78f * v.coerceIn(0, 100) / 100f)
        val fill = Path(); fill.moveTo(0f, size.height); fill.lineTo(0f, py(h[0]))
        for (i in 1 until h.size) {
            val x0 = (i - 1) * stepX; val y0 = py(h[i - 1]); val x1 = i * stepX; val y1 = py(h[i])
            fill.quadraticBezierTo(x0, y0, (x0 + x1) / 2f, (y0 + y1) / 2f)
            if (i == h.size - 1) fill.lineTo(x1, y1)
        }
        fill.lineTo(size.width, size.height); fill.close()
        drawPath(fill, col.copy(alpha = 0.35f))
    }
}

@Composable
fun FpsGraph(h: List<Int>, m: Modifier) {
    val col = acc()
    Canvas(m) {
        val guide = Color(0x1AFFFFFF)
        for (i in 0..2) { val y = size.height * i / 2f; drawLine(guide, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f) }
        if (h.size < 2) return@Canvas
        val pad = 4.dp.toPx()
        val mx = (kotlin.math.ceil(maxOf(h.maxOrNull() ?: 30, 30) / 10f) * 10f)
        val stepX = size.width / (h.size - 1)
        fun px(i: Int) = i * stepX
        fun py(v: Int) = pad + (size.height - 2 * pad) * (1f - v / mx)
        val line = Path(); val fill = Path()
        line.moveTo(px(0), py(h[0])); fill.moveTo(px(0), size.height); fill.lineTo(px(0), py(h[0]))
        for (i in 1 until h.size) {
            // kurva halus lewat titik tengah antar sampel
            val x0 = px(i - 1); val y0 = py(h[i - 1]); val x1 = px(i); val y1 = py(h[i])
            val mxp = (x0 + x1) / 2f; val myp = (y0 + y1) / 2f
            line.quadraticBezierTo(x0, y0, mxp, myp); fill.quadraticBezierTo(x0, y0, mxp, myp)
            if (i == h.size - 1) { line.lineTo(x1, y1); fill.lineTo(x1, y1) }
        }
        fill.lineTo(size.width, size.height); fill.close()
        drawPath(fill, col.copy(alpha = 0.14f))
        drawPath(line, col, style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawCircle(col, 4.dp.toPx(), Offset(px(h.size - 1), py(h.last())))
    }
}

@Composable
fun Stat(l: String, v: String) = Column { Text(l, color = Grey, fontSize = 11.sp); Text(v, color = Color.White, fontSize = 19.sp) }
