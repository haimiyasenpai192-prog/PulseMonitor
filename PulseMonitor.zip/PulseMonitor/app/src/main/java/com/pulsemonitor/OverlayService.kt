package com.pulsemonitor

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import kotlinx.coroutines.*

class OverlayService : Service() {
    private var tv: TextView? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("ov", "Overlay", NotificationManager.IMPORTANCE_LOW))
        val notif = Notification.Builder(this, "ov").setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("PulseMonitor: overlay aktif").build()
        // Tipe specialUse baru ada di API 34; di bawahnya pakai versi 2 argumen
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, notif)
        // Izin overlay bisa dicabut kapan saja; addView akan crash tanpa pengecekan ini
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (tv == null) {
            Sampler.init(this); Sampler.start()
            val v = TextView(this).apply {
                setTextColor(0xFF3DF0FF.toInt()); setBackgroundColor(0xAA0C0C0E.toInt())
                typeface = Typeface.MONOSPACE; textSize = 13f; setPadding(20, 12, 20, 12)
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 80 }
            val ok = runCatching { getSystemService(WindowManager::class.java).addView(v, lp) }.isSuccess
            if (!ok) { stopSelf(); return START_NOT_STICKY }
            tv = v
            scope.launch {
                Sampler.state.collect { s ->
                    v.text = "${s.fps} FPS\nCPU ${pct(s.cpu)}  GPU ${pct(s.gpu)}\nBAT ${deg(s.tBat)}  CPU ${deg(s.tCpu)}  GPU ${deg(s.tGpu)}"
                }
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        scope.cancel(); tv?.let { v -> runCatching { getSystemService(WindowManager::class.java).removeView(v) } }; tv = null
        super.onDestroy()
    }
}
fun deg(v: Float) = if (v >= 0) "%.0f°".format(v) else "-"
fun pct(v: Int) = if (v >= 0) "$v%" else "-"
